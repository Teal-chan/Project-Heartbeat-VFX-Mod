# copy_vfx.gd - VFX Toolbox tool: copy a note's VFX bundle to the clipboard
# Place in: user://editor_scripts/Utilities/copy_vfx.gd
#
# Run by the "Copy VFX" button in the Utilities tab → VFX Actions.
# Grabs every effect row sitting on the first selected note and stashes it in the
# session clipboard, ready for Paste VFX to stamp onto other notes.

extends RefCounted

const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")


func run(editor) -> void:
	var res := VFXUtils.copy_vfx_from_selection(editor)

	if not res.get("ok", false):
		VFXUtils.show_notification(editor, "📋 Select a note to copy VFX from.")
		return

	if int(res["count"]) == 0:
		VFXUtils.show_notification(editor, "📋 That note has no VFX to copy.")
		return

	var msg := "📋 Copied %d VFX row(s) from %s." % [int(res["count"]), res["source_label"]]
	if int(res.get("extra_selected", 0)) > 0:
		msg += "  (Multiple selected — copied from the first.)"
	VFXUtils.show_notification(editor, msg)
