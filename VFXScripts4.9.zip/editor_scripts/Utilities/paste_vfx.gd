# paste_vfx.gd - VFX Toolbox tool: paste the copied VFX bundle onto selected notes
# Place in: user://editor_scripts/Utilities/paste_vfx.gd
#
# Run by the "Paste VFX" button in the Utilities tab → VFX Actions.
# Stamps the clipboard bundle onto every selected target note, preserving each
# row's timing offset and retargeting layer/note_type. Surgical: on each target it
# overwrites only the effect TYPES the clipboard contains, leaving other effects.
# Committed through the editor's undo system, so a single Undo reverts the paste.

extends RefCounted

const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")


func run(editor) -> void:
	if not VFXUtils.has_vfx_clipboard():
		VFXUtils.show_notification(editor, "📋 Clipboard empty — use Copy VFX on a note first.")
		return

	var res := VFXUtils.build_pasted_rows(editor)
	if not res.get("ok", false):
		if String(res.get("reason", "")) == "no_target":
			VFXUtils.show_notification(editor, "📋 Select the note(s) to paste onto.")
		else:
			VFXUtils.show_notification(editor, "📋 Nothing to paste.")
		return

	# Commit through the editor's undo/redo so one Undo reverts the whole paste.
	var action = VFXUndoRedo.begin_action(editor, "Paste VFX")
	action.capture_before_state({}, "PASTE")
	action.set_new_rows(res["rows"])
	action.commit()

	VFXUtils.show_notification(editor, "✨ Pasted onto %d note(s): +%d added, %d replaced." % [
		int(res["targets"]), int(res["added"]), int(res["replaced"])
	])
