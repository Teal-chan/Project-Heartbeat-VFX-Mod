extends HBEditorModule
class_name OffsetVfxModule

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED UTILITIES - Preload the shared helper library
# ═══════════════════════════════════════════════════════════════════════════════
const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")

const ANIM_TAG := "PosOffsetAnim/v1"

const EASE_OPTIONS := [
	"linear",
	"hold",
	"step",
	"in_out_quad",
	"in_out_cubic",
	"out_elastic"
]

const RAND_START_MIN := -1000.0
const RAND_START_MAX := 1000.0

# ── Direction pad presets ───────────────────────────────────────
const DIAG := 0.70710678 # 1/sqrt(2): keeps diagonal travel the same length as the cardinals
# Screen space is +Y DOWN, so the table below treats "up" as -Y.
# If Up and Down come out inverted when you test in the editor, set this to -1.0.
const PAD_Y_SIGN := 1.0
const PAD_DIST_SHORT  := 60.0
const PAD_DIST_MEDIUM := 150.0
const PAD_DIST_LONG   := 300.0


# ── UI refs ─────────────────────────────────────────────────────
var le_t0 : LineEdit
var le_t1 : LineEdit

var le_sx : LineEdit
var le_sy : LineEdit
var le_ex : LineEdit
var le_ey : LineEdit

var cb_head   : CheckBox
var cb_tail   : CheckBox
var cb_target : CheckBox
var cb_hold   : CheckBox
var cb_rush_text : CheckBox
var cb_rush_icon : CheckBox

var dd_ease   : OptionButton
var dd_pad_dist : OptionButton

# SVG Icon cache
var ICON_OFF_APPLY  : Texture2D = null
var ICON_OFF_RESET  : Texture2D = null
var ICON_OFF_SCATTER: Texture2D = null


# ───────────────────────────────────────────────────────────────
# Lifecycle
# ───────────────────────────────────────────────────────────────

func _ready() -> void:
	super._ready()
	_build_ui()

func _build_ui() -> void:
	# Scroll root so we don't spill into the timeline
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.anchor_left = 0.0
	scroll.anchor_top = 0.0
	scroll.anchor_right = 1.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = 0
	scroll.offset_top = 0
	scroll.offset_right = 0
	scroll.offset_bottom = 0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	add_child(scroll)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(root)

	# ── Timing ─────────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Timing (relative to note hit time)"))

	var grid_t := GridContainer.new()
	grid_t.columns = 2
	grid_t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_t)

	grid_t.add_child(VFXUtils.mk_label("Start offset (ms rel. to hit):"))
	le_t0 = LineEdit.new()
	le_t0.text = "-120" # modest pre-hit default
	le_t0.custom_minimum_size.x = 80
	grid_t.add_child(le_t0)

	grid_t.add_child(VFXUtils.mk_label("End/Hold End offset (ms, can be ≥ 0):"))
	le_t1 = LineEdit.new()
	le_t1.text = "0" # at-hit by default
	le_t1.custom_minimum_size.x = 80
	grid_t.add_child(le_t1)

	# ── Offsets ────────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Offsets (GL / playfield-local units)"))

	var grid_o := GridContainer.new()
	grid_o.columns = 2
	grid_o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_o)

	grid_o.add_child(VFXUtils.mk_label("Start X:"))
	le_sx = LineEdit.new()
	le_sx.text = "0"
	le_sx.custom_minimum_size.x = 80
	grid_o.add_child(le_sx)

	grid_o.add_child(VFXUtils.mk_label("Start Y:"))
	le_sy = LineEdit.new()
	le_sy.text = "0"
	le_sy.custom_minimum_size.x = 80
	grid_o.add_child(le_sy)

	grid_o.add_child(VFXUtils.mk_label("End X:"))
	le_ex = LineEdit.new()
	le_ex.text = "0"
	le_ex.custom_minimum_size.x = 80
	grid_o.add_child(le_ex)

	grid_o.add_child(VFXUtils.mk_label("End Y:"))
	le_ey = LineEdit.new()
	le_ey.text = "-60"
	le_ey.custom_minimum_size.x = 80
	grid_o.add_child(le_ey)

	# ── Direction pad (fills the start offset; note flies home to 0,0) ──
	root.add_child(VFXUtils.mk_section_label("Direction pad (start offset → home)"))

	var row_dist := HBoxContainer.new()
	row_dist.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_dist)
	row_dist.add_child(VFXUtils.mk_label("Distance:"))
	dd_pad_dist = OptionButton.new()
	dd_pad_dist.add_item("Short", 0)
	dd_pad_dist.add_item("Medium", 1)
	dd_pad_dist.add_item("Long", 2)
	dd_pad_dist.select(1) # Medium by default
	row_dist.add_child(dd_pad_dist)
	row_dist.add_child(VFXUtils.mk_spacer())

	var pad_row := HBoxContainer.new()
	pad_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pad_row.alignment = BoxContainer.ALIGNMENT_CENTER
	root.add_child(pad_row)
	_build_direction_pad(pad_row)

	# ── Parts toggles ─────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Apply to parts"))

	var row_parts := HBoxContainer.new()
	row_parts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_parts)

	cb_head = CheckBox.new()
	cb_head.text = "Head"
	cb_head.button_pressed = true
	row_parts.add_child(cb_head)

	cb_tail = CheckBox.new()
	cb_tail.text = "Tail"
	cb_tail.button_pressed = true
	row_parts.add_child(cb_tail)

	cb_target = CheckBox.new()
	cb_target.text = "Target"
	cb_target.button_pressed = true
	row_parts.add_child(cb_target)

	cb_hold = CheckBox.new()
	cb_hold.text = "Hold text"
	cb_hold.button_pressed = true
	row_parts.add_child(cb_hold)

	cb_rush_text = CheckBox.new()
	cb_rush_text.text = "Rush Text"
	cb_rush_text.button_pressed = true
	row_parts.add_child(cb_rush_text)

	cb_rush_icon = CheckBox.new()
	cb_rush_icon.text = "Rush Icon"
	cb_rush_icon.button_pressed = true
	row_parts.add_child(cb_rush_icon)

	row_parts.add_child(VFXUtils.mk_spacer())

	# ── Easing ────────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Easing"))

	var row_e := HBoxContainer.new()
	row_e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_e)

	row_e.add_child(VFXUtils.mk_label("Ease:"))
	dd_ease = OptionButton.new()
	for i in range(EASE_OPTIONS.size()):
		dd_ease.add_item(EASE_OPTIONS[i], i)
	dd_ease.select(0) # linear
	row_e.add_child(dd_ease)
	row_e.add_child(VFXUtils.mk_spacer())

	# ── Load SVG icons (128px, 1024-safe) ─────────────────────
	if ICON_OFF_APPLY == null:
		ICON_OFF_APPLY = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/offset_apply.svg", 128)
		if ICON_OFF_APPLY == null:
			ICON_OFF_APPLY = preload("res://graphics/icons/console-line.svg")

	if ICON_OFF_RESET == null:
		ICON_OFF_RESET = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/offset_reset.svg", 128)
		if ICON_OFF_RESET == null:
			ICON_OFF_RESET = preload("res://graphics/icons/console-line.svg")

	if ICON_OFF_SCATTER == null:
		ICON_OFF_SCATTER = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/offset_scatter.svg", 128)
		if ICON_OFF_SCATTER == null:
			ICON_OFF_SCATTER = preload("res://graphics/icons/console-line.svg")

	# ── Action buttons grid (icon buttons with fixed alignment) ─
	var grid_buttons := GridContainer.new()
	grid_buttons.columns = 2
	grid_buttons.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	grid_buttons.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	grid_buttons.add_theme_constant_override("h_separation", 16)
	grid_buttons.add_theme_constant_override("v_separation", 0)
	root.add_child(grid_buttons)

	_add_offset_icon_button(
		grid_buttons,
		"Displace",
		"Authors PosOffsetAnim/v1 rows for selected notes with start/end offsets and easing.",
		"_apply_offsets",
		ICON_OFF_APPLY
	)

	_add_offset_icon_button(
		grid_buttons,
		"Reset Offset UI",
		"Reset Offset tab fields to their default values.",
		"_reset_offsets_ui",
		ICON_OFF_RESET
	)

	_add_offset_icon_button(
		grid_buttons,
		"Scatter",
		"Randomize Start X/Y and snap End X/Y to 0,0, then apply to selected notes.",
		"_randomize_start_offsets",
		ICON_OFF_SCATTER
	)

	# Footer hint
	var foot := HBoxContainer.new()
	root.add_child(foot)
	foot.add_child(VFXUtils.mk_label("Writes PosOffsetAnim/v1 rows keyed to each selected head."))
	foot.add_child(VFXUtils.mk_spacer())


# ───────────────────────────────────────────────────────────────
# Entry point - WITH UNDO/REDO SUPPORT
# ───────────────────────────────────────────────────────────────

func _apply_offsets() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return

	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var t0_rel := _parse_i(le_t0.text, -120)
	var t1_rel := _parse_i(le_t1.text, 0)
	if t1_rel < t0_rel:
		_notify("⚠️ End offset time must be ≥ start offset time.")
		return

	# Validate numbers
	if not _is_num(le_sx.text) or not _is_num(le_sy.text) or not _is_num(le_ex.text) or not _is_num(le_ey.text):
		_notify("⚠️ Start/End X/Y must be numbers.")
		return

	var start_ofs := Vector2(
		float(le_sx.text.strip_edges()),
		float(le_sy.text.strip_edges())
	)
	var end_ofs := Vector2(
		float(le_ex.text.strip_edges()),
		float(le_ey.text.strip_edges())
	)

	var ease_name := "linear"
	if dd_ease.get_selected_id() >= 0:
		ease_name = EASE_OPTIONS[dd_ease.get_selected_id()]

	var apply_head := cb_head.button_pressed
	var apply_tail := cb_tail.button_pressed
	var apply_target := cb_target.button_pressed
	var apply_hold := cb_hold.button_pressed
	var apply_rush_text := cb_rush_text.button_pressed
	var apply_rush_icon := cb_rush_icon.button_pressed

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Offset VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_offset_rows(
		specs,
		t0_rel, t1_rel,
		start_ofs, end_ofs,
		ease_name,
		apply_head, apply_tail,
		apply_target, apply_hold,
		apply_rush_text, apply_rush_icon
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()

	_notify("✅ Offset rows written for %d note(s)." % specs.size())


# ───────────────────────────────────────────────────────────────
# Reset UI + Scatter helpers
# ───────────────────────────────────────────────────────────────

func _reset_offsets_ui() -> void:
	# Timing defaults
	if le_t0:
		le_t0.text = "-120"
	if le_t1:
		le_t1.text = "0"

	# Offset defaults
	if le_sx:
		le_sx.text = "0"
	if le_sy:
		le_sy.text = "0"
	if le_ex:
		le_ex.text = "0"
	if le_ey:
		le_ey.text = "-60"

	# Parts toggles (all on by default)
	if cb_head:
		cb_head.button_pressed = true
	if cb_tail:
		cb_tail.button_pressed = true
	if cb_target:
		cb_target.button_pressed = true
	if cb_hold:
		cb_hold.button_pressed = true
	if cb_rush_text:
		cb_rush_text.button_pressed = true
	if cb_rush_icon:
		cb_rush_icon.button_pressed = true

	# Ease back to linear
	if dd_ease:
		dd_ease.select(0)

	# Pad distance back to Medium
	if dd_pad_dist:
		dd_pad_dist.select(1)

	_notify("↩️ Offset UI reset to defaults.")

func _randomize_start_offsets() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return

	# Make sure we have something to work on
	if editor.selected.is_empty():
		_notify("⚠️ No notes selected to randomize.")
		return

	# Seed RNG (harmless if called multiple times)
	randomize()

	var sx_val := randf_range(RAND_START_MIN, RAND_START_MAX)
	var sy_val := randf_range(RAND_START_MIN, RAND_START_MAX)

	# Update UI fields
	if le_sx:
		le_sx.text = "%.2f" % sx_val
	if le_sy:
		le_sy.text = "%.2f" % sy_val

	# Snap End to 0,0
	if le_ex:
		le_ex.text = "0"
	if le_ey:
		le_ey.text = "0"

	# Reuse the normal apply path (which now has undo/redo support)
	_apply_offsets()


# ───────────────────────────────────────────────────────────────
# Row builder (returns rows instead of writing directly)
# ───────────────────────────────────────────────────────────────

func _build_offset_rows(
	specs: Array,
	t0_rel: int, t1_rel: int,
	start_ofs: Vector2, end_ofs: Vector2,
	ease_name: String,
	apply_head: bool, apply_tail: bool,
	apply_target: bool, apply_hold: bool,
	apply_rush_text: bool = true, apply_rush_icon: bool = true
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	var out_rows: Array = []
	for e in existing:
		out_rows.append(e)

	for s in specs:
		var layer_s: String = String(s["layer"])
		var head_t_s: int = int(s["time"])
		var nt_s: int = int(s["note_type"])

		var t0 := max(0, head_t_s + t0_rel)
		var t1 := max(0, head_t_s + t1_rel)
		if t1 < t0:
			var tmp := t0
			t0 = t1
			t1 = tmp

		# --- Start row (offset_start) ---
		var idx0 := _find_existing_offset_row_index(
			out_rows, layer_s, t0, nt_s, head_t_s, "offset_start"
		)
		if idx0 >= 0:
			var existing_start: Dictionary = out_rows[idx0]
			out_rows[idx0] = _merge_offset_row_into_existing(
				existing_start,
				start_ofs, ease_name,
				apply_head, apply_tail, apply_target, apply_hold,
				apply_rush_text, apply_rush_icon
			)
		else:
			var start_row := _make_offset_row(
				layer_s, t0, nt_s, head_t_s,
				"offset_start", start_ofs, ease_name,
				apply_head, apply_tail, apply_target, apply_hold,
				apply_rush_text, apply_rush_icon
			)
			out_rows.append(start_row)

		# --- End row (offset_end) ---
		var idx1 := _find_existing_offset_row_index(
			out_rows, layer_s, t1, nt_s, head_t_s, "offset_end"
		)
		if idx1 >= 0:
			var existing_end: Dictionary = out_rows[idx1]
			out_rows[idx1] = _merge_offset_row_into_existing(
				existing_end,
				end_ofs, ease_name,
				apply_head, apply_tail, apply_target, apply_hold,
				apply_rush_text, apply_rush_icon
			)
		else:
			var end_row := _make_offset_row(
				layer_s, t1, nt_s, head_t_s,
				"offset_end", end_ofs, ease_name,
				apply_head, apply_tail, apply_target, apply_hold,
				apply_rush_text, apply_rush_icon
			)
			out_rows.append(end_row)

	return out_rows

func _make_offset_row(
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String,
	ofs: Vector2,
	ease_name: String,
	apply_head: bool, apply_tail: bool,
	apply_target: bool, apply_hold: bool,
	apply_rush_text: bool = true, apply_rush_icon: bool = true
) -> Dictionary:
	var h := ofs if apply_head else Vector2.ZERO
	var t := ofs if apply_tail else Vector2.ZERO
	var tg := ofs if apply_target else Vector2.ZERO
	var ho := ofs if apply_hold else Vector2.ZERO
	var rt := ofs if apply_rush_text else Vector2.ZERO
	var ri := ofs if apply_rush_icon else Vector2.ZERO

	return {
		"layer": layer,
		"time": time_ms,
		"note_type": float(note_type),
		"offset_head": [h.x, h.y],
		"offset_tail": [t.x, t.y],
		"offset_target": [tg.x, tg.y],
		"offset_hold": [ho.x, ho.y],
		"offset_rush_text": [rt.x, rt.y],
		"offset_rush_icon": [ri.x, ri.y],
		"ease": ease_name,
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time
	}

func _find_existing_offset_row_index(
	out_rows: Array,
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String
) -> int:
	for i in range(out_rows.size()):
		var e = out_rows[i]
		if typeof(e) != TYPE_DICTIONARY:
			continue
		var d: Dictionary = e
		if String(d.get("anim", "")) != ANIM_TAG:
			continue
		if String(d.get("layer", "")) != layer:
			continue
		if int(d.get("note_type", -9999)) != note_type:
			continue
		if int(d.get("anim_note_time", -9999)) != note_head_time:
			continue
		if String(d.get("anim_stage", "")) != stage:
			continue
		if int(d.get("time", -1)) != time_ms:
			continue
		return i
	return -1

func _merge_offset_row_into_existing(
	row: Dictionary,
	ofs: Vector2,
	ease_name: String,
	apply_head: bool, apply_tail: bool,
	apply_target: bool, apply_hold: bool,
	apply_rush_text: bool = true, apply_rush_icon: bool = true
) -> Dictionary:
	if apply_head:
		row["offset_head"] = [ofs.x, ofs.y]
	if apply_tail:
		row["offset_tail"] = [ofs.x, ofs.y]
	if apply_target:
		row["offset_target"] = [ofs.x, ofs.y]
	if apply_hold:
		row["offset_hold"] = [ofs.x, ofs.y]
	if apply_rush_text:
		row["offset_rush_text"] = [ofs.x, ofs.y]
	if apply_rush_icon:
		row["offset_rush_icon"] = [ofs.x, ofs.y]

	# Latest operation wins for easing
	row["ease"] = ease_name
	return row


# ───────────────────────────────────────────────────────────────
# Misc helpers
# ───────────────────────────────────────────────────────────────

func _is_num(s: String) -> bool:
	var t := s.strip_edges()
	return t.is_valid_float()

func _parse_i(s: String, def: int) -> int:
	var t := s.strip_edges()
	if t.is_empty():
		return def
	return int(t.to_float()) if t.is_valid_float() else def


# ───────────────────────────────────────────────────────────────
# UI button helper
# ───────────────────────────────────────────────────────────────

# One cell in the grid: 128×128 ratio container + HBEditorButton with icon+text.
func _add_offset_icon_button(
	parent: GridContainer,
	label_text: String,
	tooltip: String,
	func_name: String,
	icon_tex: Texture2D
) -> void:
	var cell := VBoxContainer.new()
	cell.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	cell.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_theme_constant_override("separation", 0)

	var ratio := HBoxRatioContainer.new()
	ratio.custom_minimum_size = Vector2(128, 128)
	ratio.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	ratio.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_child(ratio)

	var hb := _mk_hb_button(label_text, tooltip, func_name)
	hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hb.custom_minimum_size = Vector2(0, 0)

	var inner: Button = hb.get_button()
	if inner:
		inner.icon = icon_tex
		inner.expand_icon = true
		inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	ratio.add_child(hb)
	parent.add_child(cell)

func _mk_hb_button(text: String, tooltip: String, func_name: String) -> HBEditorButton:
	var b := HBEditorButton.new()
	b.button_mode = "function"
	b.text = text
	b.tooltip = tooltip
	b.function_name = func_name
	b.params = []
	b.disable_when_playing = true
	b.disable_with_popup = true

	# Let the parent (ratio container) control the size
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 0)

	b.set_module(self)
	return b


# ───────────────────────────────────────────────────────────────
# Direction pad
# ───────────────────────────────────────────────────────────────

# Build the reused base-game 3x3 button pad. pad_division 3 => eight directions
# plus a center "home" cell. In "function" mode the pad calls our handler with a
# single cell index (0..8) telling us which cell was pressed.
func _build_direction_pad(parent: Control) -> void:
	var pad := HBEditorButtonPad.new()
	pad.pad_division = 3
	pad.button_mode = "function"
	pad.function_name = "_on_direction_pad_pressed"
	pad.params = []
	pad.text = "Direction"
	pad.tooltip = "Press a direction: the part starts offset that way and flies home by hit time.\nCenter clears the offset to home (0,0)."
	pad.disable_when_playing = true
	pad.disable_with_popup = true
	pad.texture = preload("res://graphics/icons/arrange-pad.svg") # reuse the arrange D-pad artwork
	pad.custom_minimum_size = Vector2(140, 140)
	pad.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	pad.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	pad.set_module(self)
	parent.add_child(pad)

# Called by the pad when a cell is pressed (cell_index 0..8).
func _on_direction_pad_pressed(cell_index: int) -> void:
	var dir := _cell_to_direction(cell_index)
	var dist := _selected_pad_distance()
	var start_vec := dir * dist

	# Design: the part STARTS offset in the chosen direction and ENDS at home (0,0).
	if le_sx: le_sx.text = "%.0f" % start_vec.x
	if le_sy: le_sy.text = "%.0f" % start_vec.y
	if le_ex: le_ex.text = "0"
	if le_ey: le_ey.text = "0"

	if cell_index == 4:
		_notify("🎯 Home: offsets cleared to 0,0.")
	else:
		_notify("🧭 Start (%.0f, %.0f) → home. Press Displace to apply." % [start_vec.x, start_vec.y])

# 3x3 cell layout (cell_index = row*3 + col), screen space with +Y down:
#   0 ↖    1 ↑    2 ↗
#   3 ←    4 ·    5 →
#   6 ↙    7 ↓    8 ↘
func _cell_to_direction(idx: int) -> Vector2:
	var v := Vector2.ZERO
	match idx:
		0: v = Vector2(-DIAG, -DIAG) # up-left
		1: v = Vector2(0.0, -1.0)    # up
		2: v = Vector2(DIAG, -DIAG)  # up-right
		3: v = Vector2(-1.0, 0.0)    # left
		4: v = Vector2.ZERO          # center / home
		5: v = Vector2(1.0, 0.0)     # right
		6: v = Vector2(-DIAG, DIAG)  # down-left
		7: v = Vector2(0.0, 1.0)     # down
		8: v = Vector2(DIAG, DIAG)   # down-right
	v.y *= PAD_Y_SIGN
	return v

func _selected_pad_distance() -> float:
	match dd_pad_dist.get_selected_id():
		0: return PAD_DIST_SHORT
		1: return PAD_DIST_MEDIUM
		2: return PAD_DIST_LONG
		_: return PAD_DIST_MEDIUM


# ───────────────────────────────────────────────────────────────
# Preview / notifications
# ───────────────────────────────────────────────────────────────

func _after_write_preview() -> void:
	VFXUtils.trigger_preview_reload(editor)

func _notify(text: String) -> void:
	VFXUtils.show_notification(editor, text)
