#meta:name:TZ Counter Node
#meta:description:The actual TZ Counter that displays during playtest.
#meta:usage:Triggered automatically when the song crosses the TZ Start timing point.

extends Node

# TZ Counter Node v3 - robust signal connection strategy
#
# The problem: During editor playtest, the RhythmGame node that ACTUALLY
# processes note judgments may be a different instance than the one visible
# in the tree when our hook fires. The log proved this:
#   "[RHYTHMGAMEBASE] No hook on instance 1339459390730"  (the REAL game)
#   vs our connection to instance 1073204991729           (a stale/wrong one)
#
# Solution: Instead of connecting once, we continuously watch for ANY node
# with note_judged signal via tree.node_added AND periodic polling.
# We also connect to every candidate we find, not just the first.

var editor: Object
var playtest_root: Node
var game: Node              # The RhythmGame we were told about
var tz_start_time: int
var tz_end_time: int
var total_notes: int = 0
var notes_hit: int = 0
var tz_active: bool = false
var tz_penalty: float = 0.0

var textbox_layer: CanvasLayer = null
var textbox_panel: Panel = null
var textbox_label: Label = null

# Track all nodes we've connected to (by instance id)
var _connected_ids := {}
var _poll_timer: float = 0.0
const POLL_INTERVAL := 0.5  # Check for new game nodes every 500ms

const TAG := "[TZ NODE]"

func init_data(ed: Object, pr: Node, g: Node, start: int, end: int, total: int, penalty: float = 0.0):
	name = "TZCounterNode_%d" % end
	editor = ed
	playtest_root = pr
	game = g
	tz_start_time = start
	tz_end_time = end
	total_notes = total
	notes_hit = 0
	tz_penalty = clamp(penalty, 0.0, 30.0)
	tz_active = true
	print(TAG + " Initialized: zone %d-%d, %d notes, penalty=%.0f%%" % [start, end, total, tz_penalty])

func _ready():
	print(TAG + " _ready called")

	# Connect to playtest end
	if playtest_root and playtest_root.has_signal("quit"):
		if not playtest_root.is_connected("quit", Callable(self, "_on_playtest_end")):
			playtest_root.connect("quit", Callable(self, "_on_playtest_end"))
	if playtest_root and not playtest_root.is_connected("tree_exited", Callable(self, "_on_playtest_end")):
		playtest_root.tree_exited.connect(Callable(self, "_on_playtest_end"))

	# Strategy 1: Watch for new nodes being added to the tree
	var tree = get_tree()
	if tree and not tree.is_connected("node_added", Callable(self, "_on_tree_node_added")):
		tree.node_added.connect(Callable(self, "_on_tree_node_added"))
		print(TAG + " Watching tree for new nodes")

	# Strategy 2: Immediately scan what's already there
	_scan_and_connect()

	# Create UI
	_create_counter_textbox()
	_update_counter_display()


# Called every time ANY node is added to the scene tree
func _on_tree_node_added(node: Node):
	if node == self:
		return
	# Quick check: does this node have the signal we care about?
	if node.has_signal("note_judged") or node.has_signal("editor_note_judged"):
		var nid = node.get_instance_id()
		if not _connected_ids.has(nid):
			print(TAG + " node_added caught new candidate: %s (id=%d, class=%s)" % [node.name, nid, node.get_class()])
			_try_connect_to(node)


# Strategy 3: Periodic polling as a last resort
func _process(delta: float):
	# If playtest root is gone, clean up immediately regardless of tz_active
	if playtest_root and not is_instance_valid(playtest_root):
		print(TAG + " playtest_root invalidated, forcing cleanup")
		_on_playtest_end()
		return

	if not tz_active:
		return
	_poll_timer += delta
	if _poll_timer >= POLL_INTERVAL:
		_poll_timer = 0.0
		_scan_and_connect()


# BFS from multiple roots to find all nodes with note_judged
func _scan_and_connect():
	var roots: Array = []

	# Search from playtest root
	if playtest_root and is_instance_valid(playtest_root):
		roots.append(playtest_root)

	# Also search from scene tree root (catches nodes outside popup)
	var tree = get_tree()
	if tree and tree.root:
		roots.append(tree.root)

	var found_new := false
	for root in roots:
		var queue: Array = [root]
		while queue.size() > 0:
			var cur: Node = queue.pop_front()
			if cur == self:
				continue
			var cid = cur.get_instance_id()
			if not _connected_ids.has(cid):
				if cur.has_signal("note_judged") or cur.has_signal("editor_note_judged"):
					_try_connect_to(cur)
					found_new = true
			for child in cur.get_children():
				queue.append(child)

	if found_new:
		print(TAG + " Total connected instances: %d" % _connected_ids.size())


# Connect to a single node's signals
func _try_connect_to(node: Node):
	var nid = node.get_instance_id()
	if _connected_ids.has(nid):
		return

	_connected_ids[nid] = node
	print(TAG + "   Connecting to: %s (id=%d, class=%s)" % [node.name, nid, node.get_class()])

	if node.has_signal("editor_note_judged"):
		if not node.is_connected("editor_note_judged", Callable(self, "_on_note_judged_signal")):
			node.connect("editor_note_judged", Callable(self, "_on_note_judged_signal"))
			print(TAG + "   ✓ editor_note_judged connected")

	if node.has_signal("note_judged"):
		if not node.is_connected("note_judged", Callable(self, "_on_note_judged_signal")):
			node.connect("note_judged", Callable(self, "_on_note_judged_signal"))
			print(TAG + "   ✓ note_judged connected")


# --- Signal callback ---
func _on_note_judged_signal(judgement_info: Dictionary):
	var target_time = judgement_info.get("target_time", -1)

	print(TAG + " ========== signal received! target_time=%d ==========" % target_time)

	if not tz_active:
		return

	# Check if note is in TZ zone
	if target_time < tz_start_time or target_time > tz_end_time:
		return

	print(TAG + " *** Note in TZ zone! ***")

	var final_judgement = judgement_info.get("judgement", -1)
	var wrong = judgement_info.get("wrong", false)

	# FINE (3) or better required, and not wrong
	var min_rating = 3
	if final_judgement < min_rating or wrong:
		print(TAG + " *** FAIL! judgement=%d wrong=%s ***" % [final_judgement, str(wrong)])
		tz_active = false
		var fail_text = "Fail!"
		if tz_penalty > 0.0:
			fail_text = "Fail! -%.0f%%" % tz_penalty
		_show_result(fail_text, Color(1.0, 0.2, 0.2, 1.0))
		return

	# Good hit
	notes_hit += 1
	print(TAG + " *** HIT! %d/%d ***" % [notes_hit, total_notes])
	_update_counter_display()

	if notes_hit >= total_notes:
		print(TAG + " *** COMPLETE! ***")
		tz_active = false
		_show_result("Complete!", Color(0.2, 1.0, 0.2, 1.0))


func on_tz_end():
	print(TAG + " ========== on_tz_end CALLED ==========")
	print(TAG + " Final: %d/%d" % [notes_hit, total_notes])
	print(TAG + " Connected to %d game instance(s): %s" % [_connected_ids.size(), str(_connected_ids.keys())])

	if not tz_active:
		# Already resolved (complete or fail) — UI cleanup is already in progress
		return

	tz_active = false

	# Zone ended without a fail — show the final count as the result
	if notes_hit >= total_notes:
		_show_result("Complete!", Color(0.2, 1.0, 0.2, 1.0))
	else:
		_show_result("%d / %d" % [notes_hit, total_notes], Color(1.0, 0.85, 0.3, 1.0))


# -------- UI --------

func _create_counter_textbox():
	textbox_layer = CanvasLayer.new()
	textbox_layer.name = "TZCounterLayer"
	textbox_layer.layer = 100

	textbox_panel = Panel.new()
	textbox_panel.position = Vector2(135, 90)
	textbox_panel.size = Vector2(400, 100)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.1, 0.1, 0.9)
	style.border_width_left = 3
	style.border_width_top = 3
	style.border_width_right = 3
	style.border_width_bottom = 3
	style.border_color = Color(0.3, 0.7, 1.0, 1.0)
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	textbox_panel.add_theme_stylebox_override("panel", style)

	textbox_label = Label.new()
	textbox_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	textbox_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	textbox_label.add_theme_font_size_override("font_size", 32)
	textbox_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	textbox_label.set_anchors_preset(Control.PRESET_FULL_RECT)

	textbox_panel.add_child(textbox_label)
	textbox_layer.add_child(textbox_panel)

	# Parent to editor, not playtest_root — ensures we can clean it up
	# even after playtest_root is freed
	if editor and is_instance_valid(editor):
		editor.add_child(textbox_layer)
	elif playtest_root and is_instance_valid(playtest_root):
		playtest_root.add_child(textbox_layer)

	# Fade in
	textbox_panel.modulate = Color(1, 1, 1, 0)
	var tween = get_tree().create_tween()
	tween.tween_property(textbox_panel, "modulate:a", 1.0, 0.3)

func _update_counter_display():
	if textbox_label:
		textbox_label.text = "%d / %d" % [notes_hit, total_notes]

func _show_result(result_text: String, color: Color):
	if textbox_label:
		textbox_label.text = result_text
		textbox_label.add_theme_color_override("font_color", color)

	var tree = get_tree()
	if tree == null:
		# Tree is gone (mid-teardown), just free immediately
		if textbox_layer and is_instance_valid(textbox_layer):
			textbox_layer.queue_free()
		textbox_layer = null
		textbox_panel = null
		textbox_label = null
		queue_free()
		return

	tree.create_timer(1.0).timeout.connect(func():
		if textbox_panel and is_instance_valid(textbox_panel):
			var t2 = get_tree()
			if t2 == null:
				if textbox_layer and is_instance_valid(textbox_layer):
					textbox_layer.queue_free()
				textbox_layer = null
				textbox_panel = null
				textbox_label = null
				queue_free()
				return
			var fade_tween = t2.create_tween()
			fade_tween.tween_property(textbox_panel, "modulate:a", 0.0, 0.3)
			fade_tween.finished.connect(func():
				if textbox_layer and is_instance_valid(textbox_layer):
					textbox_layer.queue_free()
				textbox_layer = null
				textbox_panel = null
				textbox_label = null
				queue_free()
			)
		else:
			queue_free()
	)

func _on_playtest_end():
	print(TAG + " Playtest ended, cleaning up")
	tz_active = false

	# Disconnect tree watcher
	var tree = get_tree()
	if tree and tree.is_connected("node_added", Callable(self, "_on_tree_node_added")):
		tree.disconnect("node_added", Callable(self, "_on_tree_node_added"))

	# Disconnect all signal connections
	for nid in _connected_ids:
		var node = _connected_ids[nid]
		if node and is_instance_valid(node):
			if node.has_signal("editor_note_judged") and node.is_connected("editor_note_judged", Callable(self, "_on_note_judged_signal")):
				node.disconnect("editor_note_judged", Callable(self, "_on_note_judged_signal"))
			if node.has_signal("note_judged") and node.is_connected("note_judged", Callable(self, "_on_note_judged_signal")):
				node.disconnect("note_judged", Callable(self, "_on_note_judged_signal"))
	_connected_ids.clear()

	# Immediate UI teardown — no tweens, tree may be mid-teardown
	if textbox_layer and is_instance_valid(textbox_layer):
		textbox_layer.queue_free()
	textbox_layer = null
	textbox_panel = null
	textbox_label = null
	queue_free()
