#meta:name:HBT Counter Node
#meta:description:The actual HBT (Heartbeat Time) Counter that displays during playtest.
#meta:usage:Triggered automatically when the song crosses an HBT start timing point.

extends Node

# HBT Counter Node v1
#
# Modeled on tz-counter-node.gd v3. Same defensive signal-connection strategy:
# the RhythmGame instance that processes note judgements during editor playtest
# may be a different instance than the one passed in at spawn time, so we watch
# tree.node_added AND poll periodically for any node carrying note_judged or
# editor_note_judged signals, and connect to all of them.
#
# Key differences from TZ:
# - No fixed end_time — zone resolves when the qualifier-time chord is judged.
# - Misses during the zone DON'T fail it — only missing the qualifier or being
#   below 75% at qualifier time fails it.
# - 75% threshold latches a rainbow text effect that persists until resolution.
# - Display is a percentage, not "hits / total".

var editor: Object
var playtest_root: Node
var game: Node              # The RhythmGame we were told about

var start_time: int
var qualifier_time: int
var total_regular: int             # regular notes in zone (excludes qualifier-time)
var qualifier_notes_total: int     # how many notes share qualifier_time (chord support)

var notes_hit: int = 0
var qualifier_notes_hit: int = 0
var threshold_latched: bool = false   # has the 75% rainbow trigger fired?
var zone_active: bool = true          # false once resolved (pass/fail)

const THRESHOLD: float = 0.75
const FAIL_PENALTY_DISPLAY: float = 30.0  # display only; modifier applies the actual score change

var textbox_layer: CanvasLayer = null
var textbox_panel: Panel = null
var textbox_label: Label = null

# Rainbow animation state — only ticks once threshold_latched is true
var _rainbow_phase: float = 0.0
const RAINBOW_SPEED: float = 0.6   # cycles per second through the hue wheel

# Track all nodes we've connected to (by instance id)
var _connected_ids := {}
var _poll_timer: float = 0.0
const POLL_INTERVAL := 0.5

const TAG := "[HBT NODE]"

func init_data(ed: Object, pr: Node, g: Node, st: int, qt: int, total_reg: int, q_total: int):
	name = "HBTCounterNode_%d" % qt
	editor = ed
	playtest_root = pr
	game = g
	start_time = st
	qualifier_time = qt
	total_regular = max(total_reg, 0)
	qualifier_notes_total = max(q_total, 1)
	notes_hit = 0
	qualifier_notes_hit = 0
	threshold_latched = false
	zone_active = true
	print(TAG + " Initialized: zone %d → qualifier @ %d, %d regular notes, %d qualifier-time notes" % [
		st, qt, total_regular, qualifier_notes_total
	])


func _ready():
	print(TAG + " _ready called")
	
	# Connect to playtest end
	if playtest_root and playtest_root.has_signal("quit"):
		if not playtest_root.is_connected("quit", Callable(self, "_on_playtest_end")):
			playtest_root.connect("quit", Callable(self, "_on_playtest_end"))
	if playtest_root and not playtest_root.is_connected("tree_exited", Callable(self, "_on_playtest_end")):
		playtest_root.tree_exited.connect(Callable(self, "_on_playtest_end"))
	
	# Strategy 1: Watch for new nodes being added to the tree
	var tree = get_tree()
	if tree and not tree.is_connected("node_added", Callable(self, "_on_tree_node_added")):
		tree.node_added.connect(Callable(self, "_on_tree_node_added"))
		print(TAG + " Watching tree for new nodes")
	
	# Strategy 2: Immediately scan what's already there
	_scan_and_connect()
	
	# Create UI
	_create_counter_textbox()
	_update_counter_display()


# Called every time ANY node is added to the scene tree
func _on_tree_node_added(node: Node):
	if node == self:
		return
	if node.has_signal("note_judged") or node.has_signal("editor_note_judged"):
		var nid = node.get_instance_id()
		if not _connected_ids.has(nid):
			print(TAG + " node_added caught new candidate: %s (id=%d, class=%s)" % [node.name, nid, node.get_class()])
			_try_connect_to(node)


func _process(delta: float):
	# If playtest root is gone, clean up immediately regardless of zone_active
	if playtest_root and not is_instance_valid(playtest_root):
		print(TAG + " playtest_root invalidated, forcing cleanup")
		_on_playtest_end()
		return
	
	# Rainbow animation runs whenever the threshold is latched, even after
	# resolution starts fading — looks better than snapping to a static color.
	if threshold_latched and textbox_label != null:
		_rainbow_phase = fposmod(_rainbow_phase + delta * RAINBOW_SPEED, 1.0)
		var rainbow_color = Color.from_hsv(_rainbow_phase, 0.85, 1.0)
		textbox_label.add_theme_color_override("font_color", rainbow_color)
	
	if not zone_active:
		return
	_poll_timer += delta
	if _poll_timer >= POLL_INTERVAL:
		_poll_timer = 0.0
		_scan_and_connect()


# BFS from multiple roots to find all nodes with note_judged
func _scan_and_connect():
	var roots: Array = []
	
	if playtest_root and is_instance_valid(playtest_root):
		roots.append(playtest_root)
	
	var tree = get_tree()
	if tree and tree.root:
		roots.append(tree.root)
	
	var found_new := false
	for root in roots:
		var queue: Array = [root]
		while queue.size() > 0:
			var cur: Node = queue.pop_front()
			if cur == self:
				continue
			var cid = cur.get_instance_id()
			if not _connected_ids.has(cid):
				if cur.has_signal("note_judged") or cur.has_signal("editor_note_judged"):
					_try_connect_to(cur)
					found_new = true
			for child in cur.get_children():
				queue.append(child)
	
	if found_new:
		print(TAG + " Total connected instances: %d" % _connected_ids.size())


func _try_connect_to(node: Node):
	var nid = node.get_instance_id()
	if _connected_ids.has(nid):
		return
	
	_connected_ids[nid] = node
	print(TAG + "   Connecting to: %s (id=%d, class=%s)" % [node.name, nid, node.get_class()])
	
	if node.has_signal("editor_note_judged"):
		if not node.is_connected("editor_note_judged", Callable(self, "_on_note_judged_signal")):
			node.connect("editor_note_judged", Callable(self, "_on_note_judged_signal"))
			print(TAG + "   ✓ editor_note_judged connected")
	
	if node.has_signal("note_judged"):
		if not node.is_connected("note_judged", Callable(self, "_on_note_judged_signal")):
			node.connect("note_judged", Callable(self, "_on_note_judged_signal"))
			print(TAG + "   ✓ note_judged connected")


# ─────────────────────────────────────────────
# Judgement handling — the heart of HBT logic
# ─────────────────────────────────────────────

func _on_note_judged_signal(judgement_info: Dictionary):
	if not zone_active:
		return
	
	var target_time = judgement_info.get("target_time", -1)
	
	# Out of zone entirely
	if target_time < start_time or target_time > qualifier_time:
		return
	
	var final_judgement = judgement_info.get("judgement", -1)
	var wrong = judgement_info.get("wrong", false)
	var min_rating = 3   # FINE or better, same as TZ
	var clean_hit = (final_judgement >= min_rating) and not wrong
	
	# QUALIFIER-TIME NOTE — resolution logic
	if target_time == qualifier_time:
		if not clean_hit:
			# Any miss/wrong on the qualifier chord = immediate fail
			print(TAG + " *** QUALIFIER MISS — FAIL *** judgement=%d wrong=%s" % [final_judgement, str(wrong)])
			_resolve_fail()
			return
		
		qualifier_notes_hit += 1
		print(TAG + " Qualifier note %d/%d hit cleanly" % [qualifier_notes_hit, qualifier_notes_total])
		
		# Zone only resolves when the WHOLE qualifier chord is in
		if qualifier_notes_hit >= qualifier_notes_total:
			_evaluate_and_resolve()
		return
	
	# REGULAR NOTE — accumulates toward 75% threshold
	if not clean_hit:
		# Misses during the zone don't fail it (per spec); they just don't count toward threshold
		return
	
	notes_hit += 1
	_update_counter_display()
	
	# Threshold latch — fires once when we cross 75%, persists through resolution
	if not threshold_latched and total_regular > 0:
		var pct = float(notes_hit) / float(total_regular)
		if pct >= THRESHOLD:
			threshold_latched = true
			print(TAG + " *** 75%% THRESHOLD REACHED — rainbow latched ***")


func _evaluate_and_resolve():
	# Called when the qualifier chord is fully hit. Threshold check happens here.
	var pct = 0.0
	if total_regular > 0:
		pct = float(notes_hit) / float(total_regular)
	print(TAG + " Qualifier chord complete. Regular hits: %d/%d (%.1f%%)" % [
		notes_hit, total_regular, pct * 100.0
	])
	
	if pct >= THRESHOLD:
		print(TAG + " *** PASS *** ")
		_resolve_pass(pct)
	else:
		print(TAG + " *** FAIL — below 75%% threshold ***")
		_resolve_fail()


func _resolve_pass(final_pct: float):
	zone_active = false
	threshold_latched = false  # stop rainbow animation; pass color takes over
	# Round to integer percent — matches how the live counter displays
	var pct_int: int = int(round(final_pct * 100.0))
	_show_result("%d%% Qualified!" % pct_int, Color(0.2, 1.0, 0.2, 1.0))


func _resolve_fail():
	zone_active = false
	threshold_latched = false  # stop rainbow on fail
	var fail_text = "Fail! -%.0f%%" % FAIL_PENALTY_DISPLAY
	_show_result(fail_text, Color(1.0, 0.2, 0.2, 1.0))


# ─────────────────────────────────────────────
# UI — mirrors TZ counter style for visual consistency
# ─────────────────────────────────────────────

func _create_counter_textbox():
	textbox_layer = CanvasLayer.new()
	textbox_layer.name = "HBTCounterLayer"
	textbox_layer.layer = 100
	
	textbox_panel = Panel.new()
	# Same position/size as TZ counter so they don't overlap visually if a chart
	# happens to use both — but a chart shouldn't realistically have both active
	# at the same instant.
	textbox_panel.position = Vector2(135, 90)
	textbox_panel.size = Vector2(400, 100)
	
	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.1, 0.1, 0.1, 0.9)
	style.border_width_left = 3
	style.border_width_top = 3
	style.border_width_right = 3
	style.border_width_bottom = 3
	style.border_color = Color(0.3, 0.7, 1.0, 1.0)
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	textbox_panel.add_theme_stylebox_override("panel", style)
	
	textbox_label = Label.new()
	textbox_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	textbox_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	textbox_label.add_theme_font_size_override("font_size", 32)
	textbox_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	textbox_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	
	textbox_panel.add_child(textbox_label)
	textbox_layer.add_child(textbox_panel)
	
	# Parent to editor, not playtest_root — survives playtest_root teardown
	if editor and is_instance_valid(editor):
		editor.add_child(textbox_layer)
	elif playtest_root and is_instance_valid(playtest_root):
		playtest_root.add_child(textbox_layer)
	
	# Fade in
	textbox_panel.modulate = Color(1, 1, 1, 0)
	var tween = get_tree().create_tween()
	tween.tween_property(textbox_panel, "modulate:a", 1.0, 0.3)


func _update_counter_display():
	if textbox_label == null:
		return
	# Percentage display, integer-rounded. Pre-zone shows "0%".
	var pct: int = 0
	if total_regular > 0:
		pct = int(round(float(notes_hit) / float(total_regular) * 100.0))
	textbox_label.text = "%d%%" % pct


func _show_result(result_text: String, color: Color):
	if textbox_label:
		textbox_label.text = result_text
		# Clear any rainbow override before setting the resolution color
		textbox_label.add_theme_color_override("font_color", color)
	
	var tree = get_tree()
	if tree == null:
		# Tree is gone (mid-teardown), free immediately
		if textbox_layer and is_instance_valid(textbox_layer):
			textbox_layer.queue_free()
		textbox_layer = null
		textbox_panel = null
		textbox_label = null
		queue_free()
		return
	
	tree.create_timer(1.0).timeout.connect(func():
		if textbox_panel and is_instance_valid(textbox_panel):
			var t2 = get_tree()
			if t2 == null:
				if textbox_layer and is_instance_valid(textbox_layer):
					textbox_layer.queue_free()
				textbox_layer = null
				textbox_panel = null
				textbox_label = null
				queue_free()
				return
			var fade_tween = t2.create_tween()
			fade_tween.tween_property(textbox_panel, "modulate:a", 0.0, 0.3)
			fade_tween.finished.connect(func():
				if textbox_layer and is_instance_valid(textbox_layer):
					textbox_layer.queue_free()
				textbox_layer = null
				textbox_panel = null
				textbox_label = null
				queue_free()
			)
		else:
			queue_free()
	)


func _on_playtest_end():
	print(TAG + " Playtest ended, cleaning up")
	zone_active = false
	threshold_latched = false
	
	# Disconnect tree watcher
	var tree = get_tree()
	if tree and tree.is_connected("node_added", Callable(self, "_on_tree_node_added")):
		tree.disconnect("node_added", Callable(self, "_on_tree_node_added"))
	
	# Disconnect all signal connections
	for nid in _connected_ids:
		var node = _connected_ids[nid]
		if node and is_instance_valid(node):
			if node.has_signal("editor_note_judged") and node.is_connected("editor_note_judged", Callable(self, "_on_note_judged_signal")):
				node.disconnect("editor_note_judged", Callable(self, "_on_note_judged_signal"))
			if node.has_signal("note_judged") and node.is_connected("note_judged", Callable(self, "_on_note_judged_signal")):
				node.disconnect("note_judged", Callable(self, "_on_note_judged_signal"))
	_connected_ids.clear()
	
	# Immediate UI teardown — no tweens, tree may be mid-teardown
	if textbox_layer and is_instance_valid(textbox_layer):
		textbox_layer.queue_free()
	textbox_layer = null
	textbox_panel = null
	textbox_label = null
	queue_free()
