#meta:name:Random Colors Flash (Timeout + Envelopes)
#meta:description:Writes ColorAnim/v1 using each note's GAME TIMEOUT (pre-impact only), with fixed primary-color START/END + envelope pulses. Merge-safe per selected heads.
#meta:usage:Select notes and run. Compile Shaders afterwards.

extends ScriptRunnerScript

const ANIM_TAG := "ColorAnim/v1"

const NOTE_TYPE_NAMES := {
	0:"UP",1:"LEFT",2:"DOWN",3:"RIGHT",
	4:"SLIDE_LEFT",5:"SLIDE_RIGHT",
	6:"SLIDE_CHAIN_PIECE_LEFT",7:"SLIDE_CHAIN_PIECE_RIGHT",
	8:"HEART"
}

# ─────────────────────────────────────────────────────────────
# Primary-colors preset (from your screenshot)
# ─────────────────────────────────────────────────────────────
const PRESET_PULSES_PER_BEAT := 6
const PRESET_PHASE_BEATS := 0.0
const PRESET_EASE := "hold"
const DEBUG_VFX := true

const PRESET_PHASE_STEP_BEATS := 0.1  # ⬅ per-note phase offset in beats



func _dbg(msg: String) -> void:
	if DEBUG_VFX:
		print("[ColorRandomFlash] ", msg)

# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────
func run_script() -> int:
	if _editor == null:
		push_error("[ColorPrimaryFlash] No editor.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[ColorPrimaryFlash] No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs := _collect_selected_note_specs()
	if specs.is_empty():
		push_error("[ColorPrimaryFlash] No valid note specs.")
		return ERR_DOES_NOT_EXIST

	var rng := RandomNumberGenerator.new()
	rng.randomize()

	# Each component gets its *own* random START and END color
	var S := {
		"icon":      _random_color(rng),
		"target":    _random_color(rng),
		"bar1":      _random_color(rng),
		"bar2":      _random_color(rng),
		"icon_head": _random_color(rng),
		"icon_tail": _random_color(rng),
		"hold_text": _random_color(rng),
	}

	var E := {
		"icon":      _random_color(rng),
		"target":    _random_color(rng),
		"bar1":      _random_color(rng),
		"bar2":      _random_color(rng),
		"icon_head": _random_color(rng),
		"icon_tail": _random_color(rng),
		"hold_text": _random_color(rng),
	}

	_write_color_anim(
		specs,
		S,
		E,
		true,  # env_enable
		PRESET_PULSES_PER_BEAT,
		PRESET_PHASE_BEATS,
		PRESET_EASE
	)

	# ... keep your injector / preview logic unchanged ...

	# Nudge VFX injector for live preview (same pattern as other scripts)
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", _editor, _get_vfx_path())
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable preview.")

	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[ColorPrimaryFlash] ✅ Wrote primary-color ColorAnim/v1 rows.")
	return OK


# ─────────────────────────────────────────────────────────────
# Exporter (same as v2.1)
# ─────────────────────────────────────────────────────────────
func _write_color_anim(
	specs: Array,
	S: Dictionary,
	E: Dictionary,
	env_enable: bool,
	pulses_per_beat: int,
	phase_beats: float,
	ease: String
) -> void:
	var path := _get_vfx_path()

	var existing: Array = []
	if FileAccess.file_exists(path):
		var f := FileAccess.open(path, FileAccess.READ)
		if f:
			var parsed := JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_ARRAY:
				existing = parsed
			f.close()

	# Selected heads for merge-safe behavior
	var sel_heads := {}
	for spec in specs:
		var layer := String(spec["layer"])
		var head  := int(spec["time"])
		var nt    := int(spec["note_type"])
		sel_heads["%s@%d@%d" % [layer, nt, head]] = true

	# Preserve everything except ColorAnim/v1 rows for selected heads
	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("anim","")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer",""))
		var nt_e := int(e.get("note_type",-1))
		var head_e := int(e.get("anim_note_time",-999999))
		var key_e := "%s@%d@%d" % [layer_e, nt_e, head_e]
		if not sel_heads.has(key_e):
			preserved.append(e)

	var out_rows := preserved.duplicate()

	# NOTE: index-based loop so we can phase per note
	for i in range(specs.size()):
		var spec = specs[i]

		var layer := String(spec["layer"])
		var head_ms := int(spec["time"])
		var ntype := int(spec["note_type"])

		# Timeout/BPM identical to ScaleTimeoutWindow (using note_obj)
		var note_obj = spec.get("note_obj", null)
		var timeout_ms := _compute_timeout_ms(ntype, note_obj, head_ms)
		var bpm := _bpm_at_ms(head_ms)
		if bpm <= 0.0:
			bpm = 120.0

		# Periods
		var beat_ms := int(round(60000.0 / max(1.0, bpm)))
		var sub_period_ms := int(max(1, beat_ms / max(1, pulses_per_beat)))

		# Per-note phase: base + i * step (in beats → ms)
		var phase_beats_for_note := phase_beats + PRESET_PHASE_STEP_BEATS * float(i)
		var phase_ms := int(round(beat_ms * phase_beats_for_note))

		# Window strictly before impact
		var t1 := head_ms
		var t0 := max(0, head_ms - timeout_ms)
		if t0 >= t1:
			t0 = t1 - 1

		var start_cols := _build_start_cols(S, E)   # START=Valley (coalesce)
		var end_cols := _build_end_cols(E)          # END=Peak

		# START row
		out_rows.append(_mk_row_colors(
			layer, ntype, head_ms, "anim_start", t0, start_cols, ease
		))

		# Envelope pulses with per-note phase
		if env_enable and sub_period_ms > 0:
			# Align first envelope strictly inside (t0..t1) with phase
			var rem := fposmod(float(t0) - float(phase_ms), float(sub_period_ms))
			var t := int(round(t0 + (sub_period_ms - rem)))
			if t <= t0:
				t += sub_period_ms

			var ix := 0
			while t < t1:
				var use_valley := (ix % 2) == 0
				var cols := start_cols if use_valley else end_cols
				out_rows.append(_mk_row_colors(
					layer, ntype, head_ms, "envelope", t, cols, ease
				))
				ix += 1
				t += sub_period_ms

		# IMPACT row
		out_rows.append(_mk_row_colors(
			layer, ntype, head_ms, "impact", t1, end_cols, ease
		))

	# Sort & write (unchanged)
	out_rows.sort_custom(func(a, b):
		var la := String(a.get("layer",""))
		var lb := String(b.get("layer",""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		var ta := int(a.get("time",0))
		var tb := int(b.get("time",0))
		if ta != tb:
			return ta < tb
		return la < lb
	)

	var lines := PackedStringArray()
	for e in out_rows:
		lines.append(JSON.stringify(e))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[ColorPrimaryFlash] 💾 Wrote %d rows → %s" % [out_rows.size(), path])
	else:
		push_error("[ColorPrimaryFlash] Failed to write VFX file.")


# ─────────────────────────────────────────────────────────────
# Row builders
# ─────────────────────────────────────────────────────────────
func _mk_row_colors(layer: String, ntype: int, head_time: int, stage: String, t_ms: int, cols: Dictionary, ease: String) -> Dictionary:
	var row := {
		"layer": layer,
		"time": t_ms,
		"note_type": float(ntype),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": head_time,
		"ease": String(ease)
	}
	_apply_color_if_any(row, "color_icon",      cols.get("icon", null))
	_apply_color_if_any(row, "color_target",    cols.get("target", null))
	_apply_color_if_any(row, "color_bar1",      cols.get("bar1", null))
	_apply_color_if_any(row, "color_bar2",      cols.get("bar2", null))
	_apply_color_if_any(row, "color_icon_head", cols.get("icon_head", null))
	_apply_color_if_any(row, "color_icon_tail", cols.get("icon_tail", null))
	_apply_color_if_any(row, "color_hold_text", cols.get("hold_text", null))
	return row

func _build_start_cols(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = _coalesce_color(S.get("icon", null),      E.get("icon", null))
	d["target"]     = _coalesce_color(S.get("target", null),    E.get("target", null))
	d["bar1"]       = _coalesce_color(S.get("bar1", null),      E.get("bar1", null))
	d["bar2"]       = _coalesce_color(S.get("bar2", null),      E.get("bar2", null))
	d["icon_head"]  = _coalesce_color(S.get("icon_head", null), E.get("icon_head", null))
	d["icon_tail"]  = _coalesce_color(S.get("icon_tail", null), E.get("icon_tail", null))
	d["hold_text"]  = _coalesce_color(S.get("hold_text", null), E.get("hold_text", null))
	return d

func _build_end_cols(E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = E.get("icon", null)
	d["target"]     = E.get("target", null)
	d["bar1"]       = E.get("bar1", null)
	d["bar2"]       = E.get("bar2", null)
	d["icon_head"]  = E.get("icon_head", null)
	d["icon_tail"]  = E.get("icon_tail", null)
	d["hold_text"]  = E.get("hold_text", null)
	return d


# ─────────────────────────────────────────────────────────────
# Timing helpers — same as Flicker script
# ─────────────────────────────────────────────────────────────
func _compute_timeout_ms(note_type: int, note_obj: Object, t_ms: int) -> int:
	var rg := _get_rg()
	if rg != null:
		# 1) Authoritative per-type+time (already in milliseconds)
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if DEBUG_VFX:
				_dbg("rg.get_time_out_for t="+str(t_ms)+" => "+str(ms)+"ms")
			if ms > 0:
				return ms

		# 2) Note instance using speed-at-time
		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))
		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if DEBUG_VFX:
				_dbg("note.get_time_out speed="+str(speed)+" => "+str(ms2)+"ms")
			if ms2 > 0:
				return ms2

		# 3) Generic RG helper variants (ms)
		if (rg as Object).has_method("get_time_out"):
			var try_ms := 0.0
			if (rg as Object).get_method_list().any(func(m): return m.name == "get_time_out" and m.args.size() >= 2):
				try_ms = float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if DEBUG_VFX:
				_dbg("rg.get_time_out(...) => "+str(ms3)+"ms")
			if ms3 > 0:
				return ms3

	# 4) Tempo-aware fallback (~8 beats)
	var bpm := _bpm_at_ms(t_ms)
	if bpm > 0.0:
		var beat_ms := 60000.0 / bpm
		var fallback := int(round(8.0 * beat_ms))
		if DEBUG_VFX:
			_dbg("fallback 8*beat => "+str(fallback)+"ms")
		return fallback

	if DEBUG_VFX:
		_dbg("hard fallback => 2000ms")
	return 2000


func _get_rg() -> Object:
	if _editor == null:
		return null
	var rg = _editor.get("rhythm_game")
	if rg is Object:
		return rg
	var pv = _editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	var gp = _editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null

func _bpm_at_ms(t_ms: int) -> float:
	var rg := _get_rg()
	if rg != null:
		if (rg as Object).has_method("get_bpm_at_time"):
			return float((rg as Object).call("get_bpm_at_time", t_ms))
		var tm := (rg as Object).get("tempo_map")
		if tm != null and (tm as Object).has_method("get_bpm_at_time"):
			return float((tm as Object).call("get_bpm_at_time", t_ms))
	if _editor != null:
		var em = _editor.get("tempo_map")
		if em != null and (em as Object).has_method("get_bpm_at_time"):
			return float((em as Object).call("get_bpm_at_time", t_ms))
	return 0.0


# ─────────────────────────────────────────────────────────────
# Shared helpers (selection / IO)
# ─────────────────────────────────────────────────────────────
func _coalesce_color(a: Variant, b: Variant) -> Variant:
	if a != null:
		return a
	return b

static func _r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0

func _enc_color(c: Color) -> Array:
	return [_r3(c.r), _r3(c.g), _r3(c.b), _r3(c.a)]

func _random_color(rng: RandomNumberGenerator) -> Color:
	# Tweak S/V if you want more pastel / more neon
	return Color.from_hsv(
		rng.randf(),      # hue 0..1
		0.8,              # saturation
		1.0               # value/brightness
	)


func _apply_color_if_any(dst: Dictionary, key: String, col: Variant) -> void:
	if col == null:
		return
	if col is Color:
		dst[key] = _enc_color(col)

func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type := int(data_obj.get("note_type"))
			var time_val := int(data_obj.get("time"))
			var layer2 := _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)
			var lname := NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"
			var layer_tag = "layer_" + lname + ( "2" if layer2 else "" )
			specs.append({
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj
			})
	return specs

func _safe_get(obj: Object, prop: String, fallback: Variant=null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	if obj.has_method("get") and obj.get(prop) != null:
		return obj.get(prop)
	return fallback

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null:
		if int(lidx) == 1:
			return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null:
		if bool(has_flag):
			return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null:
		if String(layer_meta).ends_with("2"):
			return true
	return false

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"
