# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Preset – Scale Pulse (0.5 beat, 1.5x, OutElastic)
#meta:description:Writes ScaleAbsAnim/v1 timeout windows with fixed start/impact scales and 0.5-beat Out Elastic PEAK/VALLEY envelopes. Matches the Scale Animation Window screenshot preset.
#meta:usage:Select notes and run. Requires Shaders/Preview ("PH_VFX_MegaInjector") to be armed to see changes.

extends ScriptRunnerScript

const ANIM_TAG := "ScaleAbsAnim/v1"
const NOTE_TYPE_NAMES := {
	0:"UP",1:"LEFT",2:"DOWN",3:"RIGHT",
	4:"SLIDE_LEFT",5:"SLIDE_RIGHT",
	6:"SLIDE_CHAIN_PIECE_LEFT",7:"SLIDE_CHAIN_PIECE_RIGHT",
	8:"HEART"
}

const SCALE_MIN_MAX := Vector2(0.4, 4.0)
const SLIDE_HIT_ATTEN := 0.85
const DEBUG_TIMEOUT := false

# ───────────────────────────────────────────────────────────────────────────────
# PRESET VALUES (from the screenshot)
# ───────────────────────────────────────────────────────────────────────────────

const PRESET_DENSITY_MS := 80
const PRESET_IMPACT_CAP := 1.0
const PRESET_ATTEN_SLIDES := true

# START scales
const PRESET_START_SCALES := {
	"head":   0.9,
	"target": 0.9,
	"bar1":   0.9,
	"bar2":   0.9,
	"tail":   0.95,
	"hold":   0.9,
}

# IMPACT scales
const PRESET_END_SCALES := {
	"head":   1.5,
	"target": 1.04,
	"bar1":   0.96,
	"bar2":   0.96,
	"tail":   1.12,
	"hold":   0.96,
}

# Envelope PEAK scales
const PRESET_ENV_PEAK := {
	"head":   1.5,
	"target": 1.5,
	"bar1":   1.5,
	"bar2":   1.5,
	"tail":   0.9,
	"hold":   0.9,
}

# Envelope VALLEY scales
const PRESET_ENV_VALLEY := {
	"head":   0.9,
	"target": 0.9,
	"bar1":   1.5,
	"bar2":   0.9,
	"tail":   1.5,
	"hold":   1.5,
}

const PRESET_BEATS_PER_PULSE := 0.5
const PRESET_PHASE_BEATS := 0.0
const PRESET_EASE_KEY := "out_elastic"

# ───────────────────────────────────────────────────────────────────────────────
# Entry point
# ───────────────────────────────────────────────────────────────────────────────

func run_script() -> int:
	if _editor == null:
		printerr("[ScalePreset] ❌ Editor not found.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		printerr("[ScalePreset] ❌ No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs := _collect_selected_note_specs()
	if specs.is_empty():
		printerr("[ScalePreset] No valid note specs.")
		return ERR_DOES_NOT_EXIST

	_export_anim_windows(
		specs,
		PRESET_START_SCALES,
		PRESET_END_SCALES,
		PRESET_DENSITY_MS,
		PRESET_IMPACT_CAP,
		PRESET_ATTEN_SLIDES,
		PRESET_ENV_PEAK,
		PRESET_ENV_VALLEY,
		PRESET_BEATS_PER_PULSE,
		PRESET_PHASE_BEATS,
		PRESET_EASE_KEY
	)

	# Ask PH_VFX_MegaInjector to reload so the preset shows in preview/playtest
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", _editor, _get_vfx_path())
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable preview.")

	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[ScalePreset] ✅ Wrote animation windows for selected notes.")
	return OK

# ───────────────────────────────────────────────────────────────────────────────
# Exporter
# ───────────────────────────────────────────────────────────────────────────────

func _export_anim_windows(
	specs: Array,
	start_scales: Dictionary,
	end_scales: Dictionary,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool,
	env_peak: Dictionary,
	env_valley: Dictionary,
	beats_per_pulse: float,
	phase_beats: float,
	ease_key: String
) -> void:
	if specs.is_empty():
		return

	var path := _get_vfx_path()

	# Load & preserve (drop only our tag for selected heads)
	var existing: Array = []
	if FileAccess.file_exists(path):
		var f := FileAccess.open(path, FileAccess.READ)
		if f:
			var parsed := JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_ARRAY:
				existing = parsed
			f.close()

	# Build a unique set of selected heads for this pass
	var selected_keys := {} # "%s@%d@%d" % [layer, note_type, head_t]
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	# Preserve everything except our own tag for the selected keys
	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e); continue
		if String(e.get("layer","")) == "$PLAYFIELD":
			preserved.append(e); continue
		if String(e.get("anim","")) != ANIM_TAG:
			preserved.append(e); continue

		var layer := String(e.get("layer",""))
		var ntype := int(e.get("note_type", -1))
		var head  := int(e.get("anim_note_time", -1))
		if layer == "" or ntype < 0 or head < 0:
			preserved.append(e); continue

		var key := "%s@%d@%d" % [layer, ntype, head]
		if not selected_keys.has(key):
			preserved.append(e)

	# Density attenuation
	var atten_map := _compute_density(specs, density_ms)

	var out_rows := preserved.duplicate()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)
		var is_slide := _is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		# Timeout (ms) exactly as the game uses it
		var timeout_ms := _compute_timeout_ms(ntype, note_obj, head_t)
		if timeout_ms <= 0:
			timeout_ms = 2000

		# Optional: BPM for envelope spacing only (not for timeout)
		var bpm := _bpm_at_ms(head_t)
		if bpm <= 0.0:
			bpm = 120.0

		# Window (strictly before impact)
		var t1 := head_t
		var t0 := max(0, head_t - timeout_ms)
		if t0 >= t1:
			t0 = t1 - 10

		# Impact scales: slide attenuation + head cap
		var end_head_scale := float(end_scales.get("head", 1.0))
		if atten_slides and is_slide:
			end_head_scale = end_head_scale * SLIDE_HIT_ATTEN
		end_head_scale = min(float(end_head_scale), impact_cap)

		# Start row
		out_rows.append(_make_row(
			layer, t0, ntype, head_t, "anim_start",
			_apply_atten(start_scales, lane_atten)
		))

		# Envelope rows (alternating PEAK/VALLEY) strictly inside (t0, t1)
		var beat_ms := int(round(60000.0 / max(1.0, bpm)))
		var pulse_ms := int(round(max(0.001, beats_per_pulse) * beat_ms))
		var phase_ms := int(round(phase_beats * beat_ms))

		var first_tick = t0 + phase_ms
		if first_tick <= t0:
			var k := int(floor(float(t0 - first_tick) / float(pulse_ms))) + 1
			first_tick = first_tick + k * pulse_ms

		var tick = first_tick
		var put_peak := true
		while tick < t1:
			var clamped_tick := max(t0 + 1, min(t1 - 1, tick))
			var env_dict := (env_peak if put_peak else env_valley)
			out_rows.append(_make_row(
				layer, clamped_tick, ntype, head_t, "envelope",
				_apply_atten(env_dict, lane_atten), ease_key
			))
			put_peak = not put_peak
			tick += pulse_ms

		# Impact row
		out_rows.append(_make_row(
			layer, t1, ntype, head_t, "impact",
			_apply_atten(_override_head(end_scales, end_head_scale), lane_atten)
		))

	# Sort & write
	out_rows.sort_custom(func(a, b):
		var la := String(a.get("layer",""))
		var lb := String(b.get("layer",""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD": return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD": return false
		var ta := float(a.get("time",0.0))
		var tb := float(b.get("time",0.0))
		if abs(ta - tb) > 0.0001:
			return ta < tb
		return la < lb
	)

	var lines := PackedStringArray()
	for e in out_rows:
		lines.append(JSON.stringify(e))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[ScalePreset] 💾 Wrote %d rows → %s" % [out_rows.size(), path])
	else:
		printerr("[ScalePreset] ❌ Failed to write VFX JSON.")

func _make_row(
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String,
	scales: Dictionary,
	ease: String = "linear"
) -> Dictionary:
	var d := {
		"layer": layer,
		"time": time_ms,
		"note_type": float(note_type),
		"scale_head":   _r3(_clamp(scales.get("head", 1.0))),
		"scale_target": _r3(_clamp(scales.get("target", 1.0))),
		"scale_bar1":   _r3(_clamp(scales.get("bar1", 1.0))),
		"scale_bar2":   _r3(_clamp(scales.get("bar2", scales.get("bar1", 1.0)))),
		"scale_tail":   _r3(_clamp(scales.get("tail", 1.0))),
		"scale_hold":   _r3(_clamp(scales.get("hold", 1.0))),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time,
	}
	if stage == "envelope":
		d["ease"] = ease
	return d

# ───────────────────────────────────────────────────────────────────────────────
# Helpers
# ───────────────────────────────────────────────────────────────────────────────

static func _r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0

func _clamp(v: Variant) -> float:
	var f := float(v)
	return clamp(f, SCALE_MIN_MAX.x, SCALE_MIN_MAX.y)

func _apply_atten(src: Dictionary, mul: float) -> Dictionary:
	return {
		"head":   float(src.get("head",   1.0)) * mul,
		"target": float(src.get("target", 1.0)) * mul,
		"bar1":   float(src.get("bar1",   1.0)) * mul,
		"bar2":   float(src.get("bar2",   float(src.get("bar1", 1.0)))) * mul,
		"tail":   float(src.get("tail",   1.0)) * mul,
		"hold":   float(src.get("hold",   1.0)) * mul,
	}

func _override_head(src: Dictionary, new_head: float) -> Dictionary:
	var d := src.duplicate()
	d["head"] = new_head
	return d

func _compute_density(specs: Array, _window_ms: int) -> Dictionary:
	# Density attenuation removed - always return 1.0 for all notes
	var out := {}
	for s in specs:
		out["%s@%d@%d" % [String(s["layer"]), int(s["time"]), int(s["note_type"])]] = 1.0
	return out

func _get_rg() -> Object:
	if _editor == null:
		return null
	var rg = _editor.get("rhythm_game")
	if rg is Object:
		return rg
	var pv = _editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	var gp = _editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null

func _compute_timeout_ms(note_type: int, note_obj: Object, t_ms: int) -> int:
	var rg := _get_rg()
	if rg != null:
		# 1) Authoritative per-type+time
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out_for t=", t_ms, " => ", ms, "ms")
			if ms > 0:
				return ms

		# 2) Note instance + speed-at-time
		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))
		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if DEBUG_TIMEOUT:
				print("[timeout] note.get_time_out(speed) t=", t_ms, " speed=", speed, " => ", ms2, "ms")
			if ms2 > 0:
				return ms2

		# 3) Generic timeout on RG
		if (rg as Object).has_method("get_time_out"):
			var try_ms := float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out(...) => ", ms3, "ms")
			if ms3 > 0:
				return ms3

	# 4) Tempo-aware fallback (~8 beats)
	var map = _editor.get_timing_map() if _editor != null else []
	if map and map.size() >= 2:
		var idx := HBUtils.bsearch_upper(map, t_ms)
		var i0 := clamp(idx - 1, 0, map.size() - 1)
		var i1 := clamp(idx, 0, map.size() - 1)
		var beat_ms := max(1, int(map[i1] - map[i0]))
		if DEBUG_TIMEOUT:
			print("[timeout] 8*beat_fallback beat_ms=", beat_ms, " => ", 8 * beat_ms, "ms")
		return 8 * beat_ms

	if DEBUG_TIMEOUT:
		print("[timeout] hard_fallback 2000ms")
	return 2000

func _bpm_at_ms(t_ms: int) -> float:
	var rg := _get_rg()
	if rg != null:
		if (rg as Object).has_method("get_bpm_at_time"):
			return float((rg as Object).call("get_bpm_at_time", t_ms))
		var tm := (rg as Object).get("tempo_map")
		if tm != null and (tm as Object).has_method("get_bpm_at_time"):
			return float((tm as Object).call("get_bpm_at_time", t_ms))

	if _editor != null:
		var em = _editor.get("tempo_map")
		if em != null and (em as Object).has_method("get_bpm_at_time"):
			return float((em as Object).call("get_bpm_at_time", t_ms))

	return 0.0

func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type := int(data_obj.get("note_type"))
			var time_val := int(data_obj.get("time"))
			var layer2 := _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)
			var lname := NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"
			var layer_tag = "layer_" + lname + ( "2" if layer2 else "" )

			var spec := {
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj,
			}

			var dur: Variant = null
			if "duration" in props:
				dur = int(data_obj.get("duration"))
			elif "end_time" in props:
				dur = int(data_obj.get("end_time")) - time_val
			if dur != null and dur > 0:
				spec["sustain_end"] = time_val + int(dur)

			specs.append(spec)
	return specs

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null:
		if int(lidx) == 1:
			return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null:
		if bool(has_flag):
			return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null:
		if String(layer_meta).ends_with("2"):
			return true
	return false

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"

func _is_slide_type(nt: int) -> bool:
	return nt == 4 or nt == 5 or nt == 6 or nt == 7
