#meta:name:Set Distance=10, Osc=0 (Osu-style phase 1)
#meta:description:For all selected notes, sets Distance to 10px and Oscillation Frequency to 0, with full undo/redo.
#meta:usage:Select notes and run. Ideal as a first phase for Osu-style close/fade-in notes.

extends ScriptRunnerScript

const TARGET_DISTANCE := 10.0
const TARGET_OSC_FREQ := 0.0

func run_script() -> int:
	if _editor == null:
		push_error("[OsuPhase1] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if _editor.selected.is_empty():
		push_error("[OsuPhase1] No notes selected.")
		return ERR_DOES_NOT_EXIST

	var items: Array = _editor.selected
	var affected := 0

	# Collect per-note data so we can build undo/redo safely
	var notes_info: Array = []

	for item in items:
		if item == null:
			continue
		if not item.has_variable("data") and not item.has_method("get"):
			continue

		var data_obj = item.data
		if data_obj == null:
			continue
		if not (data_obj is Object):
			continue

		# Check which properties exist on this data object
		var has_distance := false
		var has_osc := false

		if data_obj.has_method("get_property_list"):
			for p in data_obj.get_property_list():
				var pname := str(p.name)
				if pname == "distance":
					has_distance = true
				elif pname == "oscillation_frequency":
					has_osc = true

		if not has_distance and not has_osc:
			continue

		var old_distance := 0.0
		var old_osc := 0.0

		if has_distance:
			old_distance = float(data_obj.get("distance"))
		if has_osc:
			old_osc = float(data_obj.get("oscillation_frequency"))

		notes_info.append({
			"data": data_obj,
			"has_distance": has_distance,
			"has_osc": has_osc,
			"old_distance": old_distance,
			"old_osc": old_osc
		})
		affected += 1

	if affected == 0:
		push_warning("[OsuPhase1] No selected notes had distance/oscillation_frequency properties.")
		return OK

	# Build undo/redo
	var ur = _editor.undo_redo
	ur.create_action("Set Distance=10, OscFreq=0 (Osu-style phase 1)")

	for info in notes_info:
		var d_obj: Object = info["data"]

		if info["has_distance"]:
			var prev_d = info["old_distance"]
			ur.add_do_property(d_obj, "distance", TARGET_DISTANCE)
			ur.add_undo_property(d_obj, "distance", prev_d)

		if info["has_osc"]:
			var prev_o = info["old_osc"]
			ur.add_do_property(d_obj, "oscillation_frequency", TARGET_OSC_FREQ)
			ur.add_undo_property(d_obj, "oscillation_frequency", prev_o)

	# Let the editor know timing points / notes changed so visuals refresh
	if _editor.has_method("_on_timing_points_changed"):
		ur.add_do_method(_editor, "_on_timing_points_changed")
		ur.add_undo_method(_editor, "_on_timing_points_changed")

	ur.commit_action()

	# Nudge preview like the other authoring tools do
	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[OsuPhase1] ✅ Updated %s notes to distance=%s, osc_freq=%s" % [
		str(affected),
		str(TARGET_DISTANCE),
		str(TARGET_OSC_FREQ)
	])

	return OK
