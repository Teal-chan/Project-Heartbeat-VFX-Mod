#meta:name:Osu – Preset Chain (Distance + Scale + Alpha)
#meta:description:Runs make_osu_note.gd, waits a bit, then make_osu_note2.gd, waits again, then make_osu_note3.gd on the current selection.
#meta:usage:Select notes and run. Scripts must live in user://editor_scripts/Presets/.

extends ScriptRunnerScript

const SCRIPT_DIR := "user://editor_scripts/Presets/"
const SCRIPT_ORDER := [
	"make_osu_note.gd",   # Phase 1: distance + osc
	"make_osu_note2.gd",  # Phase 2: scale preset
	"make_osu_note3.gd"   # Phase 3: alpha fade (RGB-preserving)
]

const FRAME_DELAY := 20
const APPROX_FPS := 60.0

func run_script() -> int:
	if _editor == null:
		push_error("[OsuPresetChain] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	print("[OsuPresetChain] 🎯 Starting Osu preset chain.")
	print("[OsuPresetChain]   Dir: %s" % SCRIPT_DIR)
	print("[OsuPresetChain]   Order: %s" % str(SCRIPT_ORDER))

	for i in range(SCRIPT_ORDER.size()):
		var filename: String = SCRIPT_ORDER[i]
		var step_index := i + 1

		print("[OsuPresetChain] 🔁 Step %s: %s" % [str(step_index), filename])

		var rc := _run_child_script(filename)
		print("[OsuPresetChain] ◀ %s.run_script() returned %s" % [filename, str(rc)])

		if int(rc) != OK:
			push_warning("[OsuPresetChain] ⚠ Step %s (%s) returned non-OK: %s" % [str(step_index), filename, str(rc)])

		# Wait between steps, but not after the last one
		if i < SCRIPT_ORDER.size() - 1:
			print("[OsuPresetChain] ⏱ Waiting %s frames before next step..." % str(FRAME_DELAY))
			_wait_frames_approx(FRAME_DELAY)

	print("[OsuPresetChain] ✅ Osu preset chain complete.")
	return OK


func _run_child_script(filename: String) -> int:
	var path := SCRIPT_DIR + filename

	if not FileAccess.file_exists(path):
		push_error("[OsuPresetChain] ❌ Script not found: %s" % path)
		return ERR_FILE_NOT_FOUND

	var code := FileAccess.get_file_as_string(path)
	if code.is_empty():
		push_error("[OsuPresetChain] ❌ Script empty or unreadable: %s" % path)
		return ERR_FILE_CANT_OPEN

	var gd := GDScript.new()
	gd.source_code = code
	var err := gd.reload()
	if err != OK:
		push_error("[OsuPresetChain] ❌ Failed to compile %s (code %s)" % [filename, str(err)])
		return err

	var inst = gd.new()
	if inst == null:
		push_error("[OsuPresetChain] ❌ Failed to instance %s" % filename)
		return ERR_CANT_CREATE

	if inst.has_method("run_script"):
		inst._editor = _editor
		var rc = inst.run_script()
		return int(rc)
	else:
		push_error("[OsuPresetChain] ❌ %s has no run_script() method." % filename)
		return ERR_INVALID_DATA


func _wait_frames_approx(frames: int) -> void:
	var f := max(frames, 0)
	if f <= 0:
		return

	var ms := int(f * (1000.0 / APPROX_FPS))
	var start = Time.get_ticks_msec()  # ⬅️ Godot 4: use Time singleton

	while Time.get_ticks_msec() - start < ms:
		# Tiny busy-wait; enough to give the engine time to apply changes between scripts.
		pass
