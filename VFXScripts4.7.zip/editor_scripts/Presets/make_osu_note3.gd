#meta:name:Osu – Phase 3 (Alpha Fade-In, RGB-Preserving)
#meta:description:For selected notes, writes ColorAnim/v1 rows so icon alpha fades from 0.2 at timeout-start to 1.0 at impact, preserving existing RGB and all other channels.
#meta:usage:Select notes and run. Intended as step 3 after make_osu_note.gd and make_osu_note2.gd.

extends ScriptRunnerScript

const ANIM_TAG := "ColorAnim/v1"

const NOTE_TYPE_NAMES := {
	0:"UP",1:"LEFT",2:"DOWN",3:"RIGHT",
	4:"SLIDE_LEFT",5:"SLIDE_RIGHT",
	6:"SLIDE_CHAIN_PIECE_LEFT",7:"SLIDE_CHAIN_PIECE_RIGHT",
	8:"HEART"
}

const DEFAULT_START_BEFORE_MS := 2000
const DEBUG_TIMEOUT := true

# Alpha values for Osu-style fade
const START_ALPHA := 0.2
const END_ALPHA   := 1.0

func run_script() -> int:
	if _editor == null:
		push_error("[OsuPhase3Alpha] No editor.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[OsuPhase3Alpha] No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs := _collect_selected_note_specs()
	if specs.is_empty():
		push_error("[OsuPhase3Alpha] No valid note specs.")
		return ERR_DOES_NOT_EXIST

	# Timing options: use timeout-based window; do NOT replace existing timings.
	var start_before_ms := DEFAULT_START_BEFORE_MS
	var replace_time := false

	# We only care about ICON alpha; we’ll preserve RGB from existing rows.
	# We'll store Color here just so we can reuse the build helpers, but
	# _merge_row will only read the alpha and keep existing RGB.
	var S := {
		"icon": Color(1.0, 1.0, 1.0, START_ALPHA),
		"target": null,
		"bar1": null,
		"bar2": null,
		"icon_head": null,
		"icon_tail": null,
		"hold_text": null
	}
	var E := {
		"icon": Color(1.0, 1.0, 1.0, END_ALPHA),
		"target": null,
		"bar1": null,
		"bar2": null,
		"icon_head": null,
		"icon_tail": null,
		"hold_text": null
	}

	_merge_and_write(specs, start_before_ms, replace_time, S, E)

	# Nudge VFX preview if available
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", _editor, _get_vfx_path())
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable preview.")

	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[OsuPhase3Alpha] ✅ Wrote alpha-fade ColorAnim/v1 rows (RGB preserved).")
	return OK


# ─────────────────────────────────────────────────────────────
# Merge + IO (based on Color Anim Window v1.2)
# ─────────────────────────────────────────────────────────────
func _merge_and_write(specs: Array, start_before_ms: int, replace_time: bool, S: Dictionary, E: Dictionary) -> void:
	var path := _get_vfx_path()

	var existing_rows: Array = []
	if FileAccess.file_exists(path):
		var f := FileAccess.open(path, FileAccess.READ)
		if f:
			var parsed := JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_ARRAY:
				existing_rows = parsed
			f.close()

	var preserved: Array = []
	var cmap: Dictionary = {}  # key -> row

	for e in existing_rows:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue

		var anim := String(e.get("anim",""))
		if anim != ANIM_TAG:
			preserved.append(e)
			continue

		var layer := String(e.get("layer",""))
		var nt := int(e.get("note_type", -1))
		var head := int(e.get("anim_note_time", -1))
		var stage := String(e.get("anim_stage",""))
		if layer == "" or nt < 0 or head < 0 or stage == "":
			preserved.append(e)
			continue

		# Keep envelope rows exactly as-is; don't merge/dedupe them.
		if stage == "envelope":
			preserved.append(e)
			continue

		var key := "%s@%d@%d@%s" % [layer, nt, head, stage]
		cmap[key] = e

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var timeout_ms := _compute_timeout_ms(ntype, note_obj, head_t)
		if timeout_ms <= 0:
			timeout_ms = DEFAULT_START_BEFORE_MS

		var t0_timeout := head_t - timeout_ms
		var t0_fixed := head_t - start_before_ms
		var t1 := head_t

		var start_cols := _build_start_cols(S, E)
		var end_cols := _build_end_cols(E)

		# anim_start
		var k_start := "%s@%d@%d@%s" % [layer, ntype, head_t, "anim_start"]
		var base_start := {}
		if cmap.has(k_start):
			base_start = cmap[k_start]
		var start_time := (
			t0_fixed if replace_time
			else (int(base_start.get("time", t0_timeout)) if not base_start.is_empty() else t0_timeout)
		)
		var merged_start := _merge_row(base_start, start_cols, layer, ntype, head_t, "anim_start", start_time)
		if not merged_start.is_empty():
			cmap[k_start] = merged_start

		# impact
		var k_end := "%s@%d@%d@%s" % [layer, ntype, head_t, "impact"]
		var base_end := {}
		if cmap.has(k_end):
			base_end = cmap[k_end]
		var end_time := (t1 if replace_time or base_end.is_empty() else int(base_end.get("time", t1)))
		var merged_end := _merge_row(base_end, end_cols, layer, ntype, head_t, "impact", end_time)
		if not merged_end.is_empty():
			cmap[k_end] = merged_end

	# Reassemble: preserved + all color rows
	var out: Array = []
	for p in preserved:
		out.append(p)
	for k in cmap.keys():
		out.append(cmap[k])

	# Sort for readability
	out.sort_custom(func(a, b):
		var la := String(a.get("layer",""))
		var lb := String(b.get("layer",""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		var ta := int(a.get("time",0))
		var tb := int(b.get("time",0))
		if ta != tb:
			return ta < tb
		return la < lb
	)

	var lines := PackedStringArray()
	for e in out:
		lines.append(JSON.stringify(e))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[OsuPhase3Alpha] 💾 Wrote %d rows → %s" % [out.size(), path])
	else:
		push_error("[OsuPhase3Alpha] Failed to write VFX file.")


# 🔧 NEW: only change icon alpha, preserve RGB & other channels
func _merge_row(base_row: Dictionary, cols: Dictionary, layer: String, ntype: int, head_time: int, stage: String, time_ms: int) -> Dictionary:
	var adding := false
	for k in cols.keys():
		if cols[k] != null:
			adding = true
			break
	if base_row.is_empty() and not adding:
		return {}

	var row := {}
	if base_row.is_empty():
		row["layer"] = layer
		row["time"] = time_ms
		row["note_type"] = float(ntype)
		row["anim"] = ANIM_TAG
		row["anim_stage"] = stage
		row["anim_note_time"] = head_time
	else:
		for k in base_row.keys():
			row[k] = base_row[k]
		row["time"] = time_ms

	# --- custom: icon alpha only ---
	var icon_val := cols.get("icon", null)
	if icon_val != null:
		var alpha := 1.0
		if icon_val is Color:
			alpha = float((icon_val as Color).a)
		else:
			alpha = float(icon_val)

		var prev_any = row.get("color_icon", null)
		var arr: Array
		if typeof(prev_any) == TYPE_ARRAY:
			arr = (prev_any as Array).duplicate()
			while arr.size() < 4:
				arr.append(1.0)
		else:
			# No prior color_icon; default to white RGB
			arr = [_r3(1.0), _r3(1.0), _r3(1.0), 1.0]
		arr[3] = _r3(alpha)
		row["color_icon"] = arr

	# Other channels (target, bars, head/tail, hold_text) are left exactly as-is.
	return row


# ─────────────────────────────────────────────────────────────
# Build per-stage channel dicts
# ─────────────────────────────────────────────────────────────
func _build_start_cols(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = _coalesce_color(S.get("icon", null),      E.get("icon", null))
	d["target"]     = _coalesce_color(S.get("target", null),    E.get("target", null))
	d["bar1"]       = _coalesce_color(S.get("bar1", null),      E.get("bar1", null))
	d["bar2"]       = _coalesce_color(S.get("bar2", null),      E.get("bar2", null))
	d["icon_head"]  = _coalesce_color(S.get("icon_head", null), E.get("icon_head", null))
	d["icon_tail"]  = _coalesce_color(S.get("icon_tail", null), E.get("icon_tail", null))
	d["hold_text"]  = _coalesce_color(S.get("hold_text", null), E.get("hold_text", null))
	return d

func _build_end_cols(E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = E.get("icon", null)
	d["target"]     = E.get("target", null)
	d["bar1"]       = E.get("bar1", null)
	d["bar2"]       = E.get("bar2", null)
	d["icon_head"]  = E.get("icon_head", null)
	d["icon_tail"]  = E.get("icon_tail", null)
	d["hold_text"]  = E.get("hold_text", null)
	return d


# ─────────────────────────────────────────────────────────────
# Timeout helpers
# ─────────────────────────────────────────────────────────────
func _get_rg() -> Object:
	if _editor == null:
		return null
	var rg = _editor.get("rhythm_game")
	if rg is Object:
		return rg
	var pv = _editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	var gp = _editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null

func _compute_timeout_ms(note_type: int, note_obj: Object, t_ms: int) -> int:
	var rg := _get_rg()
	if rg != null:
		# 1) Authoritative per-type+time
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out_for t=", t_ms, " => ", ms, "ms")
			if ms > 0:
				return ms

		# 2) Note instance + speed-at-time
		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))
		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if DEBUG_TIMEOUT:
				print("[timeout] note.get_time_out(speed) t=", t_ms, " speed=", speed, " => ", ms2, "ms")
			if ms2 > 0:
				return ms2

		# 3) Some builds expose a generic timeout on RG
		if (rg as Object).has_method("get_time_out"):
			var try_ms := float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out(...) => ", ms3, "ms")
			if ms3 > 0:
				return ms3

	# 4) Tempo-map fallback (~8 beats) using timing_map spacing (ms)
	var map = _editor.get_timing_map() if _editor != null else []
	if map and map.size() >= 2:
		var idx := HBUtils.bsearch_upper(map, t_ms)
		var i0 := clamp(idx - 1, 0, map.size() - 1)
		var i1 := clamp(idx, 0, map.size() - 1)
		var beat_ms := max(1, int(map[i1] - map[i0]))
		if DEBUG_TIMEOUT:
			print("[timeout] 8*beat_fallback beat_ms=", beat_ms, " => ", 8*beat_ms, "ms")
		return 8 * beat_ms

	if DEBUG_TIMEOUT:
		print("[timeout] hard_fallback 2000ms")
	return 2000


# ─────────────────────────────────────────────────────────────
# Selection helpers
# ─────────────────────────────────────────────────────────────
func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type := int(data_obj.get("note_type"))
			var time_val := int(data_obj.get("time"))
			var layer2 := _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)
			var lname := NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"
			var layer_tag = "layer_" + lname + ( "2" if layer2 else "" )
			specs.append({
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj
			})
	return specs

func _safe_get(obj: Object, prop: String, fallback: Variant=null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false


# ─────────────────────────────────────────────────────────────
# Color helpers
# ─────────────────────────────────────────────────────────────
static func _r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0

func _enc_color(c: Color) -> Array:
	return [_r3(c.r), _r3(c.g), _r3(c.b), _r3(c.a)]

func _coalesce_color(a: Variant, b: Variant) -> Variant:
	if a != null:
		return a
	return b

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"
