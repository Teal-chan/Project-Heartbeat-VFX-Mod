#meta:name:Scale Anim – Osu Style (Timeout+Release)
#meta:description:Applies a fixed Osu-style scale window to selected notes using GAME TIMEOUT (start→impact) and release for sustains. Writes ScaleAbsAnim/v1 rows only.
#meta:usage:Select notes and run. Uses: START Head 2.0, Target 1.0, Bar1 2.0, Bar2 2.0, Tail 2.0, Hold 0.4; END Head 1.0, Target 1.0, Bar1 1.5, Bar2 1.5, Tail 1.0, Hold 0.96; Impact cap 1.0; slide impact reduced.

extends ScriptRunnerScript

const ANIM_TAG := "ScaleAbsAnim/v1"
const NOTE_TYPE_NAMES := {
	0: "UP", 1: "LEFT", 2: "DOWN", 3: "RIGHT",
	4: "SLIDE_LEFT", 5: "SLIDE_RIGHT",
	6: "SLIDE_CHAIN_PIECE_LEFT", 7: "SLIDE_CHAIN_PIECE_RIGHT",
	8: "HEART"
}

const SCALE_MIN_MAX := Vector2(0.4, 4.0)
const DENSITY_DEF_MS := 80        # same as your normal window
const SLIDE_HIT_ATTEN := 0.85
const IMPACT_CAP := 1.0           # from screenshot
const DEBUG_TIMEOUT := true       # turn off once happy

# Osu-style preset scales from the screenshot
const PRESET_SCALES_START := {
	"head":  2.0,
	"target":1.0,
	"bar1":  2.0,
	"bar2":  2.0,
	"tail":  2.0,
	"hold":  0.4,
}

const PRESET_SCALES_END := {
	"head":  1.0,
	"target":1.0,
	"bar1":  1.5,
	"bar2":  1.5,
	"tail":  1.0,
	"hold":  0.96,
}

func run_script() -> int:
	if _editor == null:
		printerr("[ScaleAnimOsu] ❌ Editor not found.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		printerr("[ScaleAnimOsu] ❌ No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs := _collect_selected_note_specs()
	if specs.is_empty():
		printerr("[ScaleAnimOsu] ❌ No valid note specs.")
		return ERR_DOES_NOT_EXIST

	var include_release := true           # checkbox in screenshot was checked
	var density_ms := DENSITY_DEF_MS
	var impact_cap := IMPACT_CAP
	var atten_slides := true              # “Reduce slide impact/snap” checked

	_export_anim_windows(
		specs,
		PRESET_SCALES_START,
		PRESET_SCALES_END,
		include_release,
		density_ms,
		impact_cap,
		atten_slides
	)

	# Nudge the preview (same pattern as your other VFX scripts)
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", _editor, _get_vfx_path())
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable live preview.")

	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[ScaleAnimOsu] ✅ Applied Osu-style scale window to %d notes." % specs.size())
	return OK


# ─────────────────────────────────────────────────────────────
# Exporter (lifted from your Scale window, with preset params)
# ─────────────────────────────────────────────────────────────
func _export_anim_windows(specs: Array, start_scales: Dictionary, end_scales: Dictionary,
	include_release: bool, density_ms: int, impact_cap: float, atten_slides: bool) -> void:
	if specs.is_empty():
		return

	var path := _get_vfx_path()
	var existing: Array = []
	if FileAccess.file_exists(path):
		var f := FileAccess.open(path, FileAccess.READ)
		if f:
			var parsed := JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_ARRAY:
				existing = parsed
			f.close()

	var selected_heads := {}
	for s in specs:
		selected_heads[int(s["time"])] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e); continue
		if String(e.get("layer","")) == "$PLAYFIELD":
			preserved.append(e); continue
		if String(e.get("anim","")) != ANIM_TAG:
			preserved.append(e); continue
		var nt := int(e.get("anim_note_time", -999999))
		if not selected_heads.has(nt):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var is_slide := _is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		# Per-note timeout from NOTE INSTANCE (authoritative)
		var start_before_ms := _compute_timeout_ms(ntype, note_obj, head_t)
		if start_before_ms <= 0:
			start_before_ms = 2000

		var t0 := max(0, head_t - start_before_ms)
		var t1 := head_t
		if t0 >= t1:
			t0 = t1 - 10

		# Slide attenuation + head impact cap
		var end_head_scale := float(end_scales.get("head", 1.0))
		if atten_slides and is_slide:
			end_head_scale *= SLIDE_HIT_ATTEN
		end_head_scale = min(end_head_scale, impact_cap)

		# Start / Impact rows
		out_rows.append(_make_row(layer, t0, ntype, head_t, "anim_start",
			_apply_atten(start_scales, lane_atten)))
		out_rows.append(_make_row(layer, t1, ntype, head_t, "impact",
			_apply_atten(_override_head(end_scales, end_head_scale), lane_atten)))

		# Sustain RELEASE window, using timeout at release time
		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_before_ms := _compute_timeout_ms(ntype, note_obj, rel_end)
			if rel_before_ms <= 0:
				rel_before_ms = start_before_ms
			var r0 := max(0, rel_end - rel_before_ms)
			var r1 := rel_end
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(_make_row(layer, r0, ntype, head_t, "release_start",
				_apply_atten(start_scales, lane_atten)))
			out_rows.append(_make_row(layer, r1, ntype, head_t, "release_impact",
				_apply_atten(end_scales, lane_atten)))

	# Sort & write
	out_rows.sort_custom(func(a, b):
		var la := String(a.get("layer",""))
		var lb := String(b.get("layer",""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		var ta := float(a.get("time",0.0))
		var tb := float(b.get("time",0.0))
		if abs(ta - tb) > 0.0001:
			return ta < tb
		return la < lb
	)

	var lines := PackedStringArray()
	for e in out_rows:
		lines.append(JSON.stringify(e))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[ScaleAnimOsu] 💾 Wrote %d rows → %s" % [out_rows.size(), path])
	else:
		printerr("[ScaleAnimOsu] ❌ Failed to write VFX JSON.")


func _make_row(layer: String, time_ms: int, note_type: int, note_head_time: int, stage: String, scales: Dictionary) -> Dictionary:
	return {
		"layer": layer,
		"time": time_ms,
		"note_type": float(note_type),
		"scale_head": _r3(_clamp(scales.get("head", 1.0))),
		"scale_target": _r3(_clamp(scales.get("target", 1.0))),
		"scale_bar1": _r3(_clamp(scales.get("bar1", 1.0))),
		"scale_bar2": _r3(_clamp(scales.get("bar2", scales.get("bar1", 1.0)))),
		"scale_tail": _r3(_clamp(scales.get("tail", 1.0))),
		"scale_hold": _r3(_clamp(scales.get("hold", 1.0))),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time
	}

# ─────────────────────────────────────────────────────────────
# Timeout helpers (same parity as your main Scale script)
# ─────────────────────────────────────────────────────────────
func _get_rg() -> Object:
	if _editor == null:
		return null
	var rg = _editor.get("rhythm_game")
	if rg is Object:
		return rg
	var pv = _editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	var gp = _editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null

func _compute_timeout_ms(note_type: int, note_obj: Object, t_ms: int) -> int:
	var rg := _get_rg()
	if rg != null:
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out_for t=", t_ms, " => ", ms, "ms")
			if ms > 0:
				return ms

		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))

		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if DEBUG_TIMEOUT:
				print("[timeout] note.get_time_out(speed) t=", t_ms, " speed=", speed, " => ", ms2, "ms")
			if ms2 > 0:
				return ms2

		if (rg as Object).has_method("get_time_out"):
			var try_ms := float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out(...) => ", ms3, "ms")
			if ms3 > 0:
				return ms3

	var map = _editor.get_timing_map() if _editor != null else []
	if map and map.size() >= 2:
		var idx := HBUtils.bsearch_upper(map, t_ms)
		var i0 := clamp(idx - 1, 0, map.size() - 1)
		var i1 := clamp(idx, 0, map.size() - 1)
		var beat_ms := max(1, int(map[i1] - map[i0]))
		if DEBUG_TIMEOUT:
			print("[timeout] 8*beat_fallback beat_ms=", beat_ms, " => ", 8 * beat_ms, "ms")
		return 8 * beat_ms

	if DEBUG_TIMEOUT:
		print("[timeout] hard_fallback 2000ms")
	return 2000

# ─────────────────────────────────────────────────────────────
# Misc helpers (copied from your Scale script)
# ─────────────────────────────────────────────────────────────
static func _r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0

func _clamp(v: Variant) -> float:
	var f := float(v)
	return clamp(f, SCALE_MIN_MAX.x, SCALE_MIN_MAX.y)

func _apply_atten(src: Dictionary, mul: float) -> Dictionary:
	return {
		"head": float(src.get("head",1.0)) * mul,
		"target": float(src.get("target",1.0)) * mul,
		"bar1": float(src.get("bar1",1.0)) * mul,
		"bar2": float(src.get("bar2", float(src.get("bar1",1.0)))) * mul,
		"tail": float(src.get("tail",1.0)) * mul,
		"hold": float(src.get("hold",1.0)) * mul
	}

func _override_head(src: Dictionary, new_head: float) -> Dictionary:
	var d := src.duplicate()
	d["head"] = new_head
	return d

func _compute_density(specs: Array, _window_ms: int) -> Dictionary:
	# Density attenuation removed - always return 1.0 for all notes
	var out := {}
	for s in specs:
		out["%s@%d@%d" % [String(s["layer"]), int(s["time"]), int(s["note_type"])]] = 1.0
	return out

func _is_slide_type(nt: int) -> bool:
	return nt == 4 or nt == 5 or nt == 6 or nt == 7

func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type: int = int(data_obj.get("note_type"))
			var time_val: int = int(data_obj.get("time"))

			var layer2: bool = _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)

			var lname: String = NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"

			var layer_tag: String = "layer_" + lname + ( "2" if layer2 else "" )

			var spec := {
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj,
			}

			var dur: Variant = null
			if "duration" in props:
				dur = int(data_obj.get("duration"))
			elif "end_time" in props:
				dur = int(data_obj.get("end_time")) - time_val
			if dur != null and int(dur) > 0:
				spec["sustain_end"] = time_val + int(dur)

			specs.append(spec)
	return specs

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _safe_get(obj: Object, prop: String, fallback: Variant=null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"
