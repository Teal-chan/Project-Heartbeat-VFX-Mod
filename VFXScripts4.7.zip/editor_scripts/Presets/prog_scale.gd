# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Set Scale – Animation Window (Progressive Range) v1.0 (Shader-Unified, Timeout Parity)
#meta:description:Authors per-note animated scale windows using GAME TIMEOUT (start→impact) and optionally at sustain release (start→release impact). Scales are linearly interpolated from Start values on the first selected note to End values on the last selected note.
#meta:usage:Select one or more notes and run. GamePreview updates if the Scale Anim Preview reader is armed.

extends ScriptRunnerScript

const ANIM_TAG := "ScaleAbsAnim/v1"
const NOTE_TYPE_NAMES := {
	0: "UP", 1: "LEFT", 2: "DOWN", 3: "RIGHT",
	4: "SLIDE_LEFT", 5: "SLIDE_RIGHT",
	6: "SLIDE_CHAIN_PIECE_LEFT", 7: "SLIDE_CHAIN_PIECE_RIGHT",
	8: "HEART"
}

const SCALE_MIN_MAX := Vector2(0.4, 4.0)
const DENSITY_DEF_MS := 80
const SLIDE_HIT_ATTEN := 0.85
const IMPACT_CAP := 1.18

# Reasonable defaults; feel free to tweak.
const DEFAULT_SCALES_START := {
	"head": 0.90, "target": 0.90, "bar1": 0.90,
	"bar2": 0.90, "tail": 0.95, "hold": 0.90
}
const DEFAULT_SCALES_END := {
	"head": 1.22, "target": 1.04, "bar1": 0.96,
	"bar2": 0.96, "tail": 1.12, "hold": 0.96
}

const DEBUG_TIMEOUT := false

# ───────────────────────────────────────────────────────────────────────────────
# Entry
# ───────────────────────────────────────────────────────────────────────────────

func run_script() -> int:
	if _editor == null:
		printerr("[ScaleAnimWindowProgressive] ❌ Editor not found.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		printerr("[ScaleAnimWindowProgressive] ❌ No notes selected.")
		return ERR_DOES_NOT_EXIST

	var popup := ConfirmationDialog.new()
	popup.title = "Scale Animation Window (Progressive Range – Start → End)"
	popup.min_size = Vector2(680, 560)

	var vbox := VBoxContainer.new()
	popup.add_child(vbox)

	# Timing info / density
	var row := HBoxContainer.new()
	vbox.add_child(row)
	row.add_child(_mk_label("Start window length source:"))
	var Ls := _mk_label("GAME TIMEOUT per note (same as Timeout Window)")
	Ls.add_theme_color_override("font_color", Color(0.8, 1.0, 0.8))
	row.add_child(Ls)
	row.add_child(_mk_spacer())
	row.add_child(_mk_label("Density window (ms):"))
	var sb_density := SpinBox.new()
	sb_density.min_value = 0
	sb_density.max_value = 200
	sb_density.step = 5
	sb_density.value = DENSITY_DEF_MS
	row.add_child(sb_density)

	# Release window toggle
	var row2 := HBoxContainer.new()
	vbox.add_child(row2)
	var cb_release := CheckBox.new()
	cb_release.text = "Also author RELEASE window for sustains (uses GAME TIMEOUT @ release)"
	cb_release.button_pressed = true
	row2.add_child(cb_release)
	row2.add_child(_mk_spacer())

	# Progressive scales UI: Start → End
	vbox.add_child(_mk_section_label("Start scales (applied to first selected note)"))
	var grid_start := GridContainer.new()
	grid_start.columns = 6
	vbox.add_child(grid_start)

	var in_start_head   := _mk_scale_field(grid_start, "Head",   DEFAULT_SCALES_START["head"])
	var in_start_target := _mk_scale_field(grid_start, "Target", DEFAULT_SCALES_START["target"])
	var in_start_bar1   := _mk_scale_field(grid_start, "Bar 1",  DEFAULT_SCALES_START["bar1"])
	var in_start_bar2   := _mk_scale_field(grid_start, "Bar 2",  DEFAULT_SCALES_START["bar2"])
	var in_start_tail   := _mk_scale_field(grid_start, "Tail",   DEFAULT_SCALES_START["tail"])
	var in_start_hold   := _mk_scale_field(grid_start, "Hold",   DEFAULT_SCALES_START["hold"])

	vbox.add_child(_mk_section_label("End scales (applied to last selected note)"))
	var grid_end := GridContainer.new()
	grid_end.columns = 6
	vbox.add_child(grid_end)

	var in_end_head   := _mk_scale_field(grid_end, "Head",   DEFAULT_SCALES_END["head"])
	var in_end_target := _mk_scale_field(grid_end, "Target", DEFAULT_SCALES_END["target"])
	var in_end_bar1   := _mk_scale_field(grid_end, "Bar 1",  DEFAULT_SCALES_END["bar1"])
	var in_end_bar2   := _mk_scale_field(grid_end, "Bar 2",  DEFAULT_SCALES_END["bar2"])
	var in_end_tail   := _mk_scale_field(grid_end, "Tail",   DEFAULT_SCALES_END["tail"])
	var in_end_hold   := _mk_scale_field(grid_end, "Hold",   DEFAULT_SCALES_END["hold"])

	# Impact cap + slide attenuation
	var row3 := HBoxContainer.new()
	vbox.add_child(row3)
	row3.add_child(_mk_label("Impact cap (head):"))
	var sb_cap := SpinBox.new()
	sb_cap.min_value = SCALE_MIN_MAX.x
	sb_cap.max_value = SCALE_MIN_MAX.y
	sb_cap.step = 0.01
	sb_cap.value = IMPACT_CAP
	row3.add_child(sb_cap)
	var cb_slide := CheckBox.new()
	cb_slide.text = "Reduce slide impact/snap (legibility)"
	cb_slide.button_pressed = true
	row3.add_child(cb_slide)
	row3.add_child(_mk_spacer())

	popup.get_ok_button().text = "Write rows"
	_editor.add_child(popup)
	popup.popup_centered()

	popup.confirmed.connect(func():
		var specs := _collect_selected_note_specs()
		if specs.is_empty():
			printerr("[ScaleAnimWindowProgressive] No valid note specs.")
			popup.queue_free()
			return

		# Ensure "progressive" is in chronological order
		specs.sort_custom(func(a, b):
			return int(a["time"]) < int(b["time"])
		)

		var density_ms := int(sb_density.value)
		var cap := float(sb_cap.value)
		var atten_slides := cb_slide.button_pressed

		var start_scales_global := {
			"head":   float(in_start_head.value),
			"target": float(in_start_target.value),
			"bar1":   float(in_start_bar1.value),
			"bar2":   float(in_start_bar2.value),
			"tail":   float(in_start_tail.value),
			"hold":   float(in_start_hold.value)
		}

		var end_scales_global := {
			"head":   float(in_end_head.value),
			"target": float(in_end_target.value),
			"bar1":   float(in_end_bar1.value),
			"bar2":   float(in_end_bar2.value),
			"tail":   float(in_end_tail.value),
			"hold":   float(in_end_hold.value)
		}

		_export_anim_windows(
			specs,
			start_scales_global,
			end_scales_global,
			cb_release.button_pressed,
			density_ms,
			cap,
			atten_slides
		)

		# Preview nudge
		var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
		if mgr:
			if mgr.has_method("reload_now"):
				mgr.call_deferred("reload_now")
			else:
				if mgr.has_method("disarm"):
					mgr.call("disarm")
				if mgr.has_method("configure"):
					mgr.call("configure", _editor, _get_vfx_path())
				if mgr.has_method("arm"):
					mgr.call_deferred("arm")
		else:
			if _editor.message_shower:
				_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable live preview.")

		if _editor.game_preview and not _editor.game_playback.is_playing():
			_editor.game_preview.set_visualizer_processing_enabled(true)
		if _editor.has_method("force_game_process"):
			_editor.force_game_process()

		print("[ScaleAnimWindowProgressive] ✅ Wrote animation windows.")
		popup.queue_free()
	)

	return OK

# ───────────────────────────────────────────────────────────────────────────────
# Exporter – progressive per-note scales
# ───────────────────────────────────────────────────────────────────────────────

func _export_anim_windows(
	specs: Array,
	start_scales_global: Dictionary,
	end_scales_global: Dictionary,
	include_release: bool,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool
) -> void:
	if specs.is_empty():
		return

	var path := _get_vfx_path()

	# Load existing rows
	var existing: Array = []
	if FileAccess.file_exists(path):
		var f := FileAccess.open(path, FileAccess.READ)
		if f:
			var parsed := JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_ARRAY:
				existing = parsed
			f.close()

	# Build a unique key set for selected heads
	var selected_keys := {} # "%s@%d@%d" % [layer, note_type, head_t]
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	# Preserve everything except our own tag for the selected keys
	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue

		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue

		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer := String(e.get("layer", ""))
		var ntype := int(e.get("note_type", -1))
		var head  := int(e.get("anim_note_time", -1))
		if layer == "" or ntype < 0 or head < 0:
			preserved.append(e)
			continue

		var key := "%s@%d@%d" % [layer, ntype, head]
		if not selected_keys.has(key):
			preserved.append(e)

	# Density attenuation
	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()

	var count := specs.size()
	if count <= 0:
		return

	for i in range(count):
		var spec = specs[i]

		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var is_slide := _is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		# Progressive factor: 0.0 → first note, 1.0 → last note
		var t := 0.0
		if count > 1:
			t = float(i) / float(count - 1)

		# Per-note base scales, same for start / impact / release
		var base_scales := _lerp_scales_dict(start_scales_global, end_scales_global, t)

		# Per-note timeout from the NOTE INSTANCE (authoritative)
		var start_before_ms := _compute_timeout_ms(ntype, note_obj, head_t)
		if start_before_ms <= 0:
			start_before_ms = 2000

		var t0 := max(0, head_t - start_before_ms)
		var t1 := head_t
		if t0 >= t1:
			t0 = t1 - 10

		# Slide attenuation + head impact cap
		var end_head_scale := float(base_scales.get("head", 1.0))
		if atten_slides and is_slide:
			end_head_scale *= SLIDE_HIT_ATTEN
		end_head_scale = min(end_head_scale, impact_cap)

		# Start row
		out_rows.append(
			_make_row(
				layer,
				t0,
				ntype,
				head_t,
				"anim_start",
				_apply_atten(base_scales, lane_atten)
			)
		)

		# Impact row (head overridden for slide attenuation / cap)
		out_rows.append(
			_make_row(
				layer,
				t1,
				ntype,
				head_t,
				"impact",
				_apply_atten(_override_head(base_scales, end_head_scale), lane_atten)
			)
		)

		# Optional sustain RELEASE window, using the same per-note base scales
		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_before_ms := _compute_timeout_ms(ntype, note_obj, rel_end)
			if rel_before_ms <= 0:
				rel_before_ms = start_before_ms
			var r0 := max(0, rel_end - rel_before_ms)
			var r1 := rel_end
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(
				_make_row(
					layer,
					r0,
					ntype,
					head_t,
					"release_start",
					_apply_atten(base_scales, lane_atten)
				)
			)
			out_rows.append(
				_make_row(
					layer,
					r1,
					ntype,
					head_t,
					"release_impact",
					_apply_atten(base_scales, lane_atten)
				)
			)

	# Sort & write
	out_rows.sort_custom(func(a, b):
		var la := String(a.get("layer", ""))
		var lb := String(b.get("layer", ""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		var ta := float(a.get("time", 0.0))
		var tb := float(b.get("time", 0.0))
		if abs(ta - tb) > 0.0001:
			return ta < tb
		return la < lb
	)

	var lines := PackedStringArray()
	for e in out_rows:
		lines.append(JSON.stringify(e))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[ScaleAnimWindowProgressive] 💾 Wrote %d rows → %s" % [out_rows.size(), path])
	else:
		printerr("[ScaleAnimWindowProgressive] ❌ Failed to write VFX JSON.")

# ───────────────────────────────────────────────────────────────────────────────
# Helpers
# ───────────────────────────────────────────────────────────────────────────────

func _make_row(
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String,
	scales: Dictionary
) -> Dictionary:
	return {
		"layer": layer,
		"time": time_ms,
		"note_type": float(note_type),
		"scale_head":   _r3(_clamp(scales.get("head", 1.0))),
		"scale_target": _r3(_clamp(scales.get("target", 1.0))),
		"scale_bar1":   _r3(_clamp(scales.get("bar1", 1.0))),
		"scale_bar2":   _r3(_clamp(scales.get("bar2", scales.get("bar1", 1.0)))),
		"scale_tail":   _r3(_clamp(scales.get("tail", 1.0))),
		"scale_hold":   _r3(_clamp(scales.get("hold", 1.0))),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time
	}

func _lerp_scales_dict(a: Dictionary, b: Dictionary, t: float) -> Dictionary:
	var res := {}
	var keys := ["head", "target", "bar1", "bar2", "tail", "hold"]
	for k in keys:
		var av := float(a.get(k, 1.0))
		var bv := float(b.get(k, 1.0))
		res[k] = av + (bv - av) * t
	return res

static func _r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0

func _clamp(v: Variant) -> float:
	var f := float(v)
	return clamp(f, SCALE_MIN_MAX.x, SCALE_MIN_MAX.y)

func _apply_atten(src: Dictionary, mul: float) -> Dictionary:
	return {
		"head":   float(src.get("head", 1.0)) * mul,
		"target": float(src.get("target", 1.0)) * mul,
		"bar1":   float(src.get("bar1", 1.0)) * mul,
		"bar2":   float(src.get("bar2", float(src.get("bar1", 1.0)))) * mul,
		"tail":   float(src.get("tail", 1.0)) * mul,
		"hold":   float(src.get("hold", 1.0)) * mul
	}

func _override_head(src: Dictionary, new_head: float) -> Dictionary:
	var d := src.duplicate()
	d["head"] = new_head
	return d

func _compute_density(specs: Array, _window_ms: int) -> Dictionary:
	# Density attenuation removed - always return 1.0 for all notes
	var out := {}
	for s in specs:
		out["%s@%d@%d" % [String(s["layer"]), int(s["time"]), int(s["note_type"])]] = 1.0
	return out

# ───────────────────────────────────────────────────────────────────────────────
# Timeout / game access
# ───────────────────────────────────────────────────────────────────────────────

func _get_rg() -> Object:
	if _editor == null:
		return null
	var rg = _editor.get("rhythm_game")
	if rg is Object:
		return rg
	var pv = _editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	var gp = _editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null

func _compute_timeout_ms(note_type: int, note_obj: Object, t_ms: int) -> int:
	var rg := _get_rg()
	if rg != null:
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out_for t=", t_ms, " => ", ms, "ms")
			if ms > 0:
				return ms

		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))

		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if DEBUG_TIMEOUT:
				print("[timeout] note.get_time_out(speed) t=", t_ms, " speed=", speed, " => ", ms2, "ms")
			if ms2 > 0:
				return ms2

		if (rg as Object).has_method("get_time_out"):
			var try_ms := float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out(...) => ", ms3, "ms")
			if ms3 > 0:
				return ms3

	var map = _editor.get_timing_map() if _editor != null else []
	if map and map.size() >= 2:
		var idx := HBUtils.bsearch_upper(map, t_ms)
		var i0 := clamp(idx - 1, 0, map.size() - 1)
		var i1 := clamp(idx, 0, map.size() - 1)
		var beat_ms := max(1, int(map[i1] - map[i0]))
		if DEBUG_TIMEOUT:
			print("[timeout] 8*beat_fallback beat_ms=", beat_ms, " => ", 8 * beat_ms, "ms")
		return 8 * beat_ms

	if DEBUG_TIMEOUT:
		print("[timeout] hard_fallback 2000ms")
	return 2000

# ───────────────────────────────────────────────────────────────────────────────
# Selection helpers
# ───────────────────────────────────────────────────────────────────────────────

func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type: int = int(data_obj.get("note_type"))
			var time_val: int = int(data_obj.get("time"))

			var layer2: bool = _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)

			var lname: String = NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"

			var layer_tag: String = "layer_" + lname + ("2" if layer2 else "")

			var spec := {
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj,
			}

			var dur: Variant = null
			if "duration" in props:
				dur = int(data_obj.get("duration"))
			elif "end_time" in props:
				dur = int(data_obj.get("end_time")) - time_val
			if dur != null and int(dur) > 0:
				spec["sustain_end"] = time_val + int(dur)

			specs.append(spec)
	return specs

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false

func _is_slide_type(nt: int) -> bool:
	return nt == 4 or nt == 5 or nt == 6 or nt == 7

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"

# ───────────────────────────────────────────────────────────────────────────────
# Tiny UI helpers
# ───────────────────────────────────────────────────────────────────────────────

func _mk_section_label(t: String) -> Label:
	var L := Label.new()
	L.text = t
	L.add_theme_color_override("font_color", Color(0.85, 0.85, 1.0))
	return L

func _mk_label(t: String) -> Label:
	var L := Label.new()
	L.text = t
	return L

func _mk_spacer() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return c

func _mk_scale_field(grid: GridContainer, title: String, def_val: float) -> SpinBox:
	grid.add_child(_mk_label(title))
	var sb := SpinBox.new()
	sb.min_value = SCALE_MIN_MAX.x
	sb.max_value = SCALE_MIN_MAX.y
	sb.step = 0.01
	sb.value = def_val
	grid.add_child(sb)
	return sb
