#meta:name:Preset – Restore Xbox/Steam Deck Colors
#meta:description:Restores Xbox/Steam Deck default colors via ColorAnim/v1 (anim_start→impact) using GAME TIMEOUT per note. START=END so color is flat; preserves envelope rows.
#meta:usage:Select notes and run. Uses same timing + merge rules as Color Anim Window v1.2.

extends ScriptRunnerScript

const ANIM_TAG := "ColorAnim/v1"

const NOTE_TYPE_NAMES := {
	0:"UP",1:"LEFT",2:"DOWN",3:"RIGHT",
	4:"SLIDE_LEFT",5:"SLIDE_RIGHT",
	6:"SLIDE_CHAIN_PIECE_LEFT",7:"SLIDE_CHAIN_PIECE_RIGHT",
	8:"HEART"
}

const DEFAULT_START_BEFORE_MS := 2000
const DEBUG_TIMEOUT := false

# PlayStation palette
const COLOR_PURPLE := Color(0.6, 0.2, 0.8, 1.0)
const COLOR_GOLD   := Color(1.0, 0.842, 0.0, 1.0)

# Icon colors per lane tag (layer_ + name [+2])
const LAYER_ICON_COLORS := {
	"layer_UP":    Color(0.925, 0.859, 0.200, 1.0),  # Y - Yellow
	"layer_DOWN":  Color(0.235, 0.859, 0.306, 1.0),  # A - green
	"layer_LEFT":  Color(0.251, 0.8, 0.816, 1.0),  # X - blue
	"layer_RIGHT": Color(0.816, 0.259, 0.259, 1.0),  # B - red
	"layer_SLIDE_LEFT":  COLOR_GOLD,
	"layer_SLIDE_RIGHT": COLOR_GOLD,
	"layer_HEART": COLOR_PURPLE,

	# Second lanes: same colors
	"layer_SLIDE_LEFT2":  COLOR_GOLD,
	"layer_SLIDE_RIGHT2": COLOR_GOLD,
	"layer_HEART2": COLOR_PURPLE
}

func run_script() -> int:
	if _editor == null:
		push_error("[PSColorPreset] No editor.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[PSColorPreset] No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs := _collect_selected_note_specs()
	if specs.is_empty():
		push_error("[PSColorPreset] No valid note specs.")
		return ERR_DOES_NOT_EXIST

	_merge_and_write(specs, DEFAULT_START_BEFORE_MS, false)

	# Refresh VFX preview
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", _editor, _get_vfx_path())
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable preview.")

	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[PSColorPreset] ✅ Restored PlayStation colors via ColorAnim/v1.")
	return OK


# ─────────────────────────────────────────────
# Merge + IO (based on Color Anim Window v1.2)
# ─────────────────────────────────────────────
func _merge_and_write(specs: Array, start_before_ms: int, replace_time: bool) -> void:
	var path := _get_vfx_path()

	var existing_rows: Array = []
	if FileAccess.file_exists(path):
		var f := FileAccess.open(path, FileAccess.READ)
		if f:
			var parsed := JSON.parse_string(f.get_as_text())
			if typeof(parsed) == TYPE_ARRAY:
				existing_rows = parsed
			f.close()

	var preserved: Array = []
	var cmap: Dictionary = {}  # key -> row
	for e in existing_rows:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue

		var anim := String(e.get("anim",""))
		if anim != ANIM_TAG:
			preserved.append(e)
			continue

		var layer := String(e.get("layer",""))
		var nt := int(e.get("note_type", -1))
		var head := int(e.get("anim_note_time", -1))
		var stage := String(e.get("anim_stage",""))
		if layer == "" or nt < 0 or head < 0 or stage == "":
			preserved.append(e)
			continue

		# Keep envelope rows untouched
		if stage == "envelope":
			preserved.append(e)
			continue

		var key := "%s@%d@%d@%s" % [layer, nt, head, stage]
		cmap[key] = e

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		# Lookup PS palette for this lane / note
		var ps_data := _get_ps_color_dicts(layer, ntype)
		if ps_data.is_empty():
			continue  # unsupported lane; skip

		var S: Dictionary = ps_data[0]
		var E: Dictionary = ps_data[1]

		# Timeout-based window
		var timeout_ms := _compute_timeout_ms(ntype, note_obj, head_t)
		if timeout_ms <= 0:
			timeout_ms = DEFAULT_START_BEFORE_MS
		var t0_timeout := head_t - timeout_ms
		var t0_fixed := head_t - start_before_ms
		var t1 := head_t

		var start_cols := _build_start_cols(S, E)
		var end_cols := _build_end_cols(E)

		# anim_start
		var k_start := "%s@%d@%d@%s" % [layer, ntype, head_t, "anim_start"]
		var base_start := {}
		if cmap.has(k_start):
			base_start = cmap[k_start]
		var start_time := (
			t0_fixed if replace_time
			else (int(base_start.get("time", t0_timeout)) if not base_start.is_empty() else t0_timeout)
		)
		var merged_start := _merge_row(base_start, start_cols, layer, ntype, head_t, "anim_start", start_time)
		if not merged_start.is_empty():
			cmap[k_start] = merged_start

		# impact
		var k_end := "%s@%d@%d@%s" % [layer, ntype, head_t, "impact"]
		var base_end := {}
		if cmap.has(k_end):
			base_end = cmap[k_end]
		var end_time := (t1 if replace_time or base_end.is_empty() else int(base_end.get("time", t1)))
		var merged_end := _merge_row(base_end, end_cols, layer, ntype, head_t, "impact", end_time)
		if not merged_end.is_empty():
			cmap[k_end] = merged_end

	# Reassemble output
	var out: Array = []
	for p in preserved:
		out.append(p)
	for k in cmap.keys():
		out.append(cmap[k])

	# Sort for readability
	out.sort_custom(func(a, b):
		var la := String(a.get("layer",""))
		var lb := String(b.get("layer",""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		var ta := int(a.get("time",0))
		var tb := int(b.get("time",0))
		if ta != tb:
			return ta < tb
		return la < lb
	)

	var lines := PackedStringArray()
	for e in out:
		lines.append(JSON.stringify(e))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[PSColorPreset] 💾 Wrote %d rows → %s" % [out.size(), path])
	else:
		push_error("[PSColorPreset] Failed to write VFX file.")


func _merge_row(base_row: Dictionary, cols: Dictionary, layer: String, ntype: int, head_time: int, stage: String, time_ms: int) -> Dictionary:
	var adding := false
	for k in cols.keys():
		if cols[k] != null:
			adding = true
			break
	if base_row.is_empty() and not adding:
		return {}

	var row := {}
	if base_row.is_empty():
		row["layer"] = layer
		row["time"] = time_ms
		row["note_type"] = float(ntype)
		row["anim"] = ANIM_TAG
		row["anim_stage"] = stage
		row["anim_note_time"] = head_time
	else:
		for k in base_row.keys():
			row[k] = base_row[k]
		row["time"] = time_ms

	_apply_color_if_any(row, "color_icon",      cols.get("icon", null))
	_apply_color_if_any(row, "color_target",    cols.get("target", null))
	_apply_color_if_any(row, "color_bar1",      cols.get("bar1", null))
	_apply_color_if_any(row, "color_bar2",      cols.get("bar2", null))
	_apply_color_if_any(row, "color_icon_head", cols.get("icon_head", null))
	_apply_color_if_any(row, "color_icon_tail", cols.get("icon_tail", null))
	_apply_color_if_any(row, "color_hold_text", cols.get("hold_text", null))
	return row


# ─────────────────────────────────────────────
# PlayStation color helpers
# ─────────────────────────────────────────────
func _get_ps_color_dicts(layer_tag: String, note_type: int) -> Array:
	var icon_col: Variant = null
	if LAYER_ICON_COLORS.has(layer_tag):
		icon_col = LAYER_ICON_COLORS[layer_tag]

	var target_col: Variant = null
	# Slides & heart: golden target ring by default
	if note_type in [4,5,6,7,8]:
		target_col = COLOR_GOLD

	if icon_col == null and target_col == null:
		return []  # nothing to do for this note

	var S := {
		"icon":      icon_col,
		"target":    target_col,
		"bar1":      null,
		"bar2":      null,
		"icon_head": null,
		"icon_tail": null,
		"hold_text": null
	}
	var E := {
		"icon":      icon_col,
		"target":    target_col,
		"bar1":      null,
		"bar2":      null,
		"icon_head": null,
		"icon_tail": null,
		"hold_text": null
	}
	return [S, E]


func _build_start_cols(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = _coalesce_color(S.get("icon", null),      E.get("icon", null))
	d["target"]     = _coalesce_color(S.get("target", null),    E.get("target", null))
	d["bar1"]       = _coalesce_color(S.get("bar1", null),      E.get("bar1", null))
	d["bar2"]       = _coalesce_color(S.get("bar2", null),      E.get("bar2", null))
	d["icon_head"]  = _coalesce_color(S.get("icon_head", null), E.get("icon_head", null))
	d["icon_tail"]  = _coalesce_color(S.get("icon_tail", null), E.get("icon_tail", null))
	d["hold_text"]  = _coalesce_color(S.get("hold_text", null), E.get("hold_text", null))
	return d

func _build_end_cols(E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = E.get("icon", null)
	d["target"]     = E.get("target", null)
	d["bar1"]       = E.get("bar1", null)
	d["bar2"]       = E.get("bar2", null)
	d["icon_head"]  = E.get("icon_head", null)
	d["icon_tail"]  = E.get("icon_tail", null)
	d["hold_text"]  = E.get("hold_text", null)
	return d


# ─────────────────────────────────────────────
# Timeout helpers (same as Color v1.2)
# ─────────────────────────────────────────────
func _get_rg() -> Object:
	if _editor == null:
		return null
	var rg = _editor.get("rhythm_game")
	if rg is Object:
		return rg
	var pv = _editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	var gp = _editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null


func _compute_timeout_ms(note_type: int, note_obj: Object, t_ms: int) -> int:
	var rg := _get_rg()
	if rg != null:
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out_for t=", t_ms, " => ", ms, "ms")
			if ms > 0:
				return ms

		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))
		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if DEBUG_TIMEOUT:
				print("[timeout] note.get_time_out(speed) t=", t_ms, " speed=", speed, " => ", ms2, "ms")
			if ms2 > 0:
				return ms2

		if (rg as Object).has_method("get_time_out"):
			var try_ms := float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if DEBUG_TIMEOUT:
				print("[timeout] rg.get_time_out(...) => ", ms3, "ms")
			if ms3 > 0:
				return ms3

	var map = _editor.get_timing_map() if _editor != null else []
	if map and map.size() >= 2:
		var idx := HBUtils.bsearch_upper(map, t_ms)
		var i0 := clamp(idx - 1, 0, map.size() - 1)
		var i1 := clamp(idx, 0, map.size() - 1)
		var beat_ms := max(1, int(map[i1] - map[i0]))
		if DEBUG_TIMEOUT:
			print("[timeout] 8*beat_fallback beat_ms=", beat_ms, " => ", 8*beat_ms, "ms")
		return 8 * beat_ms

	if DEBUG_TIMEOUT:
		print("[timeout] hard_fallback 2000ms")
	return 2000


# ─────────────────────────────────────────────
# Selection / helpers
# ─────────────────────────────────────────────
func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type := int(data_obj.get("note_type"))
			var time_val := int(data_obj.get("time"))
			var layer2 := _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)
			var lname := NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"
			var layer_tag = "layer_" + lname + ( "2" if layer2 else "" )
			specs.append({
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj
			})
	return specs


func _safe_get(obj: Object, prop: String, fallback: Variant=null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback


func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out


func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false


func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"


# Small color helpers
static func _r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0

func _enc_color(c: Color) -> Array:
	return [_r3(c.r), _r3(c.g), _r3(c.b), _r3(c.a)]

func _apply_color_if_any(dst: Dictionary, key: String, col: Variant) -> void:
	if col == null:
		return
	if col is Color:
		dst[key] = _enc_color(col)

func _coalesce_color(a: Variant, b: Variant) -> Variant:
	if a != null:
		return a
	return b
