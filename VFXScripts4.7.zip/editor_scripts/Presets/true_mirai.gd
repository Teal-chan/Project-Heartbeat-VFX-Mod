# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Mirai – True Mirai Link (Chain)
#meta:description:Runs MiraiVFX.gd (Mirai link), then make_osu_note2.gd, then make_osu_note3.gd on the current selection, with a short delay between each.
#meta:usage:Select notes and run. Child scripts must live in user://editor_scripts/Presets/.

extends ScriptRunnerScript

const SCRIPT_DIR := "user://editor_scripts/Presets/"

const SCRIPT_ORDER := [
	"MiraiVFX.gd",        # Phase 1: Mirai link VFX (distance/timeout/etc)
	"make_osu_note2.gd",  # Phase 2: distance/scale preset
	"make_osu_note3.gd",  # Phase 3: alpha fade
]

const FRAME_DELAY := 20
const APPROX_FPS := 60.0


func run_script() -> int:
	if _editor == null:
		push_error("[TrueMiraiChain] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if _editor.selected.is_empty():
		push_warning("[TrueMiraiChain] No notes selected; child scripts may do nothing.")

	print("[TrueMiraiChain] 🎯 Starting True Mirai preset chain.")
	print("[TrueMiraiChain]   Dir: %s" % SCRIPT_DIR)
	print("[TrueMiraiChain]   Order: %s" % str(SCRIPT_ORDER))

	for i in range(SCRIPT_ORDER.size()):
		var filename: String = SCRIPT_ORDER[i]
		var step_index := i + 1

		print("[TrueMiraiChain] 🔁 Step %s: %s" % [str(step_index), filename])

		var rc := _run_child_script(filename)
		print("[TrueMiraiChain] ◀ %s.run_script() returned %s" % [filename, str(rc)])

		if int(rc) != OK:
			push_warning("[TrueMiraiChain] ⚠ Step %s (%s) returned non-OK: %s" % [str(step_index), filename, str(rc)])

		# Wait between steps, but not after the last one
		if i < SCRIPT_ORDER.size() - 1:
			print("[TrueMiraiChain] ⏱ Waiting %s frames before next step..." % str(FRAME_DELAY))
			_wait_frames_approx(FRAME_DELAY)

	print("[TrueMiraiChain] ✅ True Mirai preset chain complete.")
	return OK


func _run_child_script(filename: String) -> int:
	var path := SCRIPT_DIR + filename

	var file := FileAccess.open(path, FileAccess.READ)
	var err := FileAccess.get_open_error()
	if err != OK:
		push_error("[TrueMiraiChain] ❌ Error loading %s (code %d)" % [path, err])
		return ERR_FILE_CANT_OPEN

	var script := GDScript.new()
	script.source_code = file.get_as_text()
	var reload_err := script.reload()
	if reload_err != OK:
		push_error("[TrueMiraiChain] ❌ Failed to compile %s (code %d)" % [filename, reload_err])
		return reload_err

	var inst = script.new()
	if inst == null:
		push_error("[TrueMiraiChain] ❌ Failed to instance %s" % filename)
		return ERR_CANT_CREATE

	# ScriptRunnerScript child → run + apply its timing-point changes directly
	if inst is ScriptRunnerScript:
		var runner := inst as ScriptRunnerScript
		runner._editor = _editor
		if runner.has_method("init_script"):
			runner.init_script()
		if runner.has_method("run_script"):
			var rc := int(runner.run_script())
			if rc == OK:
				_apply_child_changes(runner)
			return rc

		push_error("[TrueMiraiChain] ❌ %s has no run_script() method." % filename)
		return ERR_INVALID_DATA

	# Plain tool with run(editor)
	if inst.has_method("run"):
		inst.run(_editor)
		return OK

	push_error("[TrueMiraiChain] ❌ %s has no supported entry point." % filename)
	return ERR_INVALID_DATA


func _apply_child_changes(inst: ScriptRunnerScript) -> void:
	# Apply timing-point property changes from a child ScriptRunnerScript
	# directly to the real timing points. This bypasses undo/redo, but makes
	# chained tools (like MiraiVFX) actually modify the chart.
	if inst == null:
		return
	if inst._timing_point_changed_properties.is_empty():
		return

	for clone in inst._timing_point_changed_properties:
		var changed_props: Dictionary = inst._timing_point_changed_properties[clone]
		var target_item = inst._clone_to_original_timing_point_map.get(clone, null)
		if target_item == null:
			continue
		# target_item.data is the real HBNoteData / timing point data object.
		var data_obj = target_item.data
		if data_obj == null:
			continue

		for property_name in changed_props.keys():
			if property_name in data_obj:
				data_obj.set(property_name, changed_props[property_name])
				if property_name == "position":
					# Mark as manually moved, same as editor would.
					if "pos_modified" in data_obj:
						data_obj.pos_modified = true

	# Let the editor refresh visuals if possible
	if _editor != null:
		if _editor.has_method("timing_points_changed"):
			_editor.timing_points_changed()
		if _editor.has_method("sync_inspector_values"):
			_editor.sync_inspector_values()


func _wait_frames_approx(frames: int) -> void:
	var f := max(frames, 0)
	if f <= 0:
		return

	var ms := int(f * (1000.0 / APPROX_FPS))
	var start := Time.get_ticks_msec()

	while Time.get_ticks_msec() - start < ms:
		# Tiny busy-wait; enough to give the engine time to apply changes between scripts.
		pass
