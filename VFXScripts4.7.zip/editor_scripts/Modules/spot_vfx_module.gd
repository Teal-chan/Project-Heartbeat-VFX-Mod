extends HBEditorModule
class_name SpotlightVfxModule

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED UTILITIES - Preload the shared helper library
# ═══════════════════════════════════════════════════════════════════════════════
const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")

const ANIM_TAG := "SpotlightAnim/v1"

# radius/soft in UV, dim = brightness outside spot (0 = black, 1 = no dim)
const DEFAULT_START := {
	"radius": 0.22,
	"soft": 0.32,
	"dim": 0.15
}
const DEFAULT_END := {
	"radius": 0.10,
	"soft": 0.25,
	"dim": 0.05
}

const DEBUG_TIMEOUT := true

# ── UI refs ─────────────────────────────────────────────────────
var cb_release : CheckBox
var dd_ease    : OptionButton

# Hold end timing
var line_end_hold   : LineEdit
var cb_use_note_end : CheckBox

var sb_rs : SpinBox
var sb_ss : SpinBox
var sb_ds : SpinBox

var sb_re : SpinBox
var sb_se : SpinBox
var sb_de : SpinBox

# SVG icon cache
var ICON_SPOT_ON  : Texture2D = null
var ICON_SPOT_OFF : Texture2D = null

# ───────────────────────────────────────────────────────────────
# Lifecycle
# ───────────────────────────────────────────────────────────────

func _ready() -> void:
	super._ready()
	_build_ui()

func _build_ui() -> void:
	# Scroll root so we don't spill into the timeline
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.anchor_left = 0.0
	scroll.anchor_top = 0.0
	scroll.anchor_right = 1.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = 0
	scroll.offset_top = 0
	scroll.offset_right = 0
	scroll.offset_bottom = 0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	add_child(scroll)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(root)

	# ── Timing info ────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Window timing"))

	var row_t := HBoxContainer.new()
	row_t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_t)

	row_t.add_child(VFXUtils.mk_label("Window length source:"))
	var Ls := Label.new()
	Ls.text = "GAME TIMEOUT per note (same as Scale/Timeout Anim)"
	Ls.add_theme_color_override("font_color", Color(0.8, 1.0, 0.8))
	row_t.add_child(Ls)
	row_t.add_child(VFXUtils.mk_spacer())

	# Release window toggle
	var row_rel := HBoxContainer.new()
	row_rel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_rel)

	cb_release = CheckBox.new()
	cb_release.text = "Also author RELEASE window for sustains (uses GAME TIMEOUT @ release)"
	cb_release.button_pressed = true
	row_rel.add_child(cb_release)
	row_rel.add_child(VFXUtils.mk_spacer())

	# Hold end timing (for Rush/Sustain notes)
	var row_hold := HBoxContainer.new()
	row_hold.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_hold)

	row_hold.add_child(VFXUtils.mk_label("Hold end (ms after impact):"))
	line_end_hold = LineEdit.new()
	line_end_hold.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_end_hold.custom_minimum_size.x = 80
	line_end_hold.text = "0"
	line_end_hold.placeholder_text = "0"
	line_end_hold.tooltip_text = "Maintains spotlight for this many ms after impact. Use for Rush/Sustain notes."
	row_hold.add_child(line_end_hold)

	cb_use_note_end = CheckBox.new()
	cb_use_note_end.text = "Use hold end"
	cb_use_note_end.tooltip_text = "Automatically extend to the note's end time (Rush duration or Sustain release). Overrides manual ms value."
	cb_use_note_end.button_pressed = false
	row_hold.add_child(cb_use_note_end)
	row_hold.add_child(VFXUtils.mk_spacer())

	# ── Ease choice ────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Interpolation (ease between rows)"))

	var row_ease := HBoxContainer.new()
	row_ease.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_ease)

	row_ease.add_child(VFXUtils.mk_label("Ease:"))
	dd_ease = OptionButton.new()
	dd_ease.add_item("linear")
	dd_ease.add_item("in_out_quad")
	dd_ease.add_item("in_out_cubic")
	dd_ease.add_item("out_elastic")
	dd_ease.add_item("hold")
	dd_ease.add_item("step")
	dd_ease.select(1) # in_out_quad
	row_ease.add_child(dd_ease)
	row_ease.add_child(VFXUtils.mk_spacer())

	# ── START params ───────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("START (far before impact)"))

	var grid_s := GridContainer.new()
	grid_s.columns = 2
	grid_s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_s)

	grid_s.add_child(VFXUtils.mk_label("Radius (UV):"))
	sb_rs = SpinBox.new()
	sb_rs.min_value = 0.01
	sb_rs.max_value = 2.0
	sb_rs.step = 0.01
	sb_rs.value = DEFAULT_START["radius"]
	sb_rs.custom_minimum_size.x = 80
	grid_s.add_child(sb_rs)

	grid_s.add_child(VFXUtils.mk_label("Soft edge:"))
	sb_ss = SpinBox.new()
	sb_ss.min_value = 0.0
	sb_ss.max_value = 2.0
	sb_ss.step = 0.01
	sb_ss.value = DEFAULT_START["soft"]
	sb_ss.custom_minimum_size.x = 80
	grid_s.add_child(sb_ss)

	grid_s.add_child(VFXUtils.mk_label("Outside brightness (0=black,1=no dim):"))
	sb_ds = SpinBox.new()
	sb_ds.min_value = 0.0
	sb_ds.max_value = 1.0
	sb_ds.step = 0.01
	sb_ds.value = DEFAULT_START["dim"]
	sb_ds.custom_minimum_size.x = 80
	grid_s.add_child(sb_ds)

	# ── END params ─────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("IMPACT (at hit time / release time)"))

	var grid_e := GridContainer.new()
	grid_e.columns = 2
	grid_e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_e)

	grid_e.add_child(VFXUtils.mk_label("Radius (UV):"))
	sb_re = SpinBox.new()
	sb_re.min_value = 0.01
	sb_re.max_value = 2.0
	sb_re.step = 0.01
	sb_re.value = DEFAULT_END["radius"]
	sb_re.custom_minimum_size.x = 80
	grid_e.add_child(sb_re)

	grid_e.add_child(VFXUtils.mk_label("Soft edge:"))
	sb_se = SpinBox.new()
	sb_se.min_value = 0.0
	sb_se.max_value = 2.0
	sb_se.step = 0.01
	sb_se.value = DEFAULT_END["soft"]
	sb_se.custom_minimum_size.x = 80
	grid_e.add_child(sb_se)

	grid_e.add_child(VFXUtils.mk_label("Outside brightness (0=black,1=no dim):"))
	sb_de = SpinBox.new()
	sb_de.min_value = 0.0
	sb_de.max_value = 1.0
	sb_de.step = 0.01
	sb_de.value = DEFAULT_END["dim"]
	sb_de.custom_minimum_size.x = 80
	grid_e.add_child(sb_de)

	# ── Load SVG icons (128px) ─────────────────────────────────
	if ICON_SPOT_ON == null:
		ICON_SPOT_ON = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/spot_on.svg", 128)
		if ICON_SPOT_ON == null:
			ICON_SPOT_ON = preload("res://graphics/icons/console-line.svg")

	if ICON_SPOT_OFF == null:
		ICON_SPOT_OFF = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/spot_off.svg", 128)
		if ICON_SPOT_OFF == null:
			ICON_SPOT_OFF = preload("res://graphics/icons/console-line.svg")

	# ── Action buttons grid (Spot On / Reset UI) ───────────────
	var grid_buttons := GridContainer.new()
	grid_buttons.columns = 2
	grid_buttons.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	grid_buttons.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	grid_buttons.add_theme_constant_override("h_separation", 16)
	grid_buttons.add_theme_constant_override("v_separation", 0)
	root.add_child(grid_buttons)

	_add_spot_icon_button(
		grid_buttons,
		"Spotlight",
		"Authors SpotlightAnim/v1 windows using GAME TIMEOUT (start→impact, optional release).",
		"_apply_spotlight",
		ICON_SPOT_ON
	)

	_add_spot_icon_button(
		grid_buttons,
		"Reset UI",
		"Reset Spotlight parameters to their default values.",
		"_reset_spotlight_ui",
		ICON_SPOT_OFF
	)

	# Footer hint
	var foot := HBoxContainer.new()
	root.add_child(foot)
	foot.add_child(VFXUtils.mk_label("Exports SpotlightAnim/v1 rows; MegaInjector reloads for live preview if present."))
	foot.add_child(VFXUtils.mk_spacer())

# ───────────────────────────────────────────────────────────────
# Entry - WITH UNDO/REDO SUPPORT
# ───────────────────────────────────────────────────────────────

func _apply_spotlight() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	if editor.selected.is_empty():
		_notify("❌ No notes selected.")
		return

	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No valid note specs.")
		return

	var start_cfg := {
		"radius": float(sb_rs.value),
		"soft": float(sb_ss.value),
		"dim": float(sb_ds.value)
	}
	var end_cfg := {
		"radius": float(sb_re.value),
		"soft": float(sb_se.value),
		"dim": float(sb_de.value)
	}

	var ease_name := "in_out_quad"
	var sel_id := dd_ease.get_selected_id()
	if sel_id >= 0:
		ease_name = dd_ease.get_item_text(sel_id)

	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Spotlight VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_spot_rows(
		specs,
		start_cfg,
		end_cfg,
		cb_release.button_pressed,
		ease_name,
		end_hold_ms,
		use_note_end
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()

	_notify("✅ SpotlightAnim window written for %d note(s)." % specs.size())

# ───────────────────────────────────────────────────────────────
# Reset UI helper
# ───────────────────────────────────────────────────────────────

func _reset_spotlight_ui() -> void:
	# Release toggle
	if cb_release:
		cb_release.button_pressed = true

	# Hold end timing
	if line_end_hold:
		line_end_hold.text = "0"
	if cb_use_note_end:
		cb_use_note_end.button_pressed = false

	# Ease back to in_out_quad (index 1)
	if dd_ease:
		dd_ease.select(1)

	# Start params
	if sb_rs:
		sb_rs.value = DEFAULT_START["radius"]
	if sb_ss:
		sb_ss.value = DEFAULT_START["soft"]
	if sb_ds:
		sb_ds.value = DEFAULT_START["dim"]

	# End params
	if sb_re:
		sb_re.value = DEFAULT_END["radius"]
	if sb_se:
		sb_se.value = DEFAULT_END["soft"]
	if sb_de:
		sb_de.value = DEFAULT_END["dim"]

	_notify("↩️ Spotlight UI reset to defaults.")

# ───────────────────────────────────────────────────────────────
# Row builder (returns rows instead of writing directly)
# ───────────────────────────────────────────────────────────────

func _build_spot_rows(
	specs: Array,
	start_cfg: Dictionary,
	end_cfg: Dictionary,
	include_release: bool,
	ease_name: String,
	end_hold_ms: int = 0,
	use_note_end: bool = false
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	# Heads to replace (same convention as original: by head time only)
	var selected_heads := {}
	for s in specs:
		selected_heads[int(s["time"])] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue
		var nt := int(e.get("anim_note_time", -999999))
		if not selected_heads.has(nt):
			preserved.append(e)

	var out_rows := preserved.duplicate()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		# Per-note timeout from note/game (ms)
		var start_before_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t, DEBUG_TIMEOUT)
		if start_before_ms <= 0:
			start_before_ms = 2000

		var t0 := max(0, head_t - start_before_ms)
		var t1 := head_t
		if t0 >= t1:
			t0 = t1 - 10

		out_rows.append(_make_row(layer, t0, ntype, head_t, "spot_start", start_cfg, ease_name))
		out_rows.append(_make_row(layer, t1, ntype, head_t, "spot_impact", end_cfg, ease_name))

		# Hold end - maintains spotlight after impact
		var hold_end_time := 0
		if use_note_end and spec.has("sustain_end"):
			hold_end_time = int(spec["sustain_end"])
		elif end_hold_ms > 0:
			hold_end_time = head_t + end_hold_ms

		if hold_end_time > t1:
			out_rows.append(_make_row(layer, hold_end_time, ntype, head_t, "spot_hold_end", end_cfg, ease_name))

		# Optional sustain release window
		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_before_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, rel_end, DEBUG_TIMEOUT)
			if rel_before_ms <= 0:
				rel_before_ms = start_before_ms
			var r0 := max(0, rel_end - rel_before_ms)
			var r1 := rel_end
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(_make_row(layer, r0, ntype, head_t, "spot_release_start", start_cfg, ease_name))
			out_rows.append(_make_row(layer, r1, ntype, head_t, "spot_release_impact", end_cfg, ease_name))

	return out_rows

func _make_row(
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String,
	cfg: Dictionary,
	ease_name: String
) -> Dictionary:
	return {
		"layer": layer,
		"time": time_ms,
		"note_type": float(note_type),
		"spot_radius": VFXUtils.r3(float(cfg.get("radius", DEFAULT_START["radius"]))),
		"spot_soft": VFXUtils.r3(float(cfg.get("soft", DEFAULT_START["soft"]))),
		"spot_dim": VFXUtils.r3(float(cfg.get("dim", DEFAULT_START["dim"]))),
		"spot_enable": true,
		"spot_center": [0.5, 0.5],
		"ease": ease_name,
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time
	}


# ───────────────────────────────────────────────────────────────
# Timing helper
# ───────────────────────────────────────────────────────────────

func _parse_end_hold_ms() -> int:
	if line_end_hold == null:
		return 0
	var t := line_end_hold.text.strip_edges()
	if t.is_empty():
		return 0
	if not t.is_valid_float():
		return 0
	var v := int(round(float(t)))
	if v < 0:
		return 0
	return v


# ───────────────────────────────────────────────────────────────
# UI button helper
# ───────────────────────────────────────────────────────────────

func _add_spot_icon_button(
	parent: GridContainer,
	label_text: String,
	tooltip: String,
	func_name: String,
	icon_tex: Texture2D
) -> void:
	var cell := VBoxContainer.new()
	cell.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	cell.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_theme_constant_override("separation", 0)

	var ratio := HBoxRatioContainer.new()
	ratio.custom_minimum_size = Vector2(128, 128)
	ratio.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	ratio.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_child(ratio)

	var hb := _mk_hb_button(label_text, tooltip, func_name)
	hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	hb.custom_minimum_size = Vector2(0, 0)

	var inner: Button = hb.get_button()
	if inner:
		inner.icon = icon_tex
		inner.expand_icon = true
		inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	ratio.add_child(hb)
	parent.add_child(cell)

func _mk_hb_button(text: String, tooltip: String, func_name: String) -> HBEditorButton:
	var b := HBEditorButton.new()
	b.button_mode = "function"
	b.text = text
	b.tooltip = tooltip
	b.function_name = func_name
	b.params = []
	b.disable_when_playing = true
	b.disable_with_popup = true

	# Let the ratio container control size (128×128 square)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 0)

	b.set_module(self)
	return b


# ───────────────────────────────────────────────────────────────
# Preview / notifications
# ───────────────────────────────────────────────────────────────

func _after_write_preview() -> void:
	VFXUtils.trigger_preview_reload(editor)

func _notify(text: String) -> void:
	VFXUtils.show_notification(editor, text)
