# vfx_utils.gd - Shared utilities for VFX Toolbox modules
# Place in: user://editor_scripts/Modules/vfx_utils.gd
#
# Usage in modules:
#   const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
#
# Then call functions as:
#   VFXUtils.safe_get(obj, "property", fallback)
#   VFXUtils.get_vfx_path(editor)
#   etc.

class_name VFXUtils

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS - Shared across all modules
# ═══════════════════════════════════════════════════════════════════════════════

# Animation tags - the version strings for each effect type
const SCALE_TAG := "ScaleAbsAnim/v1"
const COLOR_TAG := "ColorAnim/v1"
const ROTATE_TAG := "RotateAnim/v1"
const OFFSET_TAG := "PosOffsetAnim/v1"
const SPOT_TAG := "SpotlightAnim/v1"
const GLOW_TAG := "GlowAnim/v1"

# Field animation layer names
const PF_SLIDE_TAG := "$PLAYFIELD"
const PF_ROTATE_TAG := "$PF_ROTATE_SEL"
const PF_SCALE_TAG := "$PF_SCALE_SEL"
const MIRAI_LINK_TAG := "$MIRAI_LINK"

# Note type name mapping
const NOTE_TYPE_NAMES := {
	0: "UP", 1: "LEFT", 2: "DOWN", 3: "RIGHT",
	4: "SLIDE_LEFT", 5: "SLIDE_RIGHT",
	6: "SLIDE_CHAIN_PIECE_LEFT", 7: "SLIDE_CHAIN_PIECE_RIGHT",
	8: "HEART"
}

# Easing function choices (shared by all modules that support easing)
const EASE_CHOICES := [
	{"label": "Hold (step)", "key": "hold"},
	{"label": "Linear", "key": "linear"},
	{"label": "In-Out Quad", "key": "in_out_quad"},
	{"label": "In-Out Cubic", "key": "in_out_cubic"},
	{"label": "Out Elastic", "key": "out_elastic"},
]


# ═══════════════════════════════════════════════════════════════════════════════
# OBJECT PROPERTY HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Safely get a property from an object, checking property list and meta.
## Returns fallback if property doesn't exist or object is null.
static func safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	# Check property list first
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	# Check metadata
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	# Try direct get (may return null for missing properties)
	if obj.has_method("get"):
		var v := obj.get(prop)
		if v != null:
			return v
	return fallback


## Get list of property names for an object
static func get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out


## Check if an object represents a Layer 2 note
static func is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	# Check layer_index property (0 = layer 1, 1 = layer 2)
	var lidx := safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	# Check second_layer flag
	var has_flag := safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	# Check if layer name ends with "2"
	var layer_meta := safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false


## Check if note type is a slide (head or chain piece)
static func is_slide_type(note_type: int) -> bool:
	return note_type == 4 or note_type == 5 or note_type == 6 or note_type == 7


## Check if note type is a slide head specifically
static func is_slide_head_type(note_type: int) -> bool:
	return note_type == 4 or note_type == 5


## Check if note type is a slide chain piece
static func is_slide_chain_type(note_type: int) -> bool:
	return note_type == 6 or note_type == 7


# ═══════════════════════════════════════════════════════════════════════════════
# TIMING HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Get the rhythm game object from the editor (tries multiple paths)
static func get_rg(editor: Node) -> Object:
	if editor == null:
		return null
	# Try direct rhythm_game property
	var rg = editor.get("rhythm_game")
	if rg is Object:
		return rg
	# Try playtest popup
	var pv = editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		var r2 = (pv as Node).get("rhythm_game")
		if r2 is Object:
			return r2
	# Try GamePreview child
	var gp = editor.find_child("GamePreview", true, false)
	if gp != null and gp.has_method("get"):
		var r3 = gp.get("rhythm_game")
		if r3 is Object:
			return r3
	return null


## Compute the timeout window for a note (how long before hit it appears)
## Returns milliseconds
static func compute_timeout_ms(editor: Node, note_type: int, note_obj: Object, t_ms: int, debug: bool = false) -> int:
	var rg := get_rg(editor)
	if rg != null:
		# Try get_time_out_for(note_type, time)
		if (rg as Object).has_method("get_time_out_for"):
			var ms := int(round(float((rg as Object).call("get_time_out_for", note_type, t_ms))))
			if debug:
				print("[VFXUtils.timeout] rg.get_time_out_for t=", t_ms, " => ", ms, "ms")
			if ms > 0:
				return ms

		# Get note speed for fallback methods
		var speed := 1.0
		if (rg as Object).has_method("get_note_speed_at_time"):
			speed = float((rg as Object).call("get_note_speed_at_time", t_ms))

		# Try note.get_time_out(speed)
		if note_obj != null and (note_obj as Object).has_method("get_time_out"):
			var ms2 := int(round(float((note_obj as Object).call("get_time_out", speed))))
			if debug:
				print("[VFXUtils.timeout] note.get_time_out(speed) t=", t_ms, " speed=", speed, " => ", ms2, "ms")
			if ms2 > 0:
				return ms2

		# Try rg.get_time_out(speed, time) or rg.get_time_out(speed)
		if (rg as Object).has_method("get_time_out"):
			var try_ms := float((rg as Object).call("get_time_out", speed, t_ms))
			if try_ms <= 0.0:
				try_ms = float((rg as Object).call("get_time_out", speed))
			var ms3 := int(round(try_ms))
			if debug:
				print("[VFXUtils.timeout] rg.get_time_out(...) => ", ms3, "ms")
			if ms3 > 0:
				return ms3

	# Fallback: use timing map to estimate 8 beats
	var map = editor.get_timing_map() if editor != null else []
	if map and map.size() >= 2:
		var idx := HBUtils.bsearch_upper(map, t_ms)
		var i0 := clamp(idx - 1, 0, map.size() - 1)
		var i1 := clamp(idx, 0, map.size() - 1)
		var beat_ms := max(1, int(map[i1] - map[i0]))
		if debug:
			print("[VFXUtils.timeout] 8*beat_fallback beat_ms=", beat_ms, " => ", 8 * beat_ms, "ms")
		return 8 * beat_ms

	# Hard fallback
	if debug:
		print("[VFXUtils.timeout] hard_fallback 2000ms")
	return 2000


## Get BPM at a specific time in milliseconds
static func bpm_at_ms(editor: Node, t_ms: int) -> float:
	var rg := get_rg(editor)
	if rg != null:
		# Try rhythm game's get_bpm_at_time
		if (rg as Object).has_method("get_bpm_at_time"):
			return float((rg as Object).call("get_bpm_at_time", t_ms))
		# Try tempo_map.get_bpm_at_time
		var tm := (rg as Object).get("tempo_map")
		if tm != null and (tm as Object).has_method("get_bpm_at_time"):
			return float((tm as Object).call("get_bpm_at_time", t_ms))

	# Try editor's tempo_map
	if editor != null:
		var em = editor.get("tempo_map")
		if em != null and (em as Object).has_method("get_bpm_at_time"):
			return float((em as Object).call("get_bpm_at_time", t_ms))

	return 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# PATH HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Get the VFX JSON path for the current song/difficulty
static func get_vfx_path(editor: Node) -> String:
	if editor and editor.current_song and editor.current_difficulty:
		var sid := str(editor.current_song.id)
		var diff := str(editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"


# ═══════════════════════════════════════════════════════════════════════════════
# SELECTION HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Collect specs for all selected notes in the editor
## Returns array of dictionaries with: time, note_type, layer, note_obj, sustain_end (optional)
static func collect_selected_note_specs(editor: Node) -> Array:
	var specs: Array = []
	if editor == null:
		return specs
	
	for item in editor.selected:
		var data_obj := safe_get(item, "data", null)
		if data_obj == null:
			continue
		
		var props := get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type := int(data_obj.get("note_type"))
			var time_val := int(data_obj.get("time"))

			var layer2 := is_layer2_from_obj(data_obj) or is_layer2_from_obj(item)

			# Get layer name, normalizing chain pieces to their head type
			var lname: String = NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"

			var layer_tag: String = "layer_" + lname + ("2" if layer2 else "")

			var spec := {
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj,
			}

			# Try to get duration/end_time for Sustain and Rush notes
			var dur: Variant = null
			if "duration" in props:
				dur = int(data_obj.get("duration"))
			elif "end_time" in props:
				dur = int(data_obj.get("end_time")) - time_val
			
			# Fallback: try direct property access
			if dur == null or int(dur) <= 0:
				var end_t = data_obj.get("end_time")
				if end_t != null and int(end_t) > time_val:
					dur = int(end_t) - time_val
			
			# Fallback: try get_duration() method
			if dur == null or int(dur) <= 0:
				if data_obj.has_method("get_duration"):
					var d = data_obj.get_duration()
					if d != null and int(d) > 0:
						dur = int(d)
			
			if dur != null and int(dur) > 0:
				spec["sustain_end"] = time_val + int(dur)

			specs.append(spec)
	
	return specs


## Build composite key for a note: "layer@note_type@time"
static func make_note_key(layer: String, note_type: int, time_ms: int) -> String:
	return "%s@%d@%d" % [layer, note_type, time_ms]


## Parse a composite key back to components
static func parse_note_key(key: String) -> Dictionary:
	var parts := key.split("@")
	if parts.size() != 3:
		return {}
	return {
		"layer": parts[0],
		"note_type": int(parts[1]),
		"time": int(parts[2])
	}


# ═══════════════════════════════════════════════════════════════════════════════
# JSON HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Round to 3 decimal places (for clean JSON output)
static func r3(v: float) -> float:
	return float(int(v * 1000.0)) / 1000.0


## Load existing VFX JSON file, returns empty array if not found
static func load_vfx_json(path: String) -> Array:
	if not FileAccess.file_exists(path):
		return []
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return []
	var parsed := JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_ARRAY:
		return []
	return parsed


## Save VFX JSON file (sorted by time)
static func save_vfx_json(path: String, rows: Array) -> Error:
	# Sort by time
	rows.sort_custom(func(a, b):
		return int(a.get("time", 0)) < int(b.get("time", 0))
	)
	
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return ERR_CANT_OPEN
	f.store_string(JSON.stringify(rows, "\t"))
	f.close()
	return OK


## Write VFX JSON with standard sorting (playfield first, then by time, then by layer)
## Uses the compact one-row-per-line format for readability
static func write_sorted_vfx_json(path: String, out_rows: Array, module_name: String = "VFXUtils") -> void:
	out_rows.sort_custom(func(a, b):
		var la := String(a.get("layer", ""))
		var lb := String(b.get("layer", ""))
		# $PLAYFIELD rows always come first
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		# Then sort by time
		var ta := float(a.get("time", 0.0))
		var tb := float(b.get("time", 0.0))
		if abs(ta - tb) > 0.0001:
			return ta < tb
		# Finally by layer name
		return la < lb
	)

	var lines := PackedStringArray()
	for row in out_rows:
		lines.append(JSON.stringify(row))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if fout:
		fout.store_string(content)
		fout.close()
		print("[%s] 💾 Wrote %d rows → %s" % [module_name, out_rows.size(), path])
	else:
		printerr("[%s] ❌ Failed to write VFX JSON." % module_name)


## Merge new rows into existing rows (for merge-safe modules)
## Removes existing rows that match by key criteria, then adds new rows
static func merge_rows(existing: Array, new_rows: Array, match_keys: Array[String]) -> Array:
	var result := []
	
	# Build set of new row signatures
	var new_sigs := {}
	for row in new_rows:
		var sig := ""
		for key in match_keys:
			sig += str(row.get(key, "")) + "|"
		new_sigs[sig] = true
	
	# Keep existing rows that don't match any new row
	for row in existing:
		var sig := ""
		for key in match_keys:
			sig += str(row.get(key, "")) + "|"
		if not new_sigs.has(sig):
			result.append(row)
	
	# Add all new rows
	result.append_array(new_rows)
	
	return result


# ═══════════════════════════════════════════════════════════════════════════════
# UI HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Load an SVG icon from file and rasterize to texture
static func load_svg_icon(path: String, size: int = 160) -> Texture2D:
	if not FileAccess.file_exists(path):
		print("[VFXUtils] SVG not found at:", path)
		return null

	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		print("[VFXUtils] Failed to open SVG:", path)
		return null

	var buffer := file.get_buffer(file.get_length())
	file.close()

	var img := Image.new()
	var err := img.load_svg_from_buffer(buffer)
	if err != OK:
		print("[VFXUtils] Failed to load SVG from buffer:", path, " error:", err)
		return null

	# Rasterize to square icon texture
	img.resize(size, size, Image.INTERPOLATE_BILINEAR)

	var tex := ImageTexture.create_from_image(img)
	return tex


## Create a section label (styled header text)
static func mk_section_label(text: String) -> Label:
	var L := Label.new()
	L.text = text
	L.add_theme_color_override("font_color", Color(0.85, 0.85, 1.0))
	L.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return L


## Create a plain label
static func mk_label(text: String) -> Label:
	var L := Label.new()
	L.text = text
	return L


## Create an expanding spacer control
static func mk_spacer() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return c


## Left-align the internal LineEdit of a SpinBox
static func left_align_spinbox(sb: SpinBox) -> void:
	if sb.has_method("get_line_edit"):
		var le = sb.get_line_edit()
		if le is LineEdit:
			le.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT


# ═══════════════════════════════════════════════════════════════════════════════
# PREVIEW / NOTIFICATION HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

## Trigger MegaInjector to reload and preview changes
static func trigger_preview_reload(editor: Node) -> void:
	if editor == null:
		return
	var mgr = editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", editor, get_vfx_path(editor))
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		show_notification(editor, "⚠️ Run 'Step 2: Compile Shaders' once to enable live preview.")

	# Force game preview to update
	if editor.game_preview and not editor.game_playback.is_playing():
		editor.game_preview.set_visualizer_processing_enabled(true)
	if editor.has_method("force_game_process"):
		editor.force_game_process()


## Show a notification in the editor
static func show_notification(editor: Node, text: String) -> void:
	if editor and editor.message_shower:
		editor.message_shower._show_notification(text)
	else:
		print(text)


# ═══════════════════════════════════════════════════════════════════════════════
# EASING FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

## Evaluate an easing function by name
## t should be in range [0.0, 1.0]
static func ease_eval(ease_name: String, t: float) -> float:
	match ease_name.to_lower():
		"hold", "step":
			return 0.0
		"linear":
			return t
		"in_out_quad":
			if t < 0.5:
				return 2.0 * t * t
			else:
				return 1.0 - pow(-2.0 * t + 2.0, 2) / 2.0
		"in_out_cubic":
			if t < 0.5:
				return 4.0 * t * t * t
			else:
				return 1.0 - pow(-2.0 * t + 2.0, 3) / 2.0
		"out_elastic":
			if t <= 0.0:
				return 0.0
			if t >= 1.0:
				return 1.0
			var c4 := (2.0 * PI) / 3.0
			return pow(2.0, -10.0 * t) * sin((t * 10.0 - 0.75) * c4) + 1.0
		_:
			return t


## Calculate progress between two times, clamped to [0, 1]
static func progress(t: float, t0: float, t1: float) -> float:
	if t1 <= t0:
		return 1.0
	return clamp((t - t0) / (t1 - t0), 0.0, 1.0)


## Shortest-arc angle interpolation (for rotation)
static func shortest_arc_lerp(a0: float, a1: float, t: float) -> float:
	var diff := fmod(a1 - a0 + 540.0, 360.0) - 180.0
	return a0 + diff * t
