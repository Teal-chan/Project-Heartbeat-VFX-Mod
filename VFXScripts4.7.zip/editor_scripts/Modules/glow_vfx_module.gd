extends HBEditorModule
class_name GlowVfxModule

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED UTILITIES - Preload the shared helper library
# ═══════════════════════════════════════════════════════════════════════════════
const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")

const ANIM_TAG := "GlowAnim/v1"

const GLOW_MIN_MAX := Vector2(0.0, 2.5)
const DENSITY_DEF_MS := 80
const SLIDE_HIT_ATTEN := 0.85
const IMPACT_CAP := 2.0

# Simple "nice looking" defaults
const DEFAULT_GLOW_STATIC := {
	"head":   1.2,
	"target": 0.8,
	"bar1":   0.6,
	"bar2":   0.6,
	"tail":   0.8,
	"hold":   0.9,
	"rush":   1.0,
}

# Grow/Shrink defaults
const DEFAULT_GLOW_START := {
	"head":   0.4,
	"target": 0.3,
	"bar1":   0.25,
	"bar2":   0.25,
	"tail":   0.35,
	"hold":   0.3,
	"rush":   0.3,
}
const DEFAULT_GLOW_END := DEFAULT_GLOW_STATIC

# Pulse envelope defaults
const DEFAULT_ENV_PEAK := {
	"head":   1.8,
	"target": 1.2,
	"bar1":   1.0,
	"bar2":   1.0,
	"tail":   1.4,
	"hold":   1.2,
	"rush":   1.5,
}

const DEFAULT_ENV_VALLEY := {
	"head":   0.1,
	"target": 0.0,
	"bar1":   0.0,
	"bar2":   0.0,
	"tail":   0.1,
	"hold":   0.0,
	"rush":   0.0,
}

const DEFAULT_BEATS_PER_PULSE := 1.0
const DEFAULT_PHASE_BEATS := 0.0

const EASE_CHOICES := [
	{"label":"Hold (step)", "key":"hold"},
	{"label":"Linear", "key":"linear"},
	{"label":"In-Out Quad", "key":"in_out_quad"},
	{"label":"In-Out Cubic", "key":"in_out_cubic"},
	{"label":"Out Elastic", "key":"out_elastic"},
]

# ── Shared UI refs ─────────────────────────────────────────────
var line_custom_start : LineEdit
var sb_density : SpinBox
var cb_release : CheckBox
var sb_cap : SpinBox
var cb_slide : CheckBox

# Hold end timing
var line_end_hold    : LineEdit
var cb_use_note_end  : CheckBox

# ── SVG Icon cache ─────────────────────────────────────────────
var ICON_GLOW_STATIC  : Texture2D = null
var ICON_GLOW_GROW    : Texture2D = null
var ICON_GLOW_PROG    : Texture2D = null
var ICON_GLOW_PULSE   : Texture2D = null
var ICON_GLOW_RESET   : Texture2D = null

# Static Glow UI
var st_head      : SpinBox
var st_target    : SpinBox
var st_bar1      : SpinBox
var st_bar2      : SpinBox
var st_tail      : SpinBox
var st_hold      : SpinBox
var st_rush_text : SpinBox
var st_rush_icon : SpinBox

# Grow/Shrink UI
var gs_s_head      : SpinBox
var gs_s_target    : SpinBox
var gs_s_bar1      : SpinBox
var gs_s_bar2      : SpinBox
var gs_s_tail      : SpinBox
var gs_s_hold      : SpinBox
var gs_s_rush_text : SpinBox
var gs_s_rush_icon : SpinBox

var gs_e_head      : SpinBox
var gs_e_target    : SpinBox
var gs_e_bar1      : SpinBox
var gs_e_bar2      : SpinBox
var gs_e_tail      : SpinBox
var gs_e_hold      : SpinBox
var gs_e_rush_text : SpinBox
var gs_e_rush_icon : SpinBox

# Pulse UI
var pl_s_head      : SpinBox
var pl_s_target    : SpinBox
var pl_s_bar1      : SpinBox
var pl_s_bar2      : SpinBox
var pl_s_tail      : SpinBox
var pl_s_hold      : SpinBox
var pl_s_rush_text : SpinBox
var pl_s_rush_icon : SpinBox

var pl_e_head      : SpinBox
var pl_e_target    : SpinBox
var pl_e_bar1      : SpinBox
var pl_e_bar2      : SpinBox
var pl_e_tail      : SpinBox
var pl_e_hold      : SpinBox
var pl_e_rush_text : SpinBox
var pl_e_rush_icon : SpinBox

var pl_peak_head      : SpinBox
var pl_peak_target    : SpinBox
var pl_peak_bar1      : SpinBox
var pl_peak_bar2      : SpinBox
var pl_peak_tail      : SpinBox
var pl_peak_hold      : SpinBox
var pl_peak_rush_text : SpinBox
var pl_peak_rush_icon : SpinBox

var pl_val_head      : SpinBox
var pl_val_target    : SpinBox
var pl_val_bar1      : SpinBox
var pl_val_bar2      : SpinBox
var pl_val_tail      : SpinBox
var pl_val_hold      : SpinBox
var pl_val_rush_text : SpinBox
var pl_val_rush_icon : SpinBox

var sb_beats : SpinBox
var sb_phase : SpinBox
var dd_ease  : OptionButton

# ───────────────────────────────────────────────────────────────
# Lifecycle
# ───────────────────────────────────────────────────────────────

func _ready() -> void:
	super._ready()
	_build_ui()

func _build_ui() -> void:
	# Scroll root so content can't spill into the timeline
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.anchor_left = 0.0
	scroll.anchor_top = 0.0
	scroll.anchor_right = 1.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = 0
	scroll.offset_top = 0
	scroll.offset_right = 0
	scroll.offset_bottom = 0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	add_child(scroll)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(root)

	# ── Load SVG icons for 128×128 buttons ─────────────────────
	if ICON_GLOW_STATIC == null:
		ICON_GLOW_STATIC = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/glow_static.svg", 128)
		if ICON_GLOW_STATIC == null:
			ICON_GLOW_STATIC = preload("res://graphics/icons/console-line.svg")

	if ICON_GLOW_GROW == null:
		ICON_GLOW_GROW = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/glow_grow.svg", 128)
		if ICON_GLOW_GROW == null:
			ICON_GLOW_GROW = preload("res://graphics/icons/console-line.svg")

	if ICON_GLOW_PROG == null:
		ICON_GLOW_PROG = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/glow_prog.svg", 128)
		if ICON_GLOW_PROG == null:
			ICON_GLOW_PROG = preload("res://graphics/icons/console-line.svg")

	if ICON_GLOW_PULSE == null:
		ICON_GLOW_PULSE = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/glow_pulse.svg", 128)
		if ICON_GLOW_PULSE == null:
			ICON_GLOW_PULSE = preload("res://graphics/icons/console-line.svg")

	if ICON_GLOW_RESET == null:
		ICON_GLOW_RESET = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/glow_reset.svg", 128)
		if ICON_GLOW_RESET == null:
			ICON_GLOW_RESET = preload("res://graphics/icons/console-line.svg")

	# ── Shared timing ──────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Glow timing (window for all modes)"))

	var row_t := HBoxContainer.new()
	row_t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_t)

	row_t.add_child(VFXUtils.mk_label("Start window (ms before hit):"))
	line_custom_start = LineEdit.new()
	line_custom_start.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_custom_start.custom_minimum_size.x = 80
	line_custom_start.placeholder_text = "blank"
	line_custom_start.alignment = HORIZONTAL_ALIGNMENT_LEFT
	row_t.add_child(line_custom_start)

	row_t.add_child(VFXUtils.mk_label("= use GAME TIMEOUT"))
	row_t.add_child(VFXUtils.mk_spacer())

	row_t.add_child(VFXUtils.mk_label("Density window (ms):"))
	sb_density = SpinBox.new()
	sb_density.min_value = 0
	sb_density.max_value = 200
	sb_density.step = 5
	sb_density.value = DENSITY_DEF_MS
	sb_density.custom_minimum_size.x = 80
	VFXUtils.left_align_spinbox(sb_density)
	row_t.add_child(sb_density)

	var row2 := HBoxContainer.new()
	row2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row2)
	cb_release = CheckBox.new()
	cb_release.text = "Release window for sustains"
	cb_release.tooltip_text = "Also authors a RELEASE window for sustains using the same window length."
	cb_release.button_pressed = true
	row2.add_child(cb_release)
	row2.add_child(VFXUtils.mk_spacer())

	# Hold end timing (for Rush/Sustain notes)
	var row_hold := HBoxContainer.new()
	row_hold.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_hold)

	row_hold.add_child(VFXUtils.mk_label("Hold end (ms after impact):"))
	line_end_hold = LineEdit.new()
	line_end_hold.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_end_hold.custom_minimum_size.x = 80
	line_end_hold.text = "0"
	line_end_hold.placeholder_text = "0"
	line_end_hold.tooltip_text = "Maintains glow and continues envelope for this many ms after impact. Use for Rush/Sustain notes."
	row_hold.add_child(line_end_hold)

	cb_use_note_end = CheckBox.new()
	cb_use_note_end.text = "Use hold end"
	cb_use_note_end.tooltip_text = "Automatically extend to the note's end time (Rush duration or Sustain release). Overrides manual ms value."
	cb_use_note_end.button_pressed = false
	row_hold.add_child(cb_use_note_end)
	row_hold.add_child(VFXUtils.mk_spacer())

	var row3 := HBoxContainer.new()
	row3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row3)

	row3.add_child(VFXUtils.mk_label("Impact cap (head glow):"))
	sb_cap = SpinBox.new()
	sb_cap.min_value = GLOW_MIN_MAX.x
	sb_cap.max_value = GLOW_MIN_MAX.y
	sb_cap.step = 0.05
	sb_cap.value = IMPACT_CAP
	sb_cap.custom_minimum_size.x = 80
	VFXUtils.left_align_spinbox(sb_cap)
	row3.add_child(sb_cap)

	cb_slide = CheckBox.new()
	cb_slide.text = "Reduce slide glow"
	cb_slide.tooltip_text = "Attenuate slide impact glow for legibility."
	cb_slide.button_pressed = true
	row3.add_child(cb_slide)
	row3.add_child(VFXUtils.mk_spacer())

	# ── STATIC GLOW ────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Static Glow – single set for Start & Impact"))

	var row_static := HBoxContainer.new()
	row_static.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_static.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_static)

	st_head   = _mk_glow_card(row_static, "Head",   DEFAULT_GLOW_STATIC["head"])
	st_target = _mk_glow_card(row_static, "Target", DEFAULT_GLOW_STATIC["target"])
	st_bar1   = _mk_glow_card(row_static, "Bar 1",  DEFAULT_GLOW_STATIC["bar1"])
	st_bar2   = _mk_glow_card(row_static, "Bar 2",  DEFAULT_GLOW_STATIC["bar2"])
	st_tail   = _mk_glow_card(row_static, "Tail",   DEFAULT_GLOW_STATIC["tail"])
	st_hold   = _mk_glow_card(row_static, "Hold",   DEFAULT_GLOW_STATIC["hold"])
	st_rush_text = _mk_glow_card(row_static, "Rush Text", DEFAULT_GLOW_STATIC.get("rush", 1.0))
	st_rush_icon = _mk_glow_card(row_static, "Rush Icon", DEFAULT_GLOW_STATIC.get("rush", 1.0))

	var row_static_btn := HBoxContainer.new()
	row_static_btn.alignment = BoxContainer.ALIGNMENT_CENTER
	row_static_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_static_btn)

	var hb_static := _mk_hb_button(
		"Static Glow",
		"Uses one glow set for both start and impact (and optional release).",
		"_apply_static_glow"
	)
	hb_static.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

	var ratio_static := HBoxRatioContainer.new()
	ratio_static.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_static.custom_minimum_size = Vector2(128, 128)
	ratio_static.add_child(hb_static)
	row_static_btn.add_child(ratio_static)

	var static_inner: Button = hb_static.get_button()
	if static_inner:
		static_inner.icon = ICON_GLOW_STATIC
		static_inner.expand_icon = true
		static_inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# ── GROW / SHRINK / PROGRESSIVE ───────────────────────────
	root.add_child(VFXUtils.mk_section_label("Grow/Shrink/Progressive Glow – Start / End sets"))

	var row_gs_start := HBoxContainer.new()
	row_gs_start.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_gs_start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_gs_start)

	gs_s_head   = _mk_glow_card(row_gs_start, "Start Head",   DEFAULT_GLOW_START["head"])
	gs_s_target = _mk_glow_card(row_gs_start, "Start Target", DEFAULT_GLOW_START["target"])
	gs_s_bar1   = _mk_glow_card(row_gs_start, "Start Bar 1",  DEFAULT_GLOW_START["bar1"])
	gs_s_bar2   = _mk_glow_card(row_gs_start, "Start Bar 2",  DEFAULT_GLOW_START["bar2"])
	gs_s_tail   = _mk_glow_card(row_gs_start, "Start Tail",   DEFAULT_GLOW_START["tail"])
	gs_s_hold   = _mk_glow_card(row_gs_start, "Start Hold",   DEFAULT_GLOW_START["hold"])
	gs_s_rush_text = _mk_glow_card(row_gs_start, "Start Rush Text", DEFAULT_GLOW_START.get("rush", 0.3))
	gs_s_rush_icon = _mk_glow_card(row_gs_start, "Start Rush Icon", DEFAULT_GLOW_START.get("rush", 0.3))

	var row_gs_end := HBoxContainer.new()
	row_gs_end.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_gs_end.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_gs_end)

	gs_e_head   = _mk_glow_card(row_gs_end, "End Head",   DEFAULT_GLOW_END["head"])
	gs_e_target = _mk_glow_card(row_gs_end, "End Target", DEFAULT_GLOW_END["target"])
	gs_e_bar1   = _mk_glow_card(row_gs_end, "End Bar 1",  DEFAULT_GLOW_END["bar1"])
	gs_e_bar2   = _mk_glow_card(row_gs_end, "End Bar 2",  DEFAULT_GLOW_END["bar2"])
	gs_e_tail   = _mk_glow_card(row_gs_end, "End Tail",   DEFAULT_GLOW_END["tail"])
	gs_e_hold   = _mk_glow_card(row_gs_end, "End Hold",   DEFAULT_GLOW_END["hold"])
	gs_e_rush_text = _mk_glow_card(row_gs_end, "End Rush Text", DEFAULT_GLOW_END.get("rush", 1.0))
	gs_e_rush_icon = _mk_glow_card(row_gs_end, "End Rush Icon", DEFAULT_GLOW_END.get("rush", 1.0))

	var hb_gs := _mk_hb_button(
		"Grow/Shrink Glow",
		"Separate Start / End glow (timeout or custom window).",
		"_apply_grow_shrink_glow"
	)
	hb_gs.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var hb_prog := _mk_hb_button(
		"Prog Glow",
		"Interpolates Start → End glow from first to last selected note.",
		"_apply_progressive_glow"
	)
	hb_prog.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var row_gs_btn := HBoxContainer.new()
	row_gs_btn.alignment = BoxContainer.ALIGNMENT_CENTER
	row_gs_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_gs_btn)

	var ratio_gs := HBoxRatioContainer.new()
	ratio_gs.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_gs.custom_minimum_size = Vector2(128, 128)
	ratio_gs.add_child(hb_gs)
	ratio_gs.add_child(hb_prog)
	row_gs_btn.add_child(ratio_gs)

	var gs_inner: Button = hb_gs.get_button()
	if gs_inner:
		gs_inner.icon = ICON_GLOW_GROW
		gs_inner.expand_icon = true
		gs_inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var prog_inner: Button = hb_prog.get_button()
	if prog_inner:
		prog_inner.icon = ICON_GLOW_PROG
		prog_inner.expand_icon = true
		prog_inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# ── PULSE GLOW ─────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Pulse Glow – beat envelopes inside window"))

	var row_pl_start := HBoxContainer.new()
	row_pl_start.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_pl_start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_pl_start)

	pl_s_head   = _mk_glow_card(row_pl_start, "Start Head",   DEFAULT_GLOW_START["head"])
	pl_s_target = _mk_glow_card(row_pl_start, "Start Target", DEFAULT_GLOW_START["target"])
	pl_s_bar1   = _mk_glow_card(row_pl_start, "Start Bar 1",  DEFAULT_GLOW_START["bar1"])
	pl_s_bar2   = _mk_glow_card(row_pl_start, "Start Bar 2",  DEFAULT_GLOW_START["bar2"])
	pl_s_tail   = _mk_glow_card(row_pl_start, "Start Tail",   DEFAULT_GLOW_START["tail"])
	pl_s_hold   = _mk_glow_card(row_pl_start, "Start Hold",   DEFAULT_GLOW_START["hold"])
	pl_s_rush_text = _mk_glow_card(row_pl_start, "Start Rush Text", DEFAULT_GLOW_START.get("rush", 0.3))
	pl_s_rush_icon = _mk_glow_card(row_pl_start, "Start Rush Icon", DEFAULT_GLOW_START.get("rush", 0.3))

	var row_pl_end := HBoxContainer.new()
	row_pl_end.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_pl_end.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_pl_end)

	pl_e_head   = _mk_glow_card(row_pl_end, "Impact Head",   DEFAULT_GLOW_END["head"])
	pl_e_target = _mk_glow_card(row_pl_end, "Impact Target", DEFAULT_GLOW_END["target"])
	pl_e_bar1   = _mk_glow_card(row_pl_end, "Impact Bar 1",  DEFAULT_GLOW_END["bar1"])
	pl_e_bar2   = _mk_glow_card(row_pl_end, "Impact Bar 2",  DEFAULT_GLOW_END["bar2"])
	pl_e_tail   = _mk_glow_card(row_pl_end, "Impact Tail",   DEFAULT_GLOW_END["tail"])
	pl_e_hold   = _mk_glow_card(row_pl_end, "Impact Hold",   DEFAULT_GLOW_END["hold"])
	pl_e_rush_text = _mk_glow_card(row_pl_end, "Impact Rush Text", DEFAULT_GLOW_END.get("rush", 1.0))
	pl_e_rush_icon = _mk_glow_card(row_pl_end, "Impact Rush Icon", DEFAULT_GLOW_END.get("rush", 1.0))

	root.add_child(VFXUtils.mk_section_label("Pulse envelopes (PEAK / VALLEY between Start → Impact)"))

	var row_peak := HBoxContainer.new()
	row_peak.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_peak.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_peak)

	pl_peak_head   = _mk_glow_card(row_peak, "Peak Head",   DEFAULT_ENV_PEAK["head"])
	pl_peak_target = _mk_glow_card(row_peak, "Peak Target", DEFAULT_ENV_PEAK["target"])
	pl_peak_bar1   = _mk_glow_card(row_peak, "Peak Bar 1",  DEFAULT_ENV_PEAK["bar1"])
	pl_peak_bar2   = _mk_glow_card(row_peak, "Peak Bar 2",  DEFAULT_ENV_PEAK["bar2"])
	pl_peak_tail   = _mk_glow_card(row_peak, "Peak Tail",   DEFAULT_ENV_PEAK["tail"])
	pl_peak_hold   = _mk_glow_card(row_peak, "Peak Hold",   DEFAULT_ENV_PEAK["hold"])
	pl_peak_rush_text = _mk_glow_card(row_peak, "Peak Rush Text", DEFAULT_ENV_PEAK.get("rush", 1.5))
	pl_peak_rush_icon = _mk_glow_card(row_peak, "Peak Rush Icon", DEFAULT_ENV_PEAK.get("rush", 1.5))

	var row_val := HBoxContainer.new()
	row_val.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_val)

	pl_val_head   = _mk_glow_card(row_val, "Valley Head",   DEFAULT_ENV_VALLEY["head"])
	pl_val_target = _mk_glow_card(row_val, "Valley Target", DEFAULT_ENV_VALLEY["target"])
	pl_val_bar1   = _mk_glow_card(row_val, "Valley Bar 1",  DEFAULT_ENV_VALLEY["bar1"])
	pl_val_bar2   = _mk_glow_card(row_val, "Valley Bar 2",  DEFAULT_ENV_VALLEY["bar2"])
	pl_val_tail   = _mk_glow_card(row_val, "Valley Tail",   DEFAULT_ENV_VALLEY["tail"])
	pl_val_hold   = _mk_glow_card(row_val, "Valley Hold",   DEFAULT_ENV_VALLEY["hold"])
	pl_val_rush_text = _mk_glow_card(row_val, "Valley Rush Text", DEFAULT_ENV_VALLEY.get("rush", 0.0))
	pl_val_rush_icon = _mk_glow_card(row_val, "Valley Rush Icon", DEFAULT_ENV_VALLEY.get("rush", 0.0))

	var row_env := HBoxContainer.new()
	row_env.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_env)

	row_env.add_child(VFXUtils.mk_label("Beats per pulse:"))
	sb_beats = SpinBox.new()
	sb_beats.min_value = 0.125
	sb_beats.max_value = 8.0
	sb_beats.step = 0.125
	sb_beats.value = DEFAULT_BEATS_PER_PULSE
	sb_beats.custom_minimum_size.x = 80
	sb_beats.alignment = HORIZONTAL_ALIGNMENT_LEFT
	row_env.add_child(sb_beats)

	row_env.add_child(VFXUtils.mk_spacer())
	row_env.add_child(VFXUtils.mk_label("Phase (beats):"))
	sb_phase = SpinBox.new()
	sb_phase.min_value = -8.0
	sb_phase.max_value = 8.0
	sb_phase.step = 0.125
	sb_phase.value = DEFAULT_PHASE_BEATS
	sb_phase.custom_minimum_size.x = 80
	VFXUtils.left_align_spinbox(sb_phase)
	row_env.add_child(sb_phase)

	row_env.add_child(VFXUtils.mk_spacer())
	row_env.add_child(VFXUtils.mk_label("Envelope ease:"))
	dd_ease = OptionButton.new()
	for i in range(EASE_CHOICES.size()):
		dd_ease.add_item(EASE_CHOICES[i]["label"], i)
	dd_ease.select(1) # Linear default
	row_env.add_child(dd_ease)

	var hb_pulse := _mk_hb_button(
		"Pulse Glow",
		"Timeout-based window with glow pulses between Start and Impact.",
		"_apply_pulse_glow"
	)
	hb_pulse.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var row_pulse_btn := HBoxContainer.new()
	row_pulse_btn.alignment = BoxContainer.ALIGNMENT_CENTER
	row_pulse_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_pulse_btn)

	var ratio_pulse := HBoxRatioContainer.new()
	ratio_pulse.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_pulse.custom_minimum_size = Vector2(128, 128)
	ratio_pulse.add_child(hb_pulse)
	row_pulse_btn.add_child(ratio_pulse)

	var pulse_inner: Button = hb_pulse.get_button()
	if pulse_inner:
		pulse_inner.icon = ICON_GLOW_PULSE
		pulse_inner.expand_icon = true
		pulse_inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# ── Reset UI button ────────────────────────────────────────
	var row_reset := HBoxContainer.new()
	row_reset.alignment = BoxContainer.ALIGNMENT_CENTER
	row_reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_reset)

	var hb_reset := _mk_hb_button(
		"Reset Glow UI",
		"Reset all Glow fields in this tab back to their default values.",
		"_reset_to_defaults"
	)
	hb_reset.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var ratio_reset := HBoxRatioContainer.new()
	ratio_reset.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_reset.custom_minimum_size = Vector2(128, 128)
	ratio_reset.add_child(hb_reset)
	row_reset.add_child(ratio_reset)

	var reset_inner: Button = hb_reset.get_button()
	if reset_inner:
		reset_inner.icon = ICON_GLOW_RESET
		reset_inner.expand_icon = true
		reset_inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# Footer hint
	var foot := HBoxContainer.new()
	root.add_child(foot)
	foot.add_child(VFXUtils.mk_label("Glow rows go into the same *_vfx.json as Scale/Color/etc."))
	foot.add_child(VFXUtils.mk_spacer())

# ───────────────────────────────────────────────────────────────
# Entry points - WITH UNDO/REDO SUPPORT
# ───────────────────────────────────────────────────────────────

func _apply_static_glow() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed
	var include_release := cb_release.button_pressed

	var glow := {
		"head":      float(st_head.value),
		"target":    float(st_target.value),
		"bar1":      float(st_bar1.value),
		"bar2":      float(st_bar2.value),
		"tail":      float(st_tail.value),
		"hold":      float(st_hold.value),
		"rush_text": float(st_rush_text.value),
		"rush_icon": float(st_rush_icon.value),
	}

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Static Glow VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_window_glow_rows(specs, glow, glow, include_release, density_ms, cap, atten_slides)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✨ Static Glow window written for %d note(s)." % specs.size())

func _apply_grow_shrink_glow() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed
	var include_release := cb_release.button_pressed

	var start := {
		"head":      float(gs_s_head.value),
		"target":    float(gs_s_target.value),
		"bar1":      float(gs_s_bar1.value),
		"bar2":      float(gs_s_bar2.value),
		"tail":      float(gs_s_tail.value),
		"hold":      float(gs_s_hold.value),
		"rush_text": float(gs_s_rush_text.value),
		"rush_icon": float(gs_s_rush_icon.value),
	}
	var finish := {
		"head":      float(gs_e_head.value),
		"target":    float(gs_e_target.value),
		"bar1":      float(gs_e_bar1.value),
		"bar2":      float(gs_e_bar2.value),
		"tail":      float(gs_e_tail.value),
		"hold":      float(gs_e_hold.value),
		"rush_text": float(gs_e_rush_text.value),
		"rush_icon": float(gs_e_rush_icon.value),
	}

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Grow/Shrink Glow VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_window_glow_rows(specs, start, finish, include_release, density_ms, cap, atten_slides)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✨ Grow/Shrink Glow window written for %d note(s)." % specs.size())

func _apply_progressive_glow() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	# time-order selection
	specs.sort_custom(func(a, b):
		return int(a["time"]) < int(b["time"])
	)

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed
	var include_release := cb_release.button_pressed

	var start_glow_global := {
		"head":      float(gs_s_head.value),
		"target":    float(gs_s_target.value),
		"bar1":      float(gs_s_bar1.value),
		"bar2":      float(gs_s_bar2.value),
		"tail":      float(gs_s_tail.value),
		"hold":      float(gs_s_hold.value),
		"rush_text": float(gs_s_rush_text.value),
		"rush_icon": float(gs_s_rush_icon.value),
	}
	var end_glow_global := {
		"head":      float(gs_e_head.value),
		"target":    float(gs_e_target.value),
		"bar1":      float(gs_e_bar1.value),
		"bar2":      float(gs_e_bar2.value),
		"tail":      float(gs_e_tail.value),
		"hold":      float(gs_e_hold.value),
		"rush_text": float(gs_e_rush_text.value),
		"rush_icon": float(gs_e_rush_icon.value),
	}

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Progressive Glow VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_progressive_glow_rows(
		specs,
		start_glow_global,
		end_glow_global,
		include_release,
		density_ms,
		cap,
		atten_slides
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✨ Progressive Glow windows written for %d note(s)." % specs.size())

func _apply_pulse_glow() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed

	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	var start := {
		"head":      float(pl_s_head.value),
		"target":    float(pl_s_target.value),
		"bar1":      float(pl_s_bar1.value),
		"bar2":      float(pl_s_bar2.value),
		"tail":      float(pl_s_tail.value),
		"hold":      float(pl_s_hold.value),
		"rush_text": float(pl_s_rush_text.value),
		"rush_icon": float(pl_s_rush_icon.value),
	}
	var finish := {
		"head":      float(pl_e_head.value),
		"target":    float(pl_e_target.value),
		"bar1":      float(pl_e_bar1.value),
		"bar2":      float(pl_e_bar2.value),
		"tail":      float(pl_e_tail.value),
		"hold":      float(pl_e_hold.value),
		"rush_text": float(pl_e_rush_text.value),
		"rush_icon": float(pl_e_rush_icon.value),
	}
	var env_peak := {
		"head":      float(pl_peak_head.value),
		"target":    float(pl_peak_target.value),
		"bar1":      float(pl_peak_bar1.value),
		"bar2":      float(pl_peak_bar2.value),
		"tail":      float(pl_peak_tail.value),
		"hold":      float(pl_peak_hold.value),
		"rush_text": float(pl_peak_rush_text.value),
		"rush_icon": float(pl_peak_rush_icon.value),
	}
	var env_valley := {
		"head":      float(pl_val_head.value),
		"target":    float(pl_val_target.value),
		"bar1":      float(pl_val_bar1.value),
		"bar2":      float(pl_val_bar2.value),
		"tail":      float(pl_val_tail.value),
		"hold":      float(pl_val_hold.value),
		"rush_text": float(pl_val_rush_text.value),
		"rush_icon": float(pl_val_rush_icon.value),
	}

	var beats_per_pulse := float(sb_beats.value)
	var phase_beats := float(sb_phase.value)
	var ease_idx := dd_ease.get_selected_id()
	if ease_idx < 0 or ease_idx >= EASE_CHOICES.size():
		ease_idx = 1
	var ease_key := String(EASE_CHOICES[ease_idx]["key"])

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Pulse Glow VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_pulse_glow_rows(
		specs,
		start,
		finish,
		density_ms,
		cap,
		atten_slides,
		env_peak,
		env_valley,
		beats_per_pulse,
		phase_beats,
		ease_key,
		end_hold_ms,
		use_note_end
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✨ Pulse Glow windows written for %d note(s)." % specs.size())

# ───────────────────────────────────────────────────────────────
# Row builders (return rows instead of writing directly)
# ───────────────────────────────────────────────────────────────

func _get_custom_window_ms() -> int:
	if line_custom_start == null:
		return -1
	var t := line_custom_start.text.strip_edges()
	if t.is_empty():
		return -1
	if not t.is_valid_float():
		return -1
	var v := int(round(float(t.to_float())))
	if v <= 0:
		return -1
	return v

func _clamp_glow(v: Variant) -> float:
	var f := float(v)
	return clamp(f, GLOW_MIN_MAX.x, GLOW_MIN_MAX.y)

func _apply_glow_atten(src: Dictionary, mul: float) -> Dictionary:
	return {
		"head":      float(src.get("head", 0.0)) * mul,
		"target":    float(src.get("target", 0.0)) * mul,
		"bar1":      float(src.get("bar1", 0.0)) * mul,
		"bar2":      float(src.get("bar2", src.get("bar1", 0.0))) * mul,
		"tail":      float(src.get("tail", 0.0)) * mul,
		"hold":      float(src.get("hold", 0.0)) * mul,
		"rush_text": float(src.get("rush_text", 0.0)) * mul,
		"rush_icon": float(src.get("rush_icon", 0.0)) * mul,
	}

func _override_glow_head(src: Dictionary, new_head: float) -> Dictionary:
	var d := src.duplicate()
	d["head"] = new_head
	return d

func _lerp_glow_dict(a: Dictionary, b: Dictionary, t: float) -> Dictionary:
	var res := {}
	var keys := ["head", "target", "bar1", "bar2", "tail", "hold", "rush_text", "rush_icon"]
	for k in keys:
		var av := float(a.get(k, 0.0))
		var bv := float(b.get(k, 0.0))
		res[k] = av + (bv - av) * t
	return res

func _make_row(
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String,
	glow: Dictionary,
	ease: String = "linear"
) -> Dictionary:
	var d := {
		"layer": layer,
		"time": time_ms,
		"note_type": float(note_type),
		"glow_head":      _clamp_glow(glow.get("head", 0.0)),
		"glow_target":    _clamp_glow(glow.get("target", 0.0)),
		"glow_bar1":      _clamp_glow(glow.get("bar1", 0.0)),
		"glow_bar2":      _clamp_glow(glow.get("bar2", glow.get("bar1", 0.0))),
		"glow_tail":      _clamp_glow(glow.get("tail", 0.0)),
		"glow_hold":      _clamp_glow(glow.get("hold", 0.0)),
		"glow_rush_text": _clamp_glow(glow.get("rush_text", 0.0)),
		"glow_rush_icon": _clamp_glow(glow.get("rush_icon", 0.0)),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time
	}
	if stage == "envelope":
		d["ease"] = ease
	return d

func _build_window_glow_rows(
	specs: Array,
	start_glow: Dictionary,
	end_glow: Dictionary,
	include_release: bool,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	# heads of selected notes
	var selected_keys := {}
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	# preserve everything except GlowAnim rows for those heads
	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer", ""))
		var ntype_e := int(e.get("note_type", -1))
		var head_e  := int(e.get("anim_note_time", -1))
		if layer_e == "" or ntype_e < 0 or head_e < 0:
			preserved.append(e)
			continue

		var key_e := "%s@%d@%d" % [layer_e, ntype_e, head_e]
		if not selected_keys.has(key_e):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()
	var custom_ms := _get_custom_window_ms()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var is_slide: bool = VFXUtils.is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		var window_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t)
		if custom_ms > 0:
			window_ms = custom_ms
		if window_ms <= 0:
			window_ms = 2000

		var t1 := head_t
		var t0 := max(0, head_t - window_ms)
		if t0 >= t1:
			t0 = t1 - 10

		var end_head_glow := float(end_glow.get("head", 0.0))
		if atten_slides and is_slide:
			end_head_glow *= SLIDE_HIT_ATTEN
		end_head_glow = min(end_head_glow, impact_cap)

		out_rows.append(_make_row(
			layer,
			t0,
			ntype,
			head_t,
			"anim_start",
			_apply_glow_atten(start_glow, lane_atten)
		))
		out_rows.append(_make_row(
			layer,
			t1,
			ntype,
			head_t,
			"impact",
			_apply_glow_atten(_override_glow_head(end_glow, end_head_glow), lane_atten)
		))

		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_window_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, rel_end)
			if custom_ms > 0:
				rel_window_ms = custom_ms
			if rel_window_ms <= 0:
				rel_window_ms = window_ms
			var r1 := rel_end
			var r0 := max(0, rel_end - rel_window_ms)
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(_make_row(
				layer,
				r0,
				ntype,
				head_t,
				"release_start",
				_apply_glow_atten(start_glow, lane_atten)
			))
			out_rows.append(_make_row(
				layer,
				r1,
				ntype,
				head_t,
				"release_impact",
				_apply_glow_atten(end_glow, lane_atten)
			))

	return out_rows

func _build_progressive_glow_rows(
	specs: Array,
	start_glow_global: Dictionary,
	end_glow_global: Dictionary,
	include_release: bool,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	var selected_keys := {}
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer", ""))
		var ntype_e := int(e.get("note_type", -1))
		var head_e  := int(e.get("anim_note_time", -1))
		if layer_e == "" or ntype_e < 0 or head_e < 0:
			preserved.append(e)
			continue

		var key_e := "%s@%d@%d" % [layer_e, ntype_e, head_e]
		if not selected_keys.has(key_e):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()
	var count := specs.size()
	if count <= 0:
		return out_rows

	var custom_ms := _get_custom_window_ms()

	for i in range(count):
		var spec = specs[i]
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var is_slide: bool = VFXUtils.is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		var t_factor := 0.0
		if count > 1:
			t_factor = float(i) / float(count - 1)

		var base_glow := _lerp_glow_dict(start_glow_global, end_glow_global, t_factor)

		var start_before_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t)
		if custom_ms > 0:
			start_before_ms = custom_ms
		if start_before_ms <= 0:
			start_before_ms = 2000

		var t0 := max(0, head_t - start_before_ms)
		var t1 := head_t
		if t0 >= t1:
			t0 = t1 - 10

		var end_head_glow := float(base_glow.get("head", 0.0))
		if atten_slides and is_slide:
			end_head_glow *= SLIDE_HIT_ATTEN
		end_head_glow = min(end_head_glow, impact_cap)

		out_rows.append(_make_row(
			layer,
			t0,
			ntype,
			head_t,
			"anim_start",
			_apply_glow_atten(base_glow, lane_atten)
		))
		out_rows.append(_make_row(
			layer,
			t1,
			ntype,
			head_t,
			"impact",
			_apply_glow_atten(_override_glow_head(base_glow, end_head_glow), lane_atten)
		))

		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_before_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, rel_end)
			if custom_ms > 0:
				rel_before_ms = custom_ms
			if rel_before_ms <= 0:
				rel_before_ms = start_before_ms

			var r0 := max(0, rel_end - rel_before_ms)
			var r1 := rel_end
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(_make_row(
				layer,
				r0,
				ntype,
				head_t,
				"release_start",
				_apply_glow_atten(base_glow, lane_atten)
			))
			out_rows.append(_make_row(
				layer,
				r1,
				ntype,
				head_t,
				"release_impact",
				_apply_glow_atten(base_glow, lane_atten)
			))

	return out_rows

func _build_pulse_glow_rows(
	specs: Array,
	start_glow: Dictionary,
	end_glow: Dictionary,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool,
	env_peak: Dictionary,
	env_valley: Dictionary,
	beats_per_pulse: float,
	phase_beats: float,
	ease_key: String,
	end_hold_ms: int = 0,
	use_note_end: bool = false
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	var selected_keys := {}
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer", ""))
		var ntype_e := int(e.get("note_type", -1))
		var head_e := int(e.get("anim_note_time", -1))
		if layer_e == "" or ntype_e < 0 or head_e < 0:
			preserved.append(e)
			continue

		var key_e := "%s@%d@%d" % [layer_e, ntype_e, head_e]
		if not selected_keys.has(key_e):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()
	var custom_ms := _get_custom_window_ms()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)
		var is_slide: bool = VFXUtils.is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		var timeout_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t)
		if custom_ms > 0:
			timeout_ms = custom_ms
		if timeout_ms <= 0:
			timeout_ms = 2000

		var bpm: float = VFXUtils.bpm_at_ms(editor, head_t)
		if bpm <= 0.0:
			bpm = 120.0

		var t1 := head_t
		var t0 := max(0, head_t - timeout_ms)
		if t0 >= t1:
			t0 = t1 - 10

		var end_head_glow := float(end_glow.get("head", 0.0))
		if atten_slides and is_slide:
			end_head_glow = end_head_glow * SLIDE_HIT_ATTEN
		end_head_glow = min(float(end_head_glow), impact_cap)

		out_rows.append(_make_row(
			layer,
			t0,
			ntype,
			head_t,
			"anim_start",
			_apply_glow_atten(start_glow, lane_atten)
		))

		var beat_ms := int(round(60000.0 / max(1.0, bpm)))
		var pulse_ms := int(round(max(0.001, beats_per_pulse) * beat_ms))
		var phase_ms := int(round(phase_beats * beat_ms))

		if pulse_ms <= 0:
			pulse_ms = beat_ms

		var first_tick: int = t0 + phase_ms
		if first_tick <= t0:
			var k: int = int(floor(float(t0 - first_tick) / float(pulse_ms))) + 1
			first_tick = first_tick + k * pulse_ms

		var tick: int = first_tick
		var put_peak := true
		while tick < t1:
			var clamped_tick := max(t0 + 1, min(t1 - 1, tick))
			var env_dict := env_peak if put_peak else env_valley
			out_rows.append(_make_row(
				layer,
				clamped_tick,
				ntype,
				head_t,
				"envelope",
				_apply_glow_atten(env_dict, lane_atten),
				ease_key
			))
			put_peak = not put_peak
			tick += pulse_ms

		# Determine if we're using hold_end
		var hold_end_time := 0
		if use_note_end and spec.has("sustain_end"):
			hold_end_time = int(spec["sustain_end"])
		elif end_hold_ms > 0:
			hold_end_time = head_t + end_hold_ms

		if hold_end_time > t1:
			# Post-impact envelopes (impact to hold_end)
			# Continue from where we left off, keeping the same phase/rhythm
			var rem := fposmod(float(t1) - float(phase_ms), float(pulse_ms))
			var post_tick := int(round(t1 + (pulse_ms - rem)))
			if post_tick <= t1:
				post_tick += pulse_ms

			while post_tick < hold_end_time:
				var env_dict := env_peak if put_peak else env_valley
				out_rows.append(_make_row(
					layer,
					post_tick,
					ntype,
					head_t,
					"envelope",
					_apply_glow_atten(env_dict, lane_atten),
					ease_key
				))
				put_peak = not put_peak
				post_tick += pulse_ms

			out_rows.append(_make_row(
				layer,
				hold_end_time,
				ntype,
				head_t,
				"hold_end",
				_apply_glow_atten(_override_glow_head(end_glow, end_head_glow), lane_atten)
			))
		else:
			out_rows.append(_make_row(
				layer,
				t1,
				ntype,
				head_t,
				"impact",
				_apply_glow_atten(_override_glow_head(end_glow, end_head_glow), lane_atten)
			))

	return out_rows


# ───────────────────────────────────────────────────────────────
# Glow-specific helpers
# ───────────────────────────────────────────────────────────────

func _compute_density(specs: Array, window_ms: int) -> Dictionary:
	var out := {}
	if window_ms <= 0:
		for s in specs:
			out["%s@%d@%d" % [String(s["layer"]), int(s["time"]), int(s["note_type"])]] = 1.0
		return out
	for i in range(specs.size()):
		var si = specs[i]
		var li := String(si["layer"])
		var ti := int(si["time"])
		var nti := int(si["note_type"])
		var count := 1
		for j in range(specs.size()):
			if i == j:
				continue
			var sj = specs[j]
			if String(sj["layer"]) != li:
				continue
			if abs(int(sj["time"]) - ti) <= window_ms:
				count += 1
		var atten := 1.0 / sqrt(float(max(1, count)))
		out["%s@%d@%d" % [li, ti, nti]] = atten
	return out

func _mk_glow_card(parent: Container, title: String, def_val: float) -> SpinBox:
	var card := VBoxContainer.new()
	card.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	card.custom_minimum_size.x = 80
	parent.add_child(card)

	var lbl := Label.new()
	lbl.text = title
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	card.add_child(lbl)

	var sb := SpinBox.new()
	sb.min_value = GLOW_MIN_MAX.x
	sb.max_value = GLOW_MIN_MAX.y
	sb.step = 0.05
	sb.value = def_val
	sb.custom_minimum_size.x = 72
	sb.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	card.add_child(sb)

	return sb

func _mk_hb_button(text: String, tooltip: String, func_name: String) -> HBEditorButton:
	var b := HBEditorButton.new()
	b.button_mode = "function"
	b.text = text
	b.tooltip = tooltip
	b.function_name = func_name
	b.params = []
	b.disable_when_playing = true
	b.disable_with_popup = true

	# Let the ratio container control the final size
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 0)

	b.set_module(self)
	return b

func _parse_end_hold_ms() -> int:
	if line_end_hold == null:
		return 0
	var t := line_end_hold.text.strip_edges()
	if t.is_empty():
		return 0
	if not t.is_valid_float():
		return 0
	var v := int(round(float(t)))
	if v < 0:
		return 0
	return v


# ───────────────────────────────────────────────────────────────
# Preview / notifications
# ───────────────────────────────────────────────────────────────

func _after_write_preview() -> void:
	VFXUtils.trigger_preview_reload(editor)

func _notify(text: String) -> void:
	VFXUtils.show_notification(editor, text)

func _reset_to_defaults() -> void:
	# Shared timing
	if line_custom_start:
		line_custom_start.text = ""
	if sb_density:
		sb_density.value = DENSITY_DEF_MS
	if cb_release:
		cb_release.button_pressed = true
	if sb_cap:
		sb_cap.value = IMPACT_CAP
	if cb_slide:
		cb_slide.button_pressed = true

	# Hold end timing
	if line_end_hold:
		line_end_hold.text = "0"
	if cb_use_note_end:
		cb_use_note_end.button_pressed = false

	# Static
	if st_head:      st_head.value      = DEFAULT_GLOW_STATIC["head"]
	if st_target:    st_target.value    = DEFAULT_GLOW_STATIC["target"]
	if st_bar1:      st_bar1.value      = DEFAULT_GLOW_STATIC["bar1"]
	if st_bar2:      st_bar2.value      = DEFAULT_GLOW_STATIC["bar2"]
	if st_tail:      st_tail.value      = DEFAULT_GLOW_STATIC["tail"]
	if st_hold:      st_hold.value      = DEFAULT_GLOW_STATIC["hold"]
	if st_rush_text: st_rush_text.value = DEFAULT_GLOW_STATIC.get("rush", 1.0)
	if st_rush_icon: st_rush_icon.value = DEFAULT_GLOW_STATIC.get("rush", 1.0)

	# Grow/Shrink – Start
	if gs_s_head:      gs_s_head.value      = DEFAULT_GLOW_START["head"]
	if gs_s_target:    gs_s_target.value    = DEFAULT_GLOW_START["target"]
	if gs_s_bar1:      gs_s_bar1.value      = DEFAULT_GLOW_START["bar1"]
	if gs_s_bar2:      gs_s_bar2.value      = DEFAULT_GLOW_START["bar2"]
	if gs_s_tail:      gs_s_tail.value      = DEFAULT_GLOW_START["tail"]
	if gs_s_hold:      gs_s_hold.value      = DEFAULT_GLOW_START["hold"]
	if gs_s_rush_text: gs_s_rush_text.value = DEFAULT_GLOW_START.get("rush", 0.3)
	if gs_s_rush_icon: gs_s_rush_icon.value = DEFAULT_GLOW_START.get("rush", 0.3)

	# Grow/Shrink – End
	if gs_e_head:      gs_e_head.value      = DEFAULT_GLOW_END["head"]
	if gs_e_target:    gs_e_target.value    = DEFAULT_GLOW_END["target"]
	if gs_e_bar1:      gs_e_bar1.value      = DEFAULT_GLOW_END["bar1"]
	if gs_e_bar2:      gs_e_bar2.value      = DEFAULT_GLOW_END["bar2"]
	if gs_e_tail:      gs_e_tail.value      = DEFAULT_GLOW_END["tail"]
	if gs_e_hold:      gs_e_hold.value      = DEFAULT_GLOW_END["hold"]
	if gs_e_rush_text: gs_e_rush_text.value = DEFAULT_GLOW_END.get("rush", 1.0)
	if gs_e_rush_icon: gs_e_rush_icon.value = DEFAULT_GLOW_END.get("rush", 1.0)

	# Pulse – Start
	if pl_s_head:      pl_s_head.value      = DEFAULT_GLOW_START["head"]
	if pl_s_target:    pl_s_target.value    = DEFAULT_GLOW_START["target"]
	if pl_s_bar1:      pl_s_bar1.value      = DEFAULT_GLOW_START["bar1"]
	if pl_s_bar2:      pl_s_bar2.value      = DEFAULT_GLOW_START["bar2"]
	if pl_s_tail:      pl_s_tail.value      = DEFAULT_GLOW_START["tail"]
	if pl_s_hold:      pl_s_hold.value      = DEFAULT_GLOW_START["hold"]
	if pl_s_rush_text: pl_s_rush_text.value = DEFAULT_GLOW_START.get("rush", 0.3)
	if pl_s_rush_icon: pl_s_rush_icon.value = DEFAULT_GLOW_START.get("rush", 0.3)

	# Pulse – Impact
	if pl_e_head:      pl_e_head.value      = DEFAULT_GLOW_END["head"]
	if pl_e_target:    pl_e_target.value    = DEFAULT_GLOW_END["target"]
	if pl_e_bar1:      pl_e_bar1.value      = DEFAULT_GLOW_END["bar1"]
	if pl_e_bar2:      pl_e_bar2.value      = DEFAULT_GLOW_END["bar2"]
	if pl_e_tail:      pl_e_tail.value      = DEFAULT_GLOW_END["tail"]
	if pl_e_hold:      pl_e_hold.value      = DEFAULT_GLOW_END["hold"]
	if pl_e_rush_text: pl_e_rush_text.value = DEFAULT_GLOW_END.get("rush", 1.0)
	if pl_e_rush_icon: pl_e_rush_icon.value = DEFAULT_GLOW_END.get("rush", 1.0)

	# Pulse – Peak env
	if pl_peak_head:      pl_peak_head.value      = DEFAULT_ENV_PEAK["head"]
	if pl_peak_target:    pl_peak_target.value    = DEFAULT_ENV_PEAK["target"]
	if pl_peak_bar1:      pl_peak_bar1.value      = DEFAULT_ENV_PEAK["bar1"]
	if pl_peak_bar2:      pl_peak_bar2.value      = DEFAULT_ENV_PEAK["bar2"]
	if pl_peak_tail:      pl_peak_tail.value      = DEFAULT_ENV_PEAK["tail"]
	if pl_peak_hold:      pl_peak_hold.value      = DEFAULT_ENV_PEAK["hold"]
	if pl_peak_rush_text: pl_peak_rush_text.value = DEFAULT_ENV_PEAK.get("rush", 1.5)
	if pl_peak_rush_icon: pl_peak_rush_icon.value = DEFAULT_ENV_PEAK.get("rush", 1.5)

	# Pulse – Valley env
	if pl_val_head:      pl_val_head.value      = DEFAULT_ENV_VALLEY["head"]
	if pl_val_target:    pl_val_target.value    = DEFAULT_ENV_VALLEY["target"]
	if pl_val_bar1:      pl_val_bar1.value      = DEFAULT_ENV_VALLEY["bar1"]
	if pl_val_bar2:      pl_val_bar2.value      = DEFAULT_ENV_VALLEY["bar2"]
	if pl_val_tail:      pl_val_tail.value      = DEFAULT_ENV_VALLEY["tail"]
	if pl_val_hold:      pl_val_hold.value      = DEFAULT_ENV_VALLEY["hold"]
	if pl_val_rush_text: pl_val_rush_text.value = DEFAULT_ENV_VALLEY.get("rush", 0.0)
	if pl_val_rush_icon: pl_val_rush_icon.value = DEFAULT_ENV_VALLEY.get("rush", 0.0)

	# Pulse controls
	if sb_beats:
		sb_beats.value = DEFAULT_BEATS_PER_PULSE
	if sb_phase:
		sb_phase.value = DEFAULT_PHASE_BEATS
	if dd_ease:
		var idx := 0
		for i in range(EASE_CHOICES.size()):
			if String(EASE_CHOICES[i]["key"]) == "linear":
				idx = i
				break
		dd_ease.select(idx)

	_notify("✅ Glow UI reset to defaults.")
