extends HBEditorModule
class_name ScaleVfxModule

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED UTILITIES - Preload the shared helper library
# ═══════════════════════════════════════════════════════════════════════════════
const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")

const ANIM_TAG := "ScaleAbsAnim/v1"

const SCALE_MIN_MAX := Vector2(0.4, 4.0)
const DENSITY_DEF_MS := 80
const SLIDE_HIT_ATTEN := 0.85
const IMPACT_CAP := 1.18
const DEBUG_TIMEOUT := true

# Grow/Shrink defaults (same as your window scripts)
const DEFAULT_SCALES_START := {"head":0.90, "target":0.90, "bar1":0.90, "bar2":0.90, "tail":0.95, "hold":0.90, "rush":0.90, "rush_graphic":0.5}
const DEFAULT_SCALES_END   := {"head":1.22, "target":1.04, "bar1":0.96, "bar2":0.96, "tail":1.12, "hold":0.96, "rush":1.10, "rush_graphic":1.0}

# Pulse envelope defaults
const DEFAULT_ENV_PEAKS  := {"head":1.10,"target":1.00,"bar1":0.98,"bar2":0.98,"tail":1.06,"hold":1.00,"rush":1.05}
const DEFAULT_ENV_VALLEY := {"head":0.90,"target":0.92,"bar1":0.94,"bar2":0.94,"tail":0.96,"hold":0.96,"rush":0.92}
const DEFAULT_BEATS_PER_PULSE := 1.0
const DEFAULT_PHASE_BEATS := 0.0

var ICON_STATIC_SCALE: Texture2D = null
var ICON_GROWSHRINK_SCALE: Texture2D = null
var ICON_PROG_SCALE: Texture2D = null
var ICON_PULSE_SCALE: Texture2D = null
var ICON_RESET_SCALE: Texture2D = null

# ── Shared UI refs ─────────────────────────────────────────────
var line_custom_start : LineEdit
var sb_density : SpinBox
var cb_release : CheckBox
var sb_cap : SpinBox
var cb_slide : CheckBox
var line_end_hold : LineEdit
var cb_use_note_end : CheckBox

# Static (single-value) UI
var st_head : SpinBox
var st_target : SpinBox
var st_bar1 : SpinBox
var st_bar2 : SpinBox
var st_tail : SpinBox
var st_hold : SpinBox
var st_rush : SpinBox
var st_rush_graphic : SpinBox

# Grow/Shrink UI
var gs_s_head : SpinBox
var gs_s_target : SpinBox
var gs_s_bar1 : SpinBox
var gs_s_bar2 : SpinBox
var gs_s_tail : SpinBox
var gs_s_hold : SpinBox
var gs_s_rush : SpinBox
var gs_s_rush_graphic : SpinBox

var gs_e_head : SpinBox
var gs_e_target : SpinBox
var gs_e_bar1 : SpinBox
var gs_e_bar2 : SpinBox
var gs_e_tail : SpinBox
var gs_e_hold : SpinBox
var gs_e_rush : SpinBox
var gs_e_rush_graphic : SpinBox

# Pulse UI
var pl_s_head : SpinBox
var pl_s_target : SpinBox
var pl_s_bar1 : SpinBox
var pl_s_bar2 : SpinBox
var pl_s_tail : SpinBox
var pl_s_hold : SpinBox
var pl_s_rush : SpinBox

var pl_e_head : SpinBox
var pl_e_target : SpinBox
var pl_e_bar1 : SpinBox
var pl_e_bar2 : SpinBox
var pl_e_tail : SpinBox
var pl_e_hold : SpinBox
var pl_e_rush : SpinBox

var pl_peak_head : SpinBox
var pl_peak_target : SpinBox
var pl_peak_bar1 : SpinBox
var pl_peak_bar2 : SpinBox
var pl_peak_tail : SpinBox
var pl_peak_hold : SpinBox
var pl_peak_rush : SpinBox

var pl_val_head : SpinBox
var pl_val_target : SpinBox
var pl_val_bar1 : SpinBox
var pl_val_bar2 : SpinBox
var pl_val_tail : SpinBox
var pl_val_hold : SpinBox
var pl_val_rush : SpinBox

var sb_beats : SpinBox
var sb_phase : SpinBox
var dd_ease : OptionButton

# ───────────────────────────────────────────────────────────────
# Lifecycle
# ───────────────────────────────────────────────────────────────

func _ready() -> void:
	super._ready()
	_build_ui()

func _build_ui() -> void:
	# Scroll root so content can't spill into the timeline
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.anchor_left = 0.0
	scroll.anchor_top = 0.0
	scroll.anchor_right = 1.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = 0
	scroll.offset_top = 0
	scroll.offset_right = 0
	scroll.offset_bottom = 0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	add_child(scroll)

	# Margin inside the scroll area
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(root)

	# ── Shared timing ───────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Window timing (all modes)"))

	var row_t := HBoxContainer.new()
	row_t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_t)

	row_t.add_child(VFXUtils.mk_label("Start window (ms before hit):"))
	line_custom_start = LineEdit.new()
	line_custom_start.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_custom_start.custom_minimum_size.x = 80
	line_custom_start.placeholder_text = "blank"
	line_custom_start.alignment = HORIZONTAL_ALIGNMENT_LEFT
	row_t.add_child(line_custom_start)

	row_t.add_child(VFXUtils.mk_label("= use GAME TIMEOUT"))
	row_t.add_child(VFXUtils.mk_spacer())

	row_t.add_child(VFXUtils.mk_label("Density window (ms):"))
	sb_density = SpinBox.new()
	sb_density.min_value = 0
	sb_density.max_value = 200
	sb_density.step = 5
	sb_density.value = DENSITY_DEF_MS
	sb_density.custom_minimum_size.x = 80
	VFXUtils.left_align_spinbox(sb_density)
	row_t.add_child(sb_density)

	# Release window for sustains
	var row2 := HBoxContainer.new()
	row2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row2)
	cb_release = CheckBox.new()
	cb_release.text = "Release window for sustains"
	cb_release.tooltip_text = "Also authors a RELEASE window for sustains using the same window length."
	cb_release.button_pressed = true
	row2.add_child(cb_release)
	row2.add_child(VFXUtils.mk_spacer())

	# End hold timing (for Rush/Sustain notes to maintain scale past impact)
	var row_end := HBoxContainer.new()
	row_end.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_end)

	row_end.add_child(VFXUtils.mk_label("Hold end scale (ms after impact):"))
	line_end_hold = LineEdit.new()
	line_end_hold.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_end_hold.custom_minimum_size.x = 80
	line_end_hold.text = "0"
	line_end_hold.placeholder_text = "0"
	line_end_hold.tooltip_text = "Maintains end scale for this many ms after impact. Use for Rush/Sustain notes."
	row_end.add_child(line_end_hold)

	cb_use_note_end = CheckBox.new()
	cb_use_note_end.text = "Use hold end"
	cb_use_note_end.tooltip_text = "Automatically extend to the note's end time (Rush duration or Sustain release). Overrides manual ms value."
	cb_use_note_end.button_pressed = false
	row_end.add_child(cb_use_note_end)
	row_end.add_child(VFXUtils.mk_spacer())

	# Impact cap + slide attenuation
	var row3 := HBoxContainer.new()
	row3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row3)
	row3.add_child(VFXUtils.mk_label("Impact cap (head):"))
	sb_cap = SpinBox.new()
	sb_cap.min_value = 0.4
	sb_cap.max_value = 4.0
	sb_cap.step = 0.01
	sb_cap.value = IMPACT_CAP
	sb_cap.custom_minimum_size.x = 80
	VFXUtils.left_align_spinbox(sb_cap) 
	row3.add_child(sb_cap)

	cb_slide = CheckBox.new()
	cb_slide.text = "Reduce slide impact"
	cb_slide.tooltip_text = "Attenuate slide hit/snap scales for legibility."
	cb_slide.button_pressed = true
	row3.add_child(cb_slide)
	row3.add_child(VFXUtils.mk_spacer())

	# ── STATIC (single value) ──────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Static Scale – single value for Start & Impact"))

	var row_static := HBoxContainer.new()
	row_static.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_static.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_static)

	st_head   = _mk_scale_card(row_static, "Head",   DEFAULT_SCALES_END["head"])
	st_target = _mk_scale_card(row_static, "Target", DEFAULT_SCALES_END["target"])
	st_bar1   = _mk_scale_card(row_static, "Bar 1",  DEFAULT_SCALES_END["bar1"])
	st_bar2   = _mk_scale_card(row_static, "Bar 2",  DEFAULT_SCALES_END["bar2"])
	st_tail   = _mk_scale_card(row_static, "Tail",   DEFAULT_SCALES_END["tail"])
	st_hold   = _mk_scale_card(row_static, "Hold",   DEFAULT_SCALES_END["hold"])
	st_rush   = _mk_scale_card(row_static, "Rush Text", DEFAULT_SCALES_END["rush"])
	st_rush_graphic = _mk_scale_card(row_static, "Rush Icon", DEFAULT_SCALES_END["rush_graphic"])

	# Row for the Static Scale button + icon
	var row_static_btn := HBoxContainer.new()
	row_static_btn.alignment = BoxContainer.ALIGNMENT_CENTER
	row_static_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_static_btn)

	var hb_static := _mk_hb_button(
		"Static Scale",
		"Uses one scale set for both start and impact (and optional release).",
		"_apply_static_scale"
	)
	hb_static.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

	# Ratio container for this row (add button BEFORE adding to tree)
	var ratio_static := HBoxRatioContainer.new()
	ratio_static.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_static.add_child(hb_static)

	row_static_btn.add_child(ratio_static)

	# Icon wiring stays the same
	if ICON_STATIC_SCALE == null:
		ICON_STATIC_SCALE = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/scale.svg")
		if ICON_STATIC_SCALE == null:
			ICON_STATIC_SCALE = preload("res://graphics/icons/console-line.svg")

	var static_inner_button: Button = hb_static.get_button()
	static_inner_button.icon = ICON_STATIC_SCALE
	static_inner_button.expand_icon = true
	static_inner_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER




	# ── GROW / SHRINK ──────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Grow/Shrink/Progressive – separate Start / End scales"))

	var row_gs_start := HBoxContainer.new()
	row_gs_start.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_gs_start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_gs_start)


	gs_s_head   = _mk_scale_card(row_gs_start, "Start Head",   DEFAULT_SCALES_START["head"])
	gs_s_target = _mk_scale_card(row_gs_start, "Start Target", DEFAULT_SCALES_START["target"])
	gs_s_bar1   = _mk_scale_card(row_gs_start, "Start Bar 1",  DEFAULT_SCALES_START["bar1"])
	gs_s_bar2   = _mk_scale_card(row_gs_start, "Start Bar 2",  DEFAULT_SCALES_START["bar2"])
	gs_s_tail   = _mk_scale_card(row_gs_start, "Start Tail",   DEFAULT_SCALES_START["tail"])
	gs_s_hold   = _mk_scale_card(row_gs_start, "Start Hold",   DEFAULT_SCALES_START["hold"])
	gs_s_rush   = _mk_scale_card(row_gs_start, "Start Rush Text", DEFAULT_SCALES_START["rush"])
	gs_s_rush_graphic = _mk_scale_card(row_gs_start, "Start Rush Icon", DEFAULT_SCALES_START["rush_graphic"])

	var row_gs_end := HBoxContainer.new()
	row_gs_end.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_gs_end.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_gs_end)

	gs_e_head   = _mk_scale_card(row_gs_end, "End Head",   DEFAULT_SCALES_END["head"])
	gs_e_target = _mk_scale_card(row_gs_end, "End Target", DEFAULT_SCALES_END["target"])
	gs_e_bar1   = _mk_scale_card(row_gs_end, "End Bar 1",  DEFAULT_SCALES_END["bar1"])
	gs_e_bar2   = _mk_scale_card(row_gs_end, "End Bar 2",  DEFAULT_SCALES_END["bar2"])
	gs_e_tail   = _mk_scale_card(row_gs_end, "End Tail",   DEFAULT_SCALES_END["tail"])
	gs_e_hold   = _mk_scale_card(row_gs_end, "End Hold",   DEFAULT_SCALES_END["hold"])
	gs_e_rush   = _mk_scale_card(row_gs_end, "End Rush Text", DEFAULT_SCALES_END["rush"])
	gs_e_rush_graphic = _mk_scale_card(row_gs_end, "End Rush Icon", DEFAULT_SCALES_END["rush_graphic"])

	var hb_gs := _mk_hb_button(
		"Grow/Shrink",
		"Uses separate Start and End scales (timeout or custom window length).",
		"_apply_grow_shrink_scale"
	)
	hb_gs.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var hb_prog := _mk_hb_button(
		"Prog Scale",
		"Linearly interpolates Start → End scales from first to last selected note.",
		"_apply_progressive_scale"
	)
	hb_prog.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var row_gs_btn := HBoxContainer.new()
	row_gs_btn.alignment = BoxContainer.ALIGNMENT_CENTER
	row_gs_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_gs_btn)

	var ratio_gs := HBoxRatioContainer.new()
	ratio_gs.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

	# IMPORTANT: add children before adding ratio_gs to the tree
	ratio_gs.add_child(hb_gs)
	ratio_gs.add_child(hb_prog)

	row_gs_btn.add_child(ratio_gs)



	# Load icon for Grow/Shrink button (user:// SVG, fallback to built-in if missing)
	if ICON_GROWSHRINK_SCALE == null:
		ICON_GROWSHRINK_SCALE = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/grow_shrink.svg")
		if ICON_GROWSHRINK_SCALE == null:
			ICON_GROWSHRINK_SCALE = preload("res://graphics/icons/console-line.svg")

	var gs_inner_button: Button = hb_gs.get_button()
	gs_inner_button.icon = ICON_GROWSHRINK_SCALE
	gs_inner_button.expand_icon = true
	gs_inner_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	# Load icon for Prog Scale button (user:// SVG, fallback to built-in if missing)
	if ICON_PROG_SCALE == null:
		ICON_PROG_SCALE = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/prog_scale.svg")
		if ICON_PROG_SCALE == null:
			ICON_PROG_SCALE = preload("res://graphics/icons/console-line.svg")

	var prog_inner_button: Button = hb_prog.get_button()
	prog_inner_button.icon = ICON_PROG_SCALE
	prog_inner_button.expand_icon = true
	prog_inner_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER


	# ── PULSE ──────────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Pulse – timeout window + beat envelopes inside"))

	var row_pl_start := HBoxContainer.new()
	row_pl_start.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_pl_start.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_pl_start)


	pl_s_head   = _mk_scale_card(row_pl_start, "Start Head",   DEFAULT_SCALES_START["head"])
	pl_s_target = _mk_scale_card(row_pl_start, "Start Target", DEFAULT_SCALES_START["target"])
	pl_s_bar1   = _mk_scale_card(row_pl_start, "Start Bar 1",  DEFAULT_SCALES_START["bar1"])
	pl_s_bar2   = _mk_scale_card(row_pl_start, "Start Bar 2",  DEFAULT_SCALES_START["bar2"])
	pl_s_tail   = _mk_scale_card(row_pl_start, "Start Tail",   DEFAULT_SCALES_START["tail"])
	pl_s_hold   = _mk_scale_card(row_pl_start, "Start Hold",   DEFAULT_SCALES_START["hold"])
	pl_s_rush   = _mk_scale_card(row_pl_start, "Start Rush",   DEFAULT_SCALES_START["rush"])

	var row_pl_end := HBoxContainer.new()
	row_pl_end.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_pl_end.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_pl_end)

	pl_e_head   = _mk_scale_card(row_pl_end, "Impact Head",   DEFAULT_SCALES_END["head"])
	pl_e_target = _mk_scale_card(row_pl_end, "Impact Target", DEFAULT_SCALES_END["target"])
	pl_e_bar1   = _mk_scale_card(row_pl_end, "Impact Bar 1",  DEFAULT_SCALES_END["bar1"])
	pl_e_bar2   = _mk_scale_card(row_pl_end, "Impact Bar 2",  DEFAULT_SCALES_END["bar2"])
	pl_e_tail   = _mk_scale_card(row_pl_end, "Impact Tail",   DEFAULT_SCALES_END["tail"])
	pl_e_hold   = _mk_scale_card(row_pl_end, "Impact Hold",   DEFAULT_SCALES_END["hold"])
	pl_e_rush   = _mk_scale_card(row_pl_end, "Impact Rush",   DEFAULT_SCALES_END["rush"])

	root.add_child(VFXUtils.mk_section_label("Pulse envelopes (PEAK/VALLEY between Start → Impact)"))

	var row_peak := HBoxContainer.new()
	row_peak.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_peak.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_peak)


	pl_peak_head   = _mk_scale_card(row_peak, "Peak Head",   DEFAULT_ENV_PEAKS["head"])
	pl_peak_target = _mk_scale_card(row_peak, "Peak Target", DEFAULT_ENV_PEAKS["target"])
	pl_peak_bar1   = _mk_scale_card(row_peak, "Peak Bar 1",  DEFAULT_ENV_PEAKS["bar1"])
	pl_peak_bar2   = _mk_scale_card(row_peak, "Peak Bar 2",  DEFAULT_ENV_PEAKS["bar2"])
	pl_peak_tail   = _mk_scale_card(row_peak, "Peak Tail",   DEFAULT_ENV_PEAKS["tail"])
	pl_peak_hold   = _mk_scale_card(row_peak, "Peak Hold",   DEFAULT_ENV_PEAKS["hold"])
	pl_peak_rush   = _mk_scale_card(row_peak, "Peak Rush",   DEFAULT_ENV_PEAKS["rush"])

	var row_val := HBoxContainer.new()
	row_val.alignment = BoxContainer.ALIGNMENT_BEGIN
	row_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_val)


	pl_val_head   = _mk_scale_card(row_val, "Valley Head",   DEFAULT_ENV_VALLEY["head"])
	pl_val_target = _mk_scale_card(row_val, "Valley Target", DEFAULT_ENV_VALLEY["target"])
	pl_val_bar1   = _mk_scale_card(row_val, "Valley Bar 1",  DEFAULT_ENV_VALLEY["bar1"])
	pl_val_bar2   = _mk_scale_card(row_val, "Valley Bar 2",  DEFAULT_ENV_VALLEY["bar2"])
	pl_val_tail   = _mk_scale_card(row_val, "Valley Tail",   DEFAULT_ENV_VALLEY["tail"])
	pl_val_hold   = _mk_scale_card(row_val, "Valley Hold",   DEFAULT_ENV_VALLEY["hold"])
	pl_val_rush   = _mk_scale_card(row_val, "Valley Rush",   DEFAULT_ENV_VALLEY["rush"])

	var row_env := HBoxContainer.new()
	row_env.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_env)

	row_env.add_child(VFXUtils.mk_label("Beats per pulse:"))
	sb_beats = SpinBox.new()
	sb_beats.min_value = 0.125
	sb_beats.max_value = 8.0
	sb_beats.step = 0.125
	sb_beats.value = DEFAULT_BEATS_PER_PULSE
	sb_beats.custom_minimum_size.x = 80
	sb_beats.alignment = HORIZONTAL_ALIGNMENT_LEFT    
	row_env.add_child(sb_beats)

	row_env.add_child(VFXUtils.mk_spacer())
	row_env.add_child(VFXUtils.mk_label("Phase (beats):"))
	sb_phase = SpinBox.new()
	sb_phase.min_value = -8.0
	sb_phase.max_value = 8.0
	sb_phase.step = 0.125
	sb_phase.value = DEFAULT_PHASE_BEATS
	sb_phase.custom_minimum_size.x = 80
	VFXUtils.left_align_spinbox(sb_phase)   
	row_env.add_child(sb_phase)

	row_env.add_child(VFXUtils.mk_spacer())
	row_env.add_child(VFXUtils.mk_label("Envelope ease:"))
	dd_ease = OptionButton.new()
	for i in range(VFXUtils.EASE_CHOICES.size()):
		dd_ease.add_item(VFXUtils.EASE_CHOICES[i]["label"], i)
	dd_ease.select(1) # Linear default
	row_env.add_child(dd_ease)

	var hb_pulse := _mk_hb_button(
		"Pulse Scale",
		"Timeout-based window with envelope pulses between Start and Impact.",
		"_apply_pulse_scale"
	)
	hb_pulse.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var row_pulse_btn := HBoxContainer.new()
	row_pulse_btn.alignment = BoxContainer.ALIGNMENT_CENTER
	row_pulse_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_pulse_btn)

	var ratio_pulse := HBoxRatioContainer.new()
	ratio_pulse.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_pulse.add_child(hb_pulse)

	row_pulse_btn.add_child(ratio_pulse)
	# Load icon for Pulse Scale button (user:// SVG, fallback to built-in if missing)
	if ICON_PULSE_SCALE == null:
		ICON_PULSE_SCALE = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/pulse_scale.svg")
		if ICON_PULSE_SCALE == null:
			ICON_PULSE_SCALE = preload("res://graphics/icons/console-line.svg")

	var pulse_inner_button: Button = hb_pulse.get_button()
	pulse_inner_button.icon = ICON_PULSE_SCALE
	pulse_inner_button.expand_icon = true
	pulse_inner_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	
	# ── Reset UI button ─────────────────────────────────────────
	var row_reset := HBoxContainer.new()
	row_reset.alignment = BoxContainer.ALIGNMENT_CENTER
	row_reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_reset)

	var hb_reset := _mk_hb_button(
		"Reset Scale UI",
		"Reset all Scale fields in this tab back to their default values.",
		"_reset_to_defaults"
	)
	hb_reset.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN

	var ratio_reset := HBoxRatioContainer.new()
	ratio_reset.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ratio_reset.add_child(hb_reset)

	row_reset.add_child(ratio_reset)

	# Load icon for Reset UI button (user:// SVG, fallback to built-in)
	if ICON_RESET_SCALE == null:
		ICON_RESET_SCALE = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/scale_reset.svg")
		if ICON_RESET_SCALE == null:
			ICON_RESET_SCALE = preload("res://graphics/icons/console-line.svg")

	var reset_inner_button: Button = hb_reset.get_button()
	if reset_inner_button:
		reset_inner_button.icon = ICON_RESET_SCALE
		reset_inner_button.expand_icon = true
		reset_inner_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER



	# Footer hint
	var foot := HBoxContainer.new()
	root.add_child(foot)
	foot.add_child(VFXUtils.mk_label("If start window is blank, per-note GAME TIMEOUT is used (same as existing scripts). \nCaution: The Rush Icon value will overshoot by a starting factor of 0.5 on impact, due to the game's built-in scaling."))
	foot.add_child(VFXUtils.mk_spacer())

# ───────────────────────────────────────────────────────────────
# Entry points (called by the buttons) - WITH UNDO/REDO SUPPORT
# ───────────────────────────────────────────────────────────────

func _apply_static_scale() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed
	var include_release := cb_release.button_pressed
	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	var scales := {
		"head":   float(st_head.value),
		"target": float(st_target.value),
		"bar1":   float(st_bar1.value),
		"bar2":   float(st_bar2.value),
		"tail":   float(st_tail.value),
		"hold":   float(st_hold.value),
		"rush":   float(st_rush.value),
		"rush_graphic": float(st_rush_graphic.value),
	}

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Static Scale VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_window_scale_rows(
		specs, scales, scales, include_release, 
		density_ms, cap, atten_slides, end_hold_ms, use_note_end
	)
	
	# ─── Commit the action (handles write + preview) ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✅ Static Scale window written for %d note(s)." % specs.size())

func _apply_grow_shrink_scale() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed
	var include_release := cb_release.button_pressed
	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	var start := {
		"head":   float(gs_s_head.value),
		"target": float(gs_s_target.value),
		"bar1":   float(gs_s_bar1.value),
		"bar2":   float(gs_s_bar2.value),
		"tail":   float(gs_s_tail.value),
		"hold":   float(gs_s_hold.value),
		"rush":   float(gs_s_rush.value),
		"rush_graphic": float(gs_s_rush_graphic.value),
	}
	var finish := {
		"head":   float(gs_e_head.value),
		"target": float(gs_e_target.value),
		"bar1":   float(gs_e_bar1.value),
		"bar2":   float(gs_e_bar2.value),
		"tail":   float(gs_e_tail.value),
		"hold":   float(gs_e_hold.value),
		"rush":   float(gs_e_rush.value),
		"rush_graphic": float(gs_e_rush_graphic.value),
	}

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Grow/Shrink Scale VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_window_scale_rows(
		specs, start, finish, include_release, 
		density_ms, cap, atten_slides, end_hold_ms, use_note_end
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✅ Grow/Shrink window written for %d note(s)." % specs.size())

func _apply_progressive_scale() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return

	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	# Ensure progressive range runs in time order
	specs.sort_custom(func(a, b):
		return int(a["time"]) < int(b["time"])
	)

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed
	var include_release := cb_release.button_pressed

	var start_scales_global := {
		"head":   float(gs_s_head.value),
		"target": float(gs_s_target.value),
		"bar1":   float(gs_s_bar1.value),
		"bar2":   float(gs_s_bar2.value),
		"tail":   float(gs_s_tail.value),
		"hold":   float(gs_s_hold.value),
		"rush":   float(gs_s_rush.value),
		"rush_graphic": float(gs_s_rush_graphic.value),
	}
	var end_scales_global := {
		"head":   float(gs_e_head.value),
		"target": float(gs_e_target.value),
		"bar1":   float(gs_e_bar1.value),
		"bar2":   float(gs_e_bar2.value),
		"tail":   float(gs_e_tail.value),
		"hold":   float(gs_e_hold.value),
		"rush":   float(gs_e_rush.value),
		"rush_graphic": float(gs_e_rush_graphic.value),
	}

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Progressive Scale VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_progressive_scale_rows(
		specs,
		start_scales_global,
		end_scales_global,
		include_release,
		density_ms,
		cap,
		atten_slides
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✅ Progressive scale windows written for %d note(s)." % specs.size())


func _apply_pulse_scale() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var density_ms := int(sb_density.value)
	var cap := float(sb_cap.value)
	var atten_slides := cb_slide.button_pressed

	var start := {
		"head":   float(pl_s_head.value),
		"target": float(pl_s_target.value),
		"bar1":   float(pl_s_bar1.value),
		"bar2":   float(pl_s_bar2.value),
		"tail":   float(pl_s_tail.value),
		"hold":   float(pl_s_hold.value),
		"rush":   float(pl_s_rush.value),
	}
	var finish := {
		"head":   float(pl_e_head.value),
		"target": float(pl_e_target.value),
		"bar1":   float(pl_e_bar1.value),
		"bar2":   float(pl_e_bar2.value),
		"tail":   float(pl_e_tail.value),
		"hold":   float(pl_e_hold.value),
		"rush":   float(pl_e_rush.value),
	}
	var env_peak := {
		"head":   float(pl_peak_head.value),
		"target": float(pl_peak_target.value),
		"bar1":   float(pl_peak_bar1.value),
		"bar2":   float(pl_peak_bar2.value),
		"tail":   float(pl_peak_tail.value),
		"hold":   float(pl_peak_hold.value),
		"rush":   float(pl_peak_rush.value),
	}
	var env_valley := {
		"head":   float(pl_val_head.value),
		"target": float(pl_val_target.value),
		"bar1":   float(pl_val_bar1.value),
		"bar2":   float(pl_val_bar2.value),
		"tail":   float(pl_val_tail.value),
		"hold":   float(pl_val_hold.value),
		"rush":   float(pl_val_rush.value),
	}

	var beats_per_pulse := float(sb_beats.value)
	var phase_beats := float(sb_phase.value)
	var ease_idx := dd_ease.get_selected_id()
	if ease_idx < 0 or ease_idx >= VFXUtils.EASE_CHOICES.size():
		ease_idx = 1
	var ease_key := String(VFXUtils.EASE_CHOICES[ease_idx]["key"])

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Pulse Scale VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_pulse_scale_rows(
		specs,
		start, finish,
		density_ms, cap, atten_slides,
		env_peak, env_valley,
		beats_per_pulse, phase_beats, ease_key
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✅ Pulse windows written for %d note(s)." % specs.size())

# ───────────────────────────────────────────────────────────────
# Row builders (return rows instead of writing directly)
# ───────────────────────────────────────────────────────────────

func _get_custom_window_ms() -> int:
	if line_custom_start == null:
		return -1
	var t := line_custom_start.text.strip_edges()
	if t.is_empty():
		return -1
	if not t.is_valid_float():
		return -1
	var v := int(round(float(t.to_float())))
	if v <= 0:
		return -1
	return v

func _parse_end_hold_ms() -> int:
	if line_end_hold == null:
		return 0
	var t := line_end_hold.text.strip_edges()
	if t.is_empty():
		return 0
	if not t.is_valid_float():
		return 0
	var v := int(round(float(t.to_float())))
	if v < 0:
		return 0
	return v

func _build_window_scale_rows(
	specs: Array,
	start_scales: Dictionary,
	end_scales: Dictionary,
	include_release: bool,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool,
	end_hold_ms: int = 0,
	use_note_end: bool = false
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	var selected_keys := {}
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer", ""))
		var ntype_e := int(e.get("note_type", -1))
		var head_e := int(e.get("anim_note_time", -1))
		if layer_e == "" or ntype_e < 0 or head_e < 0:
			preserved.append(e)
			continue

		var key_e := "%s@%d@%d" % [layer_e, ntype_e, head_e]
		if not selected_keys.has(key_e):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()
	var custom_ms := _get_custom_window_ms()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var is_slide: bool = VFXUtils.is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		var window_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t, DEBUG_TIMEOUT)
		if custom_ms > 0:
			window_ms = custom_ms
		if window_ms <= 0:
			window_ms = 2000

		var t1 := head_t
		var t0 := max(0, head_t - window_ms)
		if t0 >= t1:
			t0 = t1 - 10

		var end_head_scale := float(end_scales.get("head", 1.0))
		if atten_slides and is_slide:
			end_head_scale *= SLIDE_HIT_ATTEN
		end_head_scale = min(end_head_scale, impact_cap)

		out_rows.append(
			_make_row(
				layer,
				t0,
				ntype,
				head_t,
				"anim_start",
				_apply_atten(start_scales, lane_atten)
			)
		)
		
		# Determine if we're using hold_end (for Rush/Sustain) or impact
		var hold_end_time := 0
		if use_note_end and spec.has("sustain_end"):
			hold_end_time = int(spec["sustain_end"])
		elif end_hold_ms > 0:
			hold_end_time = head_t + end_hold_ms

		# Write either impact OR hold_end row, not both
		if hold_end_time > t1:
			# Use hold_end - write end scales at the note's end time
			out_rows.append(
				_make_row(
					layer,
					hold_end_time,
					ntype,
					head_t,
					"hold_end",
					_apply_atten(_override_head(end_scales, end_head_scale), lane_atten)
				)
			)
		else:
			# Use impact - write end scales at the hit time
			out_rows.append(
				_make_row(
					layer,
					t1,
					ntype,
					head_t,
					"impact",
					_apply_atten(_override_head(end_scales, end_head_scale), lane_atten)
				)
			)

		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_window_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, rel_end, DEBUG_TIMEOUT)
			if custom_ms > 0:
				rel_window_ms = custom_ms
			if rel_window_ms <= 0:
				rel_window_ms = window_ms
			var r1 := rel_end
			var r0 := max(0, rel_end - rel_window_ms)
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(
				_make_row(
					layer,
					r0,
					ntype,
					head_t,
					"release_start",
					_apply_atten(start_scales, lane_atten)
				)
			)
			out_rows.append(
				_make_row(
					layer,
					r1,
					ntype,
					head_t,
					"release_impact",
					_apply_atten(end_scales, lane_atten)
				)
			)

	return out_rows


func _build_progressive_scale_rows(
	specs: Array,
	start_scales_global: Dictionary,
	end_scales_global: Dictionary,
	include_release: bool,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	var selected_keys := {}
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer", ""))
		var ntype_e := int(e.get("note_type", -1))
		var head_e  := int(e.get("anim_note_time", -1))
		if layer_e == "" or ntype_e < 0 or head_e < 0:
			preserved.append(e)
			continue

		var key_e := "%s@%d@%d" % [layer_e, ntype_e, head_e]
		if not selected_keys.has(key_e):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()
	var count := specs.size()
	if count <= 0:
		return out_rows

	var custom_ms := _get_custom_window_ms()

	for i in range(count):
		var spec = specs[i]
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var is_slide: bool = VFXUtils.is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		# 0.0 at first selected note, 1.0 at last
		var t_factor := 0.0
		if count > 1:
			t_factor = float(i) / float(count - 1)

		# Per-note base scales from global Start → End
		var base_scales := _lerp_scales_dict(start_scales_global, end_scales_global, t_factor)

		# Per-note timeout from game or custom override
		var start_before_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t, DEBUG_TIMEOUT)
		if custom_ms > 0:
			start_before_ms = custom_ms
		if start_before_ms <= 0:
			start_before_ms = 2000

		var t0 := max(0, head_t - start_before_ms)
		var t1 := head_t
		if t0 >= t1:
			t0 = t1 - 10

		# Slide attenuation + impact cap on head
		var end_head_scale := float(base_scales.get("head", 1.0))
		if atten_slides and is_slide:
			end_head_scale *= SLIDE_HIT_ATTEN
		end_head_scale = min(end_head_scale, impact_cap)

		# Start row
		out_rows.append(_make_row(
			layer,
			t0,
			ntype,
			head_t,
			"anim_start",
			_apply_atten(base_scales, lane_atten)
		))

		# Impact row (head overridden for slide/cap)
		out_rows.append(_make_row(
			layer,
			t1,
			ntype,
			head_t,
			"impact",
			_apply_atten(_override_head(base_scales, end_head_scale), lane_atten)
		))

		# Optional sustain RELEASE window
		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_before_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, rel_end, DEBUG_TIMEOUT)
			if custom_ms > 0:
				rel_before_ms = custom_ms
			if rel_before_ms <= 0:
				rel_before_ms = start_before_ms

			var r0 := max(0, rel_end - rel_before_ms)
			var r1 := rel_end
			if r0 >= r1:
				r0 = r1 - 10

			out_rows.append(_make_row(
				layer,
				r0,
				ntype,
				head_t,
				"release_start",
				_apply_atten(base_scales, lane_atten)
			))
			out_rows.append(_make_row(
				layer,
				r1,
				ntype,
				head_t,
				"release_impact",
				_apply_atten(base_scales, lane_atten)
			))

	return out_rows


func _build_pulse_scale_rows(
	specs: Array,
	start_scales: Dictionary,
	end_scales: Dictionary,
	density_ms: int,
	impact_cap: float,
	atten_slides: bool,
	env_peak: Dictionary,
	env_valley: Dictionary,
	beats_per_pulse: float,
	phase_beats: float,
	ease_key: String
) -> Array:
	if specs.is_empty():
		return []

	var path: String = VFXUtils.get_vfx_path(editor)
	var existing: Array = VFXUtils.load_vfx_json(path)

	var selected_keys := {}
	for s in specs:
		var layer := String(s["layer"])
		var ntype := int(s["note_type"])
		var head_t := int(s["time"])
		selected_keys["%s@%d@%d" % [layer, ntype, head_t]] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("layer", "")) == "$PLAYFIELD":
			preserved.append(e)
			continue
		if String(e.get("anim", "")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer_e := String(e.get("layer", ""))
		var ntype_e := int(e.get("note_type", -1))
		var head_e := int(e.get("anim_note_time", -1))
		if layer_e == "" or ntype_e < 0 or head_e < 0:
			preserved.append(e)
			continue

		var key_e := "%s@%d@%d" % [layer_e, ntype_e, head_e]
		if not selected_keys.has(key_e):
			preserved.append(e)

	var atten_map := _compute_density(specs, density_ms)
	var out_rows := preserved.duplicate()
	var custom_ms := _get_custom_window_ms()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)
		var is_slide: bool = VFXUtils.is_slide_type(ntype)
		var lane_key := "%s@%d@%d" % [layer, head_t, ntype]
		var lane_atten := float(atten_map.get(lane_key, 1.0))

		var timeout_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t, DEBUG_TIMEOUT)
		if custom_ms > 0:
			timeout_ms = custom_ms
		if timeout_ms <= 0:
			timeout_ms = 2000

		var bpm: float = VFXUtils.bpm_at_ms(editor, head_t)
		if bpm <= 0.0:
			bpm = 120.0

		var t1 := head_t
		var t0 := max(0, head_t - timeout_ms)
		if t0 >= t1:
			t0 = t1 - 10

		var end_head_scale := float(end_scales.get("head", 1.0))
		if atten_slides and is_slide:
			end_head_scale = end_head_scale * SLIDE_HIT_ATTEN
		end_head_scale = min(float(end_head_scale), impact_cap)

		out_rows.append(_make_row(
			layer,
			t0,
			ntype,
			head_t,
			"anim_start",
			_apply_atten(start_scales, lane_atten)
		))

		var beat_ms := int(round(60000.0 / max(1.0, bpm)))
		var pulse_ms := int(round(max(0.001, beats_per_pulse) * beat_ms))
		var phase_ms := int(round(phase_beats * beat_ms))

		if pulse_ms <= 0:
			pulse_ms = beat_ms

		var first_tick: int = t0 + phase_ms
		if first_tick <= t0:
			var k: int = int(floor(float(t0 - first_tick) / float(pulse_ms))) + 1
			first_tick = first_tick + k * pulse_ms

		var tick: int = first_tick
		var put_peak := true
		while tick < t1:
			var clamped_tick := max(t0 + 1, min(t1 - 1, tick))
			var env_dict := env_peak if put_peak else env_valley
			out_rows.append(_make_row(
				layer,
				clamped_tick,
				ntype,
				head_t,
				"envelope",
				_apply_atten(env_dict, lane_atten),
				ease_key
			))
			put_peak = not put_peak
			tick += pulse_ms

		out_rows.append(_make_row(
			layer,
			t1,
			ntype,
			head_t,
			"impact",
			_apply_atten(_override_head(end_scales, end_head_scale), lane_atten)
		))

	return out_rows


# ───────────────────────────────────────────────────────────────
# Scale-specific helpers (kept local - not generic enough for VFXUtils)
# ───────────────────────────────────────────────────────────────

func _clamp(v: Variant) -> float:
	var f := float(v)
	return clamp(f, SCALE_MIN_MAX.x, SCALE_MIN_MAX.y)

func _apply_atten(src: Dictionary, mul: float) -> Dictionary:
	return {
		"head":   float(src.get("head", 1.0)) * mul,
		"target": float(src.get("target", 1.0)) * mul,
		"bar1":   float(src.get("bar1", 1.0)) * mul,
		"bar2":   float(src.get("bar2", float(src.get("bar1", 1.0)))) * mul,
		"tail":   float(src.get("tail", 1.0)) * mul,
		"hold":   float(src.get("hold", 1.0)) * mul,
		"rush":   float(src.get("rush", 1.0)) * mul,
		"rush_graphic": float(src.get("rush_graphic", 1.0)) * mul
	}

func _override_head(src: Dictionary, new_head: float) -> Dictionary:
	var d := src.duplicate()
	d["head"] = new_head
	return d

func _lerp_scales_dict(a: Dictionary, b: Dictionary, t: float) -> Dictionary:
	var res := {}
	var keys := ["head", "target", "bar1", "bar2", "tail", "hold", "rush", "rush_graphic"]
	for k in keys:
		var av := float(a.get(k, 1.0))
		var bv := float(b.get(k, 1.0))
		res[k] = av + (bv - av) * t
	return res


func _compute_density(specs: Array, _window_ms: int) -> Dictionary:
	# Density attenuation removed - always return 1.0 for all notes
	var out := {}
	for s in specs:
		out["%s@%d@%d" % [String(s["layer"]), int(s["time"]), int(s["note_type"])]] = 1.0
	return out


func _make_row(
	layer: String,
	time_ms: int,
	note_type: int,
	note_head_time: int,
	stage: String,
	scales: Dictionary,
	ease: String = "linear"
) -> Dictionary:
	var d := {
		"layer": layer,
		"time": time_ms,
		"note_type": note_type,
		"scale_head": VFXUtils.r3(_clamp(scales.get("head", 1.0))),
		"scale_target": VFXUtils.r3(_clamp(scales.get("target", 1.0))),
		"scale_bar1": VFXUtils.r3(_clamp(scales.get("bar1", 1.0))),
		"scale_bar2": VFXUtils.r3(_clamp(scales.get("bar2", scales.get("bar1", 1.0)))),
		"scale_tail": VFXUtils.r3(_clamp(scales.get("tail", 1.0))),
		"scale_hold": VFXUtils.r3(_clamp(scales.get("hold", 1.0))),
		"scale_rush": VFXUtils.r3(_clamp(scales.get("rush", 1.0))),
		"scale_rush_graphic": VFXUtils.r3(_clamp(scales.get("rush_graphic", 1.0))),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": note_head_time
	}
	if stage == "envelope":
		d["ease"] = ease
	return d


# ───────────────────────────────────────────────────────────────
# UI helpers (module-specific)
# ───────────────────────────────────────────────────────────────

func _mk_scale_card(parent: Container, title: String, def_val: float) -> SpinBox:
	var card := VBoxContainer.new()
	# Let cards pack tightly from the left
	card.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	card.custom_minimum_size.x = 80
	parent.add_child(card)

	var lbl := Label.new()
	lbl.text = title
	# Keep label centered above its field, but the whole card is left-packed
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	card.add_child(lbl)

	var sb := SpinBox.new()
	sb.min_value = SCALE_MIN_MAX.x
	sb.max_value = SCALE_MIN_MAX.y
	sb.step = 0.01
	sb.value = def_val
	sb.custom_minimum_size.x = 72
	sb.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	card.add_child(sb)

	return sb

func _mk_hb_button(text: String, tooltip: String, func_name: String) -> HBEditorButton:
	var b := HBEditorButton.new()
	b.button_mode = "function"
	b.text = text
	b.tooltip = tooltip
	b.function_name = func_name
	b.params = []
	b.disable_when_playing = true
	b.disable_with_popup = true

	b.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	b.custom_minimum_size = Vector2(80, 64)

	b.set_module(self)
	return b

func _reset_to_defaults() -> void:
	# Shared timing
	if line_custom_start:
		line_custom_start.text = ""
	if sb_density:
		sb_density.value = DENSITY_DEF_MS
	if cb_release:
		cb_release.button_pressed = true
	if sb_cap:
		sb_cap.value = IMPACT_CAP
	if cb_slide:
		cb_slide.button_pressed = true
	if line_end_hold:
		line_end_hold.text = "0"
	if cb_use_note_end:
		cb_use_note_end.button_pressed = false

	# Static
	if st_head:
		st_head.value = DEFAULT_SCALES_END["head"]
	if st_target:
		st_target.value = DEFAULT_SCALES_END["target"]
	if st_bar1:
		st_bar1.value = DEFAULT_SCALES_END["bar1"]
	if st_bar2:
		st_bar2.value = DEFAULT_SCALES_END["bar2"]
	if st_tail:
		st_tail.value = DEFAULT_SCALES_END["tail"]
	if st_hold:
		st_hold.value = DEFAULT_SCALES_END["hold"]
	if st_rush:
		st_rush.value = DEFAULT_SCALES_END["rush"]
	if st_rush_graphic:
		st_rush_graphic.value = DEFAULT_SCALES_END["rush_graphic"]

	# Grow/Shrink – Start
	if gs_s_head:
		gs_s_head.value = DEFAULT_SCALES_START["head"]
	if gs_s_target:
		gs_s_target.value = DEFAULT_SCALES_START["target"]
	if gs_s_bar1:
		gs_s_bar1.value = DEFAULT_SCALES_START["bar1"]
	if gs_s_bar2:
		gs_s_bar2.value = DEFAULT_SCALES_START["bar2"]
	if gs_s_tail:
		gs_s_tail.value = DEFAULT_SCALES_START["tail"]
	if gs_s_hold:
		gs_s_hold.value = DEFAULT_SCALES_START["hold"]
	if gs_s_rush:
		gs_s_rush.value = DEFAULT_SCALES_START["rush"]
	if gs_s_rush_graphic:
		gs_s_rush_graphic.value = DEFAULT_SCALES_START["rush_graphic"]

	# Grow/Shrink – End
	if gs_e_head:
		gs_e_head.value = DEFAULT_SCALES_END["head"]
	if gs_e_target:
		gs_e_target.value = DEFAULT_SCALES_END["target"]
	if gs_e_bar1:
		gs_e_bar1.value = DEFAULT_SCALES_END["bar1"]
	if gs_e_bar2:
		gs_e_bar2.value = DEFAULT_SCALES_END["bar2"]
	if gs_e_tail:
		gs_e_tail.value = DEFAULT_SCALES_END["tail"]
	if gs_e_hold:
		gs_e_hold.value = DEFAULT_SCALES_END["hold"]
	if gs_e_rush:
		gs_e_rush.value = DEFAULT_SCALES_END["rush"]
	if gs_e_rush_graphic:
		gs_e_rush_graphic.value = DEFAULT_SCALES_END["rush_graphic"]

	# Pulse – Start
	if pl_s_head:
		pl_s_head.value = DEFAULT_SCALES_START["head"]
	if pl_s_target:
		pl_s_target.value = DEFAULT_SCALES_START["target"]
	if pl_s_bar1:
		pl_s_bar1.value = DEFAULT_SCALES_START["bar1"]
	if pl_s_bar2:
		pl_s_bar2.value = DEFAULT_SCALES_START["bar2"]
	if pl_s_tail:
		pl_s_tail.value = DEFAULT_SCALES_START["tail"]
	if pl_s_hold:
		pl_s_hold.value = DEFAULT_SCALES_START["hold"]
	if pl_s_rush:
		pl_s_rush.value = DEFAULT_SCALES_START["rush"]

	# Pulse – End
	if pl_e_head:
		pl_e_head.value = DEFAULT_SCALES_END["head"]
	if pl_e_target:
		pl_e_target.value = DEFAULT_SCALES_END["target"]
	if pl_e_bar1:
		pl_e_bar1.value = DEFAULT_SCALES_END["bar1"]
	if pl_e_bar2:
		pl_e_bar2.value = DEFAULT_SCALES_END["bar2"]
	if pl_e_tail:
		pl_e_tail.value = DEFAULT_SCALES_END["tail"]
	if pl_e_hold:
		pl_e_hold.value = DEFAULT_SCALES_END["hold"]
	if pl_e_rush:
		pl_e_rush.value = DEFAULT_SCALES_END["rush"]

	# Pulse – Peak env
	if pl_peak_head:
		pl_peak_head.value = DEFAULT_ENV_PEAKS["head"]
	if pl_peak_target:
		pl_peak_target.value = DEFAULT_ENV_PEAKS["target"]
	if pl_peak_bar1:
		pl_peak_bar1.value = DEFAULT_ENV_PEAKS["bar1"]
	if pl_peak_bar2:
		pl_peak_bar2.value = DEFAULT_ENV_PEAKS["bar2"]
	if pl_peak_tail:
		pl_peak_tail.value = DEFAULT_ENV_PEAKS["tail"]
	if pl_peak_hold:
		pl_peak_hold.value = DEFAULT_ENV_PEAKS["hold"]
	if pl_peak_rush:
		pl_peak_rush.value = DEFAULT_ENV_PEAKS["rush"]

	# Pulse – Valley env
	if pl_val_head:
		pl_val_head.value = DEFAULT_ENV_VALLEY["head"]
	if pl_val_target:
		pl_val_target.value = DEFAULT_ENV_VALLEY["target"]
	if pl_val_bar1:
		pl_val_bar1.value = DEFAULT_ENV_VALLEY["bar1"]
	if pl_val_bar2:
		pl_val_bar2.value = DEFAULT_ENV_VALLEY["bar2"]
	if pl_val_tail:
		pl_val_tail.value = DEFAULT_ENV_VALLEY["tail"]
	if pl_val_hold:
		pl_val_hold.value = DEFAULT_ENV_VALLEY["hold"]
	if pl_val_rush:
		pl_val_rush.value = DEFAULT_ENV_VALLEY["rush"]

	# Pulse controls
	if sb_beats:
		sb_beats.value = DEFAULT_BEATS_PER_PULSE
	if sb_phase:
		sb_phase.value = DEFAULT_PHASE_BEATS
	if dd_ease:
		var idx := 0
		for i in range(VFXUtils.EASE_CHOICES.size()):
			if String(VFXUtils.EASE_CHOICES[i]["key"]) == "linear":
				idx = i
				break
		dd_ease.select(idx)

	_notify("✅ Scale UI reset to defaults.")


func _after_write_preview() -> void:
	VFXUtils.trigger_preview_reload(editor)


func _notify(text: String) -> void:
	VFXUtils.show_notification(editor, text)
