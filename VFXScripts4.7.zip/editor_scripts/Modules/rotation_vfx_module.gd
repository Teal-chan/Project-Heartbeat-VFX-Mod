extends HBEditorModule
class_name RotateVfxModule

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED UTILITIES - Preload the shared helper library
# ═══════════════════════════════════════════════════════════════════════════════
const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")

const ANIM_TAG := "RotateAnim/v1"

# ── UI refs ─────────────────────────────────────────────────────

# SVG Icon cache
var ICON_ROT_APPLY : Texture2D = null
var ICON_ROT_RESET : Texture2D = null

var cb_release   : CheckBox
var cb_mirror    : CheckBox
var cb_relative  : CheckBox

var le_s_head    : LineEdit
var le_s_tail    : LineEdit
var le_s_target  : LineEdit
var le_s_hold    : LineEdit

var le_e_head    : LineEdit
var le_e_tail    : LineEdit
var le_e_target  : LineEdit
var le_e_hold    : LineEdit

# Rush-specific rotation fields (Start and End)
var le_s_rush_text : LineEdit
var le_s_rush_icon : LineEdit
var le_e_rush_text : LineEdit
var le_e_rush_icon : LineEdit

var dd_ease      : OptionButton
var dd_blend     : OptionButton
var sb_priority  : SpinBox

# Full-spin controls
var cb_spin_enable     : CheckBox
var sb_spin_turns      : SpinBox
var dd_spin_head_dir   : OptionButton
var dd_spin_tail_dir   : OptionButton
var dd_spin_target_dir : OptionButton
var dd_spin_hold_dir   : OptionButton
var dd_spin_rush_text_dir : OptionButton
var dd_spin_rush_icon_dir : OptionButton

# Hold end timing
var line_end_hold      : LineEdit
var cb_use_note_end    : CheckBox

# ───────────────────────────────────────────────────────────────
# Lifecycle
# ───────────────────────────────────────────────────────────────

func _ready() -> void:
	super._ready()
	_build_ui()

func _build_ui() -> void:
	# Scroll root (prevents spilling into timeline)
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.anchor_left = 0.0
	scroll.anchor_top = 0.0
	scroll.anchor_right = 1.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = 0
	scroll.offset_top = 0
	scroll.offset_right = 0
	scroll.offset_bottom = 0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	add_child(scroll)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(root)

	var row2 := HBoxContainer.new()
	row2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row2)
	cb_release = CheckBox.new()
	cb_release.text = "Release window for sustains"
	cb_release.tooltip_text = "Also authors a RELEASE window for sustains using the same window length."
	cb_release.button_pressed = true
	row2.add_child(cb_release)
	row2.add_child(VFXUtils.mk_spacer())
	
	# Hold end timing (for Rush/Sustain notes to maintain rotation past impact)
	var row_hold := HBoxContainer.new()
	row_hold.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_hold)

	row_hold.add_child(VFXUtils.mk_label("Hold end rotation (ms after impact):"))
	line_end_hold = LineEdit.new()
	line_end_hold.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_end_hold.custom_minimum_size.x = 80
	line_end_hold.text = "0"
	line_end_hold.placeholder_text = "0"
	line_end_hold.tooltip_text = "Maintains end rotation for this many ms after impact. Use for Rush/Sustain notes."
	row_hold.add_child(line_end_hold)

	cb_use_note_end = CheckBox.new()
	cb_use_note_end.text = "Use hold end"
	cb_use_note_end.tooltip_text = "Automatically extend to the note's end time (Rush duration or Sustain release). Overrides manual ms value."
	cb_use_note_end.button_pressed = false
	row_hold.add_child(cb_use_note_end)
	row_hold.add_child(VFXUtils.mk_spacer())

	# Info
	root.add_child(VFXUtils.mk_section_label("RotateAnim/v1 – Merge-safe, timeout-based windows"))
	root.add_child(VFXUtils.mk_label("New rows use each note's GAME TIMEOUT; blank START copies END; blank both leaves channel unchanged."))

	# ── START angles ───────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("START rotations (deg, CW -). Blank → copy END; blank both → unchanged"))

	var grid_s := GridContainer.new()
	grid_s.columns = 2
	grid_s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_s)

	le_s_head   = _mk_angle_field(grid_s, "Head (Icon):")
	le_s_tail   = _mk_angle_field(grid_s, "Tail (Sustain):")
	le_s_target = _mk_angle_field(grid_s, "Target (Receptor):")
	le_s_hold   = _mk_angle_field(grid_s, "Hold Text:")

	# ── END angles ─────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("END rotations (deg)"))

	var grid_e := GridContainer.new()
	grid_e.columns = 2
	grid_e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_e)

	le_e_head   = _mk_angle_field(grid_e, "Head (Icon):", "0")
	le_e_tail   = _mk_angle_field(grid_e, "Tail (Sustain):")
	le_e_target = _mk_angle_field(grid_e, "Target (Receptor):", "0")
	le_e_hold   = _mk_angle_field(grid_e, "Hold Text:", "0")

	# ── Rush START angles (for hold_end phase) ─────────────────
	root.add_child(VFXUtils.mk_section_label("Rush START rotations \nBlank copies Rush END; blank both leaves unchanged."))

	var grid_rush_s := GridContainer.new()
	grid_rush_s.columns = 2
	grid_rush_s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_rush_s)

	le_s_rush_text = _mk_angle_field(grid_rush_s, "Rush Text:")
	le_s_rush_icon = _mk_angle_field(grid_rush_s, "Rush Icon:")

	# ── Rush END angles (for hold_end phase) ───────────────────
	root.add_child(VFXUtils.mk_section_label("Rush END rotations"))

	var grid_rush_e := GridContainer.new()
	grid_rush_e.columns = 2
	grid_rush_e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_rush_e)

	le_e_rush_text = _mk_angle_field(grid_rush_e, "Rush Text:")
	le_e_rush_icon = _mk_angle_field(grid_rush_e, "Rush Icon:")

	# ── Options ────────────────────────────────────────────────
	cb_mirror = CheckBox.new()
	cb_mirror.text = "Mirror tail if blank (tail = -head)"
	cb_mirror.button_pressed = true
	root.add_child(cb_mirror)

	cb_relative = CheckBox.new()
	cb_relative.text = "Relative (add to existing impact angles)"
	cb_relative.button_pressed = false
	root.add_child(cb_relative)

	# ── Interpolation metadata ─────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Interpolation / Blending (optional metadata)"))

	var row_meta := HBoxContainer.new()
	row_meta.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_meta)

	row_meta.add_child(VFXUtils.mk_label("Ease:"))
	dd_ease = OptionButton.new()
	for n in ["linear","in_out_quad","in_out_cubic","out_elastic"]:
		dd_ease.add_item(n)
	row_meta.add_child(dd_ease)

	row_meta.add_child(VFXUtils.mk_label("Blend:"))
	dd_blend = OptionButton.new()
	for n in ["replace","add","multiply","min","max"]:
		dd_blend.add_item(n)
	row_meta.add_child(dd_blend)

	row_meta.add_child(VFXUtils.mk_label("Priority:"))
	sb_priority = SpinBox.new()
	sb_priority.allow_greater = true
	sb_priority.allow_lesser = true
	sb_priority.min_value = -1024
	sb_priority.max_value = 1024
	sb_priority.step = 1
	sb_priority.value = 0
	row_meta.add_child(sb_priority)
	row_meta.add_child(VFXUtils.mk_spacer())

	# ── Full-spin settings (multi-turn) ────────────────────────
	root.add_child(VFXUtils.mk_section_label("Full spins (N × 360° from Start → Impact; END blank = auto-filled)"))

	var row_spin := HBoxContainer.new()
	row_spin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_spin)

	cb_spin_enable = CheckBox.new()
	cb_spin_enable.text = "Enable full spins (multi-turn) using START angles"
	cb_spin_enable.button_pressed = false
	row_spin.add_child(cb_spin_enable)
	row_spin.add_child(VFXUtils.mk_spacer())

	var row_spin2 := HBoxContainer.new()
	row_spin2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_spin2)

	row_spin2.add_child(VFXUtils.mk_label("Turns (×360°):"))
	sb_spin_turns = SpinBox.new()
	sb_spin_turns.min_value = 1
	sb_spin_turns.max_value = 16
	sb_spin_turns.step = 1
	sb_spin_turns.value = 1
	sb_spin_turns.custom_minimum_size.x = 60
	row_spin2.add_child(sb_spin_turns)
	row_spin2.add_child(VFXUtils.mk_spacer())

	var row_spin3 := HBoxContainer.new()
	row_spin3.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_spin3)

	row_spin3.add_child(VFXUtils.mk_label("Head dir:"))
	dd_spin_head_dir = _mk_spin_dir_option()
	row_spin3.add_child(dd_spin_head_dir)

	row_spin3.add_child(VFXUtils.mk_label("Tail dir:"))
	dd_spin_tail_dir = _mk_spin_dir_option()
	row_spin3.add_child(dd_spin_tail_dir)

	row_spin3.add_child(VFXUtils.mk_label("Target dir:"))
	dd_spin_target_dir = _mk_spin_dir_option()
	row_spin3.add_child(dd_spin_target_dir)

	row_spin3.add_child(VFXUtils.mk_label("Hold dir:"))
	dd_spin_hold_dir = _mk_spin_dir_option()
	row_spin3.add_child(dd_spin_hold_dir)

	row_spin3.add_child(VFXUtils.mk_spacer())

	var row_spin4 := HBoxContainer.new()
	row_spin4.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_spin4)

	row_spin4.add_child(VFXUtils.mk_label("Rush Text dir:"))
	dd_spin_rush_text_dir = _mk_spin_dir_option()
	row_spin4.add_child(dd_spin_rush_text_dir)

	row_spin4.add_child(VFXUtils.mk_label("Rush Icon dir:"))
	dd_spin_rush_icon_dir = _mk_spin_dir_option()
	row_spin4.add_child(dd_spin_rush_icon_dir)
	row_spin3.add_child(VFXUtils.mk_spacer())

	# ── Load SVG icons (128px) ────────────────────────────────
	if ICON_ROT_APPLY == null:
		ICON_ROT_APPLY = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/rotate_apply.svg", 128)
		if ICON_ROT_APPLY == null:
			ICON_ROT_APPLY = preload("res://graphics/icons/console-line.svg") # fallback

	if ICON_ROT_RESET == null:
		ICON_ROT_RESET = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/rotate_reset.svg", 128)
		if ICON_ROT_RESET == null:
			ICON_ROT_RESET = preload("res://graphics/icons/console-line.svg") # fallback

	# ── Action buttons grid (Apply / Reset) ───────────────────
	var grid_buttons := GridContainer.new()
	grid_buttons.columns = 2
	grid_buttons.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	grid_buttons.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	grid_buttons.add_theme_constant_override("h_separation", 16)
	grid_buttons.add_theme_constant_override("v_separation", 0)
	root.add_child(grid_buttons)

	_add_rotate_icon_button(
		grid_buttons,
		"Apply Rotation",
		"Merge-safe RotateAnim/v1 start → impact (and optional release) using GAME TIMEOUT windows.",
		"_apply_rotate",
		ICON_ROT_APPLY
	)

	_add_rotate_icon_button(
		grid_buttons,
		"Reset Rotation UI",
		"Reset all Rotation fields in this tab back to their default values.",
		"_reset_to_defaults",
		ICON_ROT_RESET
	)


	# Footer hint
	var foot := HBoxContainer.new()
	root.add_child(foot)
	foot.add_child(VFXUtils.mk_label("Uses per-note GAME TIMEOUT for new windows. Merge-safe with existing VFX JSON."))
	foot.add_child(VFXUtils.mk_spacer())


# ───────────────────────────────────────────────────────────────
# Entry point - WITH UNDO/REDO SUPPORT
# ───────────────────────────────────────────────────────────────

func _apply_rotate() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return

	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var S := {
		"head":      _parse_opt_deg(le_s_head.text),
		"tail":      _parse_opt_deg(le_s_tail.text),
		"target":    _parse_opt_deg(le_s_target.text),
		"hold":      _parse_opt_deg(le_s_hold.text),
		"rush_text": _parse_opt_deg(le_s_rush_text.text) if le_s_rush_text else null,
		"rush_icon": _parse_opt_deg(le_s_rush_icon.text) if le_s_rush_icon else null,
	}
	var E := {
		"head":      _parse_opt_deg(le_e_head.text),
		"tail":      _parse_opt_deg(le_e_tail.text),
		"target":    _parse_opt_deg(le_e_target.text),
		"hold":      _parse_opt_deg(le_e_hold.text),
		"rush_text": _parse_opt_deg(le_e_rush_text.text) if le_e_rush_text else null,
		"rush_icon": _parse_opt_deg(le_e_rush_icon.text) if le_e_rush_icon else null,
	}

	# Mirror tail if requested
	if cb_mirror.button_pressed:
		if E["tail"] == null and E["head"] != null:
			E["tail"] = -float(E["head"])
		if S["tail"] == null and S["head"] != null:
			S["tail"] = -float(S["head"])

	# Hold end settings
	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	# Ease / blend / priority
	var ease_name := ""
	var blend_name := ""
	if dd_ease.get_selected_id() >= 0:
		ease_name = dd_ease.get_item_text(dd_ease.get_selected_id())
	if dd_blend.get_selected_id() >= 0:
		blend_name = dd_blend.get_item_text(dd_blend.get_selected_id())
	var pri := int(sb_priority.value)

	# Full spin settings
	var spin_enable := cb_spin_enable.button_pressed
	var spin_turns := int(sb_spin_turns.value)
	var dir_head := _spin_dir_from_ob(dd_spin_head_dir)
	var dir_tail := _spin_dir_from_ob(dd_spin_tail_dir)
	var dir_target := _spin_dir_from_ob(dd_spin_target_dir)
	var dir_hold := _spin_dir_from_ob(dd_spin_hold_dir)
	var dir_rush_text := _spin_dir_from_ob(dd_spin_rush_text_dir) if dd_spin_rush_text_dir else 0
	var dir_rush_icon := _spin_dir_from_ob(dd_spin_rush_icon_dir) if dd_spin_rush_icon_dir else 0

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Rotation VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_rotation_rows(
		specs,
		cb_release.button_pressed,
		S,
		E,
		cb_relative.button_pressed,
		ease_name,
		blend_name,
		pri,
		spin_enable,
		spin_turns,
		dir_head,
		dir_tail,
		dir_target,
		dir_hold,
		dir_rush_text,
		dir_rush_icon,
		end_hold_ms,
		use_note_end
	)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()

	_notify("✅ RotateAnim/v1 windows written/merged for %d note(s)." % specs.size())

# ───────────────────────────────────────────────────────────────
# Row builder (returns rows instead of writing directly)
# ───────────────────────────────────────────────────────────────

func _build_rotation_rows(
	specs: Array,
	include_release: bool,
	S: Dictionary,
	E: Dictionary,
	as_relative: bool,
	ease_name: String,
	blend_name: String,
	priority: int,
	spin_enable: bool,
	spin_turns: int,
	spin_head_dir: int,
	spin_tail_dir: int,
	spin_target_dir: int,
	spin_hold_dir: int,
	spin_rush_text_dir: int = 0,
	spin_rush_icon_dir: int = 0,
	end_hold_ms: int = 0,
	use_note_end: bool = false
) -> Array:
	var path: String = VFXUtils.get_vfx_path(editor)

	var existing_rows: Array = VFXUtils.load_vfx_json(path)

	var preserved: Array = []
	var rmap: Dictionary = {} # key -> row

	for e in existing_rows:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("anim","")) != ANIM_TAG:
			preserved.append(e)
			continue

		var layer := String(e.get("layer",""))
		var nt := int(e.get("note_type",-1))
		var head := int(e.get("anim_note_time",-1))
		var stage := String(e.get("anim_stage",""))
		if layer == "" or nt < 0 or head < 0 or stage == "":
			preserved.append(e)
			continue

		var key := "%s@%d@%d@%s" % [layer, nt, head, stage]
		rmap[key] = e

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		# Timeout parity for NEW rows
		var timeout_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t)
		if timeout_ms <= 0:
			timeout_ms = 2000
		# The game timeout is the scoring window, but notes are visually on screen
		# for longer than this. Pad the window so the rotation is already active
		# when the note first becomes visible.
		var visual_timeout_ms: int = int(timeout_ms * 1.5)
		var t0_timeout := max(0, head_t - visual_timeout_ms)
		var t1 := head_t

		var start_cols := _build_start_angles(S, E)
		var end_cols := _build_end_angles(E)

		# Relative-add against existing impact row (if any)
		if as_relative:
			var k_impact := "%s@%d@%d@%s" % [layer, ntype, head_t, "impact"]
			var base := rmap.get(k_impact, {})
			var base_ch := {
				"head":   _deg_or_zero(base.get("rotation_deg_head", null)),
				"tail":   _deg_or_zero(base.get("rotation_deg_tail", null)),
				"target": _deg_or_zero(base.get("rotation_deg_target", null)),
				"hold":   _deg_or_zero(base.get("rotation_deg_holdtext", null))
			}
			for ch in ["head","tail","target","hold"]:
				if end_cols[ch] != null:
					end_cols[ch] = base_ch[ch] + float(end_cols[ch])
				if start_cols[ch] != null:
					start_cols[ch] = base_ch[ch] + float(start_cols[ch])

		# Apply per-component full spins, if enabled.
		# Only kicks in when END field for that component was blank in the UI.
		if spin_enable and spin_turns > 0:
			_apply_spin_to_cols(
				start_cols,
				end_cols,
				S,
				E,
				spin_turns,
				spin_head_dir,
				spin_tail_dir,
				spin_target_dir,
				spin_hold_dir,
				spin_rush_text_dir,
				spin_rush_icon_dir
			)

		# anim_start (keep existing time if row exists; otherwise timeout-based)
		var k_start := "%s@%d@%d@%s" % [layer, ntype, head_t, "anim_start"]
		var base_start := rmap.get(k_start, {})
		var t_start := (int(base_start.get("time", t0_timeout)) if not base_start.is_empty() else t0_timeout)
		var merged_start := _merge_row_rotation(
			base_start,
			start_cols,
			layer,
			ntype,
			head_t,
			"anim_start",
			t_start,
			ease_name,
			blend_name,
			priority
		)
		if not merged_start.is_empty():
			rmap[k_start] = merged_start

		# Determine if we're using hold_end (for Rush/Sustain) or impact
		var hold_end_time := 0
		if use_note_end and spec.has("sustain_end"):
			hold_end_time = int(spec["sustain_end"])
		elif end_hold_ms > 0:
			hold_end_time = head_t + end_hold_ms

		# Write either impact OR hold_end row, not both
		if hold_end_time > t1:
			# Use hold_end - write rush-specific end angles at the note's end time
			var rush_end_cols := _build_rush_end_angles(S, E)
			var k_hold := "%s@%d@%d@%s" % [layer, ntype, head_t, "hold_end"]
			var base_hold := rmap.get(k_hold, {})
			var merged_hold := _merge_row_rotation(
				base_hold,
				rush_end_cols,
				layer,
				ntype,
				head_t,
				"hold_end",
				hold_end_time,
				ease_name,
				blend_name,
				priority
			)
			if not merged_hold.is_empty():
				rmap[k_hold] = merged_hold
			# Remove any existing impact row for this note
			var k_impact := "%s@%d@%d@%s" % [layer, ntype, head_t, "impact"]
			if rmap.has(k_impact):
				rmap.erase(k_impact)
		else:
			# impact (keep existing time if row exists; otherwise head time)
			var k_end := "%s@%d@%d@%s" % [layer, ntype, head_t, "impact"]
			var base_end := rmap.get(k_end, {})
			var t_end := (int(base_end.get("time", t1)) if not base_end.is_empty() else t1)
			var merged_end := _merge_row_rotation(
				base_end,
				end_cols,
				layer,
				ntype,
				head_t,
				"impact",
				t_end,
				ease_name,
				blend_name,
				priority
			)
			if not merged_end.is_empty():
				rmap[k_end] = merged_end
			# Remove any existing hold_end row for this note
			var k_hold := "%s@%d@%d@%s" % [layer, ntype, head_t, "hold_end"]
			if rmap.has(k_hold):
				rmap.erase(k_hold)

		# Optional release window (timeout at sustain_end)
		if include_release and spec.has("sustain_end") and int(spec["sustain_end"]) > head_t:
			var rel_end := int(spec["sustain_end"])
			var rel_timeout_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, rel_end)
			if rel_timeout_ms <= 0:
				rel_timeout_ms = timeout_ms
			var r0_timeout := max(0, rel_end - rel_timeout_ms)

			var k_rs := "%s@%d@%d@%s" % [layer, ntype, head_t, "release_start"]
			var k_ri := "%s@%d@%d@%s" % [layer, ntype, head_t, "release_impact"]
			var base_rs := rmap.get(k_rs, {})
			var base_ri := rmap.get(k_ri, {})

			var t_rs := (int(base_rs.get("time", r0_timeout)) if not base_rs.is_empty() else r0_timeout)
			var t_ri := (int(base_ri.get("time", rel_end)) if not base_ri.is_empty() else rel_end)

			var merged_rs := _merge_row_rotation(
				base_rs,
				start_cols,
				layer,
				ntype,
				head_t,
				"release_start",
				t_rs,
				ease_name,
				blend_name,
				priority
			)
			var merged_ri := _merge_row_rotation(
				base_ri,
				end_cols,
				layer,
				ntype,
				head_t,
				"release_impact",
				t_ri,
				ease_name,
				blend_name,
				priority
			)

			if not merged_rs.is_empty():
				rmap[k_rs] = merged_rs
			if not merged_ri.is_empty():
				rmap[k_ri] = merged_ri

	# Reassemble output
	var out: Array = []
	for p in preserved:
		out.append(p)
	for k in rmap.keys():
		out.append(rmap[k])

	return out


# ───────────────────────────────────────────────────────────────
# Full-spin helper (per-component)
# ───────────────────────────────────────────────────────────────

func _apply_spin_to_cols(
	start_cols: Dictionary,
	end_cols: Dictionary,
	S: Dictionary,
	E: Dictionary,
	spin_turns: int,
	spin_head_dir: int,
	spin_tail_dir: int,
	spin_target_dir: int,
	spin_hold_dir: int,
	spin_rush_text_dir: int = 0,
	spin_rush_icon_dir: int = 0
) -> void:
	if spin_turns <= 0:
		return

	var full := float(spin_turns) * 360.0

	var dirs := {
		"head":      spin_head_dir,
		"tail":      spin_tail_dir,
		"target":    spin_target_dir,
		"hold":      spin_hold_dir,
		"rush_text": spin_rush_text_dir,
		"rush_icon": spin_rush_icon_dir,
	}

	for ch in dirs.keys():
		var dir := int(dirs[ch])
		if dir == 0:
			continue

		# Only apply spins when END field was blank in the UI
		# (i.e. E[ch] == null) and we have a START angle.
		if E.get(ch, null) != null:
			continue

		var s_val := start_cols.get(ch, null)
		if s_val == null:
			continue

		end_cols[ch] = float(s_val) + full * float(dir)

# ───────────────────────────────────────────────────────────────
# Row builders
# ───────────────────────────────────────────────────────────────

func _merge_row_rotation(
	base_row: Dictionary,
	cols: Dictionary,
	layer: String,
	ntype: int,
	head_time: int,
	stage: String,
	time_ms: int,
	ease_name: String,
	blend_name: String,
	priority: int
) -> Dictionary:
	var adding := false
	for k in cols.keys():
		if cols[k] != null:
			adding = true
			break
	if base_row.is_empty() and not adding:
		return {}

	var row := {}
	if base_row.is_empty():
		row["anim"] = ANIM_TAG
		row["anim_stage"] = stage
		row["anim_note_time"] = head_time
		row["layer"] = layer
		row["time"] = time_ms
		row["note_type"] = float(ntype)
		row["ease"] = ease_name if ease_name != "" else "linear"
		row["blend"] = blend_name if blend_name != "" else "replace"
		row["priority"] = priority
		row["group"] = "rotate"
		row["time_domain"] = "ms"
		row["anim_id"] = null
		row["quantize"] = null
	else:
		for k in base_row.keys():
			row[k] = base_row[k]
		row["time"] = time_ms
		if not row.has("ease"):
			row["ease"] = ease_name if ease_name != "" else "linear"
		if not row.has("blend"):
			row["blend"] = blend_name if blend_name != "" else "replace"
		if not row.has("priority"):
			row["priority"] = priority
		if not row.has("group"):
			row["group"] = "rotate"
		if not row.has("time_domain"):
			row["time_domain"] = "ms"
		if not row.has("anim_id"):
			row["anim_id"] = null
		if not row.has("quantize"):
			row["quantize"] = null

	_apply_deg_if_any(row, "rotation_deg_head", cols.get("head", null))
	_apply_deg_if_any(row, "rotation_deg_tail", cols.get("tail", null))
	_apply_deg_if_any(row, "rotation_deg_target", cols.get("target", null))
	_apply_deg_if_any(row, "rotation_deg_holdtext", cols.get("hold", null))
	_apply_deg_if_any(row, "rotation_deg_rushtext", cols.get("rush_text", null))
	_apply_deg_if_any(row, "rotation_deg_rushicon", cols.get("rush_icon", null))
	return row

# For pre-impact phase: rush mirrors head/hold
func _build_start_angles(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := {
		"head":   _coalesce_angle(S.get("head", null),   E.get("head", null)),
		"tail":   _coalesce_angle(S.get("tail", null),   E.get("tail", null)),
		"target": _coalesce_angle(S.get("target", null), E.get("target", null)),
		"hold":   _coalesce_angle(S.get("hold", null),   E.get("hold", null)),
	}
	# Rush mirrors head/hold during pre-impact
	d["rush_text"] = d["hold"]
	d["rush_icon"] = d["head"]
	return d

# For pre-impact phase: rush mirrors head/hold
func _build_end_angles(E: Dictionary) -> Dictionary:
	var d := {
		"head":   E.get("head", null),
		"tail":   E.get("tail", null),
		"target": E.get("target", null),
		"hold":   E.get("hold", null),
	}
	# Rush mirrors head/hold during pre-impact
	d["rush_text"] = d["hold"]
	d["rush_icon"] = d["head"]
	return d

# Build rush START angles for post-impact phase (Valley)
func _build_rush_start_angles(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := _build_end_angles(E)  # Start from regular end values
	# Override with Rush START if provided, else fall back to Rush END
	d["rush_text"] = _coalesce_angle(S.get("rush_text", null), E.get("rush_text", null))
	d["rush_icon"] = _coalesce_angle(S.get("rush_icon", null), E.get("rush_icon", null))
	# If still null, fall back to hold/head end values
	if d["rush_text"] == null:
		d["rush_text"] = d["hold"]
	if d["rush_icon"] == null:
		d["rush_icon"] = d["head"]
	return d

# Build rush END angles for post-impact phase (Peak)
func _build_rush_end_angles(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := _build_end_angles(E)  # Start from regular end values
	# Override with Rush END if provided
	if E.get("rush_text", null) != null:
		d["rush_text"] = E.get("rush_text")
	if E.get("rush_icon", null) != null:
		d["rush_icon"] = E.get("rush_icon")
	return d


# ───────────────────────────────────────────────────────────────
# Timing helpers
# ───────────────────────────────────────────────────────────────

func _parse_end_hold_ms() -> int:
	if line_end_hold == null:
		return 0
	var t := line_end_hold.text.strip_edges()
	if t.is_empty():
		return 0
	if not t.is_valid_float():
		return 0
	var v := int(round(float(t)))
	if v < 0:
		return 0
	return v


# ───────────────────────────────────────────────────────────────
# Rotation-specific helpers
# ───────────────────────────────────────────────────────────────

func _mk_angle_field(grid: GridContainer, label_text: String, placeholder: String = "") -> LineEdit:
	var lbl := Label.new()
	lbl.text = label_text
	grid.add_child(lbl)

	var h := HBoxContainer.new()
	var le := LineEdit.new()
	le.placeholder_text = placeholder
	le.custom_minimum_size.x = 80
	le.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(le)

	grid.add_child(h)
	return le


func _mk_spin_dir_option() -> OptionButton:
	var ob := OptionButton.new()
	ob.custom_minimum_size.x = 80
	ob.add_item("None", 0)
	ob.add_item("CW (-)", 1)
	ob.add_item("CCW (+)", 2)
	ob.select(0)
	return ob

func _spin_dir_from_ob(ob: OptionButton) -> int:
	if ob == null:
		return 0
	var id := ob.get_selected_id()
	match id:
		1:
			return -1  # CW = negative degrees
		2:
			return 1   # CCW = positive degrees
		_:
			return 0

func _parse_opt_deg(text: String) -> Variant:
	var s := String(text).strip_edges()
	if s.is_empty():
		return null
	if not s.is_valid_float():
		return null
	return float(s)

func _apply_deg_if_any(dst: Dictionary, key: String, deg_val: Variant) -> void:
	if deg_val == null:
		return
	# IMPORTANT: do NOT modulo 360 here; we want multi-turn values like 1440.
	dst[key] = VFXUtils.r3(float(deg_val))

func _deg_or_zero(v: Variant) -> float:
	if v == null:
		return 0.0
	return float(v)

func _coalesce_angle(a: Variant, b: Variant) -> Variant:
	if a != null:
		return a
	return b


# ───────────────────────────────────────────────────────────────
# UI button helper
# ───────────────────────────────────────────────────────────────

func _add_rotate_icon_button(
	parent: GridContainer,
	label_text: String,
	tooltip: String,
	func_name: String,
	icon_tex: Texture2D
) -> void:
	var cell := VBoxContainer.new()
	cell.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	cell.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_theme_constant_override("separation", 0) # no extra gap in the cell

	# 128×128 square, handled by ratio container
	var ratio := HBoxRatioContainer.new()
	ratio.custom_minimum_size = Vector2(128, 128)
	ratio.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	ratio.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_child(ratio)

	# HBEditorButton fills that square and now ALSO owns the text
	var hb := _mk_hb_button(label_text, tooltip, func_name)
	hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.size_flags_vertical   = Control.SIZE_EXPAND_FILL
	hb.custom_minimum_size   = Vector2(0, 0) # ratio controls final size

	var inner: Button = hb.get_button()
	if inner:
		inner.icon = icon_tex
		inner.expand_icon = true
		inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	ratio.add_child(hb)

	# No extra Label under the button anymore – text is inside the button.
	parent.add_child(cell)


func _mk_hb_button(text: String, tooltip: String, func_name: String) -> HBEditorButton:
	var b := HBEditorButton.new()
	b.button_mode = "function"
	b.text = text
	b.tooltip = tooltip
	b.function_name = func_name
	b.params = []
	b.disable_when_playing = true
	b.disable_with_popup = true

	# Let parent containers control the size (ratio container → 128×128)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 0)

	b.set_module(self)
	return b


# ───────────────────────────────────────────────────────────────
# Preview / notifications
# ───────────────────────────────────────────────────────────────

func _reset_to_defaults() -> void:
	# Release / options
	if cb_release:
		cb_release.button_pressed = true
	if cb_mirror:
		cb_mirror.button_pressed = true
	if cb_relative:
		cb_relative.button_pressed = false

	# Hold end timing
	if line_end_hold:
		line_end_hold.text = "0"
	if cb_use_note_end:
		cb_use_note_end.button_pressed = false

	# START angles – clear text so placeholders show again
	if le_s_head:
		le_s_head.text = ""
	if le_s_tail:
		le_s_tail.text = ""
	if le_s_target:
		le_s_target.text = ""
	if le_s_hold:
		le_s_hold.text = ""

	# END angles – also cleared (placeholders "0" remain as hints)
	if le_e_head:
		le_e_head.text = ""
	if le_e_tail:
		le_e_tail.text = ""
	if le_e_target:
		le_e_target.text = ""
	if le_e_hold:
		le_e_hold.text = ""

	# Rush START rotation fields
	if le_s_rush_text:
		le_s_rush_text.text = ""
	if le_s_rush_icon:
		le_s_rush_icon.text = ""

	# Rush END rotation fields
	if le_e_rush_text:
		le_e_rush_text.text = ""
	if le_e_rush_icon:
		le_e_rush_icon.text = ""

	# Interpolation / blending
	if dd_ease:
		dd_ease.select(0)  # "linear"
	if dd_blend:
		dd_blend.select(0) # "replace"
	if sb_priority:
		sb_priority.value = 0

	# Full-spin controls
	if cb_spin_enable:
		cb_spin_enable.button_pressed = false
	if sb_spin_turns:
		sb_spin_turns.value = 1
	if dd_spin_head_dir:
		dd_spin_head_dir.select(0)  # "None"
	if dd_spin_tail_dir:
		dd_spin_tail_dir.select(0)
	if dd_spin_target_dir:
		dd_spin_target_dir.select(0)
	if dd_spin_hold_dir:
		dd_spin_hold_dir.select(0)
	if dd_spin_rush_text_dir:
		dd_spin_rush_text_dir.select(0)
	if dd_spin_rush_icon_dir:
		dd_spin_rush_icon_dir.select(0)

	_notify("✅ Rotation UI reset to defaults.")


func _after_write_preview() -> void:
	VFXUtils.trigger_preview_reload(editor)

func _notify(text: String) -> void:
	VFXUtils.show_notification(editor, text)
