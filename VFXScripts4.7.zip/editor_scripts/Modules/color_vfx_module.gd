extends HBEditorModule
class_name ColorVfxModule

# ═══════════════════════════════════════════════════════════════════════════════
# SHARED UTILITIES - Preload the shared helper library
# ═══════════════════════════════════════════════════════════════════════════════
const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")
const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")

const ANIM_TAG := "ColorAnim/v1"

const DEFAULT_START_BEFORE_MS := 2000
const DEBUG_TIMEOUT := true

# Envelope defaults
const EASE_OPTIONS := [
	"hold", "step", "linear", "in_out_quad", "in_out_cubic", "out_elastic"
]
const DEFAULT_EASE := "linear"
const DEFAULT_PULSES_PER_BEAT := 1
const DEFAULT_PHASE_BEATS := 0.0

# ── UI refs ───────────────────────────────────────────────────

# SVG Icon cache
var ICON_COLOR_APPLY  : Texture2D = null
var ICON_COLOR_ENV    : Texture2D = null
var ICON_COLOR_RANDOM : Texture2D = null
var ICON_COLOR_RESET  : Texture2D = null
# Window timing
var sb_before : SpinBox
var cb_replace_time : CheckBox

# Envelope controls
var cb_env_enable : CheckBox
var sb_pulses : SpinBox
var sb_phase : SpinBox
var dd_ease : OptionButton

# Start (valley) lines
var s_icon_line      : LineEdit
var s_target_line    : LineEdit
var s_bar1_line      : LineEdit
var s_bar2_line      : LineEdit
var s_head_line      : LineEdit
var s_tail_line      : LineEdit
var s_hold_line      : LineEdit
var s_rush_text_pre_line : LineEdit  # Rush text during pre-impact approach

# End (peak) lines
var e_icon_line      : LineEdit
var e_target_line    : LineEdit
var e_bar1_line      : LineEdit
var e_bar2_line      : LineEdit
var e_head_line      : LineEdit
var e_tail_line      : LineEdit
var e_hold_line      : LineEdit
var e_rush_text_pre_line : LineEdit  # Rush text during pre-impact approach

# Rush-specific colors (Start and End) for hold_end phase
var s_rush_text_line : LineEdit
var s_rush_icon_line : LineEdit
var s_rush_bar_line  : LineEdit
var e_rush_text_line : LineEdit
var e_rush_icon_line : LineEdit
var e_rush_bar_line  : LineEdit

# Hold end timing
var line_end_hold    : LineEdit
var cb_use_note_end  : CheckBox

# ───────────────────────────────────────────────────────────────
# Lifecycle
# ───────────────────────────────────────────────────────────────

func _ready() -> void:
	super._ready()
	_build_ui()

func _build_ui() -> void:
	# Scroll root so we never spill into timeline
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.anchor_left = 0.0
	scroll.anchor_top = 0.0
	scroll.anchor_right = 1.0
	scroll.anchor_bottom = 1.0
	scroll.offset_left = 0
	scroll.offset_top = 0
	scroll.offset_right = 0
	scroll.offset_bottom = 0
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	add_child(scroll)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 8)
	margin.add_theme_constant_override("margin_right", 8)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	scroll.add_child(margin)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(root)

	# ── Window timing (merge-safe window tool) ──────────────────
	root.add_child(VFXUtils.mk_section_label("Color Window timing (merge-safe)"))

	var row_t := HBoxContainer.new()
	row_t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_t)

	row_t.add_child(VFXUtils.mk_label("Start offset before IMPACT (ms):"))
	sb_before = SpinBox.new()
	sb_before.min_value = 5
	sb_before.max_value = 10000
	sb_before.step = 5
	sb_before.value = DEFAULT_START_BEFORE_MS
	sb_before.custom_minimum_size.x = 80
	row_t.add_child(sb_before)

	cb_replace_time = CheckBox.new()
	cb_replace_time.text = "Replace window timing (use Start offset)"
	row_t.add_child(cb_replace_time)
	row_t.add_child(VFXUtils.mk_spacer())

	# Hold end timing (for Rush/Sustain notes to maintain color past impact)
	var row_end := HBoxContainer.new()
	row_end.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(row_end)

	row_end.add_child(VFXUtils.mk_label("Hold end color (ms after impact):"))
	line_end_hold = LineEdit.new()
	line_end_hold.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line_end_hold.custom_minimum_size.x = 80
	line_end_hold.text = "0"
	line_end_hold.placeholder_text = "0"
	line_end_hold.tooltip_text = "Maintains end color for this many ms after impact. Use for Rush/Sustain notes."
	row_end.add_child(line_end_hold)

	cb_use_note_end = CheckBox.new()
	cb_use_note_end.text = "Use hold end"
	cb_use_note_end.tooltip_text = "Automatically extend to the note's end time (Rush duration or Sustain release). Overrides manual ms value."
	cb_use_note_end.button_pressed = false
	row_end.add_child(cb_use_note_end)
	row_end.add_child(VFXUtils.mk_spacer())

	# ── Envelope headline ───────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("Envelope (timeout + beats, Start=Valley, End=Peak)"))

	var env_row := HBoxContainer.new()
	env_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(env_row)

	cb_env_enable = CheckBox.new()
	cb_env_enable.text = "Enable envelope beats between Start and Impact"
	cb_env_enable.button_pressed = true
	env_row.add_child(cb_env_enable)
	env_row.add_child(VFXUtils.mk_spacer())

	var env_row2 := HBoxContainer.new()
	env_row2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(env_row2)

	env_row2.add_child(VFXUtils.mk_label("Pulses per beat:"))
	sb_pulses = SpinBox.new()
	sb_pulses.min_value = 1
	sb_pulses.max_value = 8
	sb_pulses.step = 1
	sb_pulses.value = DEFAULT_PULSES_PER_BEAT
	sb_pulses.custom_minimum_size.x = 60
	env_row2.add_child(sb_pulses)

	env_row2.add_child(VFXUtils.mk_spacer())
	env_row2.add_child(VFXUtils.mk_label("Phase (beats):"))
	sb_phase = SpinBox.new()
	sb_phase.min_value = -8
	sb_phase.max_value = 8
	sb_phase.step = 0.25
	sb_phase.value = DEFAULT_PHASE_BEATS
	sb_phase.custom_minimum_size.x = 60
	env_row2.add_child(sb_phase)

	env_row2.add_child(VFXUtils.mk_spacer())
	env_row2.add_child(VFXUtils.mk_label("Ease:"))
	dd_ease = OptionButton.new()
	for e in EASE_OPTIONS:
		dd_ease.add_item(e)
	dd_ease.select(_find_ease_index(DEFAULT_EASE))
	env_row2.add_child(dd_ease)

	# ── START colors ────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("START colors (Valley)\nBlank START copies END; blank both leaves channel unchanged."))

	var grid_s := GridContainer.new()
	grid_s.columns = 2
	grid_s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_s)

	s_icon_line      = _add_color_field(grid_s, "Icon (flying):").line
	s_target_line    = _add_color_field(grid_s, "Target (receptor):").line
	s_bar1_line      = _add_color_field(grid_s, "Timing Bar 1:").line
	s_bar2_line      = _add_color_field(grid_s, "Timing Bar 2 (sustain):").line
	s_head_line      = _add_color_field(grid_s, "Sustain Icon (Head):").line
	s_tail_line      = _add_color_field(grid_s, "Sustain Icon (Tail):").line
	s_hold_line      = _add_color_field(grid_s, "Hold text:").line
	s_rush_text_pre_line = _add_color_field(grid_s, "Rush text (pre-impact):").line

	# ── END colors ──────────────────────────────────────────────
	root.add_child(VFXUtils.mk_section_label("END colors (Peak)"))

	var grid_e := GridContainer.new()
	grid_e.columns = 2
	grid_e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_e)

	e_icon_line      = _add_color_field(grid_e, "Icon (flying):",    "1.0,1.0,1.0,1.0").line
	e_target_line    = _add_color_field(grid_e, "Target (receptor):","1.0,1.0,1.0,1.0").line
	e_bar1_line      = _add_color_field(grid_e, "Timing Bar 1:",     "1.0,1.0,1.0,1.0").line
	e_bar2_line      = _add_color_field(grid_e, "Timing Bar 2:",     "1.0,1.0,1.0,1.0").line
	e_head_line      = _add_color_field(grid_e, "Sustain Icon (Head):").line
	e_tail_line      = _add_color_field(grid_e, "Sustain Icon (Tail):").line
	e_hold_line      = _add_color_field(grid_e, "Hold text:",        "1.0,1.0,1.0,1.0").line
	e_rush_text_pre_line = _add_color_field(grid_e, "Rush text (pre-impact):").line

	# ── Rush START colors (for hold_end phase) ──
	root.add_child(VFXUtils.mk_section_label("Rush START colors (Valley for hold_end phase)\nBlank copies Rush END; blank both leaves unchanged."))

	var grid_rush_s := GridContainer.new()
	grid_rush_s.columns = 2
	grid_rush_s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_rush_s)

	s_rush_text_line = _add_color_field(grid_rush_s, "Rush Text:").line
	s_rush_icon_line = _add_color_field(grid_rush_s, "Rush Icon:").line
	s_rush_bar_line  = _add_color_field(grid_rush_s, "Rush Bar:").line

	# ── Rush END colors (for hold_end phase) ──
	root.add_child(VFXUtils.mk_section_label("Rush END colors (Peak for hold_end phase)"))

	var grid_rush_e := GridContainer.new()
	grid_rush_e.columns = 2
	grid_rush_e.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.add_child(grid_rush_e)

	e_rush_text_line = _add_color_field(grid_rush_e, "Rush Text:").line
	e_rush_icon_line = _add_color_field(grid_rush_e, "Rush Icon:").line
	e_rush_bar_line  = _add_color_field(grid_rush_e, "Rush Bar:").line

	# ── Load SVG icons (128px) ─────────────────────────────────
	if ICON_COLOR_APPLY == null:
		ICON_COLOR_APPLY = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/color_apply.svg", 128)
		if ICON_COLOR_APPLY == null:
			ICON_COLOR_APPLY = preload("res://graphics/icons/console-line.svg")

	if ICON_COLOR_ENV == null:
		ICON_COLOR_ENV = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/color_env.svg", 128)
		if ICON_COLOR_ENV == null:
			ICON_COLOR_ENV = preload("res://graphics/icons/console-line.svg")

	if ICON_COLOR_RANDOM == null:
		ICON_COLOR_RANDOM = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/color_random.svg", 128)
		if ICON_COLOR_RANDOM == null:
			ICON_COLOR_RANDOM = preload("res://graphics/icons/console-line.svg")

	if ICON_COLOR_RESET == null:
		ICON_COLOR_RESET = VFXUtils.load_svg_icon("user://editor_scripts/SVGs/color_reset.svg", 128)
		if ICON_COLOR_RESET == null:
			ICON_COLOR_RESET = preload("res://graphics/icons/console-line.svg")

	# ── Action buttons grid (2 × 2) ────────────────────────────
	var grid_buttons := GridContainer.new()
	grid_buttons.columns = 2
	grid_buttons.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	grid_buttons.size_flags_vertical = Control.SIZE_SHRINK_BEGIN

	# Minimal spacing between cells
	grid_buttons.add_theme_constant_override("h_separation", 16)
	grid_buttons.add_theme_constant_override("v_separation", 0)

	root.add_child(grid_buttons)


	_add_color_icon_button(
		grid_buttons,
		"Apply Color",
		"Adds/updates ColorAnim/v1 start→impact colors using GAME TIMEOUT.\nBlank START copies END; blank both leaves channel unchanged.",
		"_apply_color_window",
		ICON_COLOR_APPLY
	)

	_add_color_icon_button(
		grid_buttons,
		"Apply Envelopes",
		"Timeout-based pre-impact window with Valley/Peak envelopes on the beat.",
		"_apply_color_envelopes",
		ICON_COLOR_ENV
	)

	_add_color_icon_button(
		grid_buttons,
		"Randomize Colors",
		"Fill END (Peak) color fields with bright random colors. START remains blank so it copies END.",
		"_randomize_colors",
		ICON_COLOR_RANDOM
	)

	_add_color_icon_button(
		grid_buttons,
		"Reset Color UI",
		"Reset all Color fields and pickers in this tab back to defaults.",
		"_reset_to_defaults",
		ICON_COLOR_RESET
	)


	# Footer
	var foot := HBoxContainer.new()
	root.add_child(foot)
	foot.add_child(VFXUtils.mk_label("Color windows use GAME TIMEOUT for new rows unless you enable 'Replace window timing' above."))
	foot.add_child(VFXUtils.mk_spacer())

# ───────────────────────────────────────────────────────────────
# Entry points - WITH UNDO/REDO SUPPORT
# ───────────────────────────────────────────────────────────────

func _apply_color_window() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var start_before_ms := int(sb_before.value)
	var replace_time := cb_replace_time.button_pressed
	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	var se := _collect_SE_colors()
	var S = se[0]
	var E = se[1]


	var any_end := false
	for k in E.keys():
		if E[k] != null:
			any_end = true
			break
	if not any_end:
		_notify("❌ No END colors provided.")
		return

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Color Window VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_merge_rows(specs, start_before_ms, replace_time, S, E, end_hold_ms, use_note_end)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✅ Color window written/merged for %d note(s)." % specs.size())


func _apply_color_envelopes() -> void:
	if editor == null:
		_notify("❌ Editor not found.")
		return
	var specs: Array = VFXUtils.collect_selected_note_specs(editor)
	if specs.is_empty():
		_notify("❌ No notes selected.")
		return

	var env_enable := cb_env_enable.button_pressed
	var pulses_per_beat := int(sb_pulses.value)
	var phase_beats := float(sb_phase.value)
	var ease = EASE_OPTIONS[dd_ease.get_selected_id()]
	var end_hold_ms := _parse_end_hold_ms()
	var use_note_end := cb_use_note_end.button_pressed

	var se := _collect_SE_colors()
	var S = se[0]
	var E = se[1]


	var any_end := false
	for k in E.keys():
		if E[k] != null:
			any_end = true
			break
	if not any_end:
		_notify("❌ No END (Peak) colors provided.")
		return

	# ─── Undo/Redo: Capture before state ───
	var selected_keys := VFXUndoRedo.build_selected_keys(specs)
	var action := VFXUndoRedo.begin_action(editor, "Apply Color Envelopes VFX")
	action.set_module(self)
	action.capture_before_state(selected_keys, ANIM_TAG)
	
	# ─── Build new rows ───
	var new_rows := _build_color_anim_rows(specs, S, E, env_enable, pulses_per_beat, phase_beats, ease, end_hold_ms, use_note_end)
	
	# ─── Commit the action ───
	action.set_new_rows(new_rows)
	action.commit()
	
	_notify("✅ Color envelopes written for %d note(s)." % specs.size())

# ───────────────────────────────────────────────────────────────
# Row builders (return rows instead of writing directly)
# ───────────────────────────────────────────────────────────────

func _build_merge_rows(specs: Array, start_before_ms: int, replace_time: bool, S: Dictionary, E: Dictionary, end_hold_ms: int = 0, use_note_end: bool = false) -> Array:
	var path: String = VFXUtils.get_vfx_path(editor)

	var existing_rows: Array = VFXUtils.load_vfx_json(path)

	var preserved: Array = []
	var cmap: Dictionary = {}  # key -> row

	for e in existing_rows:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue

		var anim := String(e.get("anim",""))
		if anim != ANIM_TAG:
			preserved.append(e)
			continue

		var layer := String(e.get("layer",""))
		var nt := int(e.get("note_type", -1))
		var head := int(e.get("anim_note_time", -1))
		var stage := String(e.get("anim_stage",""))
		if layer == "" or nt < 0 or head < 0 or stage == "":
			preserved.append(e)
			continue

		# Keep envelope rows as-is
		if stage == "envelope":
			preserved.append(e)
			continue

		var key := "%s@%d@%d@%s" % [layer, nt, head, stage]
		cmap[key] = e

	for spec in specs:
		var layer := String(spec["layer"])
		var head_t := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var timeout_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_t, DEBUG_TIMEOUT)
		if timeout_ms <= 0:
			timeout_ms = DEFAULT_START_BEFORE_MS
		var t0_timeout := head_t - timeout_ms
		var t0_fixed := head_t - start_before_ms
		var t1 := head_t

		var start_cols := _build_start_cols(S, E)
		var end_cols := _build_end_cols(E)

		# anim_start
		var k_start := "%s@%d@%d@%s" % [layer, ntype, head_t, "anim_start"]
		var base_start := {}
		if cmap.has(k_start):
			base_start = cmap[k_start]
		var start_time := (
			t0_fixed if replace_time
			else (int(base_start.get("time", t0_timeout)) if not base_start.is_empty() else t0_timeout)
		)
		var merged_start := _merge_row(base_start, start_cols, layer, ntype, head_t, "anim_start", start_time)
		if not merged_start.is_empty():
			cmap[k_start] = merged_start

		# Determine if we're using hold_end (for Rush/Sustain) or impact
		var hold_end_time := 0
		if use_note_end and spec.has("sustain_end"):
			hold_end_time = int(spec["sustain_end"])
		elif end_hold_ms > 0:
			hold_end_time = head_t + end_hold_ms

		# Always write impact row with end colors
		var k_impact := "%s@%d@%d@%s" % [layer, ntype, head_t, "impact"]
		var base_impact := {}
		if cmap.has(k_impact):
			base_impact = cmap[k_impact]
		var impact_time := (t1 if replace_time or base_impact.is_empty() else int(base_impact.get("time", t1)))
		var merged_impact := _merge_row(base_impact, end_cols, layer, ntype, head_t, "impact", impact_time)
		if not merged_impact.is_empty():
			cmap[k_impact] = merged_impact

		# If hold_end is enabled, write envelope at impact (start colors) and hold_end (end colors)
		# This creates a start→end animation during the sustain period
		if hold_end_time > t1:
			# Envelope row slightly after impact with start colors (beginning of sustain animation)
			# Offset by 1ms to ensure it comes after the impact row in processing order
			var env_time := t1 + 1
			var k_env_start := "%s@%d@%d@envelope@%d" % [layer, ntype, head_t, env_time]
			var env_start_row := _merge_row({}, start_cols, layer, ntype, head_t, "envelope", env_time)
			if not env_start_row.is_empty():
				cmap[k_env_start] = env_start_row

			# hold_end: at sustain end, transition to end colors
			var k_hold_end := "%s@%d@%d@%s" % [layer, ntype, head_t, "hold_end"]
			var base_hold_end := {}
			if cmap.has(k_hold_end):
				base_hold_end = cmap[k_hold_end]
			var merged_hold_end := _merge_row(base_hold_end, end_cols, layer, ntype, head_t, "hold_end", hold_end_time)
			if not merged_hold_end.is_empty():
				cmap[k_hold_end] = merged_hold_end
		else:
			# No hold_end - remove any existing hold rows for this note
			var k_hold_end := "%s@%d@%d@%s" % [layer, ntype, head_t, "hold_end"]
			if cmap.has(k_hold_end):
				cmap.erase(k_hold_end)

	var out: Array = []
	for p in preserved:
		out.append(p)
	for k in cmap.keys():
		out.append(cmap[k])

	return out

func _merge_row(base_row: Dictionary, cols: Dictionary, layer: String, ntype: int, head_time: int, stage: String, time_ms: int) -> Dictionary:
	var adding := false
	for k in cols.keys():
		if cols[k] != null:
			adding = true
			break
	if base_row.is_empty() and not adding:
		return {}

	var row := {}
	if base_row.is_empty():
		row["layer"] = layer
		row["time"] = time_ms
		row["note_type"] = float(ntype)
		row["anim"] = ANIM_TAG
		row["anim_stage"] = stage
		row["anim_note_time"] = head_time
	else:
		for k in base_row.keys():
			row[k] = base_row[k]
		row["time"] = time_ms

	_apply_color_if_any(row, "color_icon",      cols.get("icon", null))
	_apply_color_if_any(row, "color_target",    cols.get("target", null))
	_apply_color_if_any(row, "color_bar1",      cols.get("bar1", null))
	_apply_color_if_any(row, "color_bar2",      cols.get("bar2", null))
	_apply_color_if_any(row, "color_icon_head", cols.get("icon_head", null))
	_apply_color_if_any(row, "color_icon_tail", cols.get("icon_tail", null))
	_apply_color_if_any(row, "color_hold_text", cols.get("hold_text", null))
	_apply_color_if_any(row, "color_rush_text", cols.get("rush_text", null))
	_apply_color_if_any(row, "color_rush_icon", cols.get("rush_icon", null))
	_apply_color_if_any(row, "color_rush_bar",  cols.get("rush_bar", null))
	return row

func _build_color_anim_rows(specs: Array, S: Dictionary, E: Dictionary, env_enable: bool, pulses_per_beat: int, phase_beats: float, ease: String, end_hold_ms: int = 0, use_note_end: bool = false) -> Array:
	var path: String = VFXUtils.get_vfx_path(editor)

	var existing: Array = VFXUtils.load_vfx_json(path)

	var sel_heads := {}
	for spec in specs:
		var layer := String(spec["layer"])
		var head  := int(spec["time"])
		var nt    := int(spec["note_type"])
		sel_heads["%s@%d@%d" % [layer, nt, head]] = true

	var preserved: Array = []
	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue
		if String(e.get("anim","")) != ANIM_TAG:
			preserved.append(e)
			continue
		var layer_e := String(e.get("layer",""))
		var nt_e := int(e.get("note_type",-1))
		var head_e := int(e.get("anim_note_time",-999999))
		var key_e := "%s@%d@%d" % [layer_e, nt_e, head_e]
		if not sel_heads.has(key_e):
			preserved.append(e)

	var out_rows := preserved.duplicate()

	for spec in specs:
		var layer := String(spec["layer"])
		var head_ms := int(spec["time"])
		var ntype := int(spec["note_type"])
		var note_obj = spec.get("note_obj", null)

		var timeout_ms: int = VFXUtils.compute_timeout_ms(editor, ntype, note_obj, head_ms, DEBUG_TIMEOUT)
		var bpm: float = VFXUtils.bpm_at_ms(editor, head_ms)
		if bpm <= 0.0:
			bpm = 120.0

		var beat_ms := int(round(60000.0 / max(1.0, bpm)))
		var sub_period_ms := int(max(1, beat_ms / max(1, pulses_per_beat)))
		var phase_ms := int(round(beat_ms * phase_beats))

		var t1 := head_ms
		var t0 := max(0, head_ms - timeout_ms)
		if t0 >= t1:
			t0 = t1 - 1

		var start_cols := _build_start_cols(S, E)
		var end_cols := _build_end_cols(E)

		out_rows.append(_mk_row_colors(layer, ntype, head_ms, "anim_start", t0, start_cols, ease))

		# Pre-impact envelopes (anim_start to impact)
		if env_enable and sub_period_ms > 0:
			var rem := fposmod(float(t0) - float(phase_ms), float(sub_period_ms))
			var t := int(round(t0 + (sub_period_ms - rem)))
			if t <= t0:
				t += sub_period_ms

			var ix := 0
			while t < t1:
				var use_valley := (ix % 2) == 0
				var cols := start_cols if use_valley else end_cols
				out_rows.append(_mk_row_colors(layer, ntype, head_ms, "envelope", t, cols, ease))
				ix += 1
				t += sub_period_ms

		# Determine if we're using hold_end (for Rush/Sustain) or impact
		var hold_end_time := 0
		if use_note_end and spec.has("sustain_end"):
			hold_end_time = int(spec["sustain_end"])
		elif end_hold_ms > 0:
			hold_end_time = head_ms + end_hold_ms

		# Always write impact row
		out_rows.append(_mk_row_colors(layer, ntype, head_ms, "impact", t1, end_cols, ease))

		# If hold_end is enabled, continue the envelope pattern through the sustain
		if hold_end_time > t1:
			# Post-impact envelopes (impact to hold_end) using the same start/end colors
			if env_enable and sub_period_ms > 0:
				# Continue from impact time, keeping the same phase/rhythm
				var rem := fposmod(float(t1) - float(phase_ms), float(sub_period_ms))
				var t := int(round(t1 + (sub_period_ms - rem)))
				if t <= t1:
					t += sub_period_ms

				var ix := 0
				while t < hold_end_time:
					var use_valley := (ix % 2) == 0
					var cols := start_cols if use_valley else end_cols
					out_rows.append(_mk_row_colors(layer, ntype, head_ms, "envelope", t, cols, ease))
					ix += 1
					t += sub_period_ms
			else:
				# No envelope mode - just add a single envelope point at impact+1 to restart the animation
				out_rows.append(_mk_row_colors(layer, ntype, head_ms, "envelope", t1 + 1, start_cols, ease))

			out_rows.append(_mk_row_colors(layer, ntype, head_ms, "hold_end", hold_end_time, end_cols, ease))

	return out_rows


# ───────────────────────────────────────────────────────────────
# Timing helpers
# ───────────────────────────────────────────────────────────────

func _parse_end_hold_ms() -> int:
	if line_end_hold == null:
		return 0
	var t := line_end_hold.text.strip_edges()
	if t.is_empty():
		return 0
	if not t.is_valid_float():
		return 0
	var v := int(round(float(t.to_float())))
	if v < 0:
		return 0
	return v


# ───────────────────────────────────────────────────────────────
# Color helpers
# ───────────────────────────────────────────────────────────────

func _enc_color(c: Color) -> Array:
	return [VFXUtils.r3(c.r), VFXUtils.r3(c.g), VFXUtils.r3(c.b), VFXUtils.r3(c.a)]

func _apply_color_if_any(dst: Dictionary, key: String, col: Variant) -> void:
	if col == null:
		return
	if col is Color:
		dst[key] = _enc_color(col)

func _coalesce_color(a: Variant, b: Variant) -> Variant:
	if a != null:
		return a
	return b

# For pre-impact phase: rush mirrors icon/bar
func _build_start_cols(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = _coalesce_color(S.get("icon", null),      E.get("icon", null))
	d["target"]     = _coalesce_color(S.get("target", null),    E.get("target", null))
	d["bar1"]       = _coalesce_color(S.get("bar1", null),      E.get("bar1", null))
	d["bar2"]       = _coalesce_color(S.get("bar2", null),      E.get("bar2", null))
	d["icon_head"]  = _coalesce_color(S.get("icon_head", null), E.get("icon_head", null))
	d["icon_tail"]  = _coalesce_color(S.get("icon_tail", null), E.get("icon_tail", null))
	d["hold_text"]  = _coalesce_color(S.get("hold_text", null), E.get("hold_text", null))
	# Rush text uses its own pre-impact field (visible during approach)
	d["rush_text"]  = _coalesce_color(S.get("rush_text_pre", null), E.get("rush_text_pre", null))
	if d["rush_text"] == null:
		d["rush_text"] = d["icon"]  # Fallback to icon if not specified
	# Rush icon/bar mirror icon/bar during pre-impact (not visible yet)
	d["rush_icon"]  = d["icon"]
	d["rush_bar"]   = d["bar1"]
	return d

# For pre-impact phase: rush icon/bar mirrors icon/bar, but rush_text has its own field
func _build_end_cols(E: Dictionary) -> Dictionary:
	var d := {}
	d["icon"]       = E.get("icon", null)
	d["target"]     = E.get("target", null)
	d["bar1"]       = E.get("bar1", null)
	d["bar2"]       = E.get("bar2", null)
	d["icon_head"]  = E.get("icon_head", null)
	d["icon_tail"]  = E.get("icon_tail", null)
	d["hold_text"]  = E.get("hold_text", null)
	# Rush text uses its own pre-impact field (visible during approach)
	d["rush_text"]  = E.get("rush_text_pre", null)
	if d["rush_text"] == null:
		d["rush_text"] = d["icon"]  # Fallback to icon if not specified
	# Rush icon/bar mirror icon/bar during pre-impact (not visible yet)
	d["rush_icon"]  = d["icon"]
	d["rush_bar"]   = d["bar1"]
	return d

# Build rush START colors for post-impact phase (Valley)
func _build_rush_start_cols(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := _build_end_cols(E)  # Start from regular end values
	# Override with Rush START if provided, else fall back to Rush END
	d["rush_text"] = _coalesce_color(S.get("rush_text", null), E.get("rush_text", null))
	d["rush_icon"] = _coalesce_color(S.get("rush_icon", null), E.get("rush_icon", null))
	d["rush_bar"]  = _coalesce_color(S.get("rush_bar", null),  E.get("rush_bar", null))
	# If still null, fall back to icon/bar end values
	if d["rush_text"] == null:
		d["rush_text"] = d["icon"]
	if d["rush_icon"] == null:
		d["rush_icon"] = d["icon"]
	if d["rush_bar"] == null:
		d["rush_bar"] = d["bar1"]
	return d

# Build rush END colors for post-impact phase (Peak)
func _build_rush_end_cols(S: Dictionary, E: Dictionary) -> Dictionary:
	var d := _build_end_cols(E)  # Start from regular end values
	# Override with Rush END if provided
	if E.get("rush_text", null) != null:
		d["rush_text"] = E.get("rush_text")
	if E.get("rush_icon", null) != null:
		d["rush_icon"] = E.get("rush_icon")
	if E.get("rush_bar", null) != null:
		d["rush_bar"] = E.get("rush_bar")
	return d

func _mk_row_colors(layer: String, ntype: int, head_time: int, stage: String, t_ms: int, cols: Dictionary, ease: String) -> Dictionary:
	var row := {
		"layer": layer,
		"time": t_ms,
		"note_type": float(ntype),
		"anim": ANIM_TAG,
		"anim_stage": stage,
		"anim_note_time": head_time,
		"ease": String(ease)
	}
	_apply_color_if_any(row, "color_icon",      cols.get("icon", null))
	_apply_color_if_any(row, "color_target",    cols.get("target", null))
	_apply_color_if_any(row, "color_bar1",      cols.get("bar1", null))
	_apply_color_if_any(row, "color_bar2",      cols.get("bar2", null))
	_apply_color_if_any(row, "color_icon_head", cols.get("icon_head", null))
	_apply_color_if_any(row, "color_icon_tail", cols.get("icon_tail", null))
	_apply_color_if_any(row, "color_hold_text", cols.get("hold_text", null))
	_apply_color_if_any(row, "color_rush_text", cols.get("rush_text", null))
	_apply_color_if_any(row, "color_rush_icon", cols.get("rush_icon", null))
	_apply_color_if_any(row, "color_rush_bar",  cols.get("rush_bar", null))
	return row

func _parse_color_any(text: String) -> Variant:
	var s := String(text).strip_edges()
	if s.is_empty():
		return null
	if s.begins_with("#"):
		var h := s.substr(1)
		if h.length() in [3,4,6,8]:
			var r: float
			var g: float
			var b: float
			var a: float = 1.0
			if h.length() == 3 or h.length() == 4:
				r = int("0x" + h[0] + h[0]) / 255.0
				g = int("0x" + h[1] + h[1]) / 255.0
				b = int("0x" + h[2] + h[2]) / 255.0
				if h.length() == 4:
					a = int("0x" + h[3] + h[3]) / 255.0
			else:
				r = int("0x" + h.substr(0,2)) / 255.0
				g = int("0x" + h.substr(2,2)) / 255.0
				b = int("0x" + h.substr(4,2)) / 255.0
				if h.length() == 8:
					a = int("0x" + h.substr(6,2)) / 255.0
			return Color(clamp(r,0.0,1.0), clamp(g,0.0,1.0), clamp(b,0.0,1.0), clamp(a,0.0,1.0))
		return null
	var parts := s.split(",", false)
	if parts.size() < 3:
		return null
	var nums: Array = []
	for p in parts:
		var t := String(p).strip_edges()
		if t.is_empty():
			return null
		nums.append(float(t))
	var r2 = nums[0]
	var g2 = nums[1]
	var b2 = nums[2]
	var a2 = nums[3] if nums.size() >= 4 else 1.0
	if r2 > 1.0 or g2 > 1.0 or b2 > 1.0 or a2 > 1.0:
		r2 /= 255.0
		g2 /= 255.0
		b2 /= 255.0
		if a2 > 1.0:
			a2 /= 255.0
	return Color(clamp(r2,0.0,1.0), clamp(g2,0.0,1.0), clamp(b2,0.0,1.0), clamp(a2,0.0,1.0))

func _collect_SE_colors() -> Array:
	var S := {
		"icon":      _parse_color_any(s_icon_line.text),
		"target":    _parse_color_any(s_target_line.text),
		"bar1":      _parse_color_any(s_bar1_line.text),
		"bar2":      _parse_color_any(s_bar2_line.text),
		"icon_head": _parse_color_any(s_head_line.text),
		"icon_tail": _parse_color_any(s_tail_line.text),
		"hold_text": _parse_color_any(s_hold_line.text),
		# Rush text for pre-impact approach
		"rush_text_pre": _parse_color_any(s_rush_text_pre_line.text) if s_rush_text_pre_line else null,
		# Rush colors for hold_end phase
		"rush_text": _parse_color_any(s_rush_text_line.text) if s_rush_text_line else null,
		"rush_icon": _parse_color_any(s_rush_icon_line.text) if s_rush_icon_line else null,
		"rush_bar":  _parse_color_any(s_rush_bar_line.text) if s_rush_bar_line else null,
	}
	var E := {
		"icon":      _parse_color_any(e_icon_line.text),
		"target":    _parse_color_any(e_target_line.text),
		"bar1":      _parse_color_any(e_bar1_line.text),
		"bar2":      _parse_color_any(e_bar2_line.text),
		"icon_head": _parse_color_any(e_head_line.text),
		"icon_tail": _parse_color_any(e_tail_line.text),
		"hold_text": _parse_color_any(e_hold_line.text),
		# Rush text for pre-impact approach
		"rush_text_pre": _parse_color_any(e_rush_text_pre_line.text) if e_rush_text_pre_line else null,
		# Rush colors for hold_end phase
		"rush_text": _parse_color_any(e_rush_text_line.text) if e_rush_text_line else null,
		"rush_icon": _parse_color_any(e_rush_icon_line.text) if e_rush_icon_line else null,
		"rush_bar":  _parse_color_any(e_rush_bar_line.text) if e_rush_bar_line else null,
	}
	return [S, E]

# ───────────────────────────────────────────────────────────────
# UI helpers + HBEditorButton
# ───────────────────────────────────────────────────────────────

func _add_color_field(grid: GridContainer, label_text: String, placeholder: String = "") -> Dictionary:
	var lbl := Label.new()
	lbl.text = label_text

	var h := HBoxContainer.new()
	var le := LineEdit.new()
	le.placeholder_text = placeholder
	le.custom_minimum_size = Vector2(220, 0)

	var pick := ColorPickerButton.new()
	pick.custom_minimum_size = Vector2(34, 0)
	pick.color = Color(1,1,1,1)
	pick.color_changed.connect(func(c: Color):
		le.text = "%0.3f,%0.3f,%0.3f,%0.3f" % [c.r, c.g, c.b, c.a]
	)

	h.add_child(le)
	h.add_child(pick)
	grid.add_child(lbl)
	grid.add_child(h)

	return {"line": le, "picker": pick}

func _find_ease_index(name: String) -> int:
	for i in range(EASE_OPTIONS.size()):
		if EASE_OPTIONS[i] == name:
			return i
	return 0

func _add_color_icon_button(
	parent: GridContainer,
	label_text: String,
	tooltip: String,
	func_name: String,
	icon_tex: Texture2D
) -> void:
	var cell := VBoxContainer.new()
	cell.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	cell.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_theme_constant_override("separation", 0) # no extra gap in the cell

	# 128×128 square, handled by ratio container
	var ratio := HBoxRatioContainer.new()
	ratio.custom_minimum_size = Vector2(128, 128)
	ratio.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	ratio.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	cell.add_child(ratio)

	# HBEditorButton fills that square and now ALSO owns the text
	var hb := _mk_hb_button(label_text, tooltip, func_name)
	hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.size_flags_vertical   = Control.SIZE_EXPAND_FILL
	hb.custom_minimum_size   = Vector2(0, 0) # ratio controls final size

	var inner: Button = hb.get_button()
	if inner:
		inner.icon = icon_tex
		inner.expand_icon = true
		inner.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

	ratio.add_child(hb)

	# No extra Label under the button anymore – text is inside the button.
	parent.add_child(cell)



func _mk_hb_button(text: String, tooltip: String, func_name: String) -> HBEditorButton:
	var b := HBEditorButton.new()
	b.button_mode = "function"
	b.text = text
	b.tooltip = tooltip
	b.function_name = func_name
	b.params = []
	b.disable_when_playing = true
	b.disable_with_popup = true

	# Let the parent (ratio container) control size
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.size_flags_vertical = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 0)

	b.set_module(self)
	return b


# ───────────────────────────────────────────────────────────────
# Preview + notifications
# ───────────────────────────────────────────────────────────────

func _after_write_preview() -> void:
	VFXUtils.trigger_preview_reload(editor)

func _reset_to_defaults() -> void:
	# Window timing
	if sb_before:
		sb_before.value = DEFAULT_START_BEFORE_MS
	if cb_replace_time:
		cb_replace_time.button_pressed = false
	if line_end_hold:
		line_end_hold.text = "0"
	if cb_use_note_end:
		cb_use_note_end.button_pressed = false

	# Envelope controls
	if cb_env_enable:
		cb_env_enable.button_pressed = true
	if sb_pulses:
		sb_pulses.value = DEFAULT_PULSES_PER_BEAT
	if sb_phase:
		sb_phase.value = DEFAULT_PHASE_BEATS
	if dd_ease:
		dd_ease.select(_find_ease_index(DEFAULT_EASE))

	# Clear all START (Valley) fields
	if s_icon_line:
		s_icon_line.text = ""
	if s_target_line:
		s_target_line.text = ""
	if s_bar1_line:
		s_bar1_line.text = ""
	if s_bar2_line:
		s_bar2_line.text = ""
	if s_head_line:
		s_head_line.text = ""
	if s_tail_line:
		s_tail_line.text = ""
	if s_hold_line:
		s_hold_line.text = ""
	if s_rush_text_pre_line:
		s_rush_text_pre_line.text = ""

	# Clear all END (Peak) fields
	if e_icon_line:
		e_icon_line.text = ""
	if e_target_line:
		e_target_line.text = ""
	if e_bar1_line:
		e_bar1_line.text = ""
	if e_bar2_line:
		e_bar2_line.text = ""
	if e_head_line:
		e_head_line.text = ""
	if e_tail_line:
		e_tail_line.text = ""
	if e_hold_line:
		e_hold_line.text = ""
	if e_rush_text_pre_line:
		e_rush_text_pre_line.text = ""

	# Clear Rush START fields (hold_end phase)
	if s_rush_text_line:
		s_rush_text_line.text = ""
	if s_rush_icon_line:
		s_rush_icon_line.text = ""
	if s_rush_bar_line:
		s_rush_bar_line.text = ""

	# Clear Rush END fields
	if e_rush_text_line:
		e_rush_text_line.text = ""
	if e_rush_icon_line:
		e_rush_icon_line.text = ""
	if e_rush_bar_line:
		e_rush_bar_line.text = ""

	# Reset all ColorPickerButtons in this module to white
	_reset_color_pickers_to_white(self)

	_notify("✅ Color UI reset to defaults.")

func _randomize_colors() -> void:
	# Generate bright random colors for END (Peak) only.
	# START stays blank so it copies END (your existing rule).
	var c_icon: Color      = _rand_bright_color()
	var c_target: Color    = _rand_bright_color()
	var c_bar1: Color      = _rand_bright_color()
	var c_bar2: Color      = _rand_bright_color()
	var c_head: Color      = _rand_bright_color()
	var c_tail: Color      = _rand_bright_color()
	var c_hold: Color      = _rand_bright_color()
	var c_rush_text_pre: Color = _rand_bright_color()
	var c_rush_text: Color = _rand_bright_color()
	var c_rush_icon: Color = _rand_bright_color()
	var c_rush_bar: Color  = _rand_bright_color()

	# Apply to END (Peak) fields
	_set_line_and_picker(e_icon_line,   c_icon)
	_set_line_and_picker(e_target_line, c_target)
	_set_line_and_picker(e_bar1_line,   c_bar1)
	_set_line_and_picker(e_bar2_line,   c_bar2)
	_set_line_and_picker(e_head_line,   c_head)
	_set_line_and_picker(e_tail_line,   c_tail)
	_set_line_and_picker(e_hold_line,   c_hold)
	_set_line_and_picker(e_rush_text_pre_line, c_rush_text_pre)

	# Apply to Rush END fields (hold_end phase)
	_set_line_and_picker(e_rush_text_line, c_rush_text)
	_set_line_and_picker(e_rush_icon_line, c_rush_icon)
	_set_line_and_picker(e_rush_bar_line,  c_rush_bar)

	# Clear START (Valley) fields so they default to "copy END"
	if s_icon_line:      s_icon_line.text = ""
	if s_target_line:    s_target_line.text = ""
	if s_bar1_line:      s_bar1_line.text = ""
	if s_bar2_line:      s_bar2_line.text = ""
	if s_head_line:      s_head_line.text = ""
	if s_tail_line:      s_tail_line.text = ""
	if s_hold_line:      s_hold_line.text = ""
	if s_rush_text_pre_line: s_rush_text_pre_line.text = ""

	# Clear Rush START fields so they default to "copy Rush END"
	if s_rush_text_line: s_rush_text_line.text = ""
	if s_rush_icon_line: s_rush_icon_line.text = ""
	if s_rush_bar_line:  s_rush_bar_line.text = ""

	_notify("🎲 Randomized END colors. Click 'Apply Color' to write VFX.")


func _rand_bright_color() -> Color:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var h := rng.randf()
	var s := rng.randf_range(0.65, 1.0)
	var v := rng.randf_range(0.80, 1.0)
	return Color.from_hsv(h, s, v, 1.0)


func _set_line_and_picker(le: LineEdit, c: Color) -> void:
	if le == null:
		return

	le.text = "%0.3f,%0.3f,%0.3f,%0.3f" % [c.r, c.g, c.b, c.a]

	var parent := le.get_parent()
	if parent != null:
		for child in parent.get_children():
			if child is ColorPickerButton:
				(child as ColorPickerButton).color = c


func _reset_color_pickers_to_white(node: Node) -> void:
	for child in node.get_children():
		if child is ColorPickerButton:
			(child as ColorPickerButton).color = Color(1, 1, 1, 1)
		if child is Node:
			_reset_color_pickers_to_white(child)


func _notify(text: String) -> void:
	VFXUtils.show_notification(editor, text)
