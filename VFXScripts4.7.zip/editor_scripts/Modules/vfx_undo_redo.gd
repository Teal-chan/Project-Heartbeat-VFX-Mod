# vfx_undo_redo.gd - Undo/Redo support for VFX Toolbox modules
# Place in: user://editor_scripts/Modules/vfx_undo_redo.gd
#
# This helper enables full undo/redo support for VFX apply actions by:
# 1. Capturing the "before" state of affected VFX rows
# 2. Registering do/undo methods with the editor's UndoRedo system
# 3. Restoring/reapplying states on undo/redo
#
# Usage in modules:
#   const VFXUndoRedo = preload("user://editor_scripts/Modules/vfx_undo_redo.gd")
#
#   func _apply_my_effect() -> void:
#       var action = VFXUndoRedo.begin_action(editor, "Apply Scale VFX")
#       action.capture_before_state(path, selected_keys, ANIM_TAG)
#       
#       # ... generate your new rows ...
#       
#       action.set_new_rows(new_rows)
#       action.commit()

class_name VFXUndoRedo

const VFXUtils = preload("user://editor_scripts/Modules/vfx_utils.gd")

# ═══════════════════════════════════════════════════════════════════════════════
# ACTION CLASS - Manages a single undoable VFX operation
# ═══════════════════════════════════════════════════════════════════════════════

class VFXAction:
	var editor: Node
	var action_name: String
	var vfx_path: String
	
	# State tracking
	var before_rows: Array = []      # Rows that existed before (will be restored on undo)
	var after_rows: Array = []       # Rows that will exist after (will be applied on do/redo)
	var anim_tag: String = ""        # Animation tag to filter by
	var selected_keys: Dictionary = {} # Keys identifying which notes are affected
	
	# For preview refresh
	var _module: Node = null
	var _custom_refresh_method: String = ""
	
	func _init(p_editor: Node, p_action_name: String) -> void:
		editor = p_editor
		action_name = p_action_name
		vfx_path = VFXUtils.get_vfx_path(editor)
	
	## Set the module reference for preview refresh after undo/redo
	func set_module(module: Node) -> VFXAction:
		_module = module
		return self
	
	## Set a custom refresh method name to call instead of _after_write_preview
	## Use this for modules like Field VFX that need _refresh_slide_manager()
	func set_refresh_method(method_name: String) -> VFXAction:
		_custom_refresh_method = method_name
		return self
	
	## Capture the current state of rows that will be affected
	## Call this BEFORE making any changes
	## 
	## selected_keys: Dictionary of "layer@note_type@time" -> true for affected notes
	## anim_tag: The animation tag (e.g., "ScaleAbsAnim/v1") to identify our rows
	func capture_before_state(p_selected_keys: Dictionary, p_anim_tag: String) -> VFXAction:
		selected_keys = p_selected_keys
		anim_tag = p_anim_tag
		
		var existing := VFXUtils.load_vfx_json(vfx_path)
		before_rows = []
		
		# Capture ALL existing rows - we need the full file state
		for row in existing:
			before_rows.append(row.duplicate(true) if row is Dictionary else row)
		
		return self
	
	## Capture before state for field-based actions (by layer tag instead of note keys)
	## Used by Field VFX module for $PLAYFIELD, $PF_ROTATE_SEL, $PF_SCALE_SEL rows
	## Can be called multiple times to capture multiple layer types
	func capture_before_state_for_layer(layer_tag: String) -> VFXAction:
		# Only load once - subsequent calls just track additional layers
		if before_rows.is_empty():
			var existing := VFXUtils.load_vfx_json(vfx_path)
			for row in existing:
				before_rows.append(row.duplicate(true) if row is Dictionary else row)
		
		# Track the layer tag (stored in anim_tag field, comma-separated if multiple)
		if anim_tag.is_empty():
			anim_tag = layer_tag
		elif not anim_tag.contains(layer_tag):
			anim_tag += "," + layer_tag
		
		return self
	
	## Set the new rows that will be written
	## Call this AFTER generating your new VFX data
	func set_new_rows(rows: Array) -> VFXAction:
		after_rows = []
		for row in rows:
			after_rows.append(row.duplicate(true) if row is Dictionary else row)
		return self
	
	## Commit the action to the editor's undo/redo system
	func commit() -> void:
		if editor == null or editor.undo_redo == null:
			# Fallback: just write directly if no undo system available
			_write_rows(after_rows)
			_refresh_preview()
			return
		
		var undo_redo: UndoRedo = editor.undo_redo
		
		undo_redo.create_action(action_name)
		
		# DO: Write the new rows
		undo_redo.add_do_method(_write_rows.bind(after_rows))
		undo_redo.add_do_method(_refresh_preview)
		
		# UNDO: Restore the old rows
		undo_redo.add_undo_method(_write_rows.bind(before_rows))
		undo_redo.add_undo_method(_refresh_preview)
		
		undo_redo.commit_action()
	
	## Internal: Write rows to the VFX JSON file
	func _write_rows(rows: Array) -> void:
		VFXUtils.write_sorted_vfx_json(vfx_path, rows, "VFXUndoRedo")
	
	## Internal: Trigger preview refresh
	func _refresh_preview() -> void:
		if _module != null:
			# Use custom refresh method if specified (e.g., "_refresh_slide_manager" for Field module)
			if _custom_refresh_method != "" and _module.has_method(_custom_refresh_method):
				_module.call(_custom_refresh_method)
			elif _module.has_method("_after_write_preview"):
				_module._after_write_preview()
			else:
				VFXUtils.trigger_preview_reload(editor)
		else:
			VFXUtils.trigger_preview_reload(editor)


# ═══════════════════════════════════════════════════════════════════════════════
# STATIC ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

## Begin a new undoable VFX action
## Returns a VFXAction that you configure and then commit
static func begin_action(editor: Node, action_name: String) -> VFXAction:
	return VFXAction.new(editor, action_name)


# ═══════════════════════════════════════════════════════════════════════════════
# HELPER: Build selected_keys dictionary from note specs
# ═══════════════════════════════════════════════════════════════════════════════

## Build a selected_keys dictionary from an array of note specs
## This is what you pass to capture_before_state()
static func build_selected_keys(specs: Array) -> Dictionary:
	var keys := {}
	for spec in specs:
		var layer := String(spec["layer"])
		var ntype := int(spec["note_type"])
		var head_t := int(spec["time"])
		keys["%s@%d@%d" % [layer, ntype, head_t]] = true
	return keys
