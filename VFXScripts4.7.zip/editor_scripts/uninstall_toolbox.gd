extends ScriptRunnerScript

#meta:name:Uninstall VFX Toolbox
#meta:description:Removes custom Note VFX / Field / Presets / Playhead / Bookmarks tabs and runs Decompile Shaders + Uninject Motion. Also clears bookmark markers from the timeline (but keeps bookmark JSON files).
#meta:usage:Run once to remove those tabs from the editor.

const CUSTOM_MODULE_NAMES = [
	"VFX Presets",
	"Utilities",
	"Playhead",
	"Bookmarks",
	"Scale",
	"Color",
	"Rotation",
	"Offset",
	"Spotlight",
	"Field",
	"Glow",
]

const BOOKMARK_META_KEY := "__ph_bookmarks"

# Names used by the Field VFX module / PlayfieldSlidesManager
const FIELD_MANAGER_NAME := "PH_PlayfieldSlides_UNIFIED"
const FIELD_WRAPPER_NAME := "PH_PlayfieldWrapper_ALL"


func _run_embedded_tool(path: String) -> void:
	if _editor == null:
		return

	var res = load(path)
	if res == null:
		push_warning("[VFX Toolbox Uninstall] Could not load tool script at: " + path)
		return

	var script_instance = res.new()
	if not script_instance is ScriptRunnerScript:
		push_warning("[VFX Toolbox Uninstall] Script is not ScriptRunnerScript: " + path)
		return

	script_instance._editor = _editor

	if script_instance.has_method("init_script"):
		script_instance.init_script()

	var result = script_instance.run_script()
	if result != OK:
		push_warning("[VFX Toolbox Uninstall] Tool '%s' returned error code %d" % [path, result])


# --- NEW: attempt to uninject Field motion before removing modules --------

func _uninject_field_motion() -> void:
	if _editor == null:
		return

	# 1) Best-effort: use the live Field module's own uninject logic
	for m in _editor.modules:
		if m is HBEditorModule and m.module_name == "Field":
			if m.has_method("_on_uninject_field_anims"):
				m._on_uninject_field_anims()
				return

	# 2) Fallback: directly clean up managers + wrappers if Field module is missing
	_uninject_field_managers_fallback()
	_unwrap_field_wrappers_fallback()


func _uninject_field_managers_fallback() -> void:
	if _editor == null:
		return

	var tree = _editor.get_tree()
	if tree == null:
		return

	var root = tree.get_root()
	if root == null:
		return

	var stack: Array = [root]
	var managers: Array = []

	while stack.size() > 0:
		var n = stack.pop_back()
		if n == null:
			continue

		if String(n.name) == FIELD_MANAGER_NAME:
			managers.append(n)

		for c in n.get_children():
			if c is Node:
				stack.append(c)

	# For each manager, try to restore preview & playtest baselines, then disarm + free
	for mgr in managers:
		if mgr == null:
			continue

		if mgr.has_method("_restore_preview_to_baseline"):
			mgr._restore_preview_to_baseline()
		if mgr.has_method("_restore_playtest_wrapper_to_baseline"):
			mgr._restore_playtest_wrapper_to_baseline()
		if mgr.has_method("disarm"):
			mgr.disarm()

		mgr.queue_free()


func _unwrap_field_wrappers_fallback() -> void:
	if _editor == null:
		return

	var tree = _editor.get_tree()
	if tree == null:
		return

	var root = tree.get_root()
	if root == null:
		return

	var stack: Array = [root]

	while stack.size() > 0:
		var n = stack.pop_back()
		if n == null:
			continue

		if String(n.name) == FIELD_WRAPPER_NAME and n is Node2D:
			_unwrap_one_field_wrapper(n as Node2D)

		for c in n.get_children():
			if c is Node:
				stack.append(c)


func _unwrap_one_field_wrapper(wrapper: Node2D) -> void:
	if wrapper == null or not is_instance_valid(wrapper):
		return

	var parent = wrapper.get_parent()
	if parent == null:
		return

	# Move Node2D children out of the wrapper, preserving global position
	var children: Array = wrapper.get_children()
	for child in children:
		if not (child is Node2D):
			continue

		var c2d := child as Node2D
		var gp = c2d.get_global_position()
		wrapper.remove_child(c2d)
		parent.add_child(c2d)
		parent.move_child(c2d, wrapper.get_index())
		c2d.set_global_position(gp)

	# If the wrapper is now empty, free it
	if wrapper.get_child_count() == 0:
		wrapper.queue_free()


# --- Clear only the *visual* bookmark markers from any timelines ----------

func _clear_bookmark_markers_recursive(node: Node) -> void:
	if node == null:
		return

	# Each timeline the bookmark module touched gets a child called "BookmarkMarkers"
	var markers = node.get_node_or_null("BookmarkMarkers")
	if markers != null:
		markers.queue_free()

	for child in node.get_children():
		if child is Node:
			_clear_bookmark_markers_recursive(child)


func _clear_all_bookmark_markers() -> void:
	if _editor == null:
		return

	var tree = _editor.get_tree()
	if tree == null:
		return

	var root = tree.get_root()
	if root != null:
		_clear_bookmark_markers_recursive(root)


# -------------------------------------------------------------------------


func run_script() -> int:
	if _editor == null:
		print("[Uninstall] ❌ No HBEditor reference.")
		return ERR_DOES_NOT_EXIST

	# First: uninject playfield / field motion so the scene is restored cleanly
	_uninject_field_motion()

	var old_modules = _editor.modules
	var kept_modules: Array = []
	var removed_count = 0

	for m in old_modules:
		var should_remove = false

		if m is HBEditorModule:
			if CUSTOM_MODULE_NAMES.has(m.module_name):
				should_remove = true

		if should_remove:
			removed_count += 1

			# Detach from UI if needed
			if m.get_parent():
				m.get_parent().remove_child(m)

			m.queue_free()
		else:
			kept_modules.append(m)

	# Replace the editor's module list with only the kept ones
	_editor.modules = kept_modules

	# Clear bookmark *metadata* so a fresh install starts clean (does NOT touch JSON files)
	if _editor.has_meta(BOOKMARK_META_KEY):
		_editor.remove_meta(BOOKMARK_META_KEY)

	# Remove all visible bookmark overlays from timelines
	_clear_all_bookmark_markers()

	# Run cleanup utilities: decompile shaders
	_run_embedded_tool("user://editor_scripts/Utilities/decompile.gd")

	if _editor.message_shower:
		_editor.message_shower._show_notification("🧹 VFX Toolbox Uninstalled (motion uninjected)")

	print("[Uninstall] Done. Removed %d module(s)." % removed_count)
	return OK
