#meta:name:Mount Metadata Hook for Playtest
#meta:description:On playtest start, runs hook scripts when crossing Metadata timing points.
#meta:usage:Run once, then start/stop playtest. Add metadata points in editor with keys like "hello".

extends ScriptRunnerScript

const TAG := "[Metadata-Playtest]"
const META_KEY := "ph_metadata_playtest_hook"

class HookNode:
	extends Node

	var editor: Object = null
	var popup_root: Node = null

	# Trigger table
	var times: PackedInt32Array = PackedInt32Array()
	var keys_for_time := {}            # time:int -> String (the metadata key)
	var idx: int = 0
	var last_time_ms: int = 0

	# Hit behavior
	var hit_window_ms: int = 1
	var armed: bool = false

	# Time provider
	var time_node: Node = null
	var time_game: Object = null
	var time_mode: String = ""
	var get_time_sec: Callable = Callable()

	# Metadata key -> hook path(s)
	var hook_paths := {
		"hello": [
			"user://editor_scripts/hello-metadata.gd",
		],
		"textbox": [
			"user://editor_scripts/textbox-metadata.gd",
		],
		"TZ start": [
			"user://editor_scripts/tz-counter-simple.gd",
		],
		"TZ end": [
			"user://editor_scripts/tz-counter-simple.gd",
		],
		"HBT start": [
			"user://editor_scripts/hbt-counter-simple.gd",
		],
		# Add more key -> script mappings here as needed
	}

	func _ready() -> void:
		set_process(true)
		if editor != null:
			var tree = editor.get_tree()
			if not tree.is_connected("node_added", Callable(self, "_on_node_added")):
				tree.node_added.connect(Callable(self, "_on_node_added"))
		print(TAG + " ready; waiting for playtest popup…")

	# -------- Popup detection --------
	func _looks_like_popup(n: Node) -> bool:
		if n == null:
			return false
		var nm := String(n.name)
		# Skip GamePreview - that's the editor preview window
		if nm.findn("GamePreview") != -1:
			return false
		
		# For Control nodes, verify they have RhythmGame as a child (actual playtest)
		if nm == "Control" or nm.findn("EditorRhythmGamePopup") != -1:
			for child in n.get_children():
				if child.name == "RhythmGame" or child.get_class().findn("RhythmGame") != -1:
					print(TAG + " found actual playtest with RhythmGame child: " + nm)
					return true
			return false
		
		return n.has_method("play_song_from_position") or n.has_method("set_song")

	func _popup_root_from(n: Node) -> Node:
		var cur := n
		while cur:
			if _looks_like_popup(cur):
				return cur
			cur = cur.get_parent()
		return null

	func _on_node_added(n: Node) -> void:
		# If previous popup_root was freed without _on_playtest_end firing, clear it
		if popup_root != null and not is_instance_valid(popup_root):
			print(TAG + " stale popup_root detected, clearing")
			_on_playtest_end()
		if popup_root == null:
			var root := _popup_root_from(n)
			if root != null:
				_on_playtest_start(root)

	func _on_playtest_start(root: Node) -> void:
		popup_root = root
		print(TAG + " ▶ playtest start: " + root.name)
		_build_triggers()
		_bind_time_source()
		armed = true
		if root.has_signal("quit"):
			if not root.is_connected("quit", Callable(self, "_on_playtest_end")):
				root.connect("quit", Callable(self, "_on_playtest_end"))
		root.tree_exited.connect(Callable(self, "_on_playtest_end"))

	func _on_playtest_end() -> void:
		print(TAG + " ⏹ playtest end")
		armed = false
		time_node = null
		time_game = null
		time_mode = ""
		get_time_sec = Callable()
		popup_root = null
		_cleanup_tz_counter()

	func _cleanup_tz_counter() -> void:
		if editor == null:
			return
		# Find TZCounterNode(s), HBTCounterNode(s), and orphaned counter layers on editor
		var to_free: Array = []
		for child in editor.get_children():
			if child.name.begins_with("TZCounterNode") or child.name == "TZCounterLayer":
				to_free.append(child)
			elif child.name.begins_with("HBTCounterNode") or child.name == "HBTCounterLayer":
				to_free.append(child)
		for node in to_free:
			if is_instance_valid(node):
				print(TAG + " cleaning up " + node.name)
				if node.name.begins_with("TZCounterNode") and node.has_method("_on_playtest_end"):
					node.call("_on_playtest_end")
				elif node.name.begins_with("HBTCounterNode") and node.has_method("_on_playtest_end"):
					node.call("_on_playtest_end")
				else:
					node.queue_free()

	# -------- Trigger build - look for Metadata timing points --------
	func _build_triggers() -> void:
		times = PackedInt32Array()
		keys_for_time.clear()
		idx = 0
		last_time_ms = _now_ms_editor()

		var chart_path := ""
		if editor != null and editor.current_song != null:
			chart_path = editor.current_song.get_chart_path(editor.current_difficulty)
		print(TAG + " chart_path=" + chart_path)
		if chart_path == "" or not FileAccess.file_exists(chart_path):
			print(TAG + " chart path missing or not found.")
			return

		var rf := FileAccess.open(chart_path, FileAccess.READ)
		var parsed: Variant = JSON.parse_string(rf.get_as_text())
		rf.close()
		if parsed == null or not (parsed is Dictionary):
			print(TAG + " JSON parse failed.")
			return

		var collected: Array[int] = []
		_collect_metadata_recursive(parsed, collected)

		collected.sort()
		times = PackedInt32Array(collected)
		idx = _lower_bound(times, _now_ms_editor() - hit_window_ms)

		print(TAG + " metadata_points_found=" + str(int(times.size())))
		for t in times:
			print(TAG + " metadata@" + str(int(t)) + "ms key=\"" + str(keys_for_time.get(t, "")) + "\"")

	func _collect_metadata_recursive(node: Variant, out_times: Array) -> void:
		if node is Array:
			var arr: Array = node
			for i in arr.size():
				_collect_metadata_recursive(arr[i], out_times)
			return

		if node is Dictionary:
			var d: Dictionary = node
			
			# Look for Metadata timing points: {"type": "Metadata", "time": ..., "meta": {"key": "..."}}
			var type_field := d.get("type", null)
			if type_field is String and String(type_field) == "Metadata":
				var time_any := d.get("time", null)
				var meta_any := d.get("meta", null)
				var key_any = null
				if meta_any is Dictionary:
					key_any = meta_any.get("key", null)
				
				if (time_any is int or time_any is float) and key_any is String:
					var t := int(time_any)
					var key := String(key_any)
					out_times.append(t)
					keys_for_time[t] = key

			# Recursively search all dictionary values
			for k in d.keys():
				_collect_metadata_recursive(d[k], out_times)

	# -------- Time source binding (simplified from VFX version) --------
	func _bind_time_source() -> void:
		print(TAG + " === _bind_time_source START ===")
		time_node = null
		time_game = null
		time_mode = ""
		get_time_sec = Callable()
		if popup_root == null:
			print(TAG + " popup_root is null, returning")
			return

		print(TAG + " popup_root: " + popup_root.name)
		print(TAG + " searching for time source...")
		
		var queue: Array = [popup_root]
		var nodes_checked = 0
		while queue.size() > 0 and not get_time_sec.is_valid():
			var cur := queue.pop_front() as Node
			if cur == null:
				continue

			nodes_checked += 1
			if nodes_checked < 20:
				print(TAG + " checking node: " + cur.name + " (" + cur.get_class() + ")")

			if _try_bind_time_from_methods(cur):
				time_node = cur
				break
			
			if _try_bind_time_from_holder(cur, "game") or _try_bind_time_from_holder(cur, "rhythm_game"):
				time_node = cur
				time_mode = "game"
				break

			var cls := String(cur.get_class())
			var nm := String(cur.name)
			
			# Check for VideoStreamPlayer early - reliable time source
			if cls == "VideoStreamPlayer" or nm.findn("VideoStreamPlayer") != -1:
				print(TAG + " found VideoStreamPlayer: " + nm)
				if cur.has_method("get_stream_position"):
					var n := cur
					get_time_sec = func() -> float:
						return float(n.call("get_stream_position"))
					time_mode = "video"
					time_node = cur
					print(TAG + " bound time via VideoStreamPlayer.get_stream_position()")
					break
			
			if cls.findn("RhythmGame") != -1 or nm.findn("RhythmGame") != -1:
				print(TAG + " found RhythmGame-like node: " + nm)
				if _try_bind_time_from_methods(cur) or _try_bind_time_from_props(cur):
					time_node = cur
					break

			if cur.has_method("get_playback_position"):
				var n := cur
				get_time_sec = func() -> float:
					return float(n.call("get_playback_position"))
				time_mode = "audio"
				time_node = cur
				print(TAG + " bound time via AudioStreamPlayer")
				break

			for child in cur.get_children():
				queue.append(child)
		
		print(TAG + " checked " + str(nodes_checked) + " nodes")
		if get_time_sec.is_valid():
			print(TAG + " ✓ time source bound successfully")
		else:
			print(TAG + " ✗ NO TIME SOURCE FOUND")
		print(TAG + " === _bind_time_source END ===")

	func _try_bind_time_from_methods(n: Object) -> bool:
		var sec_methods := ["get_time", "get_song_time", "get_song_position", "get_playhead_time"]
		for m in sec_methods:
			if n.has_method(m):
				get_time_sec = Callable(n, m)
				time_mode = "method"
				if n is Object and n.has_signal("time_changed"):
					n.connect("time_changed", Callable(self, "_on_time_changed"))
					time_mode = "signal"
				print(TAG + " bound time via method: " + m)
				return true
		return false

	func _try_bind_time_from_props(n: Object) -> bool:
		var sec_props := ["time", "song_time", "position"]
		for p in sec_props:
			if n.has_method("get"):
				var v: Variant = n.get(p)
				if v is float or v is int:
					var obj := n
					var key = p
					get_time_sec = func() -> float:
						return float(obj.get(key))
					time_mode = "prop"
					print(TAG + " bound time via prop: " + p)
					return true
		
		# Check millisecond properties
		var ms_props := ["time_msec", "time_ms"]
		for p in ms_props:
			if n.has_method("get"):
				var v: Variant = n.get(p)
				if v is float or v is int:
					var obj := n
					var key = p
					get_time_sec = func() -> float:
						return float(obj.get(key)) / 1000.0
					time_mode = "prop"
					print(TAG + " bound time via prop: " + p + " (ms)")
					return true
		return false

	func _try_bind_time_from_holder(n: Object, holder_name: String) -> bool:
		if not n.has_method("get"):
			return false
		var h: Variant = n.get(holder_name)
		if not (h is Object):
			return false
		var o := h as Object
		if _try_bind_time_from_methods(o):
			time_game = o
			return true
		if _try_bind_time_from_props(o):
			time_game = o
			return true
		return false

	func _now_ms_playtest() -> int:
		if get_time_sec.is_valid():
			var sec := float(get_time_sec.call())
			return int(sec * 1000.0)
		return _now_ms_editor()

	func _now_ms_editor() -> int:
		if editor != null:
			return int(editor.playhead_position)
		return 0

	# -------- Runtime --------
	func _process(_delta: float) -> void:
		# Detect stale popup_root even if still technically valid
		if popup_root != null:
			if not is_instance_valid(popup_root) or not popup_root.is_inside_tree():
				print(TAG + " popup_root stale (freed or removed from tree), clearing")
				_on_playtest_end()
				return
		if not armed:
			return
		_step_exact(_now_ms_playtest())

	func _on_time_changed(tsec: float) -> void:
		if not armed:
			return
		_step_exact(int(tsec * 1000.0))

	func _step_exact(t_now: int) -> void:
		if t_now < last_time_ms:
			idx = _lower_bound(times, t_now - hit_window_ms)
		while idx < times.size() and times[idx] <= t_now + hit_window_ms:
			if times[idx] > last_time_ms - hit_window_ms:
				var t := times[idx]
				var key := keys_for_time.get(t, "")
				_fire_hooks(t, key)
			idx += 1
		last_time_ms = t_now

	func _fire_hooks(t: int, key: String) -> void:
		print(TAG + " _fire_hooks called: time=" + str(t) + " key=\"" + key + "\"")
		if key == "":
			print(TAG + " key is empty, returning")
			return
		if not hook_paths.has(key):
			print(TAG + " no hook registered for key=\"" + key + "\"")
			return

		print(TAG + " hook_paths has key, getting paths...")
		var entry = hook_paths[key]
		var paths: Array = []

		if entry is String:
			paths.append(String(entry))
		elif entry is Array:
			for p in entry:
				if p is String:
					paths.append(String(p))

		print(TAG + " found " + str(paths.size()) + " paths to execute")
		for path in paths:
			print(TAG + " executing hook: " + path)
			_run_script_hook(path, {"time": t, "key": key})

	func _run_script_hook(path: String, context: Dictionary) -> void:
		var res: Resource = load(path)
		if res == null:
			print(TAG + " hook load failed: " + path)
			return
		if not (res is GDScript):
			print(TAG + " hook not a GDScript: " + path)
			return

		var script: GDScript = res as GDScript
		var err: int = script.reload()
		if err != OK:
			print(TAG + " hook reload failed: " + path)
			return

		var inst := script.new()
		if inst == null:
			print(TAG + " hook instantiation failed: " + path)
			return

		var rc: int = 0

		# ScriptRunnerScript style
		if inst.has_method("run_script"):
			if inst.has_method("set_context"):
				inst.call("set_context", context)
			if editor != null:
				inst._editor = editor
			if inst.has_method("init_script"):
				inst.call("init_script")
			var ret: Variant = inst.call("run_script")
			rc = int(ret) if ret is int else OK

		# Plain GDScript style
		elif inst.has_method("run"):
			var ret2: Variant = inst.callv("run", [editor, context])
			rc = int(ret2) if ret2 is int else OK

		else:
			print(TAG + " hook has no run_script() or run(): " + path)
			return

		var hook_time = context.get("time", 0)
		var hook_key = context.get("key", "")
		print(TAG + " ✓ hook executed: " + path + " @ " + str(hook_time) + "ms key=\"" + hook_key + "\"")

	func _lower_bound(a: PackedInt32Array, v: int) -> int:
		var lo := 0
		var hi := a.size()
		while lo < hi:
			var mid := (lo + hi) >> 1
			if a[mid] < v:
				lo = mid + 1
			else:
				hi = mid
		return lo

# ===== Entry point =====
func run_script() -> int:
	if _editor == null:
		return ERR_DOES_NOT_EXIST
	if _editor.has_meta(META_KEY):
		print(TAG + " already active.")
		return OK

	var n := HookNode.new()
	n.name = "HBMetadataPlaytestHook"
	n.editor = _editor
	_editor.add_child(n)
	_editor.set_meta(META_KEY, n)
	print(TAG + " ✅ installed; start Playtest to trigger hooks.")
	return OK
