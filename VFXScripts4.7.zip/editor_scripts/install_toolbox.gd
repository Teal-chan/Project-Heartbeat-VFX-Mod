extends ScriptRunnerScript

#meta:name:Install VFX Toolbox
#meta:description:Launches required scripts for visual effects and places new editor tabs.
#meta:usage:Run once per editor session

class ScriptLauncherModule:
	extends HBEditorModule

	var tools := []
	var _container: VBoxContainer
	var enable_scroll := true
	var _svg_icon_cache: Dictionary = {}

	const ICON_SIZE_PX := 64
	const CARD_SIZE_PX := 128


	func _load_svg_icon(path: String, size: int = ICON_SIZE_PX) -> Texture2D:
		if path == "":
			return null
		if not FileAccess.file_exists(path):
			print("[VFX Toolbox] SVG not found at:", path)
			return null

		var file := FileAccess.open(path, FileAccess.READ)
		if file == null:
			print("[VFX Toolbox] Failed to open SVG:", path)
			return null

		var buffer := file.get_buffer(file.get_length())

		var img := Image.new()
		var err := img.load_svg_from_buffer(buffer)
		if err != OK:
			print("[VFX Toolbox] Failed to load SVG from buffer:", path, " error:", err)
			return null

		img.resize(size, size, Image.INTERPOLATE_BILINEAR)
		return ImageTexture.create_from_image(img)


	func _get_icon_from_tool(tool: Dictionary) -> Texture2D:
		if tool == null or not tool.has("icon"):
			return null

		var path := String(tool["icon"])
		if path == "":
			return null

		if _svg_icon_cache.has(path):
			return _svg_icon_cache[path]

		var tex := _load_svg_icon(path)
		if tex != null:
			_svg_icon_cache[path] = tex
		return tex

	func _init(tools_arg := []) -> void:
		tools = tools_arg

	func _ready() -> void:
		super._ready()

		custom_minimum_size = Vector2(0, 0)

		var parent_for_tools: Control = self

		if enable_scroll:
			var scroll := ScrollContainer.new()
			scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
			scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
			scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
			add_child(scroll)
			parent_for_tools = scroll

		_container = VBoxContainer.new()
		_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_container.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
		_container.set_anchors_preset(Control.PRESET_FULL_RECT)
		_container.add_theme_constant_override("separation", 4)
		parent_for_tools.add_child(_container)

		for tool in tools:
			if tool.has("hb_grid"):
				_add_hb_grid_group(tool)
			elif tool.has("options"):
				_add_dropdown_group(tool)
			else:
				_add_button(tool)

	# ------------------------------------------------------------------
	# UI builders
	# ------------------------------------------------------------------

	func _add_dropdown_group(tool: Dictionary) -> void:
		var group_box := VBoxContainer.new()
		group_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		group_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER

		var lbl := Label.new()
		lbl.text = str(tool.get("label", "Group"))
		group_box.add_child(lbl)

		var hb := HBoxContainer.new()
		hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		group_box.add_child(hb)

		var dd := OptionButton.new()
		dd.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		dd.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		dd.custom_minimum_size = Vector2(0, 24)

		var options: Array = tool.get("options", [])
		for i in options.size():
			var opt: Dictionary = options[i]
			var opt_label := str(opt.get("label", "Option"))
			var opt_icon := _get_icon_from_tool(opt)

			if opt_icon != null:
				dd.add_icon_item(opt_icon, opt_label, i)
			else:
				dd.add_item(opt_label, i)

		var popup := dd.get_popup()
		popup.id_pressed.connect(_on_dropdown_id_pressed.bind(dd, options))

		hb.add_child(dd)
		_container.add_child(group_box)


	func _add_button(tool: Dictionary) -> void:
		var btn := Button.new()
		btn.text = str(tool.get("label", "Tool"))
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		btn.custom_minimum_size = Vector2(0, 24)
		btn.tooltip_text = str(tool.get("path", ""))

		var path := str(tool.get("path", ""))

		var icon_tex := _get_icon_from_tool(tool)
		if icon_tex != null:
			btn.icon = icon_tex
			btn.expand_icon = false
			btn.icon_alignment = HORIZONTAL_ALIGNMENT_LEFT

		btn.pressed.connect(_on_tool_button_pressed.bind(path))

		_container.add_child(btn)


	# NEW: HBEditorButton grid group for nice columns in the Playhead tab
	func _add_hb_grid_group(tool: Dictionary) -> void:
		var group_box := VBoxContainer.new()
		group_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		group_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER

		if tool.has("label"):
			var lbl := Label.new()
			lbl.text = str(tool["label"])
			group_box.add_child(lbl)

		var grid := GridContainer.new()
		grid.columns = int(tool.get("columns", 3))
		grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		group_box.add_child(grid)

		var btn_defs: Array = tool.get("buttons", [])
		for def in btn_defs:
			var ctrl := _make_hb_button_for_tool(def)
			grid.add_child(ctrl)

		_container.add_child(group_box)

	func _make_hb_button_for_tool(tool: Dictionary) -> Control:
		var label   := str(tool.get("label", "Tool"))
		var path    := str(tool.get("path", ""))
		var tooltip := str(tool.get("tooltip", ""))
		var card_sz := int(tool.get("card_size", CARD_SIZE_PX))

		# Outer cell – what the GridContainer actually lays out
		var cell := VBoxContainer.new()
		cell.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		cell.size_flags_vertical   = Control.SIZE_SHRINK_CENTER
		cell.add_theme_constant_override("separation", 0)

		# Square card like the Color/Rotation modules
		var ratio := HBoxRatioContainer.new()
		ratio.custom_minimum_size = Vector2(card_sz, card_sz)
		ratio.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		ratio.size_flags_vertical   = Control.SIZE_SHRINK_CENTER
		cell.add_child(ratio)

		var hb := HBEditorButton.new()
		hb.set_text(label)
		if tooltip != "":
			hb.set_tooltip(tooltip)
		else:
			hb.set_tooltip(path)

		hb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.size_flags_vertical   = Control.SIZE_EXPAND_FILL
		ratio.add_child(hb)

		var inner_btn: Button = hb.get_button()
		if inner_btn:
			inner_btn.pressed.connect(_on_tool_button_pressed.bind(path))

			var icon_tex := _get_icon_from_tool(tool)
			if icon_tex != null:
				inner_btn.icon = icon_tex
				inner_btn.expand_icon = true
				inner_btn.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER

		return cell


	# ------------------------------------------------------------------
	# Launchers
	# ------------------------------------------------------------------

	func _on_dropdown_id_pressed(id: int, dd: OptionButton, options: Array) -> void:
		if id < 0 or id >= options.size():
			return

		dd.select(id)

		var opt: Dictionary = options[id]
		var path := String(opt.get("path", ""))

		if path != "":
			_run_tool(path)


	func _on_tool_button_pressed(script_path: String) -> void:
		if script_path == "":
			return
		_run_tool(script_path)


	func _notify(text: String) -> void:
		if editor and editor.message_shower:
			editor.message_shower._show_notification(text)
		else:
			print(text)


	func _run_tool(path: String) -> void:
		var file := FileAccess.open(path, FileAccess.READ)
		var err := FileAccess.get_open_error()
		if err != OK:
			_notify("⚠️ Error loading script %s (code %d)." % [path, err])
			return

		var script := GDScript.new()
		script.source_code = file.get_as_text()
		var reload_err := script.reload()
		if reload_err != OK:
			_notify("⚠️ Failed to compile script %s (code %d)." % [path, reload_err])
			return

		var inst = script.new()
		if inst == null:
			_notify("⚠️ Failed to instance script: %s" % path)
			return

		# Branch 1: ScriptRunnerScript
		if inst is ScriptRunnerScript:
			var runner := inst as ScriptRunnerScript
			runner._editor = editor
			if runner.has_method("init_script"):
				runner.init_script()

			var result = runner.run_script()
			if result == OK:
				_process_changed_values(runner)
			else:
				_notify("⚠️ ScriptRunner tool returned error code: %d" % result)
			return

		# Branch 2: plain tool with run(editor)
		if inst.has_method("run"):
			inst.run(editor)
			return

		_notify("⚠️ Script at %s has no supported entry point (needs run_script() via ScriptRunnerScript or run(editor))." % path)


	func _process_changed_values(inst: ScriptRunnerScript) -> void:
		if not inst._timing_point_changed_properties and inst.new_timing_points.is_empty():
			return

		var action_name := "Run Script (VFX Toolbox)"
		undo_redo.create_action(action_name)

		# Some transforms might change the note type and thus the layer
		var type_to_layer_name_map = {}
		for type_name in HBNoteData.NOTE_TYPE:
			type_to_layer_name_map[HBNoteData.NOTE_TYPE[type_name]] = type_name

		type_to_layer_name_map[HBNoteData.NOTE_TYPE.SLIDE_CHAIN_PIECE_LEFT] = "SLIDE_LEFT"
		type_to_layer_name_map[HBNoteData.NOTE_TYPE.SLIDE_CHAIN_PIECE_RIGHT] = "SLIDE_RIGHT"

		# Apply changed properties on cloned timing points
		for clone in inst._timing_point_changed_properties:
			var changed_property_list = inst._timing_point_changed_properties[clone]
			var target_item = inst._clone_to_original_timing_point_map[clone]

			for property_name in changed_property_list:
				if property_name in target_item.data:
					undo_redo.add_do_property(target_item.data, property_name, changed_property_list[property_name])
					undo_redo.add_undo_property(target_item.data, property_name, target_item.data.get(property_name))

					undo_redo.add_undo_method(target_item._layer.place_child.bind(target_item))
					undo_redo.add_do_method(target_item._layer.place_child.bind(target_item))

					# If note_type changes, adjust layer
					if property_name == "note_type":
						var new_note_type = changed_property_list.note_type
						if type_to_layer_name_map[new_note_type] != target_item._layer.layer_name and \
								type_to_layer_name_map[new_note_type] + "2" != target_item._layer.layer_name:
							var source_layer = target_item._layer
							var target_layer_name = type_to_layer_name_map[new_note_type]

							if source_layer.layer_name.ends_with("2"):
								target_layer_name += "2"

							var target_layer := find_layer_by_name(target_layer_name)

							undo_redo.add_do_method(editor.remove_item_from_layer.bind(source_layer, target_item))
							undo_redo.add_do_method(editor.add_item_to_layer.bind(target_layer, target_item))

							undo_redo.add_undo_method(editor.remove_item_from_layer.bind(target_layer, target_item))
							undo_redo.add_undo_method(editor.add_item_to_layer.bind(source_layer, target_item))

					if property_name == "position":
						undo_redo.add_do_property(target_item.data, "pos_modified", true)
						undo_redo.add_undo_property(target_item.data, "pos_modified", target_item.data.pos_modified)

		# Handle any new timing points
		for timing_point in inst.new_timing_points:
			var layer_name
			if "note_type" in timing_point:
				layer_name = type_to_layer_name_map[timing_point.note_type]
			else:
				layer_name = "Events"

			var layer = find_layer_by_name(layer_name)
			create_timing_point(layer, timing_point.get_timeline_item())

		undo_redo.add_do_method(self.timing_points_changed)
		undo_redo.add_undo_method(self.timing_points_changed)
		undo_redo.add_do_method(self.sync_inspector_values)
		undo_redo.add_undo_method(self.sync_inspector_values)
		undo_redo.commit_action()


# -------------------------------------------------------------------
#  Tab helpers + installer
# -------------------------------------------------------------------

func _find_module_by_title(title: String):
	for m in _editor.modules:
		if m is HBEditorModule and m.module_name == title:
			return m
	return null


func _ensure_tab(tab_title: String, tools_array: Array, location: String) -> void:
	var existing = _find_module_by_title(tab_title)
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var module = ScriptLauncherModule.new(tools_array)
	module.module_location = location
	module.module_name = tab_title
	module.priority = 900

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_scale_vfx_tab() -> void:
	var existing = _find_module_by_title("Scale")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/scale_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Scale VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Scale"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_color_vfx_tab() -> void:
	var existing = _find_module_by_title("Color")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/color_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Color VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Color"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_rot_vfx_tab() -> void:
	var existing = _find_module_by_title("Rotation")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/rotation_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Rotation VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Rotation"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_offset_vfx_tab() -> void:
	var existing = _find_module_by_title("Offset")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/offset_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Offset VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Offset"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_spot_vfx_tab() -> void:
	var existing = _find_module_by_title("Spotlight")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/spot_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Spotlight VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Spotlight"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_field_vfx_tab() -> void:
	var existing = _find_module_by_title("Field")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/field_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Field VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Field"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_glow_vfx_tab() -> void:
	var existing = _find_module_by_title("Glow")
	if existing != null:
		if existing.parent:
			existing.parent.current_tab = existing.tab_idx
		return

	var res = load("user://editor_scripts/Modules/glow_vfx_module.gd")
	if res == null:
		push_warning("[VFX Toolbox] Could not load Glow VFX module script")
		return

	var module = res.new()
	module.module_location = "left_panel"
	module.module_name = "Glow"
	module.priority = 880

	_editor.modules.append(module)
	module.set_editor(_editor)

	if module.parent:
		module.parent.current_tab = module.tab_idx


func _ensure_bookmark_tab() -> void:
	var existing_bm = _find_module_by_title("Bookmarks")
	if existing_bm != null:
		if existing_bm.parent:
			existing_bm.parent.current_tab = existing_bm.tab_idx
		return

	var bm_script = load("user://editor_scripts/Utilities/bookmarks_module.gd")
	if bm_script == null:
		push_warning("[VFX Toolbox] Could not load bookmarks_module.gd")
		return

	var bm_module = bm_script.new()
	bm_module.module_location = "right_panel"
	bm_module.module_name = "Bookmarks"
	bm_module.priority = 850

	_editor.modules.append(bm_module)
	bm_module.set_editor(_editor)

	if bm_module.parent:
		bm_module.parent.current_tab = bm_module.tab_idx


func _run_embedded_tool(path: String) -> void:
	if _editor == null:
		return

	var res = load(path)
	if res == null:
		push_warning("[VFX Toolbox] Could not load tool script at: " + path)
		return

	var script_instance = res.new()
	if not script_instance is ScriptRunnerScript:
		push_warning("[VFX Toolbox] Script is not ScriptRunnerScript: " + path)
		return

	script_instance._editor = _editor

	if script_instance.has_method("init_script"):
		script_instance.init_script()

	var result = script_instance.run_script()
	if result != OK:
		push_warning("[VFX Toolbox] Tool '%s' returned error code %d" % [path, result])



# ===================================================================
# run_script: create tabs, run utilities, inject field manager
# ===================================================================

func run_script() -> int:
	if _editor == null:
		print("No HBEditor reference available.")
		return ERR_DOES_NOT_EXIST

	# ── PRESETS tab ─────────────────────────────────────────────
	var presets_tools = [
		{
			"label": "Universal presets",
			"options": [
				{"label": "Make Osu! Note", "path": "user://editor_scripts/Presets/osupreset.gd"},
				{"label": "True Mirai Link", "path": "user://editor_scripts/Presets/true_mirai.gd"},
			]
		},
		{
			"label": "Scale presets",
			"options": [
				{"label": "Heartbeat Pulse", "path": "user://editor_scripts/Presets/HBPulse.gd"},
				{"label": "Phased Pulse", "path": "user://editor_scripts/Presets/pulse_phase.gd"},
				{"label": "Scale 2 to 1", "path": "user://editor_scripts/Presets/make_osu_note2.gd"},
			]
		},
		{
			"label": "Color presets",
			"options": [
				{"label": "Primary Color Flash", "path": "user://editor_scripts/Presets/primary_flash.gd"},
				{"label": "Phased Flash", "path": "user://editor_scripts/Presets/phase_flash.gd"},
				{"label": "Random Flash", "path": "user://editor_scripts/Presets/random_color.gd"},
				{"label": "Single Rainbow", "path": "user://editor_scripts/Presets/single_rainbow.gd"},
				{"label": "Double Rainbow", "path": "user://editor_scripts/Presets/double_rainbow.gd"},
				{"label": "PlayStation Colors", "path": "user://editor_scripts/Presets/restore_PSX.gd"},
				{"label": "PS Colors (Targets)", "path": "user://editor_scripts/Presets/PSX_target.gd"},
				{"label": "Nintendo Colors", "path": "user://editor_scripts/Presets/restore_NIN.gd"},
				{"label": "Xbox/Steam Deck Colors", "path": "user://editor_scripts/Presets/restore_XST.gd"},
				{"label": "Alpha Fade", "path": "user://editor_scripts/Presets/make_osu_note3.gd"},
			]
		},
		{
			"label": "Editor preset",
			"options": [
				{"label": "Dist10+Osc0", "path": "user://editor_scripts/Presets/make_osu_note.gd"},
			]
		},
	]

	# ── UTILITIES tab → dropdown groups + HBEditorButtons ──────
	var util_tools = [
		{
			"label": "Shaders",
			"options": [
				{"label": "Compile Shaders", "path": "user://editor_scripts/Utilities/compile.gd"},
				{"label": "Decompile Shaders", "path": "user://editor_scripts/Utilities/decompile.gd"},
			]
		},
		{
			"label": "Selection",
			"options": [
				{"label": "Cycle through Selected Chord", "path": "user://editor_scripts/Utilities/cycle_chord.gd"},
				{"label": "Select All Sustain Notes", "path": "user://editor_scripts/Utilities/select_sustains.gd"},
				{"label": "Select All Double Notes", "path": "user://editor_scripts/Utilities/select_doubles.gd"},
				{"label": "Select All Hold Notes", "path": "user://editor_scripts/Utilities/select_holds.gd"},
				{"label": "Select All Chords", "path": "user://editor_scripts/Utilities/select_chords.gd"},
				{"label": "Select Notes Between Points", "path": "user://editor_scripts/Utilities/select_between.gd"},
				{"label": "Select All Notes in Lane", "path": "user://editor_scripts/Utilities/select_lane.gd"},
				{"label": "Select All Notes With VFX", "path": "user://editor_scripts/Utilities/select_VFX_notes.gd"},
				{"label": "Select All Notes Without VFX", "path": "user://editor_scripts/Utilities/select_clear_notes.gd"},
			]
		},
		{
			"label": "Miscellaneous",
			"options": [
				{"label": "Toggle Autosave", "path": "user://editor_scripts/Utilities/toggle_autosave.gd"},
				{"label": "Enable All Layers", "path": "user://editor_scripts/Utilities/enable_layers.gd"},
				{"label": "Open VFX JSON Externally", "path": "user://editor_scripts/Utilities/open_vfx_external.gd"},
				{"label": "VFX Inspector", "path": "user://editor_scripts/Utilities/VFX_Inspector.gd"},
				{"label": "VFX Summary", "path": "user://editor_scripts/Utilities/vfx_summary.gd"},
				{"label": "Check for Orphaned VFX Rows", "path": "user://editor_scripts/Utilities/check_orphans.gd"},
				{"label": "Prune Orphaned VFX Rows", "path": "user://editor_scripts/Utilities/prune_orphans.gd"},
				{"label": "Reset Selected Notes to True Default", "path": "user://editor_scripts/Utilities/true_default.gd"},
				{"label": "Reset Selected Chords to True Default", "path": "user://editor_scripts/Utilities/true_default_chords.gd"},
			]
		},
		# HBEditorButton grid row at the bottom:
		{
			"hb_grid": true,
			"label": "VFX Actions",
			"columns": 2,
			"buttons": [
				{
					"label": "Save VFX",
					"path": "user://editor_scripts/Utilities/save-vfx.gd",
					"tooltip": "Save current note VFX setup",
					"icon": "user://editor_scripts/SVGs/save_vfx_floppy.svg"
				},
				{
					"label": "Clear VFX",
					"path": "user://editor_scripts/Utilities/clear_vfx.gd",
					"tooltip": "Clear VFX from selected notes",
					"icon": "user://editor_scripts/SVGs/clear_vfx.svg"
				},
			]
		},
	]


	# ── PLAYHEAD tab ────────────────────────────────────────────
	var playhead_tools = [
		# Check Position - standalone button at top
		{
			"hb_grid": true,
			"columns": 1,
			"buttons": [
				{
					"label": "Check Position",
					"path": "user://editor_scripts/Utilities/hello_editor.gd",
					"tooltip": "Print current playhead position (ms) to console",
					"icon": "user://editor_scripts/SVGs/check_position.svg"
				},
			]
		},

		# Main grid: 12 controls (4 columns)
		{
			"hb_grid": true,
			"label": "Playhead Controls",
			"columns": 4,
			"buttons": [
				{
					"label": "Go to Playhead",
					"path": "user://editor_scripts/Utilities/go_to_playhead.gd",
					"tooltip": "Move selection to playhead position",
					"icon": "user://editor_scripts/SVGs/go_to_playhead.svg"
				},
				{
					"label": "Forward 5ms",
					"path": "user://editor_scripts/Utilities/advance_playhead.gd",
					"tooltip": "Nudge playhead forward by 5 ms",
					"icon": "user://editor_scripts/SVGs/forward.svg"
				},
				{
					"label": "Backward 5ms",
					"path": "user://editor_scripts/Utilities/decrement_playhead.gd",
					"tooltip": "Nudge playhead backward by 5 ms",
					"icon": "user://editor_scripts/SVGs/backward.svg"
				},
				{
					"label": "Select Current",
					"path": "user://editor_scripts/Utilities/snaph.gd",
					"tooltip": "Select note(s) at playhead",
					"icon": "user://editor_scripts/SVGs/select_current.svg"
				},
				{
					"label": "Snap to First",
					"path": "user://editor_scripts/Utilities/jump_to_first.gd",
					"tooltip": "Snap playhead to first note in chart",
					"icon": "user://editor_scripts/SVGs/snap_to_first.svg"
				},
				{
					"label": "Snap to Prior",
					"path": "user://editor_scripts/Utilities/jump-to-previous.gd",
					"tooltip": "Snap playhead to previous note",
					"icon": "user://editor_scripts/SVGs/snap_to_prior.svg"
				},
				{
					"label": "Snap to Next",
					"path": "user://editor_scripts/Utilities/jump-to-next.gd",
					"tooltip": "Snap playhead to next note",
					"icon": "user://editor_scripts/SVGs/snap_to_next.svg"
				},
				{
					"label": "Snap to Last",
					"path": "user://editor_scripts/Utilities/jump_to_last.gd",
					"tooltip": "Snap playhead to last note in chart",
					"icon": "user://editor_scripts/SVGs/snap_to_last.svg"
				},
				{
					"label": "Snap+Select First",
					"path": "user://editor_scripts/Utilities/snap+sel_first.gd",
					"tooltip": "Snap+select first note",
					"icon": "user://editor_scripts/SVGs/snap_sel_first.svg"
				},
				{
					"label": "Snap+Select Prior",
					"path": "user://editor_scripts/Utilities/previous_single.gd",
					"tooltip": "Snap+select previous single note",
					"icon": "user://editor_scripts/SVGs/snap_sel_prior.svg"
				},
				{
					"label": "Snap+Select Next",
					"path": "user://editor_scripts/Utilities/next_single.gd",
					"tooltip": "Snap+select next single note",
					"icon": "user://editor_scripts/SVGs/snap_sel_next.svg"
				},
				{
					"label": "Snap+Select Last",
					"path": "user://editor_scripts/Utilities/snap+sel_last.gd",
					"tooltip": "Snap+select last note",
					"icon": "user://editor_scripts/SVGs/snap_sel_last.svg"
				},
			]
		},

		# Second grid: 2 big chainable buttons below
		{
			"hb_grid": true,
			"columns": 2,
			"buttons": [
				{
					"label": "Snap+Select Prev Note (Chainable)",
					"path": "user://editor_scripts/Utilities/previous_note.gd",
					"tooltip": "Snap+select previous note, keeping previous ones selected",
					"icon": "user://editor_scripts/SVGs/snap_sel_trail_right.svg"
				},
				{
					"label": "Snap+Select Next Note (Chainable)",
					"path": "user://editor_scripts/Utilities/next_note.gd",
					"tooltip": "Snap+select next note, keeping previous ones selected",
					"icon": "user://editor_scripts/SVGs/snap_sel_trail_left.svg"
				},
			]
		},

		{
			"label": "Snap",
			"options": [
				{"label": "Snap to Selected Note", "path": "user://editor_scripts/Utilities/snap_playhead.gd"},
				{"label": "Snap to Selection Start", "path": "user://editor_scripts/Utilities/snap_to_start.gd"},
				{"label": "Snap to Selection End", "path": "user://editor_scripts/Utilities/snap_to_end.gd"},
				{"label": "Snap to Nearest BPM Change", "path": "user://editor_scripts/Utilities/jump_to_tempo_change.gd"},
				{"label": "Snap to Nearest Time Signature Change", "path": "user://editor_scripts/Utilities/jump_to_time_sig.gd"},
				{"label": "Snap to Previous Sustain Note", "path": "user://editor_scripts/Utilities/previous_sustain.gd"},
				{"label": "Snap to Next Sustain Note", "path": "user://editor_scripts/Utilities/next_sustain.gd"},
				{"label": "Snap to Previous Double Note", "path": "user://editor_scripts/Utilities/previous_double.gd"},
				{"label": "Snap to Next Double Note", "path": "user://editor_scripts/Utilities/next_double.gd"},
				{"label": "Snap to Previous Hold Note", "path": "user://editor_scripts/Utilities/previous_hold.gd"},
				{"label": "Snap to Next Hold Note", "path": "user://editor_scripts/Utilities/next_hold.gd"},
				{"label": "Snap to Previous Chord", "path": "user://editor_scripts/Utilities/previous_chord.gd"},
				{"label": "Snap to Next Chord", "path": "user://editor_scripts/Utilities/next_chord.gd"},
				{"label": "Snap to Previous VFX Note", "path": "user://editor_scripts/Utilities/prev-vfx.gd"},
				{"label": "Snap to Previous Non-VFX Note", "path": "user://editor_scripts/Utilities/prev_non_vfx.gd"},
				{"label": "Snap to Next VFX Note", "path": "user://editor_scripts/Utilities/next-vfx.gd"},
				{"label": "Snap to Next Non-VFX Note", "path": "user://editor_scripts/Utilities/next_non_vfx.gd"},
			]
		},
		{
			"label": "Snap+Select",
			"options": [
				{"label": "Snap+Select Previous Sustain Note", "path": "user://editor_scripts/Utilities/snap+sel_prev_sus.gd"},
				{"label": "Snap+Select Next Sustain Note", "path": "user://editor_scripts/Utilities/snap+sel_next_sus.gd"},
				{"label": "Snap+Select Previous Double Note", "path": "user://editor_scripts/Utilities/snap+sel_prev_double.gd"},
				{"label": "Snap+Select Next Double Note", "path": "user://editor_scripts/Utilities/snap+sel_next_double.gd"},
				{"label": "Snap+Select Previous Chord", "path": "user://editor_scripts/Utilities/snap+sel_prev_chord.gd"},
				{"label": "Snap+Select Next Chord", "path": "user://editor_scripts/Utilities/snap+sel_next_chord.gd"},
				{"label": "Snap+Select Previous Hold Note", "path": "user://editor_scripts/Utilities/snap+sel_prev_hold.gd"},
				{"label": "Snap+Select Next Hold Note", "path": "user://editor_scripts/Utilities/snap+sel_next_hold.gd"},
				{"label": "Snap+Select Previous VFX Note", "path": "user://editor_scripts/Utilities/jump-to-prev-vfx.gd"},
				{"label": "Snap+Select Next VFX Note", "path": "user://editor_scripts/Utilities/jump_to_next-vfx.gd"},
				{"label": "Snap+Select Previous Non-VFX Note", "path": "user://editor_scripts/Utilities/snap+sel_prev_non_VFX.gd"},
				{"label": "Snap+Select Next Non-VFX Note", "path": "user://editor_scripts/Utilities/snap+sel_next_non_VFX.gd"},
			]
		},
	]


	# Tabs
	_ensure_tab("VFX Presets", presets_tools, "left_panel")
	_ensure_tab("Playhead", playhead_tools, "right_panel")
	_ensure_tab("Utilities", util_tools, "right_panel")

	# Auto-run key utilities on install
	_run_embedded_tool("user://editor_scripts/Utilities/compile.gd")

	# Bookmarks tab
	_ensure_bookmark_tab()

	# Module tabs
	_ensure_scale_vfx_tab()
	_ensure_color_vfx_tab()
	_ensure_rot_vfx_tab()
	_ensure_offset_vfx_tab()
	_ensure_spot_vfx_tab()
	_ensure_glow_vfx_tab()
	_ensure_field_vfx_tab()



	_editor.message_shower._show_notification("✨ VFX Toolbox Installed")
	return OK
