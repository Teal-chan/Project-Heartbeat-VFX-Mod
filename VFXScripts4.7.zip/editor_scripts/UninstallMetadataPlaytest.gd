#meta:name:Uninstall Metadata Hook for Playtest
#meta:description:Removes the metadata playtest hook and cleans up any active TZ counters.
#meta:usage:Run to uninstall the hook without restarting the editor.

extends ScriptRunnerScript

const TAG := "[Metadata-Playtest-Uninstall]"
const META_KEY := "ph_metadata_playtest_hook"

func run_script() -> int:
	if _editor == null:
		return ERR_DOES_NOT_EXIST

	var cleaned := false

	# Remove the hook node
	if _editor.has_meta(META_KEY):
		var hook_node = _editor.get_meta(META_KEY)
		if hook_node and is_instance_valid(hook_node):
			# Disconnect tree watcher before freeing
			var tree = hook_node.get_tree()
			if tree and tree.is_connected("node_added", Callable(hook_node, "_on_node_added")):
				tree.disconnect("node_added", Callable(hook_node, "_on_node_added"))
			hook_node.queue_free()
			print(TAG + " hook node removed.")
		_editor.remove_meta(META_KEY)
		cleaned = true

	# Clean up any lingering TZ counter nodes and layers on the editor
	var to_free: Array = []
	for child in _editor.get_children():
		if child.name.begins_with("TZCounterNode") or child.name == "TZCounterLayer" or child.name == "HBMetadataPlaytestHook":
			to_free.append(child)
	for node in to_free:
		if is_instance_valid(node):
			print(TAG + " cleaning up " + node.name)
			node.queue_free()
			cleaned = true

	if cleaned:
		print(TAG + " ✅ uninstalled successfully.")
	else:
		print(TAG + " nothing to uninstall.")
	return OK
