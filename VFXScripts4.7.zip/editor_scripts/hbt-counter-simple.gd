# user://editor_scripts/hbt-counter-simple.gd
#meta:name:HBT Counter Simple Hook
#meta:description:Simplified ScriptRunner that injects the HBT (Heartbeat Time) Counter Node into the editor.
#meta:usage:Injected into the playtest automatically when the 'Mount Metadata Hook' script is launched.
extends ScriptRunnerScript

var _ctx: Dictionary = {}
func set_context(ctx: Dictionary) -> void: _ctx = ctx

func run_script() -> int:
	var key = _ctx.get("key", "")
	
	if key == "HBT start":
		return _handle_hbt_start()
	
	return OK

func _handle_hbt_start() -> int:
	print("[HBT HOOK] HBT start")
	
	# Find playtest and game (same strategy as TZ hook)
	var playtest_root = _find_playtest_root()
	if playtest_root == null:
		print("[HBT HOOK] ERROR: No playtest root")
		return ERR_DOES_NOT_EXIST
	
	var actual_game = null
	
	if "rhythm_game" in playtest_root:
		actual_game = playtest_root.rhythm_game
		print("[HBT HOOK] Got rhythm_game via property: " + str(actual_game))
	elif playtest_root.has_method("get") and playtest_root.get("rhythm_game"):
		actual_game = playtest_root.get("rhythm_game")
		print("[HBT HOOK] Got rhythm_game via get(): " + str(actual_game))
	else:
		print("[HBT HOOK] Popup doesn't have rhythm_game, searching...")
		var queue = [playtest_root]
		while queue.size() > 0:
			var node = queue.pop_front()
			if node.has_signal("note_judged"):
				actual_game = node
				print("[HBT HOOK] Found via signal search: " + str(node.name) + " id=" + str(node.get_instance_id()))
				break
			for child in node.get_children():
				queue.append(child)
	
	if actual_game == null:
		print("[HBT HOOK] ERROR: Could not find rhythm_game")
		return ERR_DOES_NOT_EXIST
	
	print("[HBT HOOK] Using game: %s (id=%d)" % [actual_game.name, actual_game.get_instance_id()])
	
	# Find the zone that matches this trigger time
	var trigger_time = _ctx.get("time", -1)
	var all_zones = _find_all_hbt_zones()
	var zone = null
	for z in all_zones:
		if z.start == trigger_time:
			zone = z
			break
	
	if zone == null:
		print("[HBT HOOK] ERROR: No HBT zone matching start time %d" % trigger_time)
		print("[HBT HOOK] (Most likely cause: no Qualifier-flagged note found at or after %d)" % trigger_time)
		return ERR_DOES_NOT_EXIST
	
	var start_time: int = zone.start
	var qualifier_time: int = zone.qualifier_time
	var qualifier_notes_total: int = zone.qualifier_notes_total
	
	# Count regular notes (everything in the zone except notes at qualifier_time)
	var total_regular = _count_regular_notes_in_zone(start_time, qualifier_time)
	print("[HBT HOOK] Zone %d → qualifier @ %d: %d regular notes, %d qualifier-time notes" % [
		start_time, qualifier_time, total_regular, qualifier_notes_total
	])
	
	# Load and create the counter node
	var counter_script = load("user://editor_scripts/hbt-counter-node.gd")
	if counter_script == null:
		print("[HBT HOOK] ERROR: Could not load hbt-counter-node.gd")
		return ERR_FILE_CANT_OPEN
	
	var counter_node = counter_script.new()
	counter_node.init_data(_editor, playtest_root, actual_game,
		start_time, qualifier_time, total_regular, qualifier_notes_total)
	
	# Add to the editor, NOT playtest root — if playtest root is freed,
	# the counter node must survive to run its cleanup in _process
	_editor.add_child(counter_node)
	print("[HBT HOOK] ✓ Counter node added to editor!")
	
	return OK


# ─────────────────────────────────────────────
# Zone discovery
# ─────────────────────────────────────────────

func _find_all_hbt_zones() -> Array:
	# Returns an array of dicts: { start, qualifier_time, qualifier_notes_total }
	# A zone is an HBT start marker paired with the first Qualifier-flagged note
	# at or after that marker's time. Zones with no Qualifier are skipped (with
	# an error log) so a forgotten flag doesn't silently break playtest.
	if _editor == null or _editor.current_song == null:
		return []
	
	var chart_path = _editor.current_song.get_chart_path(_editor.current_difficulty)
	if not FileAccess.file_exists(chart_path):
		return []
	
	var rf := FileAccess.open(chart_path, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(rf.get_as_text())
	rf.close()
	
	if parsed == null:
		return []
	
	# Collect HBT start markers
	var starts: Array = []
	_collect_hbt_starts_recursive(parsed, starts)
	starts.sort_custom(func(a, b): return a.time < b.time)
	
	# Collect every note with meta.qualifier == true, indexed by time.
	# Also collect a count of total notes at each qualifier_time (chord support).
	var qualifier_times: Array = []           # sorted list of times that have a Qualifier-flagged note
	var notes_at_time: Dictionary = {}        # time:int -> int (count of judgement-firing notes at that time)
	_collect_qualifier_data_recursive(parsed, qualifier_times, notes_at_time)
	qualifier_times.sort()
	
	# Pair each start with the first qualifier_time at or after it.
	# Bound: a zone's qualifier must come before the next HBT start (zones don't overlap).
	var zones: Array = []
	for i in starts.size():
		var s = starts[i]
		var next_start_time: int = 999999999
		if i + 1 < starts.size():
			next_start_time = starts[i + 1].time
		
		var found_qt: int = -1
		for qt in qualifier_times:
			if qt >= s.time and qt < next_start_time:
				found_qt = qt
				break
		
		if found_qt == -1:
			print("[HBT HOOK] WARNING: HBT start at %d has no Qualifier-flagged note before next zone — skipping" % s.time)
			continue
		
		var qcount: int = int(notes_at_time.get(found_qt, 1))
		zones.append({
			"start": s.time,
			"qualifier_time": found_qt,
			"qualifier_notes_total": qcount,
		})
	
	return zones


func _collect_hbt_starts_recursive(node: Variant, out_starts: Array) -> void:
	if node is Array:
		for item in node:
			_collect_hbt_starts_recursive(item, out_starts)
	elif node is Dictionary:
		var d: Dictionary = node
		if d.get("type") == "Metadata":
			var meta_dict = d.get("meta", {})
			if meta_dict is Dictionary and meta_dict.get("key", "") == "HBT start":
				out_starts.append({"time": int(d.get("time", -1))})
		for k in d.keys():
			_collect_hbt_starts_recursive(d[k], out_starts)


func _collect_qualifier_data_recursive(node: Variant, out_qualifier_times: Array, out_notes_at_time: Dictionary) -> void:
	# Walks the chart and:
	# - Records times that have at least one note with meta.qualifier == true (out_qualifier_times)
	# - Tallies how many judgement-firing notes exist at each such time (out_notes_at_time)
	#
	# Slide handling mirrors tz-counter-simple: only slide HEADS (note_type 4 or 5)
	# count as judgement events. Chain pieces (6, 7) are skipped.
	if node is Array:
		for item in node:
			_collect_qualifier_data_recursive(item, out_qualifier_times, out_notes_at_time)
		return
	
	if not (node is Dictionary):
		return
	
	var d: Dictionary = node
	var node_name = d.get("name", "")
	
	# Slide handling — process timing_points array directly, then recurse skipping it
	if d.has("timing_points") and node_name is String and String(node_name).findn("SLIDE") != -1:
		var tp: Array = d.get("timing_points", [])
		for point in tp:
			if point is Dictionary:
				var pt_time = int(point.get("time", -1))
				var nt = int(point.get("note_type", -1))
				# Only slide heads fire judgement
				if nt == 4 or nt == 5:
					out_notes_at_time[pt_time] = int(out_notes_at_time.get(pt_time, 0)) + 1
					var pmeta = point.get("meta", {})
					if pmeta is Dictionary and bool(pmeta.get("qualifier", false)):
						if not (pt_time in out_qualifier_times):
							out_qualifier_times.append(pt_time)
		# Recurse into other keys but not timing_points
		for k in d.keys():
			if k != "timing_points":
				_collect_qualifier_data_recursive(d[k], out_qualifier_times, out_notes_at_time)
		return
	
	# Regular note handling
	if d.has("type"):
		var type_str = str(d.get("type"))
		if type_str.findn("Note") != -1 and type_str != "Metadata":
			var nt2 = int(d.get("note_type", -1))
			# Skip slide chain pieces (already handled above, never fire judgement)
			if nt2 != 6 and nt2 != 7:
				var t = int(d.get("time", -1))
				out_notes_at_time[t] = int(out_notes_at_time.get(t, 0)) + 1
				var nmeta = d.get("meta", {})
				if nmeta is Dictionary and bool(nmeta.get("qualifier", false)):
					if not (t in out_qualifier_times):
						out_qualifier_times.append(t)
				# Sustain releases also count as separate judgement events at end_time
				if type_str == "SustainNote":
					var st_end = int(d.get("end_time", -1))
					if st_end > 0:
						out_notes_at_time[st_end] = int(out_notes_at_time.get(st_end, 0)) + 1
	
	for k in d.keys():
		_collect_qualifier_data_recursive(d[k], out_qualifier_times, out_notes_at_time)


# ─────────────────────────────────────────────
# Regular note counting (everything in zone EXCEPT qualifier-time notes)
# ─────────────────────────────────────────────

var _sustain_release_count := 0

func _count_regular_notes_in_zone(start_time: int, qualifier_time: int) -> int:
	# Counts judgement events from start_time (inclusive) up to but NOT including
	# qualifier_time. Notes at qualifier_time are tracked separately by the runtime
	# (they're the resolution gate, not part of the 75% threshold math).
	if _editor == null or _editor.current_song == null:
		return 0
	
	var chart_path = _editor.current_song.get_chart_path(_editor.current_difficulty)
	if not FileAccess.file_exists(chart_path):
		return 0
	
	var rf := FileAccess.open(chart_path, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(rf.get_as_text())
	rf.close()
	
	if parsed == null:
		return 0
	
	# Collect note start-times in [start_time, qualifier_time) — exclusive upper bound.
	# Sustain releases are counted individually (can't dedupe by time).
	var note_times := {}
	_sustain_release_count = 0
	_collect_regular_note_times_recursive(parsed, start_time, qualifier_time, note_times)
	var total = note_times.size() + _sustain_release_count
	print("[HBT HOOK] Regular notes: %d starts + %d sustain releases = %d judgements" % [
		note_times.size(), _sustain_release_count, total
	])
	return total


func _collect_regular_note_times_recursive(node: Variant, start_time: int, qualifier_time: int, note_times: Dictionary) -> void:
	# Same shape as tz-counter-simple's _collect_note_times_recursive, but with
	# an exclusive upper bound (qualifier_time) so the qualifier chord is excluded.
	if node is Array:
		for item in node:
			_collect_regular_note_times_recursive(item, start_time, qualifier_time, note_times)
	elif node is Dictionary:
		var d: Dictionary = node
		var note_time = d.get("time", -1)
		var node_name = d.get("name", "")
		
		# Slide handling
		if d.has("timing_points") and node_name is String and String(node_name).findn("SLIDE") != -1:
			var tp: Array = d.get("timing_points", [])
			for point in tp:
				if point is Dictionary:
					var point_time = int(point.get("time", -1))
					var note_type = int(point.get("note_type", -1))
					if (note_type == 4 or note_type == 5) and point_time >= start_time and point_time < qualifier_time:
						note_times[point_time] = true
			for k in d.keys():
				if k != "timing_points":
					_collect_regular_note_times_recursive(d[k], start_time, qualifier_time, note_times)
			return
		
		# Regular notes
		if d.has("type") and note_time >= start_time and note_time < qualifier_time:
			var type_str = str(d.get("type"))
			if type_str.findn("Note") != -1 and type_str != "Metadata":
				var nt = d.get("note_type", -1)
				if nt == 6 or nt == 7:
					pass  # Skip chain pieces
				else:
					note_times[note_time] = true
					if type_str == "SustainNote":
						var sustain_end = d.get("end_time", -1)
						# Sustain release counts only if it lands before the qualifier
						if sustain_end >= start_time and sustain_end < qualifier_time:
							_sustain_release_count += 1
		
		for k in d.keys():
			_collect_regular_note_times_recursive(d[k], start_time, qualifier_time, note_times)


# ─────────────────────────────────────────────
# Playtest root finder (mirrors tz-counter-simple)
# ─────────────────────────────────────────────

func _find_playtest_root() -> Node:
	if _editor == null:
		return null
	var tree = _editor.get_tree()
	if tree == null:
		return null
	
	var root = tree.root
	for child in root.get_children():
		if child.name == "Editor":
			for grandchild in child.get_children():
				if grandchild.name.findn("GamePreview") == -1:
					for ggchild in grandchild.get_children():
						if ggchild.name == "RhythmGame":
							return grandchild
	return null
