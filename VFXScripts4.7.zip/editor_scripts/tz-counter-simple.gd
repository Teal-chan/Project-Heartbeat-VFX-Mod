# user://editor_scripts/tz-counter-simple.gd
#meta:name:TZ Counter Simple Hook
#meta:description:Simplified ScriptRunner that injects the TZ Counter Node into the editor
#meta:usage:Injected into the playtest automatically when the 'Mount Metadata Hook' script is launched.
extends ScriptRunnerScript

var _ctx: Dictionary = {}
func set_context(ctx: Dictionary) -> void: _ctx = ctx

func run_script() -> int:
	var key = _ctx.get("key", "")
	
	if key == "TZ start":
		return _handle_tz_start()
	elif key == "TZ end":
		return _handle_tz_end()
	
	return OK

func _handle_tz_start() -> int:
	print("[TZ HOOK] TZ start")
	
	# Find playtest and game
	var playtest_root = _find_playtest_root()
	if playtest_root == null:
		print("[TZ HOOK] ERROR: No playtest root")
		return ERR_DOES_NOT_EXIST
	
	# Get the rhythm_game from the popup
	var actual_game = null
	
	if "rhythm_game" in playtest_root:
		actual_game = playtest_root.rhythm_game
		print("[TZ HOOK] Got rhythm_game via property: " + str(actual_game))
	elif playtest_root.has_method("get") and playtest_root.get("rhythm_game"):
		actual_game = playtest_root.get("rhythm_game")
		print("[TZ HOOK] Got rhythm_game via get(): " + str(actual_game))
	else:
		print("[TZ HOOK] Popup doesn't have rhythm_game, searching...")
		var queue = [playtest_root]
		while queue.size() > 0:
			var node = queue.pop_front()
			if node.has_signal("note_judged"):
				actual_game = node
				print("[TZ HOOK] Found via signal search: " + str(node.name) + " id=" + str(node.get_instance_id()))
				break
			for child in node.get_children():
				queue.append(child)
	
	if actual_game == null:
		print("[TZ HOOK] ERROR: Could not find rhythm_game")
		return ERR_DOES_NOT_EXIST
	
	print("[TZ HOOK] Using game: %s (id=%d)" % [actual_game.name, actual_game.get_instance_id()])
	
	# Find the zone that matches this trigger time
	var trigger_time = _ctx.get("time", -1)
	var all_zones = _find_all_tz_zones()
	var zone = null
	for z in all_zones:
		if z.start == trigger_time:
			zone = z
			break
	
	if zone == null:
		print("[TZ HOOK] ERROR: No TZ zone matching time %d" % trigger_time)
		return ERR_DOES_NOT_EXIST
	
	var start_time = zone.start
	var end_time = zone.end
	var penalty = zone.penalty
	
	# Count notes
	var total = _count_notes_in_zone(start_time, end_time)
	print("[TZ HOOK] Found %d notes in zone %d-%d, penalty=%.0f%%" % [total, start_time, end_time, penalty])
	
	# Load and create the counter node
	var counter_script = load("user://editor_scripts/tz-counter-node.gd")
	if counter_script == null:
		print("[TZ HOOK] ERROR: Could not load tz-counter-node.gd")
		return ERR_FILE_CANT_OPEN
	
	var counter_node = counter_script.new()
	counter_node.init_data(_editor, playtest_root, actual_game, start_time, end_time, total, penalty)
	
	# Add to the editor, NOT playtest root — if playtest root is freed,
	# the counter node must survive to run its cleanup in _process
	_editor.add_child(counter_node)
	print("[TZ HOOK] ✓ Counter node added to editor!")
	
	return OK

func _handle_tz_end() -> int:
	print("[TZ HOOK] ========== TZ end ==========")
	
	if _editor == null:
		print("[TZ HOOK] ERROR: No editor")
		return ERR_DOES_NOT_EXIST
	
	var trigger_time = _ctx.get("time", -1)
	
	# Find the counter node whose end time matches this trigger
	var counter_node = null
	for child in _editor.get_children():
		if child.name.begins_with("TZCounterNode") and child.get("tz_end_time") == trigger_time:
			counter_node = child
			print("[TZ HOOK] Found counter node for end time %d!" % trigger_time)
			break
	
	if counter_node and is_instance_valid(counter_node):
		print("[TZ HOOK] Calling on_tz_end on counter node...")
		counter_node.on_tz_end()
	else:
		print("[TZ HOOK] ERROR: No valid counter_node for end time %d!" % trigger_time)
	
	return OK

func _find_playtest_root() -> Node:
	if _editor == null:
		return null
	var tree = _editor.get_tree()
	if tree == null:
		return null
	
	var root = tree.root
	for child in root.get_children():
		if child.name == "Editor":
			for grandchild in child.get_children():
				if grandchild.name.findn("GamePreview") == -1:
					for ggchild in grandchild.get_children():
						if ggchild.name == "RhythmGame":
							return grandchild
	return null

func _find_all_tz_zones() -> Array:
	if _editor == null or _editor.current_song == null:
		return []
	
	var chart_path = _editor.current_song.get_chart_path(_editor.current_difficulty)
	if not FileAccess.file_exists(chart_path):
		return []
	
	var rf := FileAccess.open(chart_path, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(rf.get_as_text())
	rf.close()
	
	if parsed == null:
		return []
	
	# Collect all TZ markers in chronological order
	var markers: Array = []
	_collect_tz_markers_recursive(parsed, markers)
	markers.sort_custom(func(a, b): return a.time < b.time)
	
	# Pair them up: each start with the next end
	var zones: Array = []
	var pending_start = null
	for marker in markers:
		if marker.key == "TZ start":
			pending_start = marker
		elif marker.key == "TZ end" and pending_start != null:
			zones.append({
				"start": pending_start.time,
				"end": marker.time,
				"penalty": pending_start.penalty
			})
			pending_start = null
	
	return zones


func _collect_tz_markers_recursive(node: Variant, out_markers: Array) -> void:
	if node is Array:
		for item in node:
			_collect_tz_markers_recursive(item, out_markers)
	elif node is Dictionary:
		var d: Dictionary = node
		if d.get("type") == "Metadata":
			var meta_dict = d.get("meta", {})
			if meta_dict is Dictionary:
				var k = meta_dict.get("key", "")
				var t = d.get("time", -1)
				if k == "TZ start":
					out_markers.append({
						"key": "TZ start",
						"time": t,
						"penalty": clamp(float(meta_dict.get("value", 0.0)), 0.0, 30.0)
					})
				elif k == "TZ end":
					out_markers.append({"key": "TZ end", "time": t})
		for key in d.keys():
			_collect_tz_markers_recursive(d[key], out_markers)

func _count_notes_in_zone(start_time: int, end_time: int) -> int:
	if _editor == null or _editor.current_song == null:
		return 0
	
	var chart_path = _editor.current_song.get_chart_path(_editor.current_difficulty)
	if not FileAccess.file_exists(chart_path):
		return 0
	
	var rf := FileAccess.open(chart_path, FileAccess.READ)
	var parsed: Variant = JSON.parse_string(rf.get_as_text())
	rf.close()
	
	if parsed == null:
		return 0
	
	# Collect note judgments:
	# - Normal notes/chords: each unique start time = 1 judgment
	# - Sustain releases: each individual SustainNote end_time = 1 judgment
	var note_times := {}
	_sustain_release_count = 0
	_collect_note_times_recursive(parsed, start_time, end_time, note_times)
	var total = note_times.size() + _sustain_release_count
	print("[TZ HOOK] Note groups: %d starts + %d sustain releases = %d judgments" % [note_times.size(), _sustain_release_count, total])
	return total

# Sustain releases can't be deduplicated by time, so we count them individually
var _sustain_release_count := 0

func _collect_note_times_recursive(node: Variant, start_time: int, end_time: int, note_times: Dictionary) -> void:
	if node is Array:
		for item in node:
			_collect_note_times_recursive(item, start_time, end_time, note_times)
	elif node is Dictionary:
		var d: Dictionary = node
		var note_time = d.get("time", -1)
		
		# Slides have a "timing_points" array and a name like "SLIDE_LEFT"/"SLIDE_RIGHT"
		# Each timing point with note_type 4 or 5 is a slide head (fires judgement)
		# note_type 6 or 7 are slide chain pieces (no judgement)
		var node_name = d.get("name", "")
		if d.has("timing_points") and node_name is String and String(node_name).findn("SLIDE") != -1:
			var tp: Array = d.get("timing_points", [])
			for point in tp:
				if point is Dictionary:
					var point_time = point.get("time", -1)
					var note_type = point.get("note_type", -1)
					# Only count slide heads (4 = SLIDE_LEFT, 5 = SLIDE_RIGHT)
					# Skip chain pieces (6 = SLIDE_CHAIN_PIECE_LEFT, 7 = SLIDE_CHAIN_PIECE_RIGHT)
					if (note_type == 4 or note_type == 5) and point_time >= start_time and point_time <= end_time:
						note_times[point_time] = true
			# Don't recurse into timing_points — we've already processed them
			for k in d.keys():
				if k != "timing_points":
					_collect_note_times_recursive(d[k], start_time, end_time, note_times)
			return
		
		if d.has("type") and note_time >= start_time and note_time <= end_time:
			var type_str = str(d.get("type"))
			if type_str.findn("Note") != -1 and type_str != "Metadata":
				# Skip slide chain pieces (note_type 6 or 7) - they're already handled above
				var nt = d.get("note_type", -1)
				if nt == 6 or nt == 7:
					pass  # Skip chain pieces
				else:
					note_times[note_time] = true
					# Each sustain release is its own individual judgment
					if type_str == "SustainNote":
						var sustain_end = d.get("end_time", -1)
						if sustain_end >= start_time and sustain_end <= end_time:
							_sustain_release_count += 1
		
		for k in d.keys():
			_collect_note_times_recursive(d[k], start_time, end_time, note_times)
