# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Select Notes Between
#meta:description:Selects all notes whose time lies between the earliest and latest selected notes (inclusive), across all lanes.
#meta:usage:Select at least two notes, then run. The selection will be replaced by all notes between those times.

extends ScriptRunnerScript

func run_script() -> int:
	if _editor == null:
		printerr("[SelectNotesBetween] ❌ Editor not found.")
		return ERR_DOES_NOT_EXIST

	if _editor.selected.is_empty():
		printerr("[SelectNotesBetween] ❌ No items selected.")
		return ERR_DOES_NOT_EXIST

	# 1) Collect times of selected notes only
	var selected_note_times: Array[int] = []
	var any_notes := false

	for item in _editor.selected:
		var data := _safe_get(item, "data", null)
		if data != null and data is HBBaseNote:
			any_notes = true
			selected_note_times.append(int(data.time))

	if not any_notes or selected_note_times.size() < 2:
		printerr("[SelectNotesBetween] ❌ Need at least two notes selected.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Select at least two notes first.")
		return ERR_INVALID_DATA

	# 2) Determine range (inclusive)
	var t_min := selected_note_times[0]
	var t_max := selected_note_times[0]
	for t in selected_note_times:
		if t < t_min:
			t_min = t
		if t > t_max:
			t_max = t

	if t_min == t_max:
		# All selected notes are at the same time; just select all notes at that time.
		# (This is still useful for grabbing multis.)
		print("[SelectNotesBetween] All selected notes share the same time → selecting notes at t=%d" % t_min)
	else:
		print("[SelectNotesBetween] Selecting notes between %d and %d (inclusive)." % [t_min, t_max])

	# 3) Clear current selection
	if _editor.has_method("deselect_all"):
		_editor.deselect_all()
	else:
		for it in _editor.selected:
			if it.has_method("deselect"):
				it.deselect()
		_editor.selected.clear()

	# 4) Walk all timeline items, select notes in range
	var items: Array = []
	if _editor.has_method("get_timeline_items"):
		items = _editor.get_timeline_items()
	else:
		# Fallback: use current_notes if exposed
		if _editor.has_meta("current_notes"):
			items = _editor.get_meta("current_notes")
		else:
			printerr("[SelectNotesBetween] ❌ Editor does not expose timeline items.")
			return ERR_DOES_NOT_EXIST

	var count_selected := 0

	for item in items:
		var data := _safe_get(item, "data", null)
		if data == null:
			continue
		if not (data is HBBaseNote):
			continue

		var t := int(data.time)
		if t < t_min or t > t_max:
			continue

		if _editor.has_method("select_item"):
			_editor.select_item(item, true)
		else:
			# Very unlikely fallback, but just in case
			if item.has_method("select"):
				item.select()
			_editor.selected.append(item)

		count_selected += 1

	if _editor.message_shower:
		_editor.message_shower._show_notification("Selected %d notes between %d and %d" % [count_selected, t_min, t_max])

	print("[SelectNotesBetween] ✅ Selected %d notes in range." % count_selected)
	return OK

# ───────────────────────────────────────────────────────────────────────────────
# Small helper – same pattern as your other scripts
# ───────────────────────────────────────────────────────────────────────────────

func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback
