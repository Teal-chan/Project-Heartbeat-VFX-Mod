extends ScriptRunnerScript
#meta:name:Open VFX JSON Externally (Robust)
#meta:description:Opens the *_vfx.json sidecar for the current chart, even if the filename has invisible characters.
#meta:usage:Open a song in the editor, then run this script.

func run_script() -> int:
	if _editor == null:
		push_error("Open VFX JSON: _editor is null.")
		return OK

	if _editor.current_song == null:
		push_error("Open VFX JSON: no song loaded.")
		return OK

	var difficulty: String = _editor.current_difficulty
	var chart_path: String = _editor.current_song.get_chart_path(difficulty)
	print("Open VFX JSON: chart_path (virtual) = ", chart_path)

	# Desired filename: e.g. "loli_vfx.json"
	var base_name: String = chart_path.get_basename().get_file()  # "loli"
	var target_name: String = base_name + "_vfx.json"
	print("Open VFX JSON: target logical filename = ", target_name)

	# Directory (filesystem path) we expect the file in
	var dir_virtual: String = chart_path.get_base_dir()           # "user://editor_songs/..."
	var dir_fs: String = ProjectSettings.globalize_path(dir_virtual)
	print("Open VFX JSON: directory (fs) = ", dir_fs)

	var d: DirAccess = DirAccess.open(dir_fs)
	if d == null:
		var derr: int = DirAccess.get_open_error()
		push_error("Open VFX JSON: could not open directory, error " + str(derr))
		return OK

	var target_sanitized: String = _sanitize_filename(target_name)
	var real_fname: String = ""
	print("Open VFX JSON: scanning directory for sanitized match...")

	d.list_dir_begin()
	while true:
		var fname: String = d.get_next()
		if fname == "":
			break
		if d.current_is_dir():
			continue

		var sanitized: String = _sanitize_filename(fname)
		print("  found: '", fname, "'  -> sanitized: '", sanitized, "'")

		if sanitized == target_sanitized:
			real_fname = fname
			break
	d.list_dir_end()

	if real_fname == "":
		print("No VFX File Found.")
		return OK

	var fs_path: String = dir_fs.path_join(real_fname)
	print("Open VFX JSON: opening actual file: ", fs_path)

	var result: int = OS.shell_open(fs_path)
	if result != OK:
		push_error("Open VFX JSON: OS.shell_open failed with code " + str(result))
	else:
		print("Open VFX JSON: opened in external editor.")
	return OK


func _sanitize_filename(name: String) -> String:
	# Keep only basic ASCII letters/digits/._- so we ignore zero-width and other weird chars.
	var result := ""
	for i in name.length():
		var code: int = name.unicode_at(i)
		var is_digit := code >= 48 and code <= 57      # 0-9
		var is_upper := code >= 65 and code <= 90      # A-Z
		var is_lower := code >= 97 and code <= 122     # a-z
		var is_punct := code == 46 or code == 95 or code == 45  # . _ -

		if is_digit or is_upper or is_lower or is_punct:
			result += String.chr(code)
	return result
