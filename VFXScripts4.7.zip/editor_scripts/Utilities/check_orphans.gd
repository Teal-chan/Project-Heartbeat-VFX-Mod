extends ScriptRunnerScript

#meta:name:Check Orphaned VFX
#meta:description:Compares current timeline notes vs PH VFX events and reports orphaned VFX.
#meta:usage:Run in the chart editor while PH_VFX_MegaInjector is active.

const LOG_NAME := "VFXOrphanCheck"

func run_script() -> int:
	if _editor == null:
		push_error("[%s] No editor context." % LOG_NAME)
		return ERR_DOES_NOT_EXIST

	# --- find injector -------------------------------------------------
	var mgr: Node = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr == null:
		mgr = _editor.find_child("PH_VFX_MegaInjector", true, false)

	if mgr == null:
		_show_report_popup("❌ PH_VFX_MegaInjector not found.\nInject VFX first, then re-run this script.")
		return ERR_DOES_NOT_EXIST

	# Make sure the injector/anim_bank is up to date
	if mgr.has_method("reload_now"):
		mgr.call("reload_now")

	# --- collect note keys from the current timeline -------------------
	var note_keys: Dictionary = _collect_note_keys(mgr)
	if note_keys.is_empty():
		_show_report_popup("[%s]\nNo note keys found on the timeline.\nLoad a chart in the editor first." % LOG_NAME)
		return OK

	# --- collect VFX keys from the injector's anim_bank ----------------
	var anim_bank = null
	if mgr.has_method("get"):
		anim_bank = mgr.get("anim_bank")
	if anim_bank == null:
		_show_report_popup("[%s]\nInjector anim_bank is missing; can't inspect VFX." % LOG_NAME)
		return ERR_DOES_NOT_EXIST

	var vfx_keys: Dictionary = _collect_vfx_keys_from_anim_bank(anim_bank)

	# --- Mirai link rows (optional orphan check) -----------------------
	var mirai_rows: Array = []
	if mgr.has_method("get"):
		var raw_m = mgr.get("_mirai_rows")
		if typeof(raw_m) == TYPE_ARRAY:
			mirai_rows = raw_m

	if vfx_keys.is_empty() and mirai_rows.is_empty():
		_show_report_popup("[%s]\nNo VFX events found for this chart." % LOG_NAME)
		return OK

	# --- diff: VFX keys that have no matching note key -----------------
	var orphan_keys: Array = []
	for k in vfx_keys.keys():
		var key_str := String(k)
		if not note_keys.has(key_str):
			orphan_keys.append(key_str)

	# Mirai link orphans (head or tail key missing)
	var orphan_mirai: Array = []
	for row in mirai_rows:
		if typeof(row) != TYPE_DICTIONARY:
			continue
		var hk := String(row.get("head_key", ""))
		var tk := String(row.get("tail_key", ""))
		var head_missing := (hk != "" and not note_keys.has(hk))
		var tail_missing := (tk != "" and not note_keys.has(tk))
		if head_missing or tail_missing:
			orphan_mirai.append(row)

	# --- build report text ---------------------------------------------
	var lines: Array = []

	var song_name := "(unknown song)"
	if "current_song" in _editor and _editor.current_song != null:
		var cs = _editor.current_song
		if "title" in cs:
			song_name = str(cs.title)
		elif "song_id" in cs:
			song_name = str(cs.song_id)

	lines.append("[%s] =====================================================" % LOG_NAME)
	lines.append("[%s]  Chart: %s" % [LOG_NAME, song_name])
	lines.append("[%s] -----------------------------------------------------" % LOG_NAME)
	lines.append("[%s]  Note keys on timeline: %d" % [LOG_NAME, note_keys.size()])
	lines.append("[%s]  Note keys with any VFX: %d" % [LOG_NAME, vfx_keys.size()])

	if orphan_keys.is_empty() and orphan_mirai.is_empty():
		lines.append("[%s] -----------------------------------------------------" % LOG_NAME)
		lines.append("[%s]  ✔ No orphaned VFX keys found." % LOG_NAME)
	else:
		lines.append("[%s] -----------------------------------------------------" % LOG_NAME)
		lines.append("[%s]  ⚠ Orphaned note VFX keys: %d" % [LOG_NAME, orphan_keys.size()])

		if not orphan_keys.is_empty():
			orphan_keys.sort() # nice stable order
			var max_list := 20
			var count := min(orphan_keys.size(), max_list)
			lines.append("[%s]  Listing up to %d:" % [LOG_NAME, count])
			for i in range(count):
				var key_str: String = orphan_keys[i]
				var info: Dictionary = _parse_key(key_str)
				var t_ms := int(info.get("time", -1))
				var nt  := int(info.get("note_type", -1))
				var layer := String(info.get("layer", ""))
				lines.append("[%s]   #%d  time=%6d  note_type=%d  layer=%s  key=%s" %
					[LOG_NAME, i + 1, t_ms, nt, layer, key_str])

			if orphan_keys.size() > count:
				lines.append("[%s]   ...(+%d more orphan keys not shown)" %
					[LOG_NAME, orphan_keys.size() - count])

		if not orphan_mirai.is_empty():
			lines.append("[%s] -----------------------------------------------------" % LOG_NAME)
			lines.append("[%s]  ⚠ Orphaned Mirai links: %d" %
				[LOG_NAME, orphan_mirai.size()])
			var max_list2 := 10
			var count2 := min(orphan_mirai.size(), max_list2)
			for i2 in range(count2):
				var row2: Dictionary = orphan_mirai[i2]
				var hk2 := String(row2.get("head_key", ""))
				var tk2 := String(row2.get("tail_key", ""))
				var t2  := int(row2.get("time", -1))
				lines.append("[%s]   #%d  time=%6d  head_key=%s  tail_key=%s" %
					[LOG_NAME, i2 + 1, t2, hk2, tk2])
			if orphan_mirai.size() > count2:
				lines.append("[%s]   ...(+%d more Mirai link rows not shown)" %
					[LOG_NAME, orphan_mirai.size() - count2])

	lines.append("[%s] =====================================================" % LOG_NAME)

	# Console log (nice for copy/paste)
	for l in lines:
		print(l)

	# Popup in editor
	_show_report_popup("\n".join(lines))

	return OK


# =====================================================================
# helpers
# =====================================================================

func _collect_note_keys(mgr: Node) -> Dictionary:
	var result := {}

	if _editor == null or not _editor.has_method("get_timeline_items"):
		return result

	var items: Array = _editor.get_timeline_items()
	var has_key_helper := mgr != null and mgr.has_method("_key_for_note_data")

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var note_obj = item.data
		if note_obj == null:
			continue

		var key := ""
		if has_key_helper:
			var k_val = mgr.call("_key_for_note_data", note_obj)
			if typeof(k_val) == TYPE_STRING:
				key = k_val
		else:
			key = _build_vfx_key_for_note_data(note_obj)

		if key == "":
			continue

		result[key] = true

	return result


func _collect_vfx_keys_from_anim_bank(anim_bank: Object) -> Dictionary:
	var result := {}
	if anim_bank == null:
		return result
	if not anim_bank.has_method("get"):
		return result

	# Mirrors PHVFXMegaInjector._rebuild_keys_with_vfx
	var ev_keys_var = anim_bank.get("_events_keys")
	if typeof(ev_keys_var) != TYPE_ARRAY:
		return result

	for ks in ev_keys_var:
		if typeof(ks) != TYPE_ARRAY:
			continue
		for k in ks:
			var key := String(k)
			if key != "":
				result[key] = true

	return result


# key format: "layer_UP@0@28041"
func _parse_key(key: String) -> Dictionary:
	var info := {}
	var parts: Array = key.split("@", false, 3)
	if parts.size() != 3:
		return info

	info["layer"] = String(parts[0])
	info["note_type"] = int(parts[1])
	info["time"] = int(parts[2])
	return info


# Fallback used when the injector doesn't expose _key_for_note_data
# (this matches the helper you already use in VFX Summary)
func _build_vfx_key_for_note_data(nd: Object) -> String:
	if nd == null or not nd.has_method("get"):
		return ""

	var nt_v = nd.get("note_type")
	var time_v = nd.get("time")
	if nt_v == null or time_v == null:
		return ""

	var nti := int(nt_v)
	var head_t := int(time_v)

	var lname := "UNKNOWN"
	match nti:
		0: lname = "UP"
		1: lname = "LEFT"
		2: lname = "DOWN"
		3: lname = "RIGHT"
		4, 6: lname = "SLIDE_LEFT"
		5, 7: lname = "SLIDE_RIGHT"
		8: lname = "HEART"

	var is_l2 := _guess_is_layer2_from_note(nd)
	var layer_tag := "layer_%s%s" % [lname, ("2" if is_l2 else "")]
	return "%s@%d@%d" % [layer_tag, nti, head_t]


func _guess_is_layer2_from_note(obj: Object) -> bool:
	if obj == null:
		return false

	# layer_index == 1
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if String(p.name) == "layer_index":
				var lidx = obj.get("layer_index")
				if int(lidx) == 1:
					return true
				break

	# second_layer flag
	if obj.has_method("get_property_list"):
		for p2 in obj.get_property_list():
			if String(p2.name) == "second_layer":
				if bool(obj.get("second_layer")):
					return true
				break

	# layer string ending with "2"
	if obj.has_method("get_property_list"):
		for p3 in obj.get_property_list():
			if String(p3.name) == "layer":
				var layer_meta = obj.get("layer")
				if String(layer_meta).ends_with("2"):
					return true
				break

	return false


func _show_report_popup(text: String) -> void:
	if _editor == null:
		print(text)
		return

	var tree = _editor.get_tree()
	var ui_root: Node = tree.root if tree != null else _editor

	var existing := ui_root.get_node_or_null("PH_VFXOrphanDialog")
	if existing != null and is_instance_valid(existing):
		existing.queue_free()

	var dlg := AcceptDialog.new()
	dlg.name = "PH_VFXOrphanDialog"
	dlg.title = "Orphaned VFX Check"
	dlg.min_size = Vector2(720, 480)

	var text_edit := TextEdit.new()
	text_edit.readonly = true
	text_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	text_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_edit.text = text
	text_edit.set_anchors_preset(Control.PRESET_FULL_RECT)

	dlg.add_child(text_edit)
	ui_root.add_child(dlg)

	dlg.confirmed.connect(dlg.queue_free)
	dlg.canceled.connect(dlg.queue_free)

	dlg.popup_centered_ratio(0.7)
