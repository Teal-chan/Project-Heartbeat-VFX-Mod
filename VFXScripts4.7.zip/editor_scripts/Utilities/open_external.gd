extends ScriptRunnerScript
#meta:name:Open Chart JSON Externally
#meta:description:Opens the current chart JSON file in the OS default text editor/viewer.
#meta:usage:Open a song in the editor, then run this script.

func run_script() -> int:
	if _editor == null:
		push_error("Open Chart JSON: _editor is null.")
		return OK

	if _editor.current_song == null:
		push_error("Open Chart JSON: no song loaded.")
		return OK

	var difficulty: String = _editor.current_difficulty
	var chart_path: String = _editor.current_song.get_chart_path(difficulty)
	print("Open Chart JSON: chart_path = ", chart_path)

	# Make sure the chart actually exists
	if not FileAccess.file_exists(chart_path):
		push_error("Open Chart JSON: file does not exist on disk: " + chart_path)
		return OK

	# Convert res:// / user:// to an absolute filesystem path
	var fs_path: String = ProjectSettings.globalize_path(chart_path)
	print("Open Chart JSON: filesystem path = ", fs_path)

	# Build a file:// URI for OS.shell_open (usually optional, but safer)
	var uri: String = fs_path
	if not uri.begins_with("file://"):
		uri = "file://" + uri

	# You can call OS.shell_open directly…
	var result: int = OS.shell_open(uri)
	# …or reuse the editor helper:
	# var result: int = OS.shell_open(fs_path)  # often works fine on desktop

	if result != OK:
		push_error("Open Chart JSON: OS.shell_open failed with code " + str(result))
	else:
		print("Open Chart JSON: opened in external editor: ", uri)

	return OK
