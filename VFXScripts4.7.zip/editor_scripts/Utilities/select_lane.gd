# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Select All Notes In Lane
#meta:description:Lets you choose a lane (Up/Down/Slides/etc.) and selects all matching notes across the chart, without spawning screen widgets.
#meta:usage:Run the script, pick a lane from the dropdown, and confirm. Current selection is replaced by all notes in that lane.

extends ScriptRunnerScript

const LANE_DEFS = [
	{
		"label": "Up",
		"types": [HBBaseNote.NOTE_TYPE.UP],
	},
	{
		"label": "Left",
		"types": [HBBaseNote.NOTE_TYPE.LEFT],
	},
	{
		"label": "Down",
		"types": [HBBaseNote.NOTE_TYPE.DOWN],
	},
	{
		"label": "Right",
		"types": [HBBaseNote.NOTE_TYPE.RIGHT],
	},
	{
		"label": "Slide Left (Layer 1)",
		"types": [
			HBBaseNote.NOTE_TYPE.SLIDE_LEFT,
			HBBaseNote.NOTE_TYPE.SLIDE_CHAIN_PIECE_LEFT
		],
		"second_layer": false,
	},
	{
		"label": "Slide Left (Layer 2)",
		"types": [
			HBBaseNote.NOTE_TYPE.SLIDE_LEFT,
			HBBaseNote.NOTE_TYPE.SLIDE_CHAIN_PIECE_LEFT
		],
		"second_layer": true,
	},
	{
		"label": "Slide Right (Layer 1)",
		"types": [
			HBBaseNote.NOTE_TYPE.SLIDE_RIGHT,
			HBBaseNote.NOTE_TYPE.SLIDE_CHAIN_PIECE_RIGHT
		],
		"second_layer": false,
	},
	{
		"label": "Slide Right (Layer 2)",
		"types": [
			HBBaseNote.NOTE_TYPE.SLIDE_RIGHT,
			HBBaseNote.NOTE_TYPE.SLIDE_CHAIN_PIECE_RIGHT
		],
		"second_layer": true,
	},
	{
		"label": "Heart",
		"types": [HBBaseNote.NOTE_TYPE.HEART],
	},
]

func run_script() -> int:
	if _editor == null:
		printerr("[SelectAllInLane] ❌ Editor not found.")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		printerr("[SelectAllInLane] ❌ Editor does not expose get_timeline_items().")
		return ERR_DOES_NOT_EXIST

	# Popup UI
	var popup = ConfirmationDialog.new()
	popup.title = "Select All Notes In Lane"
	popup.min_size = Vector2(420, 180)

	var vbox = VBoxContainer.new()
	popup.add_child(vbox)

	var label = Label.new()
	label.text = "Choose a lane:"
	vbox.add_child(label)

	var lane_dropdown = OptionButton.new()
	for i in range(LANE_DEFS.size()):
		var lane_def = LANE_DEFS[i]
		lane_dropdown.add_item(String(lane_def["label"]), i)
	vbox.add_child(lane_dropdown)

	var hint = Label.new()
	hint.text = "This replaces your current selection with all notes in the chosen lane."
	hint.add_theme_color_override("font_color", Color(0.9, 0.9, 1.0))
	vbox.add_child(hint)

	popup.get_ok_button().text = "Select lane notes"
	_editor.add_child(popup)
	popup.popup_centered()

	popup.confirmed.connect(func():
		var idx = lane_dropdown.get_selected_id()
		if idx < 0 or idx >= LANE_DEFS.size():
			printerr("[SelectAllInLane] ❌ Invalid lane index.")
			popup.queue_free()
			return

		var lane_def = LANE_DEFS[idx]
		var lane_label = String(lane_def["label"])
		var lane_types = lane_def["types"]

		var has_second_layer_filter = lane_def.has("second_layer")
		var second_layer_filter = false
		if has_second_layer_filter:
			second_layer_filter = bool(lane_def["second_layer"])

		var items = _editor.get_timeline_items()
		var new_selection: Array = []

		# Find matching note items
		for item in items:
			var data = _safe_get(item, "data", null)
			if data == null:
				continue
			if not (data is HBBaseNote):
				continue

			var nt = int(data.note_type)
			if not lane_types.has(nt):
				continue

			if has_second_layer_filter:
				var is_second_layer = false
				if data.has_meta("second_layer"):
					is_second_layer = bool(data.get_meta("second_layer"))
				if is_second_layer != second_layer_filter:
					continue

			new_selection.append(item)

		# Apply selection on timeline items only (no widgets)
		_apply_selection(new_selection)

		if _editor.message_shower:
			_editor.message_shower._show_notification(
				"Selected %d note(s) in lane: %s" % [new_selection.size(), lane_label]
			)
		print("[SelectAllInLane] ✅ Selected %d note(s) in lane '%s'." % [new_selection.size(), lane_label])
		popup.queue_free()
	)

	return OK

# ───────────────────────────────────────────────────────────────────────────────
# Selection helper – mirrors editor's select_all style (no widget spawning)
# ───────────────────────────────────────────────────────────────────────────────

func _apply_selection(items: Array) -> void:
	# Deselect previous
	for it in _editor.selected:
		if it != null and it.has_method("deselect"):
			it.deselect()
	_editor.selected = []

	# Select new ones (timeline items only)
	for item in items:
		if item != null and item.has_method("select"):
			item.select()
		_editor.selected.append(item)

	# Keep inspector and modules in sync like the editor does
	if _editor.has_node("VBoxContainer/VSplitContainer/HSplitContainer/HSplitContainer/Control2/TabContainer/Inspector"):
		# We already know _editor.inspector exists from your code, but keep it defensive
		var insp = _editor.inspector
		if insp:
			insp.inspect(_editor.selected)

	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()

# ───────────────────────────────────────────────────────────────────────────────
# Tiny helper
# ───────────────────────────────────────────────────────────────────────────────

func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback
