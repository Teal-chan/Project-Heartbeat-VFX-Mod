# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Select All Chord Notes
#meta:description:Selects all notes that share their time with at least one other note (chords) across the entire chart.
#meta:usage:Run to select all chord notes in the chart.

func run_script() -> int:
	if _editor == null:
		printerr("[SelectAllChordNotes] ❌ No editor reference (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	if not _editor.has_method("get_timeline_items"):
		printerr("[SelectAllChordNotes] ❌ Editor has no get_timeline_items().")
		return ERR_UNAVAILABLE
	
	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		print("[SelectAllChordNotes] ℹ️ No timeline items found.")
		return OK
	
	# Group *timeline note items* by their note data time (ms)
	var time_to_items := {}  # int -> Array[EditorTimelineItemNote]
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue
		
		var data = null
		if item.has_method("get"):
			data = item.get("data")
		if data == null:
			continue
		
		# Make sure the data actually has a time property
		var props: Array[String] = []
		if data.has_method("get_property_list"):
			for p in data.get_property_list():
				props.append(String(p.name))
		if not ("time" in props):
			continue
		
		var t := int(data.get("time"))
		
		if not time_to_items.has(t):
			time_to_items[t] = []
		time_to_items[t].append(item)
	
	# Collect all items that belong to a chord (>= 2 notes at the same time)
	var chord_items: Array = []
	for t in time_to_items.keys():
		var at_time: Array = time_to_items[t]
		if at_time.size() >= 2:
			for it in at_time:
				chord_items.append(it)
	
	if chord_items.is_empty():
		print("[SelectAllChordNotes] ℹ️ No chords found in this chart.")
		return OK
	
	# Update editor selection with the *timeline items* so modules can see them
	if _editor.has_method("clear_selection"):
		_editor.clear_selection()
	else:
		_editor.selected = []
	
	_editor.selected = chord_items
	
	# Mark the items as selected so the UI reflects it
	for it in chord_items:
		_set_item_selected(it, true)
	
	# Let the editor know selection changed (if it has such a hook)
	if _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()
	
	print("[SelectAllChordNotes] ✅ Selected %d chord note(s)." % chord_items.size())
	return OK


func _set_item_selected(item: Object, sel: bool) -> void:
	if item == null or not is_instance_valid(item):
		return
	
	var has_selected_prop := false
	if item.has_method("get_property_list"):
		for p in item.get_property_list():
			if String(p.name) == "selected":
				has_selected_prop = true
				break
	
	if has_selected_prop:
		item.set("selected", sel)
	elif item.has_method("set_selected"):
		item.call("set_selected", sel)
	elif sel and item.has_method("select"):
		item.call("select")
	elif (not sel) and item.has_method("deselect"):
		item.call("deselect")
