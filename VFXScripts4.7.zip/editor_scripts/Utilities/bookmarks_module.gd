extends HBEditorModule

var bookmarks: Array = []          # [{ "time_ms": int, "label": String, "color": String }]
var current_index: int = -1

var idx_spin: SpinBox
var desc_edit: LineEdit
var info_label: Label
var btn_prev: Button
var btn_next: Button
var btn_add: Button
var btn_clear_current: Button
var btn_clear_all: Button
var _timeline_markers_root: Control = null

const DEFAULT_BOOKMARK_COLOR := Color(1.0, 0.85, 0.1, 0.95)

var bookmark_color: Color = DEFAULT_BOOKMARK_COLOR
var _color_button: Button

const TIME_LABEL = preload("res://fonts/Roboto-Black.ttf")


func _ready() -> void:
	custom_minimum_size = Vector2(0, 160)

	var root := VBoxContainer.new()
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(root)

	# Row 1: index spinner
	var row1 := HBoxContainer.new()
	root.add_child(row1)

	var lbl_idx := Label.new()
	lbl_idx.text = "Index"
	row1.add_child(lbl_idx)

	idx_spin = SpinBox.new()
	idx_spin.min_value = 1
	idx_spin.max_value = 1
	idx_spin.step = 1
	idx_spin.value = 1
	idx_spin.editable = false
	idx_spin.custom_minimum_size = Vector2(70, 0)
	idx_spin.value_changed.connect(_on_index_spin_changed)
	row1.add_child(idx_spin)

	# Row 2: description input
	var row2 := HBoxContainer.new()
	root.add_child(row2)

	var lbl_desc := Label.new()
	lbl_desc.text = "Note"
	row2.add_child(lbl_desc)

	desc_edit = LineEdit.new()
	desc_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row2.add_child(desc_edit)

	# Row 3: Add / Clear buttons
	var row3 := HBoxContainer.new()
	root.add_child(row3)

	btn_add = Button.new()
	btn_add.text = "Add / Update at Playhead"
	btn_add.pressed.connect(_on_add_update_pressed)
	row3.add_child(btn_add)

	btn_clear_current = Button.new()
	btn_clear_current.text = "Clear Current"
	btn_clear_current.pressed.connect(_on_clear_current_pressed)
	row3.add_child(btn_clear_current)

	btn_clear_all = Button.new()
	btn_clear_all.text = "Clear All"
	btn_clear_all.pressed.connect(_on_clear_all_pressed)
	row3.add_child(btn_clear_all)

	# Row 4: Bookmark color
	var row_color := HBoxContainer.new()
	root.add_child(row_color)

	var lbl_color := Label.new()
	lbl_color.text = "Color"
	row_color.add_child(lbl_color)

	# Prefer HBEditorColorPickerButton if it exists in the project, otherwise fall back
	if ClassDB.class_exists("HBEditorColorPickerButton"):
		_color_button = HBEditorColorPickerButton.new()
	else:
		_color_button = ColorPickerButton.new()

	_color_button.custom_minimum_size = Vector2(80, 0)

	# If the button exposes a `color` property, initialize it
	if "color" in _color_button:
		_color_button.color = bookmark_color

	# Hook up color change signal if available
	if _color_button.has_signal("color_changed"):
		_color_button.color_changed.connect(_on_bookmark_color_changed)

	row_color.add_child(_color_button)

	# Row 5: Prev / Next
	var row4 := HBoxContainer.new()
	root.add_child(row4)

	btn_prev = Button.new()
	btn_prev.text = "< Prev"
	btn_prev.pressed.connect(_on_prev_pressed)
	row4.add_child(btn_prev)

	btn_next = Button.new()
	btn_next.text = "Next >"
	btn_next.pressed.connect(_on_next_pressed)
	row4.add_child(btn_next)

	# Row 6: info label (read-only)
	info_label = Label.new()
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_label.text = "No bookmarks yet."
	root.add_child(info_label)

	# At this point we *don't* know the editor yet, so no load here.
	_refresh_ui()


# Called by the installer; attach editor and then load chart-specific bookmarks.
func set_editor(p_editor) -> void:
	super.set_editor(p_editor)

	_load_bookmarks()

	var tl := _get_timeline_node()
	if tl != null:
		var cb := Callable(self, "_on_timeline_view_changed")

		if not tl.is_connected("position_offset_changed", cb):
			tl.position_offset_changed.connect(cb)

		if not tl.is_connected("time_cull_changed", cb):
			tl.time_cull_changed.connect(cb)

	_refresh_ui()
	_refresh_timeline_markers()


func _on_timeline_view_changed(_a = null, _b = null) -> void:
	_refresh_timeline_markers()


# ---------- path helpers ----------

func _get_song_json_path() -> String:
	if editor == null:
		return ""

	# 1) Explicit helper if the editor exposes it
	if editor.has_method("get_current_song_path"):
		var p = editor.call("get_current_song_path")
		if typeof(p) == TYPE_STRING and p != "":
			return p

	# 2) Common properties
	if "current_song_path" in editor:
		var p2 = editor.get("current_song_path")
		if typeof(p2) == TYPE_STRING and p2 != "":
			return p2

	if "current_song" in editor and editor.current_song != null:
		var cs = editor.current_song
		if cs is Resource and cs.resource_path != "":
			return cs.resource_path
		if cs.has_method("get_path"):
			var cp = cs.call("get_path")
			if typeof(cp) == TYPE_STRING and cp != "":
				return cp

	return ""


func _get_bookmarks_path() -> String:
	var ed := editor
	if ed != null:
		# 1) Prefer PH_VFX_MegaInjector json_path
		var inj := ed.get_node_or_null("PH_VFX_MegaInjector")
		if inj == null:
			inj = ed.find_child("PH_VFX_MegaInjector", true, false)

		if inj != null and inj.has_method("get"):
			var raw = inj.get("json_path")
			if typeof(raw) == TYPE_STRING and raw != "":
				var p: String = raw

				# Example: user://editor_songs/eidetic_image/hard_vfx.json
				# → user://editor_songs/eidetic_image/hard_bookmarks.json

				if p.ends_with(".json"):
					p = p.substr(0, p.length() - 5)
				if p.ends_with("_vfx"):
					p = p.substr(0, p.length() - 4)

				return p + "_bookmarks.json"

	# 2) Global fallback if injector is missing for some reason
	return "user://editor_scripts/bookmarks_default.json"


# ---------- load / save ----------

func _load_bookmarks() -> void:
	bookmarks.clear()
	current_index = -1

	var path := _get_bookmarks_path()

	if not FileAccess.file_exists(path):
		print("[Bookmarks] No bookmark file at %s (starting empty)." % path)
		_refresh_ui()
		return

	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("[Bookmarks] Failed to open %s for reading." % path)
		_refresh_ui()
		return

	var txt := f.get_as_text()
	f.close()

	var parsed = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_ARRAY:
		push_error("[Bookmarks] Invalid JSON in %s (expected Array)." % path)
		_refresh_ui()
		return

	bookmarks = parsed

	# Backwards compatibility: ensure each bookmark has a color
	for i in range(bookmarks.size()):
		var bm = bookmarks[i]
		if not bm.has("color") or typeof(bm.get("color")) != TYPE_STRING:
			bm["color"] = DEFAULT_BOOKMARK_COLOR.to_html()
		bookmarks[i] = bm

	bookmarks.sort_custom(func(a, b):
		return int(a.get("time_ms", 0)) < int(b.get("time_ms", 0))
	)

	if bookmarks.size() > 0:
		current_index = 0
		# Sync picker color with first bookmark
		var first_bm = bookmarks[0]
		var col_str: String = first_bm.get("color", DEFAULT_BOOKMARK_COLOR.to_html())
		bookmark_color = Color(col_str)
		if _color_button and "color" in _color_button:
			_color_button.color = bookmark_color

	print("[Bookmarks] Loaded %d bookmark(s) from %s" % [bookmarks.size(), path])
	_refresh_ui()
	_refresh_timeline_markers()


func _save_bookmarks() -> void:
	var path := _get_bookmarks_path()

	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		push_error("[Bookmarks] Failed to open %s for writing." % path)
		return

	var txt := JSON.stringify(bookmarks, "\t")
	f.store_string(txt)
	f.close()

	print("[Bookmarks] Saved %d bookmark(s) to %s"
		% [bookmarks.size(), path])


# ---------- UI callbacks ----------

func _on_index_spin_changed(value: float) -> void:
	if bookmarks.is_empty():
		return

	var idx := int(value) - 1
	idx = clamp(idx, 0, bookmarks.size() - 1)
	current_index = idx
	_jump_to_current()


func _on_add_update_pressed() -> void:
	if editor == null:
		return

	var t_ms := _get_playhead_ms()
	var label := desc_edit.text.strip_edges()

	# See if we already have a bookmark at (or very near) this time.
	var existing_idx := _find_bookmark_by_time(t_ms, 5)  # 5 ms tolerance

	var color_str: String

	if existing_idx >= 0:
		# Keep existing color when updating an existing bookmark
		color_str = String(bookmarks[existing_idx].get("color", DEFAULT_BOOKMARK_COLOR.to_html()))
	else:
		# New bookmark: start with the current picker color (or DEFAULT if you prefer)
		color_str = bookmark_color.to_html()
		# If you want always-default instead, use:
		# color_str = DEFAULT_BOOKMARK_COLOR.to_html()

	var bm := {
		"time_ms": t_ms,
		"label": label,
		"color": color_str,
	}

	if existing_idx >= 0:
		bookmarks[existing_idx] = bm
		current_index = existing_idx
	else:
		bookmarks.append(bm)
		bookmarks.sort_custom(_sort_bookmarks_by_time)
		current_index = _find_bookmark_index(t_ms, label)

	_save_bookmarks()
	_refresh_ui()
	_refresh_timeline_markers()



func _on_clear_current_pressed() -> void:
	if current_index < 0 or current_index >= bookmarks.size():
		return

	bookmarks.remove_at(current_index)

	if bookmarks.is_empty():
		current_index = -1
	else:
		current_index = clamp(current_index, 0, bookmarks.size() - 1)

	_save_bookmarks()
	_refresh_ui()
	_refresh_timeline_markers()


func _on_clear_all_pressed() -> void:
	bookmarks.clear()
	current_index = -1
	_save_bookmarks()
	_refresh_ui()
	_refresh_timeline_markers()


func _on_prev_pressed() -> void:
	if bookmarks.is_empty():
		return

	if current_index < 0:
		current_index = 0
	else:
		current_index = (current_index - 1 + bookmarks.size()) % bookmarks.size()

	_jump_to_current()


func _on_next_pressed() -> void:
	if bookmarks.is_empty():
		return

	if current_index < 0:
		current_index = 0
	else:
		current_index = (current_index + 1) % bookmarks.size()

	_jump_to_current()


# ---------- helpers ----------

func _get_timeline_node() -> Control:
	if editor == null:
		return null

	# 1) Direct property on the editor
	if "timeline" in editor:
		var tl_prop = editor.timeline
		if tl_prop is Control:
			return tl_prop as Control
		if tl_prop is Node:
			# Try to find a Control child that *looks* like a timeline
			var cand := _find_timeline_control_in(tl_prop)
			if cand != null:
				return cand

	# 2) Child called "Timeline" somewhere under the editor
	var n := editor.find_child("Timeline", true, false)
	if n is Control:
		return n as Control

	# 3) Last resort: first sizeable Control under the editor
	for c in editor.get_children():
		if c is Control:
			var ctrl := c as Control
			if ctrl.size.x > 0.0 and ctrl.size.y > 0.0:
				print("[Bookmarks] Using generic Control as timeline:", ctrl)
				return ctrl

	print("[Bookmarks] WARNING: Timeline node not found; no visual markers will be drawn.")
	return null


func _find_timeline_control_in(root: Node) -> Control:
	# Helper used by _get_timeline_node to scan for a likely candidate.
	var name_fragments := ["timeline", "track", "grid"]
	var lower_name := String(root.name).to_lower()

	if root is Control:
		for frag in name_fragments:
			if lower_name.find(frag) != -1:
				return root as Control

	for child in root.get_children():
		if child is Node:
			var found := _find_timeline_control_in(child)
			if found != null:
				return found

	return null


func _ensure_markers_root() -> Control:
	var tl := _get_timeline_node()
	if tl == null:
		return null

	# Re-use if we already made one and it's still valid
	if _timeline_markers_root != null and _timeline_markers_root.is_inside_tree():
		return _timeline_markers_root

	var root := Control.new()
	root.name = "BookmarkMarkers"
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE

	# Cover entire timeline; we’ll use the timeline’s children
	# to decide where to draw inside it.
	root.anchor_left = 0.0
	root.anchor_right = 1.0
	root.anchor_top = 0.0
	root.anchor_bottom = 1.0
	root.offset_left = 0.0
	root.offset_top = 0.0
	root.offset_right = 0.0
	root.offset_bottom = 0.0

	tl.add_child(root)
	tl.move_child(root, tl.get_child_count() - 1)

	_timeline_markers_root = root
	return root


func _time_ms_to_timeline_x(time_ms: int, tl: Control) -> float:
	if editor == null or tl == null:
		return 0.0

	# Grab the same pieces the timeline uses.
	var layers_node: Control = null
	var playhead_area_node: Control = null

	if tl.has_method("get"):
		var v_layers = tl.get("layers")
		if v_layers is Control:
			layers_node = v_layers

		var v_playhead = tl.get("playhead_area")
		if v_playhead is Control:
			playhead_area_node = v_playhead

	# Base X used everywhere in EditorTimeline:
	#   playhead_area.position.x + layers.position.x + _get_timeline_x_clamped(time)
	var base_x := 0.0
	if playhead_area_node != null:
		base_x += playhead_area_node.position.x
	if layers_node != null:
		base_x += layers_node.position.x

	# Figure out how far our bookmark is from the left edge (_cull_start_time)
	var cull_start := 0.0
	if tl.has_method("get"):
		var v_cull = tl.get("_cull_start_time")
		if typeof(v_cull) == TYPE_FLOAT or typeof(v_cull) == TYPE_INT:
			cull_start = float(v_cull)
		else:
			# Fallback: use _offset if _cull_start_time isn’t set yet
			var v_off = tl.get("_offset")
			if typeof(v_off) == TYPE_FLOAT or typeof(v_off) == TYPE_INT:
				cull_start = float(v_off)

	var diff_ms := float(time_ms) - cull_start

	# Same conversion the timeline uses internally.
	var local_x := 0.0
	if editor.has_method("scale_msec"):
		local_x = float(editor.scale_msec(diff_ms))
	else:
		# Very dumb fallback, should basically never be hit.
		var song_len_ms := 0.0
		if editor.has_method("get_song_length"):
			song_len_ms = float(editor.get_song_length()) * 1000.0
		if song_len_ms > 0.0:
			local_x = (float(time_ms) / song_len_ms) * tl.size.x

	# Clamp into the visible layer width, just like _get_timeline_x_clamped().
	var max_w := tl.size.x
	if layers_node != null:
		max_w = layers_node.size.x
	local_x = clamp(local_x, 0.0, max_w)

	var final_x := base_x + local_x

	return final_x


func _get_playhead_ms() -> int:
	if editor == null:
		return 0

	var v = editor.get("playhead_position")
	if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
		return int(round(v))
	return 0


func _on_bookmark_color_changed(new_color: Color) -> void:
	# Find a bookmark under the current playhead (within a small tolerance)
	var playhead_ms := _get_playhead_ms()
	var idx := _find_bookmark_by_time(playhead_ms, 5)

	# If there is NO bookmark at the playhead, do nothing and revert the picker
	if idx == -1:
		var col := DEFAULT_BOOKMARK_COLOR

		if current_index >= 0 and current_index < bookmarks.size():
			var bm = bookmarks[current_index]
			var col_str: String = bm.get("color", DEFAULT_BOOKMARK_COLOR.to_html())
			if typeof(col_str) == TYPE_STRING:
				col = Color(col_str)

		bookmark_color = col

		if _color_button != null and "color" in _color_button:
			_color_button.color = col

		return

	# There *is* a bookmark under the playhead → update ONLY that one
	current_index = idx

	var bm = bookmarks[idx]
	bm["color"] = new_color.to_html()
	bookmarks[idx] = bm

	bookmark_color = new_color

	_save_bookmarks()
	_refresh_ui()
	_refresh_timeline_markers()



func _jump_to_current() -> void:
	if editor == null:
		_refresh_ui()
		return

	if current_index < 0 or current_index >= bookmarks.size():
		_refresh_ui()
		return

	var bm = bookmarks[current_index]
	var t_ms := int(bm.get("time_ms", 0))

	if editor.has_method("seek"):
		editor.seek(t_ms)
	else:
		editor.playhead_position = t_ms

	if "timeline" in editor and editor.timeline and editor.timeline.has_method("ensure_playhead_is_visible"):
		editor.timeline.ensure_playhead_is_visible()

	# Sync color picker with this bookmark's color
	var col_str: String = bm.get("color", DEFAULT_BOOKMARK_COLOR.to_html())
	bookmark_color = Color(col_str)
	if _color_button and "color" in _color_button:
		_color_button.color = bookmark_color

	_refresh_ui()


func _sort_bookmarks_by_time(a, b) -> bool:
	return int(a.get("time_ms", 0)) < int(b.get("time_ms", 0))


func _find_bookmark_index(time_ms: int, label: String) -> int:
	for i in range(bookmarks.size()):
		var bm = bookmarks[i]
		if int(bm.get("time_ms", -1)) == time_ms \
		and String(bm.get("label", "")) == label:
			return i

	# Fallback: nearest by time
	var best := -1
	var best_dist := 1_000_000_000
	for i in range(bookmarks.size()):
		var t := int(bookmarks[i].get("time_ms", 0))
		var d := abs(t - time_ms)
		if d < best_dist:
			best_dist = d
			best = i
	return best


func _find_bookmark_by_time(time_ms: int, tolerance_ms: int = 0) -> int:
	for i in range(bookmarks.size()):
		var t := int(bookmarks[i].get("time_ms", 0))
		if abs(t - time_ms) <= tolerance_ms:
			return i
	return -1


func _fmt_time(ms: int) -> String:
	var total_sec := ms / 1000
	var minutes := total_sec / 60
	var seconds := total_sec % 60
	var millis := ms % 1000
	return "%02d:%02d.%03d" % [minutes, seconds, millis]

func _refresh_timeline_markers() -> void:
	var tl := _get_timeline_node()
	if tl == null:
		return

	var root := _ensure_markers_root()
	if root == null:
		return

	# Clear old markers
	for c in root.get_children():
		c.queue_free()

	if bookmarks.is_empty():
		return

	# --- vertical layout info ---------------------------------------
	var panel_node := tl.get_node_or_null("VBoxContainer/Panel")
	var scrollc := tl.get_node_or_null("VBoxContainer/ScrollContainer")
	var minimap_node := tl.get_node_or_null("VBoxContainer/Minimap")

	var header_top := 0.0      # where the black header (timestamp area) starts
	var header_h := 24.0       # height of that header strip
	var line_bottom := tl.size.y

	if panel_node != null:
		header_top = panel_node.position.y
		line_bottom = panel_node.position.y
		if scrollc != null:
			line_bottom += scrollc.size.y

		# Use playhead_area height as the header strip height if available
		if tl.has_method("get"):
			var v_playhead = tl.get("playhead_area")
			if v_playhead is Control:
				header_h = (v_playhead as Control).size.y

	var line_top := header_top

	# Height of our bookmark text/flags = same height as the timeline font
	var text_h: float = float(TIME_LABEL.get_height())

	for bm in bookmarks:
		var t_ms := int(bm.get("time_ms", 0))
		var label := String(bm.get("label", ""))

		# Get this bookmark's color (fallback to default if missing)
		var col_str: String = bm.get("color", DEFAULT_BOOKMARK_COLOR.to_html())
		var bm_color := DEFAULT_BOOKMARK_COLOR
		if typeof(col_str) == TYPE_STRING:
			bm_color = Color(col_str)

		var x := _time_ms_to_timeline_x(t_ms, tl)

		# ── vertical line ─────────────────────────────────────
		var marker := ColorRect.new()
		marker.mouse_filter = Control.MOUSE_FILTER_IGNORE
		marker.color = bm_color

		marker.anchor_left = 0.0
		marker.anchor_right = 0.0
		marker.anchor_top = 0.0
		marker.anchor_bottom = 0.0

		var half_width := 1.0
		marker.position = Vector2(x - half_width, line_top)
		marker.size = Vector2(half_width * 2.0, line_bottom - line_top)

		var tooltip := _fmt_time(t_ms)
		if label != "":
			tooltip += " — " + label
		marker.tooltip_text = tooltip

		root.add_child(marker)

		# ── label + yellow rectangle ─────────────────────────
		if label == "":
			continue

		# Width based on character count (simple approximation)
		var char_px := 7.0
		var min_w := 32.0
		var text_w := max(min_w, float(label.length()) * char_px)

		# Padding inside the box
		var pad_x := 2.0
		var pad_y := 1.0

		# Rectangle size
		var panel_w: float = text_w + pad_x * 2.0
		var panel_h: float = float(TIME_LABEL.get_height())

		# Put the rectangle near the top of the header area
		var panel_x := x + 4.0
		var panel_y := header_top + 2.0
		var min_y := header_top + 2.0
		var max_y := header_top + header_h - panel_h - 2.0
		panel_y = clamp(panel_y, min_y, max_y)

		var panel_rect := Rect2(Vector2(panel_x, panel_y), Vector2(panel_w, panel_h))

		# Label *inside* that rectangle
		var lbl := Label.new()
		lbl.text = label
		lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		lbl.position = panel_rect.position + Vector2(pad_x, pad_y)
		lbl.size = panel_rect.size - Vector2(pad_x * 2.0, pad_y * 2.0)
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		lbl.vertical_alignment = VERTICAL_ALIGNMENT_TOP
		lbl.clip_text = true
		lbl.add_theme_font_override("font", TIME_LABEL)
		lbl.add_theme_color_override("font_color", bm_color)
		root.add_child(lbl)




func _refresh_ui() -> void:
	var has_bm := not bookmarks.is_empty()

	idx_spin.editable = has_bm
	idx_spin.max_value = max(1, bookmarks.size())

	if current_index >= 0 and current_index < bookmarks.size():
		idx_spin.value = current_index + 1

		var bm = bookmarks[current_index]
		var t_ms := int(bm.get("time_ms", 0))
		var label := String(bm.get("label", ""))

		# Show current note in entry field
		desc_edit.text = label

		# ---- update color picker from this bookmark ----
		var col_str: String = bm.get("color", DEFAULT_BOOKMARK_COLOR.to_html())
		var col := DEFAULT_BOOKMARK_COLOR
		if typeof(col_str) == TYPE_STRING:
			col = Color(col_str)

		bookmark_color = col
		if _color_button != null and "color" in _color_button:
			_color_button.color = col
		# -----------------------------------------------

		info_label.text = "#%d @ %s (%d ms) — %s" % [
			current_index + 1,
			_fmt_time(t_ms),
			t_ms,
			label
		]
	else:
		idx_spin.value = 1
		if has_bm:
			info_label.text = "%d bookmark(s) — no selection" % bookmarks.size()
		else:
			info_label.text = "No bookmarks yet."

		# No selection → picker uses default color
		bookmark_color = DEFAULT_BOOKMARK_COLOR
		if _color_button != null and "color" in _color_button:
			_color_button.color = bookmark_color

	btn_prev.disabled = not has_bm
	btn_next.disabled = not has_bm
	btn_clear_current.disabled = not has_bm
	btn_clear_all.disabled = not has_bm
