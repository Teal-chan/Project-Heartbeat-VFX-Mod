extends ScriptRunnerScript

#meta:name:Select all notes WITHOUT VFX
#meta:description:Selects all timeline notes that do NOT have any VFX rows (using PH_VFX_MegaInjector).
#meta:usage:Run while the VFX Mega Injector is active to select all notes without VFX.

func run_script() -> int:
	if _editor == null:
		push_error("[SelectNotesWithoutVFX] ❌ No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	var mgr: Node = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr == null:
		mgr = _editor.find_child("PH_VFX_MegaInjector", true, false)

	if mgr == null:
		push_error("[SelectNotesWithoutVFX] ❌ PH_VFX_MegaInjector not found. Run your Inject VFX step first.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("❌ No PH_VFX_MegaInjector found. Inject VFX first.")
		return ERR_DOES_NOT_EXIST

	var keys_with_vfx: Dictionary = {}
	if mgr.has_method("get"):
		var raw = mgr.get("_keys_with_vfx")
		if typeof(raw) == TYPE_DICTIONARY:
			keys_with_vfx = raw

	if keys_with_vfx.is_empty():
		print("[SelectNotesWithoutVFX] Injector reports no VFX keys; assuming all notes are without VFX.")
		# In this weird case we'll just select everything; but normally this means VFX wasn't injected.

	var has_injector_key_helper := mgr.has_method("_key_for_note_data")

	# Use the injector's live note-data map to handle layer-2 slides correctly.
	var note_to_key_map: Dictionary = {}
	if mgr.has_method("get"):
		var m = mgr.get("_note_data_to_key_preview")
		if typeof(m) == TYPE_DICTIONARY:
			note_to_key_map = m

	if not _editor.has_method("get_timeline_items"):
		push_error("[SelectNotesWithoutVFX] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var new_selection: Array = []

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var note_obj = item.data
		if note_obj == null:
			continue

		var key := _resolve_key_for_note(mgr, note_obj, note_to_key_map, has_injector_key_helper)
		var has_vfx := (key != "" and keys_with_vfx.has(key))

		if not has_vfx:
			new_selection.append(item)

	if new_selection.is_empty():
		print("[SelectNotesWithoutVFX] No notes without VFX found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No notes without VFX found.")
		return OK

	# Clear selection on all notes
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if item is EditorTimelineItemNote:
			_set_item_selected(item, false)

	# Select only the "no VFX" ones
	for item in new_selection:
		_set_item_selected(item, true)

	# Sync editor logical selection
	if _editor.has_method("clear_selection"):
		_editor.clear_selection()
	else:
		_editor.selected = []

	_editor.selected = new_selection

	if _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("queue_redraw"):
			tl.queue_redraw()

	print("[SelectNotesWithoutVFX] ✅ Selected ", new_selection.size(), " notes WITHOUT VFX.")
	if _editor.message_shower:
		_editor.message_shower._show_notification("✨ Selected %d notes without VFX." % new_selection.size())

	return OK


# --- helpers (same as in With-VFX script) -------------------------------

func _resolve_key_for_note(
		mgr: Node,
		note_obj: Object,
		note_to_key_map: Dictionary,
		has_injector_key_helper: bool
) -> String:
	if note_to_key_map.has(note_obj):
		var k0 = note_to_key_map.get(note_obj, "")
		if typeof(k0) == TYPE_STRING and k0 != "":
			return k0

	if has_injector_key_helper:
		var k1 = mgr.call("_key_for_note_data", note_obj)
		if typeof(k1) == TYPE_STRING and k1 != "":
			return k1

	return _build_vfx_key_for_note_data(note_obj)


func _set_item_selected(item: Object, sel: bool) -> void:
	if item == null or not is_instance_valid(item):
		return

	var has_selected_prop := false

	if item.has_method("get_property_list"):
		for p in item.get_property_list():
			if String(p.name) == "selected":
				has_selected_prop = true
				break

	if has_selected_prop:
		item.set("selected", sel)
	elif item.has_method("set_selected"):
		item.call("set_selected", sel)
	elif sel and item.has_method("select"):
		item.call("select")
	elif (not sel) and item.has_method("deselect"):
		item.call("deselect")


func _build_vfx_key_for_note_data(nd: Object) -> String:
	if nd == null:
		return ""
	if not nd.has_method("get"):
		return ""

	var nt_v = nd.get("note_type")
	var time_v = nd.get("time")
	if nt_v == null or time_v == null:
		return ""

	var nti := int(nt_v)
	var head_t := int(time_v)

	var lname := "UNKNOWN"
	match nti:
		0: lname = "UP"
		1: lname = "LEFT"
		2: lname = "DOWN"
		3: lname = "RIGHT"
		4, 6: lname = "SLIDE_LEFT"
		5, 7: lname = "SLIDE_RIGHT"
		8: lname = "HEART"

	var is_l2 := _guess_is_layer2_from_note(nd)
	var layer_tag := "layer_%s%s" % [lname, ( "2" if is_l2 else "" )]
	return "%s@%d@%d" % [layer_tag, nti, head_t]


func _guess_is_layer2_from_note(obj: Object) -> bool:
	if obj == null:
		return false

	var lidx = null
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if String(p.name) == "layer_index":
				lidx = obj.get("layer_index")
				break
	if lidx == null and obj.has_method("get"):
		if "layer_index" in obj:
			lidx = obj.get("layer_index")
	if lidx != null and int(lidx) == 1:
		return true

	var has_flag = null
	if obj.has_method("get_property_list"):
		for p2 in obj.get_property_list():
			if String(p2.name) == "second_layer":
				has_flag = obj.get("second_layer")
				break
	if has_flag == null and obj.has_method("get"):
		if "second_layer" in obj:
			has_flag = obj.get("second_layer")
	if has_flag != null and bool(has_flag):
		return true

	var layer_meta = null
	if obj.has_method("get_property_list"):
		for p3 in obj.get_property_list():
			if String(p3.name) == "layer":
				layer_meta = obj.get("layer")
				break
	if layer_meta == null and obj.has_method("get"):
		if "layer" in obj:
			layer_meta = obj.get("layer")
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true

	return false
