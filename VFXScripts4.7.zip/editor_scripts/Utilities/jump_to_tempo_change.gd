extends ScriptRunnerScript

#meta:name:Jump to Nearest BPM Change
#meta:description:Moves the editor playhead to the closest tempo/BPM marker.
#meta:usage:Run to snap playhead to the nearest BPM change.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpToNearestBPM] No HBEditor reference.")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpToNearestBPM] Editor has no get_timeline_items().")
		return ERR_UNCONFIGURED

	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ No timeline items found.")
		return OK

	# ---- Collect tempo / BPM entries (duck-typed) ----
	var tempo_entries: Array = []

	for item in items:
		if item == null:
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")

		var bpm_val = null
		var time_val = null

		# Prefer bpm/time on data if present
		if data != null and data.has_method("get"):
			bpm_val = data.get("bpm")
			time_val = data.get("time")

		# Fallback: check bpm/time directly on the item (just in case)
		if bpm_val == null and item.has_method("get"):
			bpm_val = item.get("bpm")
		if time_val == null and item.has_method("get"):
			time_val = item.get("time")

		if bpm_val == null:
			continue  # Not a tempo marker

		var bpm := float(bpm_val)
		var t_ms := 0
		if time_val != null:
			t_ms = int(time_val)

		tempo_entries.append({
			"time_ms": t_ms,
			"bpm": bpm,
		})

	if tempo_entries.is_empty():
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ No BPM/tempo markers found.")
		print("[JumpToNearestBPM] No tempo markers found.")
		return OK

	print("[JumpToNearestBPM] Found %d tempo markers." % tempo_entries.size())

	# ---- Current playhead time ----
	var cur_time_ms: float = 0.0
	var p = _editor.get("playhead_position")
	if typeof(p) == TYPE_INT or typeof(p) == TYPE_FLOAT:
		cur_time_ms = float(p)

	# ---- Find nearest BPM entry ----
	var best_entry = null
	var best_dist := 1.0e30  # large number

	for entry in tempo_entries:
		var t_ms: int = entry["time_ms"]
		var dist := abs(cur_time_ms - float(t_ms))
		if dist < best_dist:
			best_dist = dist
			best_entry = entry

	if best_entry == null:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Could not determine nearest BPM marker.")
		print("[JumpToNearestBPM] best_entry is null after scan.")
		return OK

	var target_time_ms: int = best_entry["time_ms"]
	var target_bpm: float = best_entry["bpm"]

	# ---- Clamp to song length (same pattern as your snap script) ----
	if _editor.current_song:
		var max_ms := int(_editor.get_song_length() * 1000.0)
		target_time_ms = clamp(target_time_ms, 0, max_ms)

	# ---- Move the playhead using the real seek API ----
	if _editor.has_method("seek"):
		_editor.seek(target_time_ms)
	else:
		_editor.playhead_position = target_time_ms

	# Ask the timeline to bring it into view, if possible
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	# Nudge the preview game loop if present
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	# ---- Feedback ----
	var msg := "[JumpToNearestBPM] Jumped to BPM %.2f at %d ms (dist=%d ms)" \
		% [target_bpm, target_time_ms, int(best_dist)]
	print(msg)
	if _editor.message_shower:
		_editor.message_shower._show_notification(msg)

	return OK
