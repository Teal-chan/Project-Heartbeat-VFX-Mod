extends ScriptRunnerScript

#meta:name:Jump playhead to previous note
#meta:description:Moves the editor playhead to the previous note before the current time, without changing selection.
#meta:usage:Run to move to the previous note on the timeline.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpPrevNote] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpPrevNote] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var note_entries: Array = []   # each: { "time": int }

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var t := _get_time_from_item(item)
		if t < 0:
			continue

		note_entries.append({ "time": t })

	if note_entries.is_empty():
		print("[JumpPrevNote] No notes found on the timeline.")
		return OK

	var cur_ms := _get_current_playhead_ms()
	var best_time := -1

	# Find the largest note time strictly less than current playhead
	for entry in note_entries:
		var t: int = entry["time"]
		if t >= cur_ms - 1:
			continue
		if best_time < 0 or t > best_time:
			best_time = t

	if best_time < 0:
		print("[JumpPrevNote] No earlier note found (already at or before the first note).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No earlier note found.")
		return OK

	_seek_editor_to_ms(best_time)

	print("[JumpPrevNote] ◀ Jumped to previous note at ", best_time, " ms.")
	if _editor.message_shower:
		_editor.message_shower._show_notification("◀ Jumped to previous note at %d ms." % best_time)

	return OK


# --- helpers -------------------------------------------------------------
# (identical to the next-note script; you can keep them duplicated or factor into a shared include.)

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	var data = null
	if item.has_method("get"):
		data = item.get("data")

	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))

	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1


func _seek_editor_to_ms(ms: int) -> void:
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)

	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	if _editor.has_method("force_game_process"):
		_editor.force_game_process()
