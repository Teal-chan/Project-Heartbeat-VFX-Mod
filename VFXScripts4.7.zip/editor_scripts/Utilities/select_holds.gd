# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Select All Hold Notes
#meta:description:Clears the selection and selects every note whose data has `hold = true`.
#meta:usage:Run to select all Hold notes in the current difficulty.

func run_script() -> int:
	if _editor == null:
		push_error("[SelectHoldNotes] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[SelectHoldNotes] Editor has no get_timeline_items().")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()

	# Clear previous selection
	if _editor.has_method("clear_selection"):
		_editor.clear_selection()
	else:
		_editor.selected = []

	var newly_selected: Array = []
	var count := 0

	for item in items:
		if item == null or not is_instance_valid(item):
			continue

		# Most editor timeline items expose their HBTimingPoint/HBNoteData as `data`
		var data = null
		if item.has_method("get"):
			data = item.get("data")

		if data == null:
			continue

		var is_hold := false

		# Safely probe for a `hold` property on the data object
		if data.has_method("get_property_list"):
			for p in data.get_property_list():
				if String(p.name) == "hold":
					var v = data.get("hold")
					is_hold = v == true
					break
		elif data.has_method("get"):
			var v2 = data.get("hold")
			if v2 != null:
				is_hold = v2 == true

		if not is_hold:
			continue

		newly_selected.append(item)
		count += 1

		# Try to mark the timeline item as selected so the UI reflects it
		_set_timeline_item_selected(item, true)

	# Update editor selection array
	_editor.selected = newly_selected

	# Let the editor know selection changed, if it has such a hook
	if _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()

	print("[SelectHoldNotes] Selected %d Hold notes." % count)
	if _editor.message_shower:
		_editor.message_shower._show_notification("✅ Selected %d Hold notes." % count)

	return OK


func _set_timeline_item_selected(item: Object, sel: bool) -> void:
	if item == null or not is_instance_valid(item):
		return

	var has_selected_prop := false
	if item.has_method("get_property_list"):
		for p in item.get_property_list():
			if String(p.name) == "selected":
				has_selected_prop = true
				break

	if has_selected_prop:
		item.set("selected", sel)
	elif item.has_method("set_selected"):
		item.call("set_selected", sel)
	elif sel and item.has_method("select"):
		item.call("select")
	elif (not sel) and item.has_method("deselect"):
		item.call("deselect")
