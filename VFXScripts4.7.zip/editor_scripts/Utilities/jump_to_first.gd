#meta:name:Jump to first note
#meta:description:Moves the editor playhead to the earliest note on the timeline and ensures it is visible.
#meta:usage:Run to jump to the first note in the chart.

extends ScriptRunnerScript

func run_script() -> int:
	if _editor == null:
		printerr("[JumpToFirstNote] No editor context.")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		printerr("[JumpToFirstNote] Editor has no get_timeline_items().")
		return ERR_DOES_NOT_EXIST

	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		printerr("[JumpToFirstNote] No timeline items found.")
		return ERR_DOES_NOT_EXIST

	var best_time_ms := -1

	for item in items:
		if item == null:
			continue
		var t := _get_note_time_from_item(item)
		if t < 0:
			continue
		if best_time_ms < 0 or t < best_time_ms:
			best_time_ms = t

	if best_time_ms < 0:
		printerr("[JumpToFirstNote] No notes found on the timeline.")
		return ERR_DOES_NOT_EXIST

	# Clamp to song length just in case
	if _editor.current_song:
		var max_ms := int(_editor.get_song_length() * 1000.0)
		best_time_ms = clamp(best_time_ms, 0, max_ms)

	# Use proper seek if available
	if _editor.has_method("seek"):
		_editor.seek(best_time_ms)
	else:
		_editor.playhead_position = best_time_ms

	# Make it visible on the timeline
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	# Nudge preview
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[JumpToFirstNote] ▶ Jumped to first note at ", best_time_ms, " ms.")
	return OK


func _get_note_time_from_item(item: Object) -> int:
	var data = null
	if item.has_method("get"):
		data = item.get("data")

	if data != null and data.has_method("get"):
		# Heuristic: a note has a 'note_type' and a 'time'
		var nt = data.get("note_type") if data.has_method("get") else null
		var t = data.get("time") if data.has_method("get") else null
		if nt != null and t != null:
			return int(round(float(t)))

	# Fallback – try the item itself (if someone reuses the type differently)
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1
