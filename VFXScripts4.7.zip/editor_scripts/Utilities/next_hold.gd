# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Jump to next Hold note
#meta:description:Jumps the playhead to the next Hold note (data.hold == true) after the current playhead position without changing the current selection.
#meta:usage:Run to move to the next Hold note while keeping your current selection untouched.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpNextHoldNote] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpNextHoldNote] Editor has no get_timeline_items().")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var hold_entries: Array = []  # each: { "time": int }

	# Collect all Hold notes (data.hold == true)
	for item in items:
		if item == null or not is_instance_valid(item):
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")

		if data == null:
			continue

		var is_hold := false

		# Same detection logic as Select All Hold Notes
		if data.has_method("get_property_list"):
			for p in data.get_property_list():
				if String(p.name) == "hold":
					var v = data.get("hold")
					is_hold = v == true
					break
		elif data.has_method("get"):
			var v2 = data.get("hold")
			if v2 != null:
				is_hold = v2 == true

		if not is_hold:
			continue

		var t := _get_time_from_item(item)
		if t < 0:
			continue

		hold_entries.append({ "time": t })

	if hold_entries.is_empty():
		print("[JumpNextHoldNote] No Hold notes found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No Hold notes on the timeline.")
		return OK

	# Find the next Hold note strictly after the current playhead
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1

	for entry in hold_entries:
		var t: int = entry["time"]
		# strictly after current playhead (tiny tolerance)
		if t <= cur_ms + 1:
			continue
		if best_time == -1 or t < best_time:
			best_time = t

	if best_time == -1:
		print("[JumpNextHoldNote] No later Hold note found (past last Hold).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No later Hold note found.")
		return OK

	# Move playhead ONLY
	_seek_editor_to_ms(best_time)

	print("[JumpNextHoldNote] 🎵 Jumped to next Hold note at ", best_time, " ms (selection unchanged).")
	if _editor.message_shower:
		_editor.message_shower._show_notification("🎵 Jumped to next Hold note at %d ms (selection unchanged)." % best_time)

	return OK


# --- helpers: time / seek --------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0

	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0

	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1

	var data = null
	if item.has_method("get"):
		data = item.get("data")

	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))

	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)

	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	if _editor.has_method("force_game_process"):
		_editor.force_game_process()
