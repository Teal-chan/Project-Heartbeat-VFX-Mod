#meta:name:Step 4 - Write VFX to JSON
#meta:description: Adds or updates VFX entries safely.
extends ScriptRunnerScript

func run_script() -> int:
	var song_dir := "user://editor_songs/%s" % str(_editor.current_song.id)
	var json_path := "%s/%s_vfx.json" % [song_dir, str(_editor.current_difficulty).replace(" ", "_")]
	var new_entries := _generate_new_entries() # your authoring data here

	var rows := _safe_load(json_path)
	var indexed := _index_rows(rows)

	for entry in new_entries:
		var key := _make_key(entry)
		if indexed.has(key):
			# merge only changed fields
			for k in entry.keys():
				indexed[key][k] = entry[k]
		else:
			rows.append(entry)
			indexed[key] = entry

	_safe_save(json_path, rows)
	_editor.message_shower._show_notification("💾 Saved VFX to JSON")
	print("[VFX Writer] %d entries written to %s" % [rows.size(), json_path])
	return OK

# ---------- helpers ----------
func _make_key(row: Dictionary) -> String:
	return "%d#%d#%s" % [int(row.get("time",0)), int(row.get("note_type",0)), str(row.get("layer","*"))]

func _index_rows(rows: Array) -> Dictionary:
	var map := {}
	for r in rows:
		if typeof(r) == TYPE_DICTIONARY:
			map[_make_key(r)] = r
	return map

func _safe_load(path: String) -> Array:
	if not FileAccess.file_exists(path):
		return []
	var f := FileAccess.open(path, FileAccess.READ)
	if not f: return []
	var parsed := JSON.parse_string(f.get_as_text())
	return parsed if typeof(parsed) == TYPE_ARRAY else []

func _safe_save(path: String, data: Array) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if not f: return
	f.store_string(JSON.stringify(data, "\t"))  # pretty print

func _generate_new_entries() -> Array:
	# stub for demo — replace with your authoring data
	return [
		{
			"time": 5000, "note_type": 1, "layer": "layer_LEFT", "color_icon": [0.2, 0.8, 1.0, 1.0], "scale_head": 1.5
		}
	]
