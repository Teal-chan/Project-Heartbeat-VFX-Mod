# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:VFX Inspector (Selected Notes)
#meta:description:Inspects the VFX JSON for the currently selected notes and prints per-note animation stats, including Mirai links.
#meta:usage:Select one or more notes and run. Summary appears in a popup and the console.

extends ScriptRunnerScript

const NOTE_TYPE_NAMES := {
	0:"UP",1:"LEFT",2:"DOWN",3:"RIGHT",
	4:"SLIDE_LEFT",5:"SLIDE_RIGHT",
	6:"SLIDE_CHAIN_PIECE_LEFT",7:"SLIDE_CHAIN_PIECE_RIGHT",
	8:"HEART"
}

# Adjust these paths if your filenames differ
const PATH_CLEAR_VFX      := "user://editor_scripts/Utilities/clear_vfx.gd"


const DEBUG_INSPECTOR := false

func _dbg(msg: String) -> void:
	if DEBUG_INSPECTOR:
		print("[VFXInspector] ", msg)

# ─────────────────────────────────────────────
# Entry
# ─────────────────────────────────────────────
func run_script() -> int:
	if _editor == null:
		push_error("[VFXInspector] No editor context.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[VFXInspector] No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs: Array = _collect_selected_note_specs()
	if specs.is_empty():
		push_error("[VFXInspector] No valid note specs from selection.")
		return ERR_DOES_NOT_EXIST

	var path: String = _get_vfx_path()
	if path == "":
		push_warning("[VFXInspector] No VFX path for this chart.")
		return OK

	if not FileAccess.file_exists(path):
		push_warning("[VFXInspector] VFX JSON file does not exist yet: " + path)
		return OK

	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("[VFXInspector] Could not open VFX file: " + path)
		return ERR_FILE_CANT_OPEN

	var txt: String = f.get_as_text()
	f.close()

	var parsed := JSON.parse_string(txt)
	if typeof(parsed) != TYPE_ARRAY:
		push_error("[VFXInspector] VFX file is not an array; cannot inspect.")
		return ERR_PARSE_ERROR

	var rows: Array = parsed

	# Build lookup for selected heads
	var key_to_spec: Dictionary = {}
	for spec in specs:
		var layer := String(spec["layer"])
		var head  := int(spec["time"])
		var nt    := int(spec["note_type"])
		var key := "%s@%d@%d" % [layer, nt, head]
		key_to_spec[key] = spec

	# Initialize per-note stats
	var anim_stats: Dictionary = {}   # key -> { anim -> { stage -> {count, first, last} } }
	var mirai_stats: Dictionary = {}  # key -> { "as_head": int, "as_tail": int }

	for key in key_to_spec.keys():
		anim_stats[key] = {}
		mirai_stats[key] = {"as_head": 0, "as_tail": 0}

	# Pass 1: collect stats
	for row in rows:
		if typeof(row) != TYPE_DICTIONARY:
			continue

		var layer := String(row.get("layer", ""))

		# Mirai link rows
		if layer == "$MIRAI_LINK":
			var hkey := String(row.get("head_key", ""))
			var tkey := String(row.get("tail_key", ""))
			if key_to_spec.has(hkey):
				var m_h: Dictionary = mirai_stats[hkey]
				m_h["as_head"] = int(m_h.get("as_head", 0)) + 1
				mirai_stats[hkey] = m_h
			if key_to_spec.has(tkey):
				var m_t: Dictionary = mirai_stats[tkey]
				m_t["as_tail"] = int(m_t.get("as_tail", 0)) + 1
				mirai_stats[tkey] = m_t
			continue

		# Anim rows (Scale, Color, etc.)
		var anim := String(row.get("anim", ""))
		if anim == "":
			continue

		var nt := int(row.get("note_type", -1))
		var head_time := int(row.get("anim_note_time", -1))
		if nt < 0 or head_time < 0:
			continue

		var key := "%s@%d@%d" % [layer, nt, head_time]
		if not key_to_spec.has(key):
			continue

		var stage := String(row.get("anim_stage", ""))
		if stage == "":
			stage = "unknown"

		var t_ms := int(row.get("time", 0))

		var per_note: Dictionary = anim_stats[key]
		if not per_note.has(anim):
			per_note[anim] = {}
		var per_anim: Dictionary = per_note[anim]
		if not per_anim.has(stage):
			per_anim[stage] = {
				"count": 0,
				"first": t_ms,
				"last": t_ms,
				"values": [],  # Store actual values
			}

		var s: Dictionary = per_anim[stage]
		s["count"] = int(s["count"]) + 1
		if t_ms < int(s["first"]):
			s["first"] = t_ms
		if t_ms > int(s["last"]):
			s["last"] = t_ms
		
		# Collect actual values based on animation type
		var values_arr: Array = s.get("values", [])
		var value_entry := {"time": t_ms}
		
		# Debug: store all keys from the row to see what's actually there
		value_entry["_raw_keys"] = row.keys()
		
		# Try multiple possible field name patterns
		# Pattern 1: "head", "target", etc. (simple)
		# Pattern 2: "scale_head", "color_head", etc. (prefixed)
		# Pattern 3: Check what actually exists in the row
		
		if anim.begins_with("Scale"):
			value_entry["head"] = _get_value(row, ["head", "scale_head"])
			value_entry["target"] = _get_value(row, ["target", "scale_target"])
			value_entry["bar1"] = _get_value(row, ["bar1", "scale_bar1"])
			value_entry["bar2"] = _get_value(row, ["bar2", "scale_bar2"])
			value_entry["tail"] = _get_value(row, ["tail", "scale_tail"])
			value_entry["hold"] = _get_value(row, ["hold", "scale_hold"])
			value_entry["icon"] = _get_value(row, ["icon", "scale_icon"])
		elif anim.begins_with("Color"):
			value_entry["head"] = _get_value(row, ["head", "color_head"])
			value_entry["target"] = _get_value(row, ["target", "color_target"])
			value_entry["bar1"] = _get_value(row, ["bar1", "color_bar1"])
			value_entry["bar2"] = _get_value(row, ["bar2", "color_bar2"])
			value_entry["tail"] = _get_value(row, ["tail", "color_tail"])
			value_entry["hold"] = _get_value(row, ["hold", "color_hold"])
			value_entry["icon"] = _get_value(row, ["icon", "color_icon"])
		elif anim.begins_with("Rot"):
			value_entry["head"] = _get_value(row, ["head", "rotation_deg_head", "rot_head"])
			value_entry["target"] = _get_value(row, ["target", "rotation_deg_target", "rot_target"])
			value_entry["bar1"] = _get_value(row, ["bar1", "rotation_deg_bar1", "rot_bar1"])
			value_entry["bar2"] = _get_value(row, ["bar2", "rotation_deg_bar2", "rot_bar2"])
			value_entry["tail"] = _get_value(row, ["tail", "rotation_deg_tail", "rot_tail"])
			value_entry["hold"] = _get_value(row, ["hold", "rotation_deg_hold", "rot_hold"])
			value_entry["icon"] = _get_value(row, ["icon", "rotation_deg_icon", "rot_icon"])
		elif anim.begins_with("Offset"):
			value_entry["head"] = _get_value(row, ["head", "offset_head"])
			value_entry["target"] = _get_value(row, ["target", "offset_target"])
			value_entry["bar1"] = _get_value(row, ["bar1", "offset_bar1"])
			value_entry["bar2"] = _get_value(row, ["bar2", "offset_bar2"])
			value_entry["tail"] = _get_value(row, ["tail", "offset_tail"])
			value_entry["hold"] = _get_value(row, ["hold", "offset_hold"])
			value_entry["icon"] = _get_value(row, ["icon", "offset_icon"])
		elif anim.begins_with("Glow"):
			value_entry["intensity"] = _get_value(row, ["glow_intensity", "intensity"])
			value_entry["color"] = _get_value(row, ["glow_color", "color"])
		elif anim.begins_with("Spot"):
			value_entry["intensity"] = _get_value(row, ["spot_intensity", "intensity"])
			value_entry["color"] = _get_value(row, ["spot_color", "color"])
			value_entry["radius"] = _get_value(row, ["spot_radius", "radius"])
			value_entry["softness"] = _get_value(row, ["spot_softness", "softness"])
		
		values_arr.append(value_entry)
		s["values"] = values_arr
		
		per_anim[stage] = s
		per_note[anim] = per_anim
		anim_stats[key] = per_note

	# ─────────────────────────────────────────
	# Format report
	# ─────────────────────────────────────────
	var lines := PackedStringArray()
	lines.append("[VFXInspector] =====================================================")
	lines.append("[VFXInspector] VFX for selected notes → file: %s" % path)
	lines.append("[VFXInspector] Selected notes: %d" % specs.size())
	lines.append("")

	for spec in specs:
		var layer := String(spec["layer"])
		var head  := int(spec["time"])
		var nt    := int(spec["note_type"])
		var key := "%s@%d@%d" % [layer, nt, head]

		var note_name := NOTE_TYPE_NAMES.get(nt, "UNKNOWN")
		lines.append("• Note %s t=%dms type=%d (%s)" % [layer, head, nt, note_name])

		var per_note_anim: Dictionary = anim_stats.get(key, {})
		var per_note_mirai: Dictionary = mirai_stats.get(key, {"as_head": 0, "as_tail": 0})

		var had_any := false

		# Animations
		if not per_note_anim.is_empty():
			had_any = true
			for anim in per_note_anim.keys():
				lines.append("    anim %s:" % anim)
				var per_anim: Dictionary = per_note_anim[anim]
				for stage in per_anim.keys():
					var st: Dictionary = per_anim[stage]
					var c := int(st["count"])
					var first := int(st["first"])
					var last  := int(st["last"])
					var rel_first := first - head
					var rel_last  := last - head
					lines.append("        %s: %d row(s) [%d..%d] ms (rel %+d..%+d)" % [
						stage, c, first, last, rel_first, rel_last
					])
					
					# Show actual values
					var values_arr: Array = st.get("values", [])
					if not values_arr.is_empty():
						for val_entry in values_arr:
							var val_line := _format_value_entry(anim, val_entry, head)
							if val_line != "":
								lines.append("            %s" % val_line)

		# Mirai link participation
		var mh := int(per_note_mirai.get("as_head", 0))
		var mt := int(per_note_mirai.get("as_tail", 0))
		if mh > 0 or mt > 0:
			had_any = true
			lines.append("    Mirai links: as HEAD=%d, as TAIL=%d" % [mh, mt])

		if not had_any:
			lines.append("    (no VFX rows for this note)")
		lines.append("")

	var report := "\n".join(lines)

	# Print to console as before
	print(report)

	# Toast in editor
	if _editor and _editor.message_shower:
		_editor.message_shower._show_notification(
			"🔍 VFX Inspector: inspected %d note(s). See popup/console for details." % specs.size()
		)

	# Fancy popup dialog
	_show_report_dialog(report, specs.size())

	return OK

# ─────────────────────────────────────────────
# Fancy ConfirmationDialog (Clear-only)
# ─────────────────────────────────────────────
func _show_report_dialog(report: String, note_count: int) -> void:
	if _editor == null:
		return

	var dlg := ConfirmationDialog.new()
	dlg.title = "VFX Inspector – %d note(s)" % note_count
	dlg.min_size = Vector2(720, 480)

	# Main content (scrollable text)
	var text := RichTextLabel.new()
	text.bbcode_enabled = false
	text.scroll_active = true
	text.scroll_following = false
	text.fit_content = false
	text.text = report
	text.mouse_filter = Control.MOUSE_FILTER_PASS
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text.set_anchors_preset(Control.PRESET_FULL_RECT)

	dlg.add_child(text)

	# Built-in buttons: OK → Close, hide Cancel
	dlg.get_ok_button().text = "Close"
	dlg.get_cancel_button().hide()

	# Add custom "Clear VFX" button to the dialog button bar
	var clear_btn := dlg.add_button("🧹 Clear VFX for Selected Notes", true, "clear_vfx")

	# Handle custom action
	dlg.custom_action.connect(func(action: StringName):
		if action == "clear_vfx":
			_run_tool(PATH_CLEAR_VFX)  # your Clear script path constant
			dlg.queue_free()
	)

	# Close behavior
	dlg.confirmed.connect(func(): dlg.queue_free())
	dlg.canceled.connect(func(): dlg.queue_free())
	dlg.close_requested.connect(func(): dlg.queue_free())

	_editor.add_child(dlg)
	dlg.popup_centered_ratio(0.7)



# ─────────────────────────────────────────────
# Selection → specs
# ─────────────────────────────────────────────
func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue

		var props := _get_property_names(data_obj)
		if not ("note_type" in props and "time" in props):
			continue

		var sel_type := int(data_obj.get("note_type"))
		var time_val := int(data_obj.get("time"))

		var layer2 := _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)

		var lname := NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
		if lname == "SLIDE_CHAIN_PIECE_LEFT":
			lname = "SLIDE_LEFT"
		if lname == "SLIDE_CHAIN_PIECE_RIGHT":
			lname = "SLIDE_RIGHT"

		var layer_tag: String = "layer_" + lname + ( "2" if layer2 else "" )

		specs.append({
			"time": time_val,
			"note_type": sel_type,
			"layer": layer_tag,
			"note_obj": data_obj,
		})
	return specs


# ─────────────────────────────────────────────
# Helpers (same style as your other tools)
# ─────────────────────────────────────────────

func _find_scripts_module() -> HBEditorModule:
	if _editor == null:
		return null

	for m in _editor.modules:
		if m == null:
			continue
		# Look for the ScriptsModule by its script path
		var s = m.get_script()
		if s != null and s is Script:
			var path := String(s.resource_path)
			if path.ends_with("ScriptsModule.gd"):
				return m
	return null


func _run_tool(path: String) -> void:
	if _editor == null:
		push_warning("[VFXInspector] No editor context; cannot run tool.")
		return

	# Prefer the real ScriptsModule so ScriptRunnerScript changes go through UndoRedo
	var scripts_module := _find_scripts_module()
	if scripts_module != null and scripts_module.has_method("run_script"):
		scripts_module.run_script(path)
		return

	# Fallback: direct ScriptRunnerScript execution (JSON-only tools will still work)
	var res := load(path)
	if res == null:
		push_warning("[VFXInspector] Could not load tool at: " + path)
		return

	var inst = res.new()
	if inst == null:
		push_warning("[VFXInspector] Could not instance: " + path)
		return

	if inst is ScriptRunnerScript:
		var runner := inst as ScriptRunnerScript
		runner._editor = _editor
		if runner.has_method("init_script"):
			runner.init_script()
		if runner.has_method("run_script"):
			var rc := int(runner.run_script())
			if rc != OK:
				push_warning("[VFXInspector] Tool '%s' returned %d" % [path, rc])
		else:
			push_warning("[VFXInspector] ScriptRunner at %s has no run_script()." % path)
	elif inst.has_method("run"):
		inst.run(_editor)
	else:
		push_warning("[VFXInspector] Tool at %s has no supported entry point." % path)

func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	if obj.has_method("get"):
		var v = obj.get(prop)
		if v != null:
			return v
	return fallback

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"


func _format_value_entry(anim: String, entry: Dictionary, head_time: int) -> String:
	"""Format a single value entry for display."""
	var t_ms := int(entry.get("time", 0))
	var rel_t := t_ms - head_time
	var time_str := "@%dms (rel %+d)" % [t_ms, rel_t]
	
	# Debug: show what we have
	if DEBUG_INSPECTOR:
		print("[VFXInspector] _format_value_entry anim=%s entry keys=%s" % [anim, entry.keys()])
		for k in entry.keys():
			print("[VFXInspector]   %s = %s (type %d)" % [k, str(entry[k]), typeof(entry[k])])
	
	if anim.begins_with("Scale"):
		var parts := []
		for part in ["head", "target", "bar1", "bar2", "tail", "hold", "icon"]:
			var v = entry.get(part, null)
			if v != null:
				parts.append("%s=%.2f" % [part, float(v)])
		if parts.is_empty():
			var raw_keys = entry.get("_raw_keys", [])
			if not raw_keys.is_empty():
				return "%s  (raw keys: %s)" % [time_str, ", ".join(raw_keys)]
			return "%s  (no scale data)" % time_str
		return "%s  %s" % [time_str, ", ".join(parts)]
	
	elif anim.begins_with("Color"):
		var parts := []
		for part in ["head", "target", "bar1", "bar2", "tail", "hold", "icon"]:
			var v = entry.get(part, null)
			if v != null and typeof(v) == TYPE_ARRAY and v.size() >= 3:
				if v.size() >= 4:
					parts.append("%s=(%.2f,%.2f,%.2f,%.2f)" % [part, float(v[0]), float(v[1]), float(v[2]), float(v[3])])
				else:
					parts.append("%s=(%.2f,%.2f,%.2f)" % [part, float(v[0]), float(v[1]), float(v[2])])
		if parts.is_empty():
			var raw_keys = entry.get("_raw_keys", [])
			if not raw_keys.is_empty():
				return "%s  (raw keys: %s)" % [time_str, ", ".join(raw_keys)]
			return "%s  (no color data)" % time_str
		return "%s  %s" % [time_str, ", ".join(parts)]
	
	elif anim.begins_with("Rot"):
		var parts := []
		for part in ["head", "target", "bar1", "bar2", "tail", "hold", "icon"]:
			var v = entry.get(part, null)
			if v != null:
				parts.append("%s=%.1f°" % [part, float(v)])
		if parts.is_empty():
			var raw_keys = entry.get("_raw_keys", [])
			if not raw_keys.is_empty():
				return "%s  (raw keys: %s)" % [time_str, ", ".join(raw_keys)]
			return "%s  (no rotation data)" % time_str
		return "%s  %s" % [time_str, ", ".join(parts)]
	
	elif anim.begins_with("Offset"):
		var parts := []
		for part in ["head", "target", "bar1", "bar2", "tail", "hold", "icon"]:
			var v = entry.get(part, null)
			if v != null and typeof(v) == TYPE_ARRAY and v.size() >= 2:
				parts.append("%s=(%.1f,%.1f)" % [part, float(v[0]), float(v[1])])
		if parts.is_empty():
			return "%s  (no offset data)" % time_str
		return "%s  %s" % [time_str, ", ".join(parts)]
	
	elif anim.begins_with("Glow"):
		var intensity = entry.get("intensity", null)
		var color = entry.get("color", null)
		var parts := []
		if intensity != null:
			parts.append("intensity=%.2f" % float(intensity))
		if color != null and typeof(color) == TYPE_ARRAY and color.size() >= 3:
			parts.append("color=(%.2f,%.2f,%.2f)" % [float(color[0]), float(color[1]), float(color[2])])
		if parts.is_empty():
			return "%s  (no glow data)" % time_str
		return "%s  %s" % [time_str, ", ".join(parts)]
	
	elif anim.begins_with("Spot"):
		var intensity = entry.get("intensity", null)
		var color = entry.get("color", null)
		var radius = entry.get("radius", null)
		var softness = entry.get("softness", null)
		var parts := []
		if intensity != null:
			parts.append("intensity=%.2f" % float(intensity))
		if color != null and typeof(color) == TYPE_ARRAY and color.size() >= 3:
			parts.append("color=(%.2f,%.2f,%.2f)" % [float(color[0]), float(color[1]), float(color[2])])
		if radius != null:
			parts.append("radius=%.0f" % float(radius))
		if softness != null:
			parts.append("softness=%.2f" % float(softness))
		if parts.is_empty():
			return "%s  (no spotlight data)" % time_str
		return "%s  %s" % [time_str, ", ".join(parts)]
	
	return "%s  (unknown anim type)" % time_str


func _get_value(row: Dictionary, keys: Array):
	"""Try multiple possible key names and return the first found value."""
	for k in keys:
		if row.has(k):
			return row[k]
	return null
