# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:True Default (Chords)
#meta:description:Resets selected chords (2+ notes at the same time) to editor defaults: chord rows, motion, and diagonal multi angles.
#meta:usage:Select a chord (2+ notes sharing the same time) and run.

extends ScriptRunnerScript

const DEBUG_MULTI_DEFAULT := false

func _dbg(msg: String) -> void:
	if DEBUG_MULTI_DEFAULT:
		print("[TrueMultiDefault] ", msg)


func run_script() -> int:
	if _editor == null:
		push_error("[TrueMultiDefault] No editor context.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[TrueMultiDefault] No notes selected.")
		return ERR_DOES_NOT_EXIST

	# Work on ScriptRunner clones (so changes go through the ScriptsModule undo pipeline)
	var tps := get_selected_timing_points()
	if tps.is_empty():
		push_error("[TrueMultiDefault] No timing points resolved from selection.")
		return ERR_DOES_NOT_EXIST

	# Group selected notes by time (chords = 2+ notes sharing a time)
	var groups := {}
	for tp in tps:
		if tp == null:
			continue

		var props := _get_property_names(tp)
		if not ("time" in props and "position" in props and "note_type" in props and "distance" in props):
			continue  # not a normal note timing point

		var t_ms := int(tp.time)
		if not groups.has(t_ms):
			groups[t_ms] = []
		groups[t_ms].append(tp)

	var changed_any := false

	for t_ms in groups.keys():
		var group: Array = groups[t_ms]
		if group.size() < 2:
			continue

		_reset_chord_group(group)
		changed_any = true

	if not changed_any:
		print("[TrueMultiDefault] No chord groups found (need ≥2 notes at the same time).")
		return OK

	print("[TrueMultiDefault] ✅ Reset chord groups to true defaults (rows + motion + diagonal angles).")
	return OK


func _reset_chord_group(group: Array) -> void:
	# 1) Compute multi_pos for each note (same scheme as HBEditor._set_multi_pos)
	for note in group:
		var multi_pos := _calc_multi_pos(note)
		note.set_meta("multi_pos", multi_pos)

		# Default chord row: 918 - multi_pos * 96 (same as editor multi rows)
		var new_y := 918 - multi_pos * 96
		var new_pos := Vector2(note.position.x, new_y)

		set_timing_point_property(note, "position", new_pos)
		set_timing_point_property(note, "distance", 880.0)
		set_timing_point_property(note, "oscillation_amplitude", 0.0)
		set_timing_point_property(note, "oscillation_frequency", -2.0)

		# Mark as *not* manually positioned so future timing tweaks can autoplace/multi again
		if "pos_modified" in _get_property_names(note):
			set_timing_point_property(note, "pos_modified", false)

	# 2) Assign angles like HBEditor._set_multi_angles (multi_pos-based diagonals)
	group.sort_custom(func(a, b):
		return int(a.get_meta("multi_pos")) > int(b.get_meta("multi_pos"))
	)

	var size := group.size()
	for i in range(size):
		var note = group[i]
		var angle := -90.0  # fallback straight down

		# If note supports multi rules, mimic editor:
		# - 2-note chord: [-45, +45]
		# - 3+ notes: outer rows -45, inner rows +45 (based on multi_pos)
		var ok_multi := true
		if note.has_method("is_multi_allowed"):
			ok_multi = note.is_multi_allowed()

		if ok_multi:
			if size == 2:
				angle = -45.0 if i == 0 else 45.0
			elif size > 2:
				var multi_pos := int(note.get_meta("multi_pos"))
				angle = -45.0 if multi_pos > 1 else 45.0

		set_timing_point_property(note, "entry_angle", angle)


func _calc_multi_pos(note: Object) -> int:
	# Mirrors HBEditor._set_multi_pos so our rows/angles match native multi behavior.
	var nt := int(note.note_type)
	var multi_pos := 3 - nt

	var second_layer := false
	if note.has_method("has_meta") and note.has_meta("second_layer"):
		second_layer = bool(note.get_meta("second_layer"))

	if nt == HBBaseNote.NOTE_TYPE.SLIDE_LEFT or nt == HBBaseNote.NOTE_TYPE.SLIDE_CHAIN_PIECE_LEFT:
		multi_pos = 3 if second_layer else 1
	elif nt == HBBaseNote.NOTE_TYPE.SLIDE_RIGHT or nt == HBBaseNote.NOTE_TYPE.SLIDE_CHAIN_PIECE_RIGHT:
		multi_pos = 2 if second_layer else 0
	elif nt == HBBaseNote.NOTE_TYPE.HEART:
		multi_pos = 4

	return multi_pos


func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out
