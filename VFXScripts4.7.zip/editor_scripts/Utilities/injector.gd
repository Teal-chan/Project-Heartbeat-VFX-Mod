extends Node
class_name PHVFXMegaInjector

# CAVEAT! Notes placed early in the chart with a starting time that has to be -0 will cause animated VFX failure.
# This is a bug that affects the whole game and the mod can't do much to fix it.
# Only use VFX after a proper delay of at least 1 measure of the song.

const LATENCY_BIAS_MS := 0.0

const VFX_META_ORIG_MAT := "_vfx_orig_material"
const VFX_META_SM       := "_vfx_sm"

const OVERLAY_NAME := "NoteSpotlightOverlay_ColorRect"

const NOTE_VFX_SHADER_PATH := "user://editor_scripts/Shaders/note_vfx.gdshader"
const SPOT_OVERLAY_SHADER_PATH := "user://editor_scripts/Shaders/spot_overlay.gdshader"

const PHVFXAnimBank = preload("user://editor_scripts/Utilities/ph_vfx_anim_bank.gd")
var anim_bank := PHVFXAnimBank.new()

# Mirai link rows read from the VFX JSON ($MIRAI_LINK layer)
var _mirai_rows: Array = []

# --- config / IO ---
var editor: Node = null
var json_path: String = ""

# fullscreen spotlight overlays
var overlay_preview: ColorRect = null
var overlay_playtest: ColorRect = null

# spotlight overlay shader
var _spot_overlay_shader: Shader = null

# merged event index cursor (preview only — playtest uses direct lookup)
var _active_keys: Dictionary = {}
var _cursor_idx: int = 0
var _last_tick_ms: float = -1.0

# reverse maps for fast drawer lookup (notes only; trails get their own maps)
var _rev_map_preview: Dictionary = {}   # key -> Array[Node] (note drawers)
var _rev_map_playtest: Dictionary = {}  # key -> Array[Node] (note drawers)

# per-key trail roots, driven by note_data identity – we never touch their shader.
var _rev_trails_preview: Dictionary = {}   # key -> Array[Node]
var _rev_trails_playtest: Dictionary = {}  # key -> Array[Node]

# note_data → key maps to link trail drawers to their notes
var _note_data_to_key_preview: Dictionary = {}   # Object -> String
var _note_data_to_key_playtest: Dictionary = {}  # Object -> String

# --- Mirai link lines (Project Mirai style) ---
var _mirai_links_preview: Array = []        # [{first: Node, last: Node, line: Line2D}]
var _mirai_links_playtest: Array = []       # same for playtest
var _mirai_line_root_preview: Node2D = null
var _mirai_line_root_playtest: Node2D = null

# persistent pools for diff-based Mirai link sync (avoids destroy/recreate churn)
var _mirai_link_pool_preview: Dictionary = {}   # "head_key|tail_key" -> {first, last, line}
var _mirai_link_pool_playtest: Dictionary = {}  # same for playtest

# preview graph
var prev_root: Node = null
var drawers: Array = []
var drawer_key: Dictionary = {}         # Node -> key
var parts: Dictionary = {}              # Node -> part dict

# playtest graph
var popup: Node = null
var rg_logic: Node = null
var pt_root: Node = null
var pt_drawers: Array = []
var pt_drawer_key: Dictionary = {}
var pt_parts: Dictionary = {}

# timers
var poll_popup: Timer = null
var poll_refresh: Timer = null

# playback helpers
var last_ms: float = -1.0
var wall_bind_ms: float = -1.0
var last_editor_ms: float = -1.0

# simple frame counter for throttling some visual-only updates
var _frame_index: int = 0

# global scene-tree connection
var _tree_connected: bool = false
var _seen_drawer_ids: Dictionary = {}   # instance_id -> true

# live segment sets (continuous updates between rows)
var _live_prev: Dictionary = {}         # key -> end_time
var _live_pt: Dictionary = {}           # key -> end_time

# last trail update times (ms) per key, so we don't update trails every frame
var _trail_last_t_preview: Dictionary = {}   # key -> last t_ms
var _trail_last_t_playtest: Dictionary = {}  # key -> last t_ms


# local shader (for note VFX)
var _local_shader: Shader = null

# keys that have any VFX rows associated with them (animations, spotlights, Mirai links, etc.)
var _keys_with_vfx: Dictionary = {}

# per-frame sampling caches (preview / playtest)
var _frame_sample_time_preview: int = -1
var _frame_sample_cache_preview: Dictionary = {}

var _frame_sample_time_playtest: int = -1
var _frame_sample_cache_playtest: Dictionary = {}


# ------------- helpers -------------

func _load_shader(path: String) -> Shader:
	var res = load(path)
	if res is Shader:
		return res
	push_error("[PH_VFX_MegaInjector] Failed to load shader at %s" % path)
	return null

func configure(p_editor: Node, p_json: String) -> void:
	editor = p_editor
	json_path = p_json

func configure_runtime(p_controller: Node, p_json: String) -> void:
	# Runtime entrypoint: no editor, no playtest popup.
	editor = null
	popup = p_controller
	rg_logic = p_controller
	json_path = p_json

	# Use the controller as the visual root for runtime.
	pt_root = p_controller

	# Reset playtest-side caches.
	pt_drawers.clear()
	pt_drawer_key.clear()
	pt_parts.clear()
	_rev_map_playtest.clear()
	_rev_trails_playtest.clear()
	_note_data_to_key_playtest.clear()
	_live_pt.clear()
	_active_keys.clear()
	_cursor_idx = 0
	_last_tick_ms = -1.0

	_trail_last_t_playtest.clear()

	# Load VFX events.
	anim_bank.load_from_json(json_path)

	_reload_mirai_rows()
	_rebuild_keys_with_vfx()
	
	# Build drawer cache under pt_root (mirrors playtest path).
	_build_playtest_cache()

	# Start driving things (process only, no physics).
	set_process(true)
	process_priority = -1024
	_tick()



func arm() -> void:
	anim_bank.load_from_json(json_path)
	_reload_mirai_rows()
	_rebuild_keys_with_vfx()
	_build_preview_cache()
	_bind_popup_path()
	_connect_editor_signals()
	_connect_tree_global()
	_start_pollers()

	# Only use _process, not _physics_process.
	set_process(true)
	process_priority = -1024
	_tick()


func disarm() -> void:
	_disconnect_editor_signals()
	_disconnect_tree_global()
	_stop_pollers()
	set_process(false)

	anim_bank.clear()

	_active_keys.clear()
	_cursor_idx = 0
	_last_tick_ms = -1.0

	_rev_map_preview.clear()
	_rev_map_playtest.clear()
	_rev_trails_preview.clear()
	_rev_trails_playtest.clear()
	_note_data_to_key_preview.clear()
	_note_data_to_key_playtest.clear()

	drawers.clear()
	drawer_key.clear()
	parts.clear()
	pt_drawers.clear()
	pt_drawer_key.clear()
	pt_parts.clear()

	prev_root = null
	pt_root = null
	popup = null
	rg_logic = null
	_seen_drawer_ids.clear()
	_live_prev.clear()
	_live_pt.clear()
	_trail_last_t_preview.clear()
	_trail_last_t_playtest.clear()
	_frame_sample_time_preview = -1
	_frame_sample_cache_preview.clear()
	_frame_sample_time_playtest = -1
	_frame_sample_cache_playtest.clear()




	# Mirai link lines — free from pools (complete set)
	for lid in _mirai_link_pool_preview.keys():
		var entry: Dictionary = _mirai_link_pool_preview[lid]
		var line = entry.get("line", null)
		if line != null and is_instance_valid(line):
			line.queue_free()
	for lid2 in _mirai_link_pool_playtest.keys():
		var entry2: Dictionary = _mirai_link_pool_playtest[lid2]
		var line2 = entry2.get("line", null)
		if line2 != null and is_instance_valid(line2):
			line2.queue_free()
	_mirai_links_preview.clear()
	_mirai_links_playtest.clear()
	_mirai_link_pool_preview.clear()
	_mirai_link_pool_playtest.clear()
	_mirai_line_root_preview = null
	_mirai_line_root_playtest = null

	if overlay_preview != null and is_instance_valid(overlay_preview):
		overlay_preview.queue_free()
	if overlay_playtest != null and is_instance_valid(overlay_playtest):
		overlay_playtest.queue_free()
	overlay_preview = null
	overlay_playtest = null


func reload_now() -> void:
	anim_bank.load_from_json(json_path)
	_reload_mirai_rows()
	_rebuild_keys_with_vfx()
	_build_preview_cache()
	_bind_popup_path()

	var ev_times := anim_bank._events_times
	if ev_times.size() > 0:
		_cursor_idx = ev_times.bsearch(int(max(_now_preview_ms(), 0.0)))
	else:
		_cursor_idx = 0

	_active_keys.clear()
	_frame_sample_time_preview = -1
	_frame_sample_cache_preview.clear()
	_frame_sample_time_playtest = -1
	_frame_sample_cache_playtest.clear()
	_tick()


func _get_shader() -> Shader:
	if _local_shader == null:
		_local_shader = _load_shader(NOTE_VFX_SHADER_PATH)
		if _local_shader == null:
			_local_shader = Shader.new()
	return _local_shader


func _get_spot_overlay_shader() -> Shader:
	if _spot_overlay_shader == null:
		_spot_overlay_shader = _load_shader(SPOT_OVERLAY_SHADER_PATH)
		if _spot_overlay_shader == null:
			_spot_overlay_shader = Shader.new()
	return _spot_overlay_shader


func _ensure_sm(ci: CanvasItem) -> ShaderMaterial:
	if ci == null:
		return null
	if not ci.has_meta(VFX_META_ORIG_MAT):
		ci.set_meta(VFX_META_ORIG_MAT, ci.material)
	var sm := ci.material as ShaderMaterial
	if sm == null or sm.shader == null or sm.shader != _get_shader():
		sm = ShaderMaterial.new()
		sm.shader = _get_shader()
		sm.resource_local_to_scene = true
		ci.use_parent_material = false
		ci.material = sm
		# Mark that we just reasserted — caller may need to dirty caches
		ci.set_meta("_vfx_sm_reasserted", true)
	ci.set_meta(VFX_META_SM, sm)
	return sm


func _pivot_for(ci: CanvasItem) -> Vector2:
	if ci == null or not is_instance_valid(ci):
		return Vector2.ZERO

	# Cache the pivot per node so we don't recompute it every frame.
	if ci.has_meta("_vfx_pivot"):
		var cached := ci.get_meta("_vfx_pivot")
		if cached is Vector2:
			return cached

	var pivot := Vector2.ZERO

	if ci is Sprite2D:
		var s := ci as Sprite2D
		if s.centered:
			pivot = Vector2.ZERO
		elif s.region_enabled:
			pivot = s.region_rect.size * 0.5 - s.offset
		else:
			var sz := Vector2.ZERO
			if s.texture != null:
				sz = s.texture.get_size()
			pivot = sz * 0.5 - s.offset
	elif ci is Control:
		pivot = (ci as Control).size * 0.5
	elif ci.has_method("get_item_rect"):
		var r: Rect2 = ci.call("get_item_rect")
		pivot = r.position + r.size * 0.5

	ci.set_meta("_vfx_pivot", pivot)
	return pivot


# Store scale/rotation/offset on the node; we commit all three at once via _commit_transform.
func _set_scale(ci: CanvasItem, s: float) -> void:
	if ci == null or not is_instance_valid(ci):
		return
	ci.set_meta("_vfx_scale", s)


func _set_rotation(ci: CanvasItem, deg: float) -> void:
	if ci == null or not is_instance_valid(ci):
		return
	ci.set_meta("_vfx_rot_deg", deg)


func _set_offset(ci: CanvasItem, ofs: Vector2) -> void:
	if ci == null or not is_instance_valid(ci):
		return
	ci.set_meta("_vfx_offset", ofs)


func _set_color(ci: CanvasItem, col: Color) -> void:
	var sm := _ensure_sm(ci)
	if sm == null:
		return
	sm.set_shader_parameter("override_color", col)
	ci.queue_redraw()


func _set_glow(ci: CanvasItem, g: float) -> void:
	if ci == null or not is_instance_valid(ci):
		return
	var sm := _ensure_sm(ci)
	if sm == null:
		return
	sm.set_shader_parameter("u_glow", g)
	ci.queue_redraw()


# Compute and apply packed transform for a CanvasItem:
#   x' = M * x + T, with pivot/scale/rotation/offset baked in.
func _commit_transform(ci: CanvasItem) -> void:
	if ci == null or not is_instance_valid(ci):
		return

	var sm := _ensure_sm(ci)
	if sm == null:
		return

	var scale: float = 1.0
	if ci.has_meta("_vfx_scale"):
		scale = float(ci.get_meta("_vfx_scale"))

	var rot_deg: float = 0.0
	if ci.has_meta("_vfx_rot_deg"):
		rot_deg = float(ci.get_meta("_vfx_rot_deg"))

	var ofs: Vector2 = Vector2.ZERO
	if ci.has_meta("_vfx_offset"):
		ofs = ci.get_meta("_vfx_offset")

	var pivot := _pivot_for(ci)

	var s := scale
	var rad := deg_to_rad(rot_deg)
	var c := cos(rad)
	var sn := sin(rad)

	# M = R * S, with uniform scalar scale
	var a := c * s
	var b := -sn * s
	var c2 := sn * s
	var d := c * s

	# x' = R * S * (x - pivot) + pivot + ofs
	#    = M * x + (-M * pivot + pivot + ofs)
	var mp := Vector2(
		a * pivot.x + b * pivot.y,
		c2 * pivot.x + d * pivot.y
	)
	var T := pivot + ofs - mp

	sm.set_shader_parameter("u_trs0", Vector4(a, b, c2, d))
	sm.set_shader_parameter("u_trs1", T)
	ci.queue_redraw()


func _is_under_trails_layer(n: Node) -> bool:
	var cur := n
	while cur != null:
		var nm := String(cur.name).to_lower()
		if nm.findn("layer_trails") != -1:
			return true
		cur = cur.get_parent()
	return false


func _is_trail_drawer(d: Node) -> bool:
	if d == null:
		return false
	var nm := String(d.name).to_lower()
	if nm.findn("trail") != -1 or nm.findn("arrowline") != -1 or nm.findn("path") != -1:
		return true
	return _is_under_trails_layer(d)


func _rebuild_keys_with_vfx() -> void:
	_keys_with_vfx.clear()

	var ev_keys: Array = anim_bank._events_keys
	for ks in ev_keys:
		if typeof(ks) != TYPE_ARRAY:
			continue
		for k in ks:
			var key := String(k)
			if key != "":
				_keys_with_vfx[key] = true


func _reload_mirai_rows() -> void:
	_mirai_rows.clear()
	if json_path == "":
		return
	if not FileAccess.file_exists(json_path):
		return

	var f := FileAccess.open(json_path, FileAccess.READ)
	if f == null:
		return
	var parsed := JSON.parse_string(f.get_as_text())
	f.close()

	if typeof(parsed) != TYPE_ARRAY:
		return

	for e in parsed:
		if typeof(e) != TYPE_DICTIONARY:
			continue
		if String(e.get("layer", "")) != "$MIRAI_LINK":
			continue
		_mirai_rows.append(e)


func _ensure_mirai_line_root(is_preview: bool) -> Node2D:
	var root: Node = prev_root if is_preview else pt_root
	if root == null or not is_instance_valid(root):
		return null

	var parent: Node2D = null

	# Prefer GameLayer → LAYER_Trails if present
	var game_layer := root.find_child("GameLayer", true, false)
	if game_layer is Node2D:
		parent = game_layer as Node2D
		var trails := game_layer.get_node_or_null("LAYER_Trails")
		if trails is Node2D:
			parent = trails as Node2D
	elif root is Node2D:
		parent = root as Node2D

	if parent == null:
		return null

	var existing := parent.get_node_or_null("PH_MiraiLinkLines")
	var container: Node2D = existing as Node2D
	if container == null:
		container = Node2D.new()
		container.name = "PH_MiraiLinkLines"
		parent.add_child(container)
		parent.move_child(container, parent.get_child_count() - 1)
		container.z_index = -10
		container.z_as_relative = false

	if is_preview:
		_mirai_line_root_preview = container
	else:
		_mirai_line_root_playtest = container

	return container


func _sync_mirai_links(is_preview: bool) -> void:
	var pool := _mirai_link_pool_preview if is_preview else _mirai_link_pool_playtest
	var rev_map := _rev_map_preview if is_preview else _rev_map_playtest
	var lines_root := _ensure_mirai_line_root(is_preview)

	# Build set of desired link IDs from current mirai rows
	var desired: Dictionary = {}  # "head_key|tail_key" -> {head_key, tail_key}
	for row in _mirai_rows:
		if typeof(row) != TYPE_DICTIONARY:
			continue
		var head_key := String(row.get("head_key", ""))
		var tail_key := String(row.get("tail_key", ""))
		if head_key == "" or tail_key == "":
			continue
		var link_id := head_key + "|" + tail_key
		desired[link_id] = {"head_key": head_key, "tail_key": tail_key}

	# Remove pool entries that are no longer in the desired set
	var to_remove: Array[String] = []
	for lid in pool.keys():
		if not desired.has(lid):
			to_remove.append(String(lid))
	for lid2 in to_remove:
		var entry: Dictionary = pool[lid2]
		var line_node: Line2D = entry.get("line", null)
		if line_node != null and is_instance_valid(line_node):
			line_node.queue_free()
		pool.erase(lid2)

	# Sync each desired link: create if missing, update visibility based on drawer availability
	var active_links: Array = []
	for lid3 in desired.keys():
		var info: Dictionary = desired[lid3]
		var head_key := String(info["head_key"])
		var tail_key := String(info["tail_key"])

		# Look up current drawers
		var head_drawers: Array = rev_map.get(head_key, [])
		var tail_drawers: Array = rev_map.get(tail_key, [])
		var first_d: Node = head_drawers[0] if not head_drawers.is_empty() else null
		var last_d: Node = tail_drawers[0] if not tail_drawers.is_empty() else null
		var both_valid := (first_d != null and last_d != null
			and is_instance_valid(first_d) and is_instance_valid(last_d))

		if pool.has(lid3):
			# Already in pool — update drawer refs and visibility
			var entry: Dictionary = pool[lid3]
			var line_node: Line2D = entry.get("line", null)
			if line_node == null or not is_instance_valid(line_node):
				# Line was freed externally; remove from pool so it gets recreated
				pool.erase(lid3)
			else:
				entry["first"] = first_d
				entry["last"] = last_d
				line_node.visible = both_valid
				pool[lid3] = entry
				if both_valid:
					active_links.append(entry)
				continue

		# Not in pool yet — create if we have a lines_root
		if lines_root == null:
			continue

		var line := Line2D.new()
		line.name = "PH_MiraiLinkLine"
		line.width = 6.0
		line.default_color = Color(1.0, 1.0, 1.0, 0.8)
		line.begin_cap_mode = Line2D.LINE_CAP_ROUND
		line.end_cap_mode = Line2D.LINE_CAP_ROUND
		line.antialiased = true
		line.z_index = 0
		line.z_as_relative = true
		line.visible = both_valid

		lines_root.add_child(line)

		var entry := {
			"first": first_d,
			"last": last_d,
			"line": line,
		}
		pool[lid3] = entry
		if both_valid:
			active_links.append(entry)

	# Update the pool reference back
	if is_preview:
		_mirai_link_pool_preview = pool
		_mirai_links_preview = active_links
	else:
		_mirai_link_pool_playtest = pool
		_mirai_links_playtest = active_links


# ------------- discovery: preview + playtest -------------

func _build_preview_cache() -> void:
	drawers.clear()
	drawer_key.clear()
	parts.clear()
	_rev_map_preview.clear()
	_rev_trails_preview.clear()
	_note_data_to_key_preview.clear()

	prev_root = _preview_root()
	if prev_root == null:
		return

	_collect_drawers(prev_root, drawers)

	for d in drawers:
		if d == null or not is_instance_valid(d):
			continue
		var key := _key_for_drawer(d)
		if key == "":
			continue
		drawer_key[d] = key
		var pd := _parts_for_drawer(d)
		_init_part_state(pd)
		parts[d] = pd

		if not _is_trail_drawer(d):
			_register_rev_map(_rev_map_preview, key, d)
			var nd = d.get("note_data")
			if nd != null:
				_note_data_to_key_preview[nd] = key

	for d2 in drawers:
		if d2 == null or not is_instance_valid(d2):
			continue
		if not _is_trail_drawer(d2):
			continue
		var nd2 = d2.get("note_data")
		if nd2 == null:
			continue
		var key2 := _note_data_to_key_preview.get(nd2, "")
		if key2 == "":
			continue
		if not _rev_trails_preview.has(key2):
			_rev_trails_preview[key2] = []
		var arrp: Array = _rev_trails_preview[key2]
		arrp.append(d2)
		_rev_trails_preview[key2] = arrp

	var t0 := int(max(_now_preview_ms(), 0.0))
	for d3 in drawers:
		if d3 != null and is_instance_valid(d3) and not _is_trail_drawer(d3):
			_apply_one_drawer(d3, true, float(t0))
	for key_p in _rev_trails_preview.keys():
		_apply_trails_for_key(String(key_p), true, float(t0))

	_sync_mirai_links(true)


func _preview_root() -> Node:
	if editor == null:
		return null
	return editor.find_child("GamePreview", true, false)


func _bind_popup_path() -> void:
	popup = null
	rg_logic = null
	pt_root = null
	_rev_map_playtest.clear()
	_rev_trails_playtest.clear()
	_note_data_to_key_playtest.clear()

	if editor == null:
		return
	var pv := editor.get("rhythm_game_playtest_popup")
	if pv is Node:
		popup = pv as Node
	if popup == null or not popup.is_inside_tree():
		return

	var rg_prop := popup.get("rhythm_game")
	if rg_prop is Node:
		rg_logic = rg_prop as Node

	var root := popup.find_child("RhythmGame", true, false)
	if root == null:
		root = popup
	pt_root = root
	_build_playtest_cache()


func _build_playtest_cache() -> void:
	pt_drawers.clear()
	pt_drawer_key.clear()
	pt_parts.clear()
	_rev_map_playtest.clear()
	_rev_trails_playtest.clear()
	_note_data_to_key_playtest.clear()

	if pt_root == null:
		return

	_collect_drawers(pt_root, pt_drawers)

	for d in pt_drawers:
		if d == null or not is_instance_valid(d):
			continue
		if _is_trail_drawer(d):
			continue
		var key := _key_for_drawer(d)
		if key == "":
			continue
		pt_drawer_key[d] = key
		var pd := _parts_for_drawer(d)
		_init_part_state(pd)
		pt_parts[d] = pd
		_register_rev_map(_rev_map_playtest, key, d)

		var nd = d.get("note_data")
		if nd != null:
			_note_data_to_key_playtest[nd] = key

	for d2 in pt_drawers:
		if d2 == null or not is_instance_valid(d2):
			continue
		if not _is_trail_drawer(d2):
			continue
		var nd2 = d2.get("note_data")
		if nd2 == null:
			continue
		var key2 := _note_data_to_key_playtest.get(nd2, "")
		if key2 == "":
			continue
		if not _rev_trails_playtest.has(key2):
			_rev_trails_playtest[key2] = []
		var arr2: Array = _rev_trails_playtest[key2]
		arr2.append(d2)
		_rev_trails_playtest[key2] = arr2

	var tp0 := int(max(_now_playtest_ms(), 0.0))
	for d3 in pt_drawers:
		if d3 != null and is_instance_valid(d3) and not _is_trail_drawer(d3):
			_warm_seed_drawer(d3, false)
	for key_k in _rev_trails_playtest.keys():
		_apply_trails_for_key(String(key_k), false, float(tp0))

	_sync_mirai_links(false)


func _collect_drawers(root: Node, out: Array) -> void:
	if root == null:
		return
	if root.has_method("get"):
		var nd := root.get("note_data")
		if nd != null:
			out.append(root)
	for c in root.get_children():
		if c is Node:
			_collect_drawers(c, out)


func _key_for_drawer(d: Node) -> String:
	var nd := d.get("note_data")
	if nd == null:
		return ""
	if not (nd as Object).has_method("get"):
		return ""

	var nt_v := (nd as Object).get("note_type")
	var time_v := (nd as Object).get("time")
	if nt_v == null or time_v == null:
		return ""

	var nti := int(nt_v)
	var head_t := int(time_v)

	var lname := "UNKNOWN"
	match nti:
		0: lname = "UP"
		1: lname = "LEFT"
		2: lname = "DOWN"
		3: lname = "RIGHT"
		4, 6: lname = "SLIDE_LEFT"
		5, 7: lname = "SLIDE_RIGHT"
		8: lname = "HEART"

	var is_l2 := _is_layer2_from_obj(nd) or _is_layer2_from_obj(d)
	var layer_tag := "layer_%s%s" % [lname, ("2" if is_l2 else "")]
	return "%s@%d@%d" % [layer_tag, nti, head_t]


func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	if obj.has_method("get"):
		var v := obj.get(prop)
		if v != null:
			return v
	return fallback


func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false

	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true

	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true

	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true

	return false



func _parts_for_drawer(d: Node) -> Dictionary:
	var out: Dictionary = {}

	out["head"] = d.get_node_or_null("Note") as CanvasItem
	out["tail"] = d.get_node_or_null("Note2") as CanvasItem

	var target_ci: CanvasItem = null
	var nt_root := d.get_node_or_null("NoteTarget")
	if nt_root != null:
		var sp := nt_root.get_node_or_null("Sprite2D") as CanvasItem
		if sp != null:
			target_ci = sp
		else:
			for c in nt_root.get_children():
				if c is CanvasItem:
					target_ci = c
					break

	out["target"] = target_ci if target_ci != null else (nt_root as CanvasItem)
	out["target_root"] = nt_root

	var hold_nodes: Array = []
	_collect_named(d, "HoldTextSprite", hold_nodes)
	out["hold_nodes"] = hold_nodes

	var rush_nodes: Array = []
	_collect_named(d, "RushTextSprite", rush_nodes)
	# RushTextSprite may be bound to a layer (removed from drawer tree)
	# Try to get it via the drawer's property if not found
	if rush_nodes.is_empty():
		var rush_sprite = d.get("rush_text_sprite")
		if rush_sprite != null and rush_sprite is CanvasItem:
			rush_nodes.append(rush_sprite)
	out["rush_nodes"] = rush_nodes

	# Rush note graphic (the inflating note icon during rush phase)
	var rush_graphic_nodes: Array = []
	_collect_named(d, "RushNoteGraphic", rush_graphic_nodes)
	if rush_graphic_nodes.is_empty():
		var rush_graphic = d.get("rush_note_graphic")
		if rush_graphic != null and rush_graphic is CanvasItem:
			rush_graphic_nodes.append(rush_graphic)
	out["rush_graphic_nodes"] = rush_graphic_nodes

	# Rush timing bar (the rotating arm during rush phase)
	var rush_bar_nodes: Array = []
	_collect_named(d, "RushNoteTimingArm", rush_bar_nodes)
	if rush_bar_nodes.is_empty():
		var rush_bar = d.get("rush_timing_arm")
		if rush_bar != null and rush_bar is CanvasItem:
			rush_bar_nodes.append(rush_bar)
	out["rush_bar_nodes"] = rush_bar_nodes

	var trail_nodes: Array = []
	_collect_trails(d, trail_nodes)
	out["trail_nodes"] = trail_nodes

	# capture the hit collider AND remote transform under NoteTarget
	var hit_shape: CollisionShape2D = null
	var hit_rt: RemoteTransform2D = null
	if nt_root != null:
		for c in nt_root.get_children():
			if c is CollisionShape2D:
				hit_shape = c
			elif c is RemoteTransform2D:
				hit_rt = c

	out["hit_shape"] = hit_shape
	out["hit_rt"] = hit_rt

	# Will be filled in by _rebuild_hit_particle_map / _try_register_drawer
	out["hit_lane"] = null

	return out



func _collect_named(root: Node, exact: String, out: Array) -> void:
	if root == null:
		return
	if String(root.name) == exact:
		out.append(root)
	for c in root.get_children():
		if c is Node:
			_collect_named(c, exact, out)


func _collect_trails(root: Node, out: Array) -> void:
	if root == null:
		return
	var name_lower := String(root.name).to_lower()
	if root is CanvasItem:
		if name_lower.findn("trail") != -1 \
		or name_lower.findn("path") != -1 \
		or name_lower.findn("guide") != -1 \
		or name_lower.findn("arrowline") != -1:
			out.append(root)
	for c in root.get_children():
		if c is Node:
			_collect_trails(c, out)


func _register_rev_map(map: Dictionary, key: String, d: Node) -> void:
	if not map.has(key):
		map[key] = []
	var arr: Array = map[key]
	arr.append(d)
	map[key] = arr


func _init_part_state(p: Dictionary) -> void:
	# Already initialized?
	if p.has("_lastS"):
		return

	p["_lastS"] = {
		"h": -1.0, "t": -1.0, "tg": -1.0,
		"b1": -1.0, "b2": -1.0, "ho": -1.0,
		"ru": -1.0, "tr": -1.0
	}
	p["_lastC"] = {
		"h": Color(9,9,9,0), "t": Color(9,9,9,0), "tg": Color(9,9,9,0),
		"b1": Color(9,9,9,0), "b2": Color(9,9,9,0),
		"ho": Color(9,9,9,0), "ru": Color(9,9,9,0), "tr": Color(9,9,9,0)
	}
	p["_lastR"] = {
		"h": -9999.0, "t": -9999.0,
		"tg": -9999.0, "ho": -9999.0,
		"ru": -9999.0, "tr": -9999.0
	}
	p["_lastO"] = {
		"h":  Vector2(999999, 999999),
		"t":  Vector2(999999, 999999),
		"tg": Vector2(999999, 999999),
		"ho": Vector2(999999, 999999),
		"ru": Vector2(999999, 999999),
		"b1": Vector2(999999, 999999),
		"b2": Vector2(999999, 999999),
		"tr": Vector2(999999, 999999),
	}
	# per-part glow cache
	p["_lastG"] = {
		"h": -1.0, "t": -1.0, "tg": -1.0,
		"b1": -1.0, "b2": -1.0, "ho": -1.0,
		"ru": -1.0, "tr": -1.0
	}


func _warm_seed_drawer(d: Node, is_preview: bool) -> void:
	if d == null or not is_instance_valid(d):
		return

	if is_preview:
		if _is_trail_drawer(d):
			return
		var pd := _parts_for_drawer(d)
		_init_part_state(pd)
		parts[d] = pd
		var now_ms := int(max(_now_preview_ms(), 0.0))
		_apply_one_drawer(d, true, float(now_ms))

		var key := String(drawer_key.get(d, ""))
		if key != "":
			var seg_end := anim_bank._segment_end_time_for_key_at_time(key, now_ms)
			_live_prev[key] = seg_end
	else:
		if _is_trail_drawer(d):
			return
		var pd2 := _parts_for_drawer(d)
		_init_part_state(pd2)
		pt_parts[d] = pd2

		var now_ms_pt := int(max(_now_playtest_ms(), 0.0))
		_apply_one_drawer(d, false, float(now_ms_pt))

		var key_pt := String(pt_drawer_key.get(d, ""))
		if key_pt != "":
			var seg_end_pt := anim_bank._segment_end_time_for_key_at_time(key_pt, now_ms_pt)
			_live_pt[key_pt] = seg_end_pt

	var delays := [0.0, 0.01, 0.03]
	for secs in delays:
		var t := get_tree().create_timer(secs)
		t.timeout.connect(func():
			if not is_instance_valid(d):
				return
			if is_preview:
				if _is_trail_drawer(d):
					return
				var pd3 := _parts_for_drawer(d)
				_init_part_state(pd3)
				parts[d] = pd3
				var tnow := int(max(_now_preview_ms(), 0.0))
				_apply_one_drawer(d, true, float(tnow))
			else:
				if _is_trail_drawer(d):
					return
				var p2 := _parts_for_drawer(d)
				_init_part_state(p2)
				pt_parts[d] = p2
				var tnow_pt := int(max(_now_playtest_ms(), 0.0))
				_apply_one_drawer(d, false, float(tnow_pt)))

# ------------- editor hooks & pollers -------------

func _connect_editor_signals() -> void:
	if editor == null:
		return
	if not editor.is_connected("playhead_position_changed", Callable(self, "_on_editor_tick")):
		editor.playhead_position_changed.connect(Callable(self, "_on_editor_tick"))
	if not editor.is_connected("paused", Callable(self, "_on_editor_tick")):
		editor.paused.connect(Callable(self, "_on_editor_tick"))


func _disconnect_editor_signals() -> void:
	if editor == null:
		return
	if editor.is_connected("playhead_position_changed", Callable(self, "_on_editor_tick")):
		editor.playhead_position_changed.disconnect(Callable(self, "_on_editor_tick"))
	if editor.is_connected("paused", Callable(self, "_on_editor_tick")):
		editor.paused.disconnect(Callable(self, "_on_editor_tick"))


func _connect_tree_global() -> void:
	if _tree_connected or editor == null:
		return
	var tr := editor.get_tree()
	if not tr.is_connected("node_added", Callable(self, "_on_node_added_global")):
		tr.node_added.connect(Callable(self, "_on_node_added_global"))
	_tree_connected = true


func _disconnect_tree_global() -> void:
	if not _tree_connected or editor == null:
		return
	var tr := editor.get_tree()
	if tr.is_connected("node_added", Callable(self, "_on_node_added_global")):
		tr.node_added.disconnect(Callable(self, "_on_node_added_global"))
	_tree_connected = false


func _start_pollers() -> void:
	if poll_popup == null:
		poll_popup = Timer.new()
		poll_popup.wait_time = 0.25
		poll_popup.one_shot = false
		add_child(poll_popup)
		poll_popup.timeout.connect(Callable(self, "_on_poll_popup"))
		poll_popup.start()
	if poll_refresh == null:
		poll_refresh = Timer.new()
		poll_refresh.wait_time = 0.4
		poll_refresh.one_shot = false
		add_child(poll_refresh)
		poll_refresh.timeout.connect(Callable(self, "_on_poll_refresh"))
		poll_refresh.start()


func _stop_pollers() -> void:
	if poll_popup != null:
		poll_popup.stop()
		poll_popup.queue_free()
		poll_popup = null
	if poll_refresh != null:
		poll_refresh.stop()
		poll_refresh.queue_free()
		poll_refresh = null


func _on_editor_tick() -> void:
	_tick()


func _on_poll_popup() -> void:
	if popup == null or not popup.is_inside_tree():
		_bind_popup_path()


func _on_poll_refresh() -> void:
	if prev_root == null or not is_instance_valid(prev_root):
		_build_preview_cache()
	if pt_root == null or (popup != null && !popup.is_inside_tree()):
		_bind_popup_path()

	if prev_root != null:
		_sync_mirai_links(true)

	if pt_root != null:
		_light_rescan(pt_root, pt_drawers, pt_drawer_key, pt_parts, _rev_map_playtest, 1500)
		_sync_mirai_links(false)


func _on_node_added_global(n: Node) -> void:
	if n == null:
		return

	if prev_root != null and prev_root.is_inside_tree() and prev_root.is_ancestor_of(n):
		_try_register_drawer(n, drawers, drawer_key, parts, _rev_map_preview)

	if pt_root != null and pt_root.is_inside_tree() and pt_root.is_ancestor_of(n):
		_try_register_drawer(n, pt_drawers, pt_drawer_key, pt_parts, _rev_map_playtest)


func _try_register_drawer(n: Node, out_nodes: Array, key_map: Dictionary, part_map: Dictionary, rev: Dictionary) -> void:
	var d := n
	while d != null:
		if d.has_method("get"):
			var nd := d.get("note_data")
			if nd != null:
				var id := d.get_instance_id()
				if _seen_drawer_ids.has(id):
					return

				var key := _key_for_drawer(d)
				if key == "":
					return

				_seen_drawer_ids[id] = true
				out_nodes.append(d)
				key_map[d] = key

				var pd := _parts_for_drawer(d)
				_init_part_state(pd)
				part_map[d] = pd

				var is_prev := (prev_root != null and prev_root.is_inside_tree() and prev_root.is_ancestor_of(d))
				var is_pt := (pt_root != null and pt_root.is_inside_tree() and pt_root.is_ancestor_of(d))

				if is_prev:
					if not _is_trail_drawer(d):
						_register_rev_map(_rev_map_preview, key, d)
						_note_data_to_key_preview[nd] = key
						_warm_seed_drawer(d, true)
					else:
						var k_prev := _note_data_to_key_preview.get(nd, "")
						if k_prev != "":
							if not _rev_trails_preview.has(k_prev):
								_rev_trails_preview[k_prev] = []
							var arrp: Array = _rev_trails_preview[k_prev]
							arrp.append(d)
							_rev_trails_preview[k_prev] = arrp
				elif is_pt:
					if not _is_trail_drawer(d):
						_register_rev_map(_rev_map_playtest, key, d)
						_note_data_to_key_playtest[nd] = key
						_warm_seed_drawer(d, false)
					else:
						var k_pt := _note_data_to_key_playtest.get(nd, "")
						if k_pt != "":
							if not _rev_trails_playtest.has(k_pt):
								_rev_trails_playtest[k_pt] = []
							var arr2: Array = _rev_trails_playtest[k_pt]
							arr2.append(d)
							_rev_trails_playtest[k_pt] = arr2
				return
		d = d.get_parent()


func _light_rescan(root: Node, out_nodes: Array, key_map: Dictionary, part_map: Dictionary, rev: Dictionary, budget: int) -> void:
	var stack: Array = [root]
	var visited := 0
	while stack.size() > 0 and visited < budget:
		var node := stack.pop_back()
		visited += 1
		if node == null:
			continue
		_try_register_drawer(node, out_nodes, key_map, part_map, rev)
		for c_v in node.get_children():
			var c: Node = c_v
			if c != null:
				stack.append(c)


# ------------- timing -------------

func _now_preview_ms() -> float:
	if editor == null:
		return last_ms
	var p := editor.get("playhead_position")
	if typeof(p) == TYPE_INT or typeof(p) == TYPE_FLOAT:
		return float(p)
	return last_ms


func _find_first_audio_player(root: Node) -> AudioStreamPlayer:
	var stack: Array[Node] = [root]
	var visited := 0
	while stack.size() > 0 and visited < 10000:
		var n := stack.pop_back()
		visited += 1
		if n is AudioStreamPlayer:
			return n as AudioStreamPlayer
		for c_v in n.get_children():
			var c: Node = c_v
			if c != null:
				stack.append(c)
	return null


func _audio_time_ms() -> float:
	if rg_logic != null:
		var ap := rg_logic.get("audio_playback")
		if ap != null and (ap as Object).has_method("get_playback_position"):
			var base := float((ap as Object).call("get_playback_position"))
			if base > 0.0:
				var hi := base \
					+ AudioServer.get_time_since_last_mix() \
					- AudioServer.get_time_to_next_mix() \
					- AudioServer.get_output_latency() \
					+ (LATENCY_BIAS_MS / 1000.0)
				var ms := hi * 1000.0
				if ms > 0.0:
					return ms

		var game_v := rg_logic.get("game")
		if game_v != null:
			var g := game_v as Object
			if g.has_method("get_time_msec"):
				var tg := float(g.call("get_time_msec"))
				if tg > 0.0:
					return tg
			elif g is HBRhythmGameBase:
				var base_ms := float(g.time_msec)
				if base_ms > 0.0:
					return base_ms

	if popup != null:
		var asp := _find_first_audio_player(popup)
		if asp != null and asp.playing:
			var base_s := asp.get_playback_position()
			if base_s > 0.0:
				var hi_s := base_s \
					+ AudioServer.get_time_since_last_mix() \
					- AudioServer.get_time_to_next_mix() \
					- AudioServer.get_output_latency() \
					+ (LATENCY_BIAS_MS / 1000.0)
				var ms2 := hi_s * 1000.0
				if ms2 > 0.0:
					return ms2

	return 0.0


func _now_playtest_ms() -> float:
	var a := _audio_time_ms()
	if a > 0.0:
		return a

	var ed := _now_preview_ms()
	if ed >= 0.0:
		if last_editor_ms < 0.0 or abs(ed - last_editor_ms) > 0.001:
			last_editor_ms = ed
			wall_bind_ms = Time.get_ticks_msec()
			return ed
		if wall_bind_ms >= 0.0:
			return last_editor_ms + float(Time.get_ticks_msec() - wall_bind_ms)
		return ed

	return last_ms


# ------------- process/tick -------------

func _process(_dt: float) -> void:
	_tick()


func _tick() -> void:
	_frame_index += 1

	if prev_root == null or not is_instance_valid(prev_root):
		_build_preview_cache()
	if prev_root != null:
		var t := int(max(_now_preview_ms(), 0.0))
		last_ms = float(t)
		_advance_events_preview(t)
		_apply_active(true, t)
		_apply_live(true, t)

		# Only update heavy overlays / Mirai lines every other frame.
		if (_frame_index & 1) == 0:
			_update_spot_overlay(true, t)
			_update_mirai_lines(true)

	if popup != null and popup.is_inside_tree():
		var tp_raw := _now_playtest_ms()
		if tp_raw <= 0.0:
			return

		if pt_root == null or not is_instance_valid(pt_root) or pt_drawers.is_empty():
			_build_playtest_cache()

		if pt_root != null:
			var tp := int(max(tp_raw, 0.0))
			last_ms = float(tp)
			_populate_live_pt(tp)
			_apply_active(false, tp)
			_apply_live(false, tp)

			# Re-fetch parts each frame because the game may rebuild
			# child nodes (Note, NoteTarget, etc.) during the note lifecycle.
			for d_pt in pt_drawers:
				if d_pt != null and is_instance_valid(d_pt) and not _is_trail_drawer(d_pt):
					var pd_fresh := _parts_for_drawer(d_pt)
					_init_part_state(pd_fresh)
					pt_parts[d_pt] = pd_fresh
					_apply_one_drawer(d_pt, false, float(tp))
			for key_tr in _rev_trails_playtest.keys():
				_apply_trails_for_key(String(key_tr), false, float(tp))

			# Same throttling for runtime overlay / Mirai lines.
			if (_frame_index & 1) == 0:
				_update_spot_overlay(false, tp)
				_update_mirai_lines(false)



func _advance_events_preview(t_ms: int) -> void:
	# Cursor-walk for preview: advances through the merged event list as the
	# editor playhead moves forward.  Only touches _live_prev.
	var ev_times := anim_bank._events_times
	var ev_keys := anim_bank._events_keys
	if ev_times.is_empty():
		return

	if _last_tick_ms < 0.0 or t_ms < int(_last_tick_ms) - 50:
		_cursor_idx = ev_times.bsearch(t_ms)
	else:
		while _cursor_idx < ev_times.size() and ev_times[_cursor_idx] <= t_ms:
			var ks: Array = ev_keys[_cursor_idx]
			for k in ks:
				var key := String(k)
				_active_keys[key] = true
				var end_t := anim_bank._segment_end_time_for_key_at_time(key, ev_times[_cursor_idx])
				_live_prev[key] = end_t
			_cursor_idx += 1

	_last_tick_ms = float(t_ms)


func _populate_live_pt(t_ms: int) -> void:
	# Direct lookup for playtest: checks every VFX key against the current
	# time and populates _live_pt for any key whose animation spans t_ms.
	# This avoids the cursor-walk model which doesn't suit playtest timing.
	_live_pt.clear()
	for key_v in _keys_with_vfx.keys():
		var key := String(key_v)
		if anim_bank.key_active_at(key, t_ms):
			_active_keys[key] = true
			_live_pt[key] = t_ms

# --- per-key sampling cache (preview/playtest) ---

func _sample_all_for_key_cached(key: String, t_ms: int, is_preview: bool) -> Dictionary:
	if key == "":
		return {}
	if anim_bank == null:
		return {}

	var cur_time := _frame_sample_time_preview if is_preview else _frame_sample_time_playtest
	var cache := _frame_sample_cache_preview if is_preview else _frame_sample_cache_playtest

	# New frame (new t_ms) → clear cache for that mode
	if cur_time != t_ms:
		cur_time = t_ms
		cache.clear()

	# Hit cache?
	if cache.has(key):
		if is_preview:
			_frame_sample_time_preview = cur_time
			_frame_sample_cache_preview = cache
		else:
			_frame_sample_time_playtest = cur_time
			_frame_sample_cache_playtest = cache
		return cache[key]

	# Sample all five in one go
	var res := {
		"S": anim_bank._sample_scales_for_key(key, t_ms),
		"C": anim_bank._sample_colors_for_key(key, t_ms),
		"R": anim_bank._sample_rot_for_key(key, t_ms),
		"O": anim_bank._sample_offset_for_key(key, t_ms),
		"G": anim_bank._sample_glow_for_key(key, t_ms),
	}

	cache[key] = res

	if is_preview:
		_frame_sample_time_preview = cur_time
		_frame_sample_cache_preview = cache
	else:
		_frame_sample_time_playtest = cur_time
		_frame_sample_cache_playtest = cache

	return res


# --- trail helpers: width modulation from ScaleAbsAnim/v1 ---

func _apply_trail_width(tr: Node, S: Dictionary) -> void:
	if tr == null or not is_instance_valid(tr):
		return
	if not tr.has_method("get"):
		return

	var line_obj := tr.get("line")
	if line_obj == null or not (line_obj is Line2D):
		return

	var line := line_obj as Line2D

	if not tr.has_meta("_vfx_trail_base_width"):
		tr.set_meta("_vfx_trail_base_width", line.width)

	var base_width := float(tr.get_meta("_vfx_trail_base_width"))
	if base_width <= 0.0:
		return

	var target_scale := 1.0
	if S.has("target"):
		target_scale = float(S["target"])

	var clamped_scale := clamp(target_scale, 0.6, 1.6)
	var new_width: int = base_width * clamped_scale
	if abs(line.width - new_width) > 0.01:
		line.width = new_width

	# ── Taper support via SineDrawerSustain.set_taper() ──
	var taper_head := clamp(float(S.get("taper_head", 1.0)), 0.0, 2.0)
	var taper_tail := clamp(float(S.get("taper_tail", 1.0)), 0.0, 2.0)

	if tr.has_method("set_taper"):
		tr.set_taper(taper_head, taper_tail)


func _apply_trails_for_key(key: String, is_preview: bool, t_ms: float) -> void:
	var trails_map := _rev_trails_preview if is_preview else _rev_trails_playtest
	if not trails_map.has(key):
		return

	var t_int := int(t_ms)

	var samples := _sample_all_for_key_cached(key, t_int, is_preview)
	if samples.is_empty():
		return

	var O: Dictionary = samples["O"]
	var S: Dictionary = samples["S"]

	var arr: Array = trails_map[key]

	# Only move the trail root if there is a non-zero target offset.
	var target_ofs: Vector2 = O.get("target", Vector2.ZERO)
	var has_ofs := target_ofs != Vector2.ZERO

	for tr in arr:
		if tr != null and is_instance_valid(tr):
			if has_ofs:
				var R_trail := {}
				var O_trail := {"target": target_ofs}
				_apply_drawer_field_transform(tr, R_trail, O_trail)
			_apply_trail_width(tr, S)



func _apply_active(is_preview: bool, t_ms: int) -> void:
	if _active_keys.is_empty():
		return
	var keys := _active_keys.keys()
	for kv in keys:
		var k := String(kv)
		var arr: Array = (_rev_map_preview.get(k, []) if is_preview else _rev_map_playtest.get(k, []))
		for d in arr:
			if is_instance_valid(d):
				_apply_one_drawer(d, is_preview, float(t_ms))
		_apply_trails_for_key(k, is_preview, float(t_ms))
		_active_keys.erase(k)


func _apply_live(is_preview: bool, t_ms: int) -> void:
	var live := _live_prev if is_preview else _live_pt
	if live.is_empty():
		return
	var to_erase: Array[String] = []
	for k_v in live.keys():
		var k := String(k_v)
		var end_t := int(live[k])
		var arr: Array = (_rev_map_preview.get(k, []) if is_preview else _rev_map_playtest.get(k, []))
		for d in arr:
			if is_instance_valid(d):
				_apply_one_drawer(d, is_preview, float(t_ms))
		_apply_trails_for_key(k, is_preview, float(t_ms))
		if t_ms > end_t + 4:
			to_erase.append(k)
	for k2 in to_erase:
		live.erase(k2)


# --- field transform for drawer root ---

func _apply_drawer_field_transform(root: Node, R: Dictionary, O: Dictionary, use_rotation: bool = true) -> void:
	if root == null or not (root is Node2D):
		return
	var n2d := root as Node2D

	if not n2d.has_meta("_vfx_base_pos"):
		n2d.set_meta("_vfx_base_pos", n2d.position)
	if not n2d.has_meta("_vfx_base_rot"):
		n2d.set_meta("_vfx_base_rot", n2d.rotation_degrees)
	if not n2d.has_meta("_vfx_last_ofs"):
		n2d.set_meta("_vfx_last_ofs", Vector2.ZERO)
	if not n2d.has_meta("_vfx_last_rot"):
		n2d.set_meta("_vfx_last_rot", 0.0)

	var base_pos: Vector2 = n2d.get_meta("_vfx_base_pos")
	var base_rot: float = n2d.get_meta("_vfx_base_rot")
	var target_ofs: Vector2 = O.get("target", Vector2.ZERO)
	var target_rot: float = 0.0
	if use_rotation:
		target_rot = float(R.get("target", 0.0))

	var new_pos := base_pos + target_ofs
	var new_rot := base_rot + target_rot

	if n2d.position != new_pos:
		n2d.position = new_pos
	if abs(n2d.rotation_degrees - new_rot) > 0.001:
		n2d.rotation_degrees = new_rot

	n2d.set_meta("_vfx_last_ofs", target_ofs)
	n2d.set_meta("_vfx_last_rot", target_rot)

func _apply_one_drawer(d: Node, is_preview: bool, t_ms: float) -> void:
	var key := ""
	var pmap: Dictionary = {}
	if is_preview:
		key = String(drawer_key.get(d, ""))
		pmap = parts
	else:
		key = String(pt_drawer_key.get(d, ""))
		pmap = pt_parts
	if key == "":
		return

	var t_int := int(t_ms)

	var samples := _sample_all_for_key_cached(key, t_int, is_preview)
	if samples.is_empty():
		return

	var S: Dictionary = samples["S"]
	var C: Dictionary = samples["C"]
	var R: Dictionary = samples["R"]
	var O: Dictionary = samples["O"]
	var G: Dictionary = samples["G"]

	_apply_drawer_field_transform(d, R, O, false)

	var target_ofs: Vector2 = O.target

	var O_rel := {
		"head":   O.head - O.target,
		"tail":   O.tail - O.target,
		"target": Vector2.ZERO,
		"hold":   O.hold - O.target,
		"rush":   O.rush - O.target,
		"bar1":   O.bar1 - O.target,
		"bar2":   O.bar2 - O.target,
	}

	var pd: Dictionary = pmap.get(d, {})
	if pd.is_empty():
		return

	# If the game overwrote our shader material on any part, dirty the caches
	# so _apply_parts_all re-applies all values this frame.
	if not is_preview:
		var _needs_dirty := false
		for _part_name in ["head", "tail", "target"]:
			var _ci = pd.get(_part_name, null)
			if _ci is CanvasItem and _ci.has_meta("_vfx_sm_reasserted"):
				_ci.remove_meta("_vfx_sm_reasserted")
				_needs_dirty = true
		if _needs_dirty:
			pd.erase("_lastS")
			_init_part_state(pd)

	_apply_parts_all(pd, S, C, R, O_rel, G, target_ofs)



func _apply_parts_all(
	p: Dictionary,
	S: Dictionary,
	C: Dictionary,
	R: Dictionary,
	O: Dictionary,
	G: Dictionary,
	target_ofs: Vector2
) -> void:
	if p.is_empty():
		return

	var LS: Dictionary = p["_lastS"]
	var LC: Dictionary = p["_lastC"]
	var LR: Dictionary = p["_lastR"]
	var LO: Dictionary = p["_lastO"]
	var LG: Dictionary = p["_lastG"]

	var head := p.get("head", null) as CanvasItem
	var tail := p.get("tail", null) as CanvasItem
	var target_root := p.get("target_root", null)
	var target_ci := p.get("target", null) as CanvasItem
	var holds: Array = p.get("hold_nodes", [])
	var hit_shape: CollisionShape2D = p.get("hit_shape", null)

	# -------- HEAD / TAIL / TARGET / HOLDS: SCALE --------
	if head != null and LS["h"] != S.head:
		_set_scale(head, S.head)
		LS["h"] = S.head

	if tail != null and LS["t"] != S.tail:
		_set_scale(tail, S.tail)
		LS["t"] = S.tail

	if target_ci != null and LS["tg"] != S.target:
		_set_scale(target_ci, S.target)
		LS["tg"] = S.target

	# -------- HEAD / TAIL / TARGET / HOLDS: COLOR --------
	if head != null and LC["h"] != C.head:
		_set_color(head, C.head)
		LC["h"] = C.head

	if tail != null and LC["t"] != C.tail:
		_set_color(tail, C.tail)
		LC["t"] = C.tail

	if target_ci != null and LC["tg"] != C.target:
		_set_color(target_ci, C.target)
		LC["tg"] = C.target

	# -------- ROTATION: HEAD / TAIL / TARGET / HOLDS --------
	if head != null and LR["h"] != R.head:
		_set_rotation(head, R.head)
		LR["h"] = R.head

	if tail != null and LR["t"] != R.tail:
		_set_rotation(tail, R.tail)
		LR["t"] = R.tail

	if target_ci != null and LR["tg"] != R.target:
		_set_rotation(target_ci, R.target)
		LR["tg"] = R.target

	# -------- OFFSET: HEAD / TAIL / TARGET / HOLDS --------
	if head != null and LO["h"] != O.head:
		_set_offset(head, O.head)
		LO["h"] = O.head

	if tail != null and LO["t"] != O.tail:
		_set_offset(tail, O.tail)
		LO["t"] = O.tail

	if target_ci != null and LO["tg"] != O.target:
		_set_offset(target_ci, O.target)
		LO["tg"] = O.target

	# -------- HOLDS: ALL PROPERTIES IN ONE PASS --------
	for h in holds:
		if not (h is CanvasItem):
			continue
		var hold_ci := h as CanvasItem

		if LS["ho"] != S.hold:
			_set_scale(hold_ci, S.hold)
			LS["ho"] = S.hold

		if LC["ho"] != C.hold:
			_set_color(hold_ci, C.hold)
			LC["ho"] = C.hold

		if LR["ho"] != R.hold:
			_set_rotation(hold_ci, R.hold)
			LR["ho"] = R.hold

		if LO["ho"] != O.hold:
			_set_offset(hold_ci, O.hold)
			LO["ho"] = O.hold

		if LG["ho"] != G.hold:
			_set_glow(hold_ci, G.hold)
			LG["ho"] = G.hold

	# -------- RUSH: ALL PROPERTIES IN ONE PASS --------
	var rushes: Array = p.get("rush_nodes", [])
	for r in rushes:
		if not is_instance_valid(r) or not (r is CanvasItem):
			continue
		var rush_ci := r as CanvasItem

		# Rush notes have external scaling (inflation), so check actual scale, not just cached value
		var current_scale: float = rush_ci.scale.x if rush_ci.scale.x == rush_ci.scale.y else 1.0
		var target_scale: float = float(S.rush)
		if LS["ru"] != target_scale or abs(current_scale - target_scale) > 0.001:
			_set_scale(rush_ci, target_scale)
			LS["ru"] = target_scale

		if LC["ru"] != C.rush:
			_set_color(rush_ci, C.rush)
			LC["ru"] = C.rush

		if LR["ru"] != R.rush:
			_set_rotation(rush_ci, R.rush)
			LR["ru"] = R.rush

		if LO["ru"] != O.rush:
			_set_offset(rush_ci, O.rush)
			LO["ru"] = O.rush

		if LG["ru"] != G.rush:
			_set_glow(rush_ci, G.rush)
			LG["ru"] = G.rush

	# -------- RUSH GRAPHIC: Additive scale (game sets base, we add offset) --------
	var rush_graphics: Array = p.get("rush_graphic_nodes", [])
	for rg in rush_graphics:
		if not is_instance_valid(rg) or not (rg is CanvasItem):
			continue
		var rg_ci := rg as CanvasItem
		
		# The game sets rush_note_graphic.scale every frame based on inflation
		# Use call_deferred to apply our scale AFTER the game's update
		var vfx_scale: float = float(S.rush_graphic)
		if abs(vfx_scale - 1.0) > 0.001:
			_apply_rush_graphic_scale_deferred.call_deferred(rg_ci, vfx_scale)
		
		# Color, rotation, offset, glow use rush_icon for the graphic
		if LC.get("rg") != C.rush_icon:
			_set_color(rg_ci, C.rush_icon)
			LC["rg"] = C.rush_icon
		
		if LR.get("rg") != R.rush_icon:
			_set_rotation(rg_ci, R.rush_icon)
			LR["rg"] = R.rush_icon
		
		if LO.get("rg") != O.rush_icon:
			_set_offset(rg_ci, O.rush_icon)
			LO["rg"] = O.rush_icon
		
		if LG.get("rg") != G.rush_icon:
			_set_glow(rg_ci, G.rush_icon)
			LG["rg"] = G.rush_icon
		
		# Commit transform to apply rotation/offset via shader
		_commit_transform(rg_ci)

	# -------- RUSH BAR: Color for the timing arm --------
	var rush_bars: Array = p.get("rush_bar_nodes", [])
	for rb in rush_bars:
		if not is_instance_valid(rb) or not (rb is CanvasItem):
			continue
		var rb_ci := rb as CanvasItem
		
		if LC.get("rb") != C.rush_bar:
			_set_color(rb_ci, C.rush_bar)
			LC["rb"] = C.rush_bar

	# -------- TARGET_ROOT CHILDREN: ONE PASS FOR SCALE/COLOR/OFFSET/GLOW --------
	if target_root != null:
		var tr_node := target_root as Node

		for child in tr_node.get_children():
			if not (child is CanvasItem):
				continue

			var ci_child := child as CanvasItem
			var cname := String(ci_child.name).to_lower()

			var is_timing2 := cname.findn("timingarm2") != -1
			var is_timing1 := (not is_timing2) and (cname.findn("timingarm") != -1 or cname.findn("bar") != -1)
			var is_sprite_or_target := (not is_timing1) and (not is_timing2) and (cname.findn("sprite") != -1 or cname.findn("target") != -1)

			# SCALE
			if is_timing2:
				if LS["b2"] != S.bar2:
					_set_scale(ci_child, S.bar2)
					LS["b2"] = S.bar2
			elif is_timing1:
				if LS["b1"] != S.bar1:
					_set_scale(ci_child, S.bar1)
					LS["b1"] = S.bar1
			elif is_sprite_or_target:
				if LS["tg"] != S.target:
					_set_scale(ci_child, S.target)
					LS["tg"] = S.target

			# COLOR
			if is_timing2:
				if LC["b2"] != C.bar2:
					_set_color(ci_child, C.bar2)
					LC["b2"] = C.bar2
			elif is_timing1:
				if LC["b1"] != C.bar1:
					_set_color(ci_child, C.bar1)
					LC["b1"] = C.bar1
			elif is_sprite_or_target:
				if LC["tg"] != C.target:
					_set_color(ci_child, C.target)
					LC["tg"] = C.target

			# OFFSET (only bars/arms get separate offsets)
			if is_timing2:
				if LO["b2"] != O.bar2:
					_set_offset(ci_child, O.bar2)
					LO["b2"] = O.bar2
			elif is_timing1:
				if LO["b1"] != O.bar1:
					_set_offset(ci_child, O.bar1)
					LO["b1"] = O.bar1

			# GLOW
			if is_timing2:
				if LG["b2"] != G.bar2:
					_set_glow(ci_child, G.bar2)
					LG["b2"] = G.bar2
			elif is_timing1:
				if LG["b1"] != G.bar1:
					_set_glow(ci_child, G.bar1)
					LG["b1"] = G.bar1
			elif is_sprite_or_target:
				if LG["tg"] != G.target:
					_set_glow(ci_child, G.target)
					LG["tg"] = G.target
			else:
				if target_root is CanvasItem:
					var trg_root_ci := target_root as CanvasItem
					if LG.get("tg_root", -1.0) != G.target:
						_set_glow(trg_root_ci, G.target)
						LG["tg_root"] = G.target

		# Root color (for misc children) – keep behaviour from original version.
		if target_root is CanvasItem:
			var trg_root_ci2 := target_root as CanvasItem
			if LC.get("tg_root", Color(9, 9, 9, 0)) != C.target:
				_set_color(trg_root_ci2, C.target)
				LC["tg_root"] = C.target

	# -------- GLOW: HEAD / TAIL / TARGET / HOLDS --------
	if head != null and LG["h"] != G.head:
		_set_glow(head, G.head)
		LG["h"] = G.head

	if tail != null and LG["t"] != G.tail:
		_set_glow(tail, G.tail)
		LG["t"] = G.tail

	if target_ci != null and LG["tg"] != G.target:
		_set_glow(target_ci, G.target)
		LG["tg"] = G.target

	# -------- COMMIT TRANSFORMS (apply packed TRS) --------
	if head != null:
		_commit_transform(head)
	if tail != null:
		_commit_transform(tail)
	if target_ci != null:
		_commit_transform(target_ci)

	for h6 in holds:
		if h6 is CanvasItem:
			_commit_transform(h6 as CanvasItem)

	for r6 in rushes:
		if r6 is CanvasItem:
			_commit_transform(r6 as CanvasItem)

	if target_root != null:
		var tr_node5 := target_root as Node
		for ch in tr_node5.get_children():
			if ch is CanvasItem:
				_commit_transform(ch as CanvasItem)


# --- overlay helpers ---

func _ensure_spot_overlay(is_preview: bool) -> ColorRect:
	var root: Node = prev_root if is_preview else pt_root
	if root == null or not is_instance_valid(root):
		return null

	var overlay: ColorRect = overlay_preview if is_preview else overlay_playtest
	if overlay == null or not is_instance_valid(overlay):
		overlay = root.get_node_or_null(OVERLAY_NAME) as ColorRect
		if overlay == null:
			overlay = ColorRect.new()
			overlay.name = OVERLAY_NAME
			overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
			overlay.color = Color(0, 0, 0, 0)
			root.add_child(overlay)
			root.move_child(overlay, root.get_child_count() - 1)

		if root is Control:
			var rc := root as Control
			overlay.anchor_left = 0.0
			overlay.anchor_top = 0.0
			overlay.anchor_right = 1.0
			overlay.anchor_bottom = 1.0
			overlay.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			overlay.size_flags_vertical = Control.SIZE_EXPAND_FILL
			overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		else:
			var vp := root.get_viewport()
			var vp_size := Vector2(1920, 1080)
			if vp != null:
				vp_size = vp.get_visible_rect().size
			overlay.position = Vector2.ZERO
			overlay.size = vp_size

		var sm := overlay.material as ShaderMaterial
		if sm == null:
			sm = ShaderMaterial.new()
			sm.shader = _get_spot_overlay_shader()
			overlay.material = sm
		elif sm.shader == null:
			sm.shader = _get_spot_overlay_shader()

		var osize: Vector2 = overlay.get_rect().size
		if osize.x <= 0.0 or osize.y <= 0.0:
			osize = overlay.size
		var aspect := 1.0
		if osize.y != 0.0:
			aspect = osize.x / osize.y
		sm.set_shader_parameter("u_screen_ratio", Vector2(aspect, 1.0))

		if is_preview:
			overlay_preview = overlay
		else:
			overlay_playtest = overlay

	return overlay


func _note_to_spot_uv(note_ci: CanvasItem, overlay: ColorRect) -> Vector2:
	if note_ci == null or overlay == null:
		return Vector2(0.5, 0.5)

	var note_tf: Transform2D = note_ci.get_global_transform_with_canvas()
	var rect_tf: Transform2D = overlay.get_global_transform_with_canvas()

	var local_center := Vector2.ZERO
	if note_ci.has_method("get_item_rect"):
		var r: Rect2 = note_ci.call("get_item_rect")
		local_center = r.position + r.size * 0.5
	elif note_ci is Control:
		local_center = (note_ci as Control).size * 0.5

	var note_center_canvas: Vector2 = note_tf * local_center
	var canvas_to_rect: Transform2D = rect_tf.affine_inverse()
	var note_in_rect: Vector2 = canvas_to_rect * note_center_canvas

	var size: Vector2 = overlay.get_rect().size
	if size.x <= 0.0 or size.y <= 0.0:
		size = overlay.size

	return Vector2(
		clamp(note_in_rect.x / max(size.x, 1.0), 0.0, 1.0),
		clamp(note_in_rect.y / max(size.y, 1.0), 0.0, 1.0)
	)


func _apply_rush_graphic_scale_deferred(ci: CanvasItem, vfx_scale: float) -> void:
	if not is_instance_valid(ci):
		return
	# Pure additive: only apply if VFX scale differs from 1.0
	if abs(vfx_scale - 1.0) < 0.001:
		return
	
	# Guard against multiple applications per frame
	var frame: int = Engine.get_process_frames()
	var last_frame: int = ci.get_meta("_vfx_rush_frame", -1)
	if last_frame == frame:
		return
	ci.set_meta("_vfx_rush_frame", frame)
	
	var offset: float = vfx_scale - 1.0
	ci.scale.x += offset
	ci.scale.y += offset


func _update_mirai_lines(is_preview: bool) -> void:
	var links_arr := _mirai_links_preview if is_preview else _mirai_links_playtest
	if links_arr.is_empty():
		return

	var pmap := parts if is_preview else pt_parts

	for link in links_arr:
		if not link.has("first") or not link.has("last") or not link.has("line"):
			continue

		var first_d: Node = link["first"]
		var last_d: Node = link["last"]
		var line: Line2D = link["line"]

		if line == null or not is_instance_valid(line):
			continue

		if first_d == null or last_d == null:
			line.visible = false
			continue
		if not (is_instance_valid(first_d) and is_instance_valid(last_d)):
			line.visible = false
			continue

		var pd1: Dictionary = pmap.get(first_d, {})
		var pd2: Dictionary = pmap.get(last_d, {})
		if pd1.is_empty() or pd2.is_empty():
			line.visible = false
			continue

		var anchor1: CanvasItem = pd1.get("target", null)
		if anchor1 == null:
			anchor1 = pd1.get("head", null)

		var anchor2: CanvasItem = pd2.get("target", null)
		if anchor2 == null:
			anchor2 = pd2.get("head", null)

		if anchor1 == null or anchor2 == null:
			line.visible = false
			continue

		var pos1 := anchor1.get_global_transform_with_canvas().origin
		var pos2 := anchor2.get_global_transform_with_canvas().origin

		var inv_tf := line.get_global_transform_with_canvas().affine_inverse()
		var p1_local := inv_tf * pos1
		var p2_local := inv_tf * pos2

		line.visible = true
		line.points = PackedVector2Array([p1_local, p2_local])


func _update_spot_overlay(is_preview: bool, t_ms: int) -> void:
	if anim_bank.buckets_spot.is_empty():
		var ov_none: ColorRect = overlay_preview if is_preview else overlay_playtest
		if ov_none != null and is_instance_valid(ov_none):
			var sm_none := ov_none.material as ShaderMaterial
			if sm_none != null:
				sm_none.set_shader_parameter("u_tint", Color(0, 0, 0, 0.0))
		return

	var overlay := _ensure_spot_overlay(is_preview)
	if overlay == null or not is_instance_valid(overlay):
		return

	var sm := overlay.material as ShaderMaterial
	if sm == null:
		return

	var best_key := ""
	var best_prio := -2147483648
	var best_start := -1
	var best_spot: Dictionary = {}
	var best_prev: Dictionary = {}
	var best_next: Dictionary = {}

	for key_v in anim_bank.buckets_spot.keys():
		var key := String(key_v)

		var times_for_key: PackedInt32Array = anim_bank.times_spot.get(key, PackedInt32Array())
		if times_for_key.is_empty():
			continue

		var first_t := times_for_key[0]
		var last_t := times_for_key[times_for_key.size() - 1]
		if t_ms < first_t or t_ms > last_t:
			continue

		var pair := anim_bank._pair_around_time(anim_bank.times_spot, anim_bank.buckets_spot, key, t_ms)
		var prev_r: Dictionary = pair[0]
		var next_r: Dictionary = pair[1]
		if prev_r.is_empty():
			continue

		var spot := anim_bank._sample_spot_for_key(key, t_ms)
		if not bool(spot.get("enable", false)):
			continue

		var prio0 := int(prev_r.get("spot_priority", prev_r.get("priority", 0)))
		var prio1 := prio0
		if not next_r.is_empty():
			prio1 = int(next_r.get("spot_priority", next_r.get("priority", prio0)))
		var prio := max(prio0, prio1)

		var start_time := int(prev_r.get("time", t_ms))

		if prio > best_prio or (prio == best_prio and start_time > best_start):
			best_prio = prio
			best_start = start_time
			best_key = key
			best_prev = prev_r
			best_next = next_r
			best_spot = spot

	if best_key == "" or best_spot.is_empty() or not bool(best_spot.get("enable", false)):
		sm.set_shader_parameter("u_tint", Color(0, 0, 0, 0.0))
		sm.set_shader_parameter("u_spot2_enable", false)
		return

	var rev_map := _rev_map_preview if is_preview else _rev_map_playtest
	var pmap := parts if is_preview else pt_parts
	var drawers_for_key: Array = rev_map.get(best_key, [])

	var head_ci: CanvasItem = null
	var target_ci: CanvasItem = null

	for d in drawers_for_key:
		if d == null or not is_instance_valid(d):
			continue
		var pd: Dictionary = pmap.get(d, {})
		if pd.is_empty():
			continue

		if head_ci == null:
			head_ci = pd.get("head", null) as CanvasItem
		if target_ci == null:
			target_ci = pd.get("target", null) as CanvasItem
		if head_ci != null and target_ci != null:
			break

	var base_radius := float(best_spot.get("radius", 0.12))
	var soft := float(best_spot.get("soft", 0.20))
	var dim := float(best_spot.get("dim", 0.15))

	var radius2_default := base_radius * 0.65
	var soft2_default := soft * 0.9
	var radius2 := float(best_spot.get("spot2_radius", radius2_default))
	var soft2 := float(best_spot.get("spot2_soft", soft2_default))

	var spot1_center := best_spot.get("center", Vector2(0.5, 0.5))
	if target_ci != null:
		spot1_center = _note_to_spot_uv(target_ci, overlay)
	elif head_ci != null:
		spot1_center = _note_to_spot_uv(head_ci, overlay)
	var spot1_radius := base_radius
	var spot1_soft := soft

	var have_spot2 := head_ci != null
	var spot2_center := spot1_center
	if head_ci != null:
		spot2_center = _note_to_spot_uv(head_ci, overlay)
	var spot2_radius := radius2
	var spot2_soft := soft2
	
	# During hold_end (past impact time), lock BOTH spotlights to target
	# Parse impact time from key: "layer@note_type@head_time"
	var key_parts := best_key.split("@")
	if key_parts.size() >= 3:
		var impact_time := int(key_parts[2])
		if t_ms > impact_time:
			# We're in hold_end phase - icon has passed target, lock both to target
			spot2_center = spot1_center

	var alpha := clamp(1.0 - dim, 0.0, 1.0)

	sm.set_shader_parameter("u_spot1_center", spot1_center)
	sm.set_shader_parameter("u_spot1_radius", spot1_radius)
	sm.set_shader_parameter("u_spot1_soft", spot1_soft)

	sm.set_shader_parameter("u_spot2_enable", have_spot2)
	if have_spot2:
		sm.set_shader_parameter("u_spot2_center", spot2_center)
		sm.set_shader_parameter("u_spot2_radius", spot2_radius)
		sm.set_shader_parameter("u_spot2_soft", spot2_soft)

	sm.set_shader_parameter("u_tint", Color(0, 0, 0, alpha))
