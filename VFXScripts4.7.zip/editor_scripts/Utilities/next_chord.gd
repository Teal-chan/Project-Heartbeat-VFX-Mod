# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Jump to next Chord
#meta:description:Jumps the playhead to the next time where 2 or more notes occur (a chord), without changing the current selection.
#meta:usage:Run to move to the next chord in the chart while keeping your selection untouched.

func run_script() -> int:
	if _editor == null:
		printerr("[JumpNextChord] ❌ No editor reference (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	if not _editor.has_method("get_timeline_items"):
		printerr("[JumpNextChord] ❌ Editor has no get_timeline_items().")
		return ERR_UNAVAILABLE
	
	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		print("[JumpNextChord] ℹ️ No timeline items found.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No timeline items found.")
		return OK
	
	# 1) Group timeline NOTE items by their note-data time (ms), like Select All Chord Notes
	var time_to_items := {}  # int -> Array[EditorTimelineItemNote]
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue
		
		var data = null
		if item.has_method("get"):
			data = item.get("data")
		if data == null:
			continue
		
		# Make sure the data actually has a time
		var t_val = null
		if data.has_method("get"):
			t_val = data.get("time")
		if t_val == null:
			continue
		
		var t := int(round(float(t_val)))
		
		if not time_to_items.has(t):
			time_to_items[t] = []
		time_to_items[t].append(item)
	
	# 2) Collect all times that actually form chords (>= 2 notes at that time)
	var chord_times: Array = []
	for t in time_to_items.keys():
		var at_time: Array = time_to_items[t]
		if at_time.size() >= 2:
			chord_times.append(int(t))
	
	if chord_times.is_empty():
		print("[JumpNextChord] ℹ️ No chords found in this chart.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No chords found in this chart.")
		return OK
	
	chord_times.sort()
	
	# 3) Find the next chord strictly after the current playhead
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	
	for t in chord_times:
		var ti: int = t
		if ti <= cur_ms + 1:
			continue
		best_time = ti
		break
	
	if best_time == -1:
		print("[JumpNextChord] ℹ️ No later chord found (past last chord).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No later chord found.")
		return OK
	
	# 4) Move playhead ONLY (selection unchanged)
	_seek_editor_to_ms(best_time)
	
	print("[JumpNextChord] 🎶 Jumped to next chord at ", best_time, " ms (selection unchanged).")
	if _editor.message_shower:
		_editor.message_shower._show_notification("🎶 Jumped to next chord at %d ms (selection unchanged)." % best_time)
	
	return OK


# --- helpers: time / seek --------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	
	return int(round(float(v)))


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)
	
	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms
	
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()
	
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()
