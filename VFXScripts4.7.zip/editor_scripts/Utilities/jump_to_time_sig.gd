extends ScriptRunnerScript

#meta:name:Jump to Nearest Time Signature Change
#meta:description:Moves the editor playhead to the closest time-signature marker.
#meta:usage:Run to snap playhead to the nearest time signature change.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpToNearestTS] No HBEditor reference.")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpToNearestTS] Editor has no get_timeline_items().")
		return ERR_UNCONFIGURED

	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ No timeline items found.")
		return OK

	# ---- Collect time-signature entries (duck-typed, similar to BPM script) ----
	var ts_entries: Array = []

	for item in items:
		if item == null:
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")

		var ts_val = null
		var time_val = null

		# Prefer time_signature/time on data if present
		if data != null and data.has_method("get"):
			ts_val = data.get("time_signature")
			time_val = data.get("time")

		# Fallback: check time_signature/time directly on the item (just in case)
		if ts_val == null and item.has_method("get"):
			ts_val = item.get("time_signature")
		if time_val == null and item.has_method("get"):
			time_val = item.get("time")

		if ts_val == null:
			continue  # Not a time-signature marker

		var t_ms := 0
		if time_val != null:
			t_ms = int(time_val)

		ts_entries.append({
			"time_ms": t_ms,
			"time_signature": ts_val,
		})

	if ts_entries.is_empty():
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ No time-signature markers found.")
		print("[JumpToNearestTS] No time-signature markers found.")
		return OK

	print("[JumpToNearestTS] Found %d time-signature markers." % ts_entries.size())

	# ---- Current playhead time ----
	var cur_time_ms: float = 0.0
	var p = _editor.get("playhead_position")
	if typeof(p) == TYPE_INT or typeof(p) == TYPE_FLOAT:
		cur_time_ms = float(p)

	# ---- Find nearest TS entry ----
	var best_entry = null
	var best_dist := 1.0e30  # large number

	for entry in ts_entries:
		var t_ms: int = entry["time_ms"]
		var dist := abs(cur_time_ms - float(t_ms))
		if dist < best_dist:
			best_dist = dist
			best_entry = entry

	if best_entry == null:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Could not determine nearest time-signature marker.")
		print("[JumpToNearestTS] best_entry is null after scan.")
		return OK

	var target_time_ms: int = best_entry["time_ms"]
	var ts_val = best_entry["time_signature"]
	var ts_str := _format_time_signature(ts_val)

	# ---- Clamp to song length (same pattern as your snap/BPM script) ----
	if _editor.current_song:
		var max_ms := int(_editor.get_song_length() * 1000.0)
		target_time_ms = clamp(target_time_ms, 0, max_ms)

	# ---- Move the playhead using the real seek API ----
	if _editor.has_method("seek"):
		_editor.seek(target_time_ms)
	else:
		_editor.playhead_position = target_time_ms

	# Ask the timeline to bring it into view, if possible
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	# Nudge the preview game loop if present
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	# ---- Feedback ----
	var msg := "[JumpToNearestTS] Jumped to time signature %s at %d ms (dist=%d ms)" \
		% [ts_str, target_time_ms, int(best_dist)]
	print(msg)
	if _editor.message_shower:
		_editor.message_shower._show_notification(msg)

	return OK


func _format_time_signature(ts_val) -> String:
	if ts_val == null:
		return "?"
	
	var num := -1
	var den := -1

	# Try to read numerator/denominator via get_property_list + get()
	if ts_val.has_method("get_property_list") and ts_val.has_method("get"):
		for p in ts_val.get_property_list():
			var pn := String(p.name)
			if pn == "numerator":
				var v_num = ts_val.get("numerator")
				if v_num != null:
					num = int(v_num)
			elif pn == "denominator":
				var v_den = ts_val.get("denominator")
				if v_den != null:
					den = int(v_den)

	if num > 0 and den > 0:
		return "%d/%d" % [num, den]

	# Fallback: whatever Godot prints for this object
	return str(ts_val)
