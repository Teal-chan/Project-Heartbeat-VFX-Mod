extends ScriptRunnerScript

#meta:name:Snap+Select Previous Chord
#meta:description:Jumps to the previous chord (2+ notes at the same time), selects all its notes, and shows a preview widget without switching to the Inspector tab.
#meta:usage:Run to move to the previous chord and replace the current selection with all notes in that chord.

func run_script() -> int:
	if _editor == null:
		push_error("[SnapSelectPrevChord] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[SnapSelectPrevChord] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		print("[SnapSelectPrevChord] No timeline items.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No timeline items.")
		return OK

	# --- group note items by time -------------------------------------------------
	var time_to_items: Dictionary = {}  # int -> Array[EditorTimelineItemNote]

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")
		if data == null:
			continue

		var t_ms := _get_time_from_item(item)
		if t_ms < 0:
			continue

		if not time_to_items.has(t_ms):
			time_to_items[t_ms] = []
		time_to_items[t_ms].append(item)

	# collect chord times (2+ notes at same time)
	var chord_times: Array = []
	for t in time_to_items.keys():
		var at_time: Array = time_to_items[t]
		if at_time.size() >= 2:
			chord_times.append(t)

	if chord_times.is_empty():
		print("[SnapSelectPrevChord] No chords found in this chart.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No chords found in this chart.")
		return OK

	# --- choose previous chord time before current playhead -----------------------
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1

	for t in chord_times:
		var ti: int = int(t)
		if ti >= cur_ms - 1:
			continue
		if best_time == -1 or ti > best_time:
			best_time = ti

	if best_time == -1:
		print("[SnapSelectPrevChord] No earlier chord found (before first chord).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No earlier chord found.")
		return OK

	var chord_items: Array = time_to_items[best_time]

	# --- move playhead + quiet-select ALL chord notes -----------------------------
	_seek_editor_to_ms(best_time)
	_select_items_quiet(chord_items)

	print("[SnapSelectPrevChord] ✅ Jumped to previous chord at %d ms (%d notes)." % [best_time, chord_items.size()])
	if _editor.message_shower:
		_editor.message_shower._show_notification("✅ Jumped to previous chord at %d ms (%d notes)." % [best_time, chord_items.size()])

	return OK


# --- helpers: time / seek --------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0

	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0

	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1

	var data = null
	if item.has_method("get"):
		data = item.get("data")

	var time_val = null
	if data != null and data.has_method("get"):
		time_val = data.get("time")

	if time_val == null and item.has_method("get"):
		time_val = item.get("time")

	if time_val == null:
		return -1

	return int(round(float(time_val)))


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)

	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


# --- helpers: quiet multi-selection + preview widget -----------------------------

func _select_items_quiet(items: Array) -> void:
	# 1) Deselect current selection
	if "selected" in _editor and _editor.selected is Array:
		for it in _editor.selected:
			if it == null or not is_instance_valid(it):
				continue
			if it.has_method("deselect"):
				it.deselect()
			elif it.has_method("set_selected"):
				it.call("set_selected", false)
		_editor.selected.clear()

	# 2) Select all items in the chord
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		_editor.selected.append(item)

		if item.has_method("select"):
			item.select()
		elif item.has_method("set_selected"):
			item.call("set_selected", true)

	# 3) Spawn a preview widget for the first item (so we don't spam widgets)
	if items.size() > 0:
		var first_item = items[0]
		_spawn_preview_widget_for_item(first_item)

	# 4) Notify editor that selection changed
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()


func _spawn_preview_widget_for_item(item: Object) -> void:
	if _editor == null:
		return
	if item == null or not is_instance_valid(item):
		return
	if not item.has_method("get_editor_widget"):
		return

	var widget_res = item.get_editor_widget()
	if widget_res == null:
		return

	if not ("game_preview" in _editor):
		return

	var gp = _editor.game_preview
	if gp == null:
		return
	if not ("widget_area" in gp):
		return

	var widget_instance = widget_res.instantiate()
	if widget_instance == null:
		return

	if "editor" in widget_instance:
		widget_instance.editor = _editor

	gp.widget_area.add_child(widget_instance)

	if item.has_method("connect_widget"):
		item.connect_widget(widget_instance)
