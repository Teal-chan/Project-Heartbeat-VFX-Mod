# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Jump to and select previous note (single, no inspector)
#meta:description:Moves the editor playhead to the previous note before the current time and selects only that note (clears previous selection), without switching to the Inspector tab.
#meta:usage:Run to move to the previous note on the timeline and replace the current selection quietly.

extends ScriptRunnerScript

func run_script() -> int:
	if _editor == null:
		push_error("[JumpPrevNoteSingleQuiet] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpPrevNoteSingleQuiet] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE
	
	var items: Array = _editor.get_timeline_items()
	var note_entries: Array = []   # each: { "time": int, "item": Object }
	
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue
		
		var t := _get_time_from_item(item)
		if t < 0:
			continue
		
		note_entries.append({ "time": t, "item": item })
	
	if note_entries.is_empty():
		print("[JumpPrevNoteSingleQuiet] No notes found on the timeline.")
		return OK
	
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	var best_item: Object = null
	
	# Find the largest note time strictly less than current playhead
	for entry in note_entries:
		var t: int = entry["time"]
		if t >= cur_ms - 1:
			continue
		if best_item == null or t > best_time:
			best_time = t
			best_item = entry["item"]
	
	if best_item == null:
		print("[JumpPrevNoteSingleQuiet] No earlier note found (already at or before the first note).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No earlier note found.")
		return OK
	
	_seek_editor_to_ms(best_time)
	_select_only_item_quiet(best_item)
	
	print("[JumpPrevNoteSingleQuiet] ◀ Jumped to previous note at ", best_time, " ms (selection replaced, quiet).")
	if _editor.message_shower:
		_editor.message_shower._show_notification("◀ Jumped to previous note at %d ms (selection replaced)" % best_time)
	
	return OK


# --- helpers -------------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	
	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	var data = null
	if item.has_method("get"):
		data = item.get("data")
	
	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))
	
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))
	
	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)
	
	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms
	
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()
	
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


func _select_only_item_quiet(item: Object) -> void:
	if item == null or not is_instance_valid(item):
		return
	
	# 1) Deselect everything currently selected WITHOUT using select_item()
	#    to avoid Inspector-tab focusing.
	if "selected" in _editor and _editor.selected is Array:
		for it in _editor.selected:
			if it == null or not is_instance_valid(it):
				continue
			if it.has_method("deselect"):
				it.deselect()
			elif it.has_method("set_selected"):
				it.call("set_selected", false)
		
		_editor.selected.clear()
	
	# 2) Add only this item to the selection and visually select it
	_editor.selected.append(item)
	
	if item.has_method("select"):
		item.select()
	elif item.has_method("set_selected"):
		item.call("set_selected", true)
	
	# 3) Notify the editor that selection changed (updates timeline/modules)
	#    but does NOT switch to Inspector (that behavior lives in select_item()).
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()
