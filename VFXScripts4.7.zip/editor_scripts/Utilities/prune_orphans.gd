extends ScriptRunnerScript

#meta:name:Prune Orphaned VFX
#meta:description:Finds VFX keys with no matching note and prunes those rows from the VFX JSON (with backup).
#meta:usage:Run in the chart editor while PH_VFX_MegaInjector is active.

const LOG_NAME := "VFXOrphanPrune"

func run_script() -> int:
	if _editor == null:
		_notify("❌ No editor context.")
		return ERR_DOES_NOT_EXIST

	# --- Find injector + anim_bank -----------------------------------
	var inj: Node = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if inj == null:
		inj = _editor.find_child("PH_VFX_MegaInjector", true, false)
	if inj == null:
		_notify("❌ PH_VFX_MegaInjector not found. Inject VFX first.")
		return ERR_DOES_NOT_EXIST

	var anim_bank := inj.get("anim_bank")
	if anim_bank == null:
		_notify("❌ Injector has no anim_bank.")
		return ERR_DOES_NOT_EXIST

	var vfx_path: String = inj.get("json_path")
	if vfx_path == "":
		_notify("❌ Injector json_path is empty.")
		return ERR_DOES_NOT_EXIST
	if not FileAccess.file_exists(vfx_path):
		_notify("❌ VFX file not found: %s" % vfx_path)
		return ERR_FILE_NOT_FOUND

	# --- Collect keys from timeline & VFX -----------------------------
	var note_keys := _collect_timeline_note_keys()
	if note_keys.is_empty():
		_notify("No note keys found on the timeline; aborting.")
		return ERR_DOES_NOT_EXIST

	var vfx_keys := _collect_vfx_keys_from_anim_bank(anim_bank)
	if vfx_keys.is_empty():
		_notify("VFX file has no keyed events; nothing to prune.")
		return OK

	var orphan_keys: Array[String] = []
	for k in vfx_keys.keys():
		var key := String(k)
		if not note_keys.has(key):
			orphan_keys.append(key)

	# --- Basic stats / song info --------------------------------------
	var chart_name := ""
	var diff := ""
	var song = null

	if "current_song" in _editor and _editor.current_song != null:
		song = _editor.current_song
		var cs = song
		if "title" in cs:
			chart_name = String(cs.title)
		elif "song_id" in cs:
			chart_name = String(cs.song_id)

	if "current_difficulty" in _editor:
		diff = String(_editor.current_difficulty)

	if chart_name == "":
		chart_name = "(unknown song)"

	var lines: Array[String] = []
	lines.append("[%s] Chart: %s (%s)" % [LOG_NAME, chart_name, diff])
	lines.append("[%s] VFX file: %s" % [LOG_NAME, vfx_path])
	lines.append("[%s] --------------------------------------------------" % LOG_NAME)
	lines.append("[%s] Note keys on timeline: %d" % [LOG_NAME, note_keys.size()])
	lines.append("[%s] Note keys with any VFX: %d" % [LOG_NAME, vfx_keys.size()])
	lines.append("[%s] --------------------------------------------------" % LOG_NAME)

	if orphan_keys.is_empty():
		lines.append("[%s] ✅ No orphaned VFX keys found; nothing to prune." % LOG_NAME)
		_show_popup("\n".join(lines))
		for l in lines: print(l)
		return OK

	lines.append("[%s] ⚠ Orphaned VFX keys: %d" % [LOG_NAME, orphan_keys.size()])
	lines.append("[%s] Listing up to 10 keys:" % LOG_NAME)
	var preview_count := min(orphan_keys.size(), 10)
	for i in range(preview_count):
		lines.append("[%s]  #%d  %s" % [LOG_NAME, i + 1, orphan_keys[i]])
	if orphan_keys.size() > preview_count:
		lines.append("[%s]  ... (+%d more)" % [LOG_NAME, orphan_keys.size() - preview_count])

	# --- Backup + prune file ------------------------------------------
	var orig_text := ""
	var f_read := FileAccess.open(vfx_path, FileAccess.READ)
	if f_read == null:
		lines.append("[%s] ❌ Failed to open VFX file for reading." % LOG_NAME)
		_show_popup("\n".join(lines))
		for l2 in lines: print(l2)
		return ERR_CANT_OPEN
	orig_text = f_read.get_as_text()
	f_read.close()

	# build backup path in user://vfx_tmp/<song_id>/<file>.bak
	var backup_path := _make_vfx_backup_path(song, vfx_path)

	var f_backup := FileAccess.open(backup_path, FileAccess.WRITE)
	if f_backup == null:
		lines.append("[%s] ⚠ Failed to open backup file for writing: %s" % [LOG_NAME, backup_path])
	else:
		# Write the original JSON exactly as it was
		f_backup.store_string(orig_text)
		f_backup.close()
		lines.append("[%s] Backup written to: %s" % [LOG_NAME, backup_path])

	# Parse original JSON
	var parsed := JSON.parse_string(orig_text)
	if typeof(parsed) != TYPE_ARRAY:
		lines.append("[%s] ❌ VFX JSON root is not an Array; aborting prune." % LOG_NAME)
		_show_popup("\n".join(lines))
		for l3 in lines: print(l3)
		return ERR_PARSE_ERROR

	var arr: Array = parsed
	var orphan_set := {}
	for k in orphan_keys:
		orphan_set[k] = true

	var kept: Array = []
	var removed_rows := 0

	for row in arr:
		if typeof(row) != TYPE_DICTIONARY:
			kept.append(row)
			continue

		var d: Dictionary = row

		# Only prune normal per-note rows.
		if not (d.has("layer") and d.has("note_type") and d.has("anim_note_time")):
			kept.append(d)
			continue

		var layer := String(d["layer"])

		# Keep special layers like Mirai links, metadata, etc.
		if layer.begins_with("$"):
			kept.append(d)
			continue

		var nt := int(d["note_type"])
		var head_t := int(d["anim_note_time"])
		var key := "%s@%d@%d" % [layer, nt, head_t]

		if orphan_set.has(key):
			removed_rows += 1
			continue
		else:
			kept.append(d)

	var f_write := FileAccess.open(vfx_path, FileAccess.WRITE)
	if f_write == null:
		lines.append("[%s] ❌ Failed to open VFX file for writing; original is backed up." % LOG_NAME)
		_show_popup("\n".join(lines))
		for l4 in lines: print(l4)
		return ERR_CANT_OPEN

	f_write.store_string(JSON.stringify(kept, "\t"))
	f_write.close()

	lines.append("[%s] --------------------------------------------------" % LOG_NAME)
	lines.append("[%s] Pruned rows: %d" % [LOG_NAME, removed_rows])
	lines.append("[%s] Remaining rows: %d" % [LOG_NAME, kept.size()])
	lines.append("[%s] ✅ Done. Original file backed up as: %s" % [LOG_NAME, backup_path])

	for l5 in lines:
		print(l5)
	_show_popup("\n".join(lines))

	return OK


# =====================================================================
# Helper: collect timeline note keys using the same format as injector
# =====================================================================

func _collect_timeline_note_keys() -> Dictionary:
	var keys: Dictionary = {}

	if not _editor.has_method("get_timeline_items"):
		_notify("Editor has no get_timeline_items(); cannot inspect chart.")
		return keys

	var items: Array = _editor.get_timeline_items()
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var note_obj = item.data
		if note_obj == null:
			continue

		var key := _build_vfx_key_for_note_data(note_obj)
		if key == "":
			continue
		keys[key] = true

	return keys


# =====================================================================
# Helper: collect all VFX keys from PHVFXAnimBank buckets
# =====================================================================

func _collect_vfx_keys_from_anim_bank(bank: Object) -> Dictionary:
	var keys: Dictionary = {}

	var dicts: Array = [
		bank.buckets_scale,
		bank.buckets_color,
		bank.buckets_rot,
		bank.buckets_offset,
		bank.buckets_spot,
		bank.buckets_glow,
	]

	for d in dicts:
		if typeof(d) != TYPE_DICTIONARY:
			continue
		for k in (d as Dictionary).keys():
			keys[String(k)] = true

	return keys


# =====================================================================
# Key-building helpers – mirror PHVFXMegaInjector._key_for_drawer
# =====================================================================

func _lane_name_from_note_data(nd: Object) -> String:
	if nd == null or not nd.has_method("get"):
		return ""

	var nt_v = nd.get("note_type")
	if nt_v == null:
		return ""

	var nti := int(nt_v)
	match nti:
		0: return "UP"
		1: return "LEFT"
		2: return "DOWN"
		3: return "RIGHT"
		4, 6: return "SLIDE_LEFT"
		5, 7: return "SLIDE_RIGHT"
		8: return "HEART"
		_: return "UNKNOWN"


func _guess_is_layer2_from_note(obj: Object) -> bool:
	if obj == null:
		return false

	# 1) layer_index == 1
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if String(p.name) == "layer_index":
				var v = obj.get("layer_index")
				if v != null and int(v) == 1:
					return true
				break
	if obj.has_method("get"):
		if "layer_index" in obj:
			var v2 = obj.get("layer_index")
			if v2 != null and int(v2) == 1:
				return true

	# 2) second_layer flag
	if obj.has_method("get_property_list"):
		for p2 in obj.get_property_list():
			if String(p2.name) == "second_layer":
				var f = obj.get("second_layer")
				if f != null and bool(f):
					return true
				break
	if obj.has_method("get"):
		if "second_layer" in obj:
			var f2 = obj.get("second_layer")
			if f2 != null and bool(f2):
				return true

	# 3) layer string metadata ending with "2"
	if obj.has_method("get_property_list"):
		for p3 in obj.get_property_list():
			if String(p3.name) == "layer":
				var l = obj.get("layer")
				if l != null and String(l).ends_with("2"):
					return true
				break
	if obj.has_method("get"):
		if "layer" in obj:
			var l2 = obj.get("layer")
			if l2 != null and String(l2).ends_with("2"):
				return true

	return false


func _build_vfx_key_for_note_data(nd: Object) -> String:
	if nd == null or not nd.has_method("get"):
		return ""

	var nt_v = nd.get("note_type")
	var time_v = nd.get("time")
	if nt_v == null or time_v == null:
		return ""

	var nti := int(nt_v)
	var head_t := int(time_v)

	var lname := _lane_name_from_note_data(nd)
	if lname == "":
		lname = "UNKNOWN"

	var is_l2 := _guess_is_layer2_from_note(nd)
	var layer_tag := "layer_%s%s" % [lname, ("2" if is_l2 else "")]
	return "%s@%d@%d" % [layer_tag, nti, head_t]


func _make_vfx_backup_path(song, vfx_path: String) -> String:
	# user://vfx_tmp/<song_id>/<vfx_filename>.bak

	var song_id_str := ""

	if song != null:
		if "id" in song:
			song_id_str = str(song.id)
		elif "song_id" in song:
			song_id_str = str(song.song_id)

	if song_id_str == "":
		# Fallback: use folder name from VFX path
		var base_dir := vfx_path.get_base_dir()
		song_id_str = base_dir.get_file()

	var tmp_dir_virtual := "user://vfx_tmp/%s" % song_id_str
	var tmp_dir_abs := ProjectSettings.globalize_path(tmp_dir_virtual)
	DirAccess.make_dir_recursive_absolute(tmp_dir_abs)

	var base_name := vfx_path.get_file()            # e.g. "loli_vfx.json"
	var backup_virtual := "%s/%s.bak" % [tmp_dir_virtual, base_name]
	return backup_virtual


# =====================================================================
# UI helpers
# =====================================================================

func _notify(msg: String) -> void:
	if _editor and "message_shower" in _editor and _editor.message_shower:
		_editor.message_shower._show_notification(msg)
	else:
		print("[%s] %s" % [LOG_NAME, msg])


func _show_popup(text: String) -> void:
	if _editor == null:
		return

	var tree = _editor.get_tree()
	var ui_root: Node = tree.root if tree != null else _editor

	var existing := ui_root.get_node_or_null("PH_VFXOrphanPruneDialog")
	if existing != null and is_instance_valid(existing):
		existing.queue_free()

	var dlg := AcceptDialog.new()
	dlg.name = "PH_VFXOrphanPruneDialog"
	dlg.title = "VFX Orphan Prune"
	dlg.min_size = Vector2(720, 480)

	var text_edit := TextEdit.new()
	text_edit.readonly = true
	text_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	text_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_edit.text = text
	text_edit.set_anchors_preset(Control.PRESET_FULL_RECT)

	dlg.add_child(text_edit)
	ui_root.add_child(dlg)

	dlg.confirmed.connect(dlg.queue_free)
	dlg.canceled.connect(dlg.queue_free)

	dlg.popup_centered_ratio(0.7)
