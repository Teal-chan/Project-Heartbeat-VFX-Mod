extends ScriptRunnerScript

#meta:name:Step 2b: Uninject VFX
#meta:description:Disarms and removes the PH_VFX_MegaInjector node from the editor scene, and clears all VFX indicators & materials.
#meta:usage:Run to disable live VFX injection in Preview & Playtest.

func run_script() -> int:
	if _editor == null:
		push_error("[PH_VFX_Uninject] ❌ No HBEditor reference.")
		return ERR_DOES_NOT_EXIST

	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")

	if mgr == null:
		# Injector already gone; just clean up any leftovers.
		_clear_all_vfx_from_editor()
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No PH_VFX_MegaInjector node found (cleaned VFX markers/materials, if any).")
		print("[PH_VFX_Uninject] No injector node found; cleaned VFX markers/materials (if present).")
		return OK

	# Call disarm() if available to clean up timers, overlays, connections, etc.
	if mgr.has_method("disarm"):
		mgr.call("disarm")

	# Remove the node from the scene tree
	if mgr.get_parent():
		mgr.get_parent().remove_child(mgr)
	mgr.queue_free()

	# Clear markers + restore materials & transforms
	_clear_all_vfx_from_editor()

	if _editor.message_shower:
		_editor.message_shower._show_notification("🧼 VFX Mega Injector disarmed, removed, and all VFX cleared.")
	print("[PH_VFX_Uninject] Injector disarmed, removed, and all VFX cleared.")

	return OK


# ----------------- main cleanup orchestration -----------------

func _clear_all_vfx_from_editor() -> void:
	# 1) Editor timeline dots removed (marker feature removed for performance)

	# 2) Preview side (GamePreview tree)
	var preview_root := _find_preview_root()
	if preview_root != null:
		_clear_preview_specific_nodes(preview_root)
		_clear_vfx_materials_under(preview_root)

	# 3) Playtest side (RhythmGame popup, if present)
	var playtest_root := _find_playtest_root()
	if playtest_root != null:
		_clear_playtest_specific_nodes(playtest_root)
		_clear_vfx_materials_under(playtest_root)


# _clear_timeline_vfx_markers removed - marker feature removed for performance

# ----------------- preview / playtest helpers -----------------

func _find_preview_root() -> Node:
	if _editor == null:
		return null
	return _editor.find_child("GamePreview", true, false)


func _find_playtest_root() -> Node:
	if _editor == null:
		return null

	var popup_v = _editor.get("rhythm_game_playtest_popup")
	if popup_v is Node:
		var popup := popup_v as Node
		if not popup.is_inside_tree():
			return null

		var root := popup.find_child("RhythmGame", true, false)
		if root == null:
			root = popup
		return root

	return null


# ----------------- preview-specific cleanup (markers, overlays, lines) -----------------

func _clear_preview_specific_nodes(preview_root: Node) -> void:
	if preview_root == null or not is_instance_valid(preview_root):
		return

	# Preview spotlight overlay
	var overlay := preview_root.get_node_or_null("NoteSpotlightOverlay_ColorRect")
	if overlay != null and is_instance_valid(overlay):
		overlay.queue_free()

	# Mirai link container if it exists under preview
	var mirai_lines := preview_root.find_child("PH_MiraiLinkLines", true, false)
	if mirai_lines != null and is_instance_valid(mirai_lines):
		mirai_lines.queue_free()


# ----------------- playtest-specific cleanup (overlays, lines) -----------------

func _clear_playtest_specific_nodes(playtest_root: Node) -> void:
	if playtest_root == null or not is_instance_valid(playtest_root):
		return

	# Same overlay name used by the injector
	var overlay := playtest_root.get_node_or_null("NoteSpotlightOverlay_ColorRect")
	if overlay != null and is_instance_valid(overlay):
		overlay.queue_free()

	var mirai_lines := playtest_root.find_child("PH_MiraiLinkLines", true, false)
	if mirai_lines != null and is_instance_valid(mirai_lines):
		mirai_lines.queue_free()


# ----------------- core VFX restore: materials, transforms, trail widths -----------------

func _clear_vfx_materials_under(root: Node) -> void:
	if root == null or not is_instance_valid(root):
		return

	var stack: Array = [root]
	while stack.size() > 0:
		var n: Node = stack.pop_back()
		if n == null or not is_instance_valid(n):
			continue

		# 1) Restore materials on any CanvasItem that the injector touched
		if n is CanvasItem:
			var ci := n as CanvasItem

			if ci.has_meta("_vfx_orig_material"):
				var orig_mat = ci.get_meta("_vfx_orig_material")
				ci.material = orig_mat
				ci.remove_meta("_vfx_orig_material")

			# Forget our ShaderMaterial ref meta
			if ci.has_meta("_vfx_sm"):
				ci.remove_meta("_vfx_sm")

			# No need to manually zero shader params if we restored the original material.

		# 2) Restore base position/rotation for Node2D the injector moved
		if n is Node2D:
			var n2d := n as Node2D

			if n2d.has_meta("_vfx_base_pos"):
				var base_pos: Vector2 = n2d.get_meta("_vfx_base_pos")
				n2d.position = base_pos
				n2d.remove_meta("_vfx_base_pos")

			if n2d.has_meta("_vfx_base_rot"):
				var base_rot: float = n2d.get_meta("_vfx_base_rot")
				n2d.rotation_degrees = base_rot
				n2d.remove_meta("_vfx_base_rot")

			# These are just cache values; safe to drop.
			if n2d.has_meta("_vfx_last_ofs"):
				n2d.remove_meta("_vfx_last_ofs")
			if n2d.has_meta("_vfx_last_rot"):
				n2d.remove_meta("_vfx_last_rot")

		# 3) Restore trail widths if they were scaled by VFX
		if n.has_meta("_vfx_trail_base_width"):
			var base_width = float(n.get_meta("_vfx_trail_base_width"))
			if n.has_method("get"):
				var line_obj = n.get("line")
				if line_obj is Line2D:
					var line := line_obj as Line2D
					line.width = base_width
			n.remove_meta("_vfx_trail_base_width")

		# Recurse
		for c in n.get_children():
			if c is Node:
				stack.append(c)
