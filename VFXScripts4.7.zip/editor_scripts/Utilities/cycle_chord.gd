extends ScriptRunnerScript

#meta:name:Cycle within current chord (single, no inspector)
#meta:description:Cycles selection between notes in the current chord. Uses selected note’s time if any, otherwise notes at the playhead time. Spawns the preview widget for the selected note without switching to the Inspector tab.
#meta:usage:Run to rotate which note in the current chord is selected. Works after jump scripts or when you manually click a note.

func run_script() -> int:
	if _editor == null:
		push_error("[CycleChordSingleQuiet] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	if not _editor.has_method("get_items_at_time"):
		push_error("[CycleChordSingleQuiet] Editor has no get_items_at_time() method.")
		return ERR_UNAVAILABLE
	
	var chord_notes: Array = []
	var chord_time_ms := -1
	
	# --- 1) Prefer a selected note as the chord time source ---
	if "selected" in _editor and _editor.selected is Array:
		for s in _editor.selected:
			if s == null or not is_instance_valid(s):
				continue
			if not (s is EditorTimelineItemNote):
				continue
			
			var t := _get_time_from_item(s)
			if t >= 0:
				chord_time_ms = t
				break
	
	# If we found a valid chord time from selection, build chord from that time
	if chord_time_ms >= 0:
		chord_notes = _get_notes_at_time(chord_time_ms)
	
	# --- 2) If no chord from selection, fall back to playhead time ---
	if chord_notes.is_empty():
		var cur_ms := _get_current_playhead_ms()
		chord_time_ms = cur_ms
		chord_notes = _get_notes_at_time(chord_time_ms)
	
	if chord_notes.is_empty():
		print("[CycleChordSingleQuiet] No chord notes found at selected note time or playhead time.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No chord found to cycle.")
		return OK
	
	# --- Determine which note in this chord is currently active (if any) ---
	var current_index := -1
	
	if "selected" in _editor and _editor.selected is Array:
		for i in chord_notes.size():
			var note = chord_notes[i]
			if note in _editor.selected:
				current_index = i
				break
	
	# Compute next index (wrap around)
	var next_index := 0
	if current_index >= 0:
		next_index = (current_index + 1) % chord_notes.size()
	
	var next_item: Object = chord_notes[next_index]
	var next_time := _get_time_from_item(next_item)
	
	_select_only_item_quiet(next_item)
	
	print("[CycleChordSingleQuiet] ⟳ Cycled chord selection: note ", next_index + 1, "/", chord_notes.size(), " at ", next_time, " ms.")
	if _editor.message_shower:
		_editor.message_shower._show_notification("⟳ Cycled chord note %d/%d at %d ms." % [next_index + 1, chord_notes.size(), next_time])
	
	return OK


# --- helpers -------------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	
	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1
	
	var data = null
	if item.has_method("get"):
		data = item.get("data")
	
	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))
	
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))
	
	return -1


func _get_notes_at_time(time_ms: int) -> Array:
	var result: Array = []
	var items_at_time: Array = _editor.get_items_at_time(time_ms)
	
	for item in items_at_time:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue
		result.append(item)
	
	return result


func _select_only_item_quiet(item: Object) -> void:
	if item == null or not is_instance_valid(item):
		return
	
	# 1) Deselect everything currently selected WITHOUT using select_item()
	if "selected" in _editor and _editor.selected is Array:
		for it in _editor.selected:
			if it == null or not is_instance_valid(it):
				continue
			if it.has_method("deselect"):
				it.deselect()
			elif it.has_method("set_selected"):
				it.call("set_selected", false)
		
		_editor.selected.clear()
	
	# 2) Add only this item to the selection and visually select it
	_editor.selected.append(item)
	
	if item.has_method("select"):
		item.select()
	elif item.has_method("set_selected"):
		item.call("set_selected", true)
	
	# 3) Spawn preview widget for this item (but don't touch Inspector/tab logic)
	_spawn_preview_widget_for_item(item)
	
	# 4) Notify the editor that selection changed
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()


func _spawn_preview_widget_for_item(item: Object) -> void:
	# Mirrors HBEditor.select_item's widget logic, without inspector/tab changes.
	if _editor == null:
		return
	if item == null or not is_instance_valid(item):
		return
	
	if not item.has_method("get_editor_widget"):
		return
	
	var widget_res = item.get_editor_widget()
	if widget_res == null:
		return
	
	# Access game_preview.widget_area just like HBEditor does
	if not ("game_preview" in _editor):
		return
	
	var gp = _editor.game_preview
	if gp == null:
		return
	if not ("widget_area" in gp):
		return
	
	var widget_instance = widget_res.instantiate()
	if widget_instance == null:
		return
	
	# HBEditor sets this to itself; we do the same with _editor
	if "editor" in widget_instance:
		widget_instance.editor = _editor
	
	gp.widget_area.add_child(widget_instance)
	
	if item.has_method("connect_widget"):
		item.connect_widget(widget_instance)
