# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Snap+Select Last Note
#meta:description:Jumps to the latest note on the timeline, selects all notes at that time, and shows their preview widget without switching to the Inspector tab.
#meta:usage:Run to jump to the last note(s) in the chart and replace the current selection quietly.

func run_script() -> int:
	if _editor == null:
		printerr("[SnapSelectLastNote] No editor context.")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		printerr("[SnapSelectLastNote] Editor has no get_timeline_items().")
		return ERR_DOES_NOT_EXIST

	var items: Array = _editor.get_timeline_items()
	if items.is_empty():
		printerr("[SnapSelectLastNote] No timeline items found.")
		return ERR_DOES_NOT_EXIST

	var best_time_ms := -1
	var best_items: Array = []

	# Find latest note time and collect all notes at that time
	for item in items:
		if item == null or not is_instance_valid(item):
			continue

		var t := _get_note_time_from_item(item)
		if t < 0:
			continue

		if best_time_ms < 0 or t > best_time_ms:
			best_time_ms = t
			best_items.clear()
			best_items.append(item)
		elif t == best_time_ms:
			best_items.append(item)

	if best_time_ms < 0 or best_items.is_empty():
		printerr("[SnapSelectLastNote] No notes found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ No notes found on the timeline.")
		return ERR_DOES_NOT_EXIST

	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		best_time_ms = clamp(best_time_ms, 0, max_ms)

	_seek_editor_to_ms(best_time_ms)
	_select_items_quiet(best_items)

	var msg := "[SnapSelectLastNote] ▶ Jumped to last note(s) at %d ms, selected %d." \
		% [best_time_ms, best_items.size()]
	print(msg)
	if _editor.message_shower:
		_editor.message_shower._show_notification(msg)

	return OK


# --- helpers --------------------------------------------------------------------

func _get_note_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1

	var data = null
	if item.has_method("get"):
		data = item.get("data")

	# Heuristic: a note has 'note_type' and 'time'
	if data != null and data.has_method("get"):
		var nt = data.get("note_type")
		var t = data.get("time")
		if nt != null and t != null:
			return int(round(float(t)))

	# Fallback – try the item itself
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)

	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


func _select_items_quiet(items: Array) -> void:
	# 1) Deselect current selection without triggering inspector changes
	if "selected" in _editor and _editor.selected is Array:
		for it in _editor.selected:
			if it == null or not is_instance_valid(it):
				continue
			if it.has_method("deselect"):
				it.deselect()
			elif it.has_method("set_selected"):
				it.call("set_selected", false)
		_editor.selected.clear()

	# 2) Add new items and visually select them
	for item in items:
		if item == null or not is_instance_valid(item):
			continue

		_editor.selected.append(item)

		if item.has_method("select"):
			item.select()
		elif item.has_method("set_selected"):
			item.call("set_selected", true)

	# 3) Spawn preview widget for the first item only
	if items.size() > 0:
		_spawn_preview_widget_for_item(items[0])

	# 4) Notify editor that selection changed (no inspector/tab switch here)
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()
	elif _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()


func _spawn_preview_widget_for_item(item: Object) -> void:
	if _editor == null:
		return
	if item == null or not is_instance_valid(item):
		return
	if not item.has_method("get_editor_widget"):
		return

	var widget_res = item.get_editor_widget()
	if widget_res == null:
		return

	if not ("game_preview" in _editor):
		return

	var gp = _editor.game_preview
	if gp == null:
		return
	if not ("widget_area" in gp):
		return

	var widget_instance = widget_res.instantiate()
	if widget_instance == null:
		return

	if "editor" in widget_instance:
		widget_instance.editor = _editor

	gp.widget_area.add_child(widget_instance)

	if item.has_method("connect_widget"):
		item.connect_widget(widget_instance)
