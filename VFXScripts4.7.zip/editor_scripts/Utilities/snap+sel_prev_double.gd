extends ScriptRunnerScript

#meta:name:Snap+Select Previous Double Note
#meta:description:Jumps to the previous HBDoubleNote on the timeline, selects only that note, and shows its preview widget without switching to the Inspector tab.
#meta:usage:Run to move to the previous Double note and replace the current selection quietly.

func run_script() -> int:
	if _editor == null:
		push_error("[SnapSelectPrevDouble] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[SnapSelectPrevDouble] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var double_entries: Array = []	# each: { "time": int, "item": Object }

	for item in items:
		if item == null or not is_instance_valid(item):
			continue

		if not (item is EditorTimelineItemNote):
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")
		if data == null:
			continue

		if not (data is HBDoubleNote):
			continue

		var t := _get_time_from_item(item)
		if t < 0:
			continue

		double_entries.append({ "time": t, "item": item })

	if double_entries.is_empty():
		print("[SnapSelectPrevDouble] No Double notes found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No Double notes on the timeline.")
		return OK

	# --- choose the previous Double before current playhead -----------------------
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	var best_item: Object = null

	for entry in double_entries:
		var t: int = entry["time"]
		if t >= cur_ms - 1:
			continue
		if best_item == null or t > best_time:
			best_time = t
			best_item = entry["item"]

	if best_item == null:
		print("[SnapSelectPrevDouble] No earlier Double note found (before first Double).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No earlier Double note found.")
		return OK

	# --- move playhead + quiet-select with widget --------------------------------
	_seek_editor_to_ms(best_time)
	_select_only_item_quiet(best_item)

	print("[SnapSelectPrevDouble] ✅ Jumped to previous Double note at ", best_time, " ms.")
	if _editor.message_shower:
		_editor.message_shower._show_notification("✅ Jumped to previous Double note at %d ms." % best_time)

	return OK


# --- helpers: time / seek / selection / preview ---------------------------------
# Reuse the exact same helpers as in the Next script:

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0

	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0

	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1

	var data = null
	if item.has_method("get"):
		data = item.get("data")

	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))

	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1


func _seek_editor_to_ms(ms: int) -> void:
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)

	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


func _select_only_item_quiet(item: Object) -> void:
	if item == null or not is_instance_valid(item):
		return

	if "selected" in _editor and _editor.selected is Array:
		for it in _editor.selected:
			if it == null or not is_instance_valid(it):
				continue
			if it.has_method("deselect"):
				it.deselect()
			elif it.has_method("set_selected"):
				it.call("set_selected", false)

		_editor.selected.clear()

	_editor.selected.append(item)

	if item.has_method("select"):
		item.select()
	elif item.has_method("set_selected"):
		item.call("set_selected", true)

	_spawn_preview_widget_for_item(item)

	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()


func _spawn_preview_widget_for_item(item: Object) -> void:
	if _editor == null:
		return
	if item == null or not is_instance_valid(item):
		return
	if not item.has_method("get_editor_widget"):
		return

	var widget_res = item.get_editor_widget()
	if widget_res == null:
		return

	if not ("game_preview" in _editor):
		return

	var gp = _editor.game_preview
	if gp == null:
		return
	if not ("widget_area" in gp):
		return

	var widget_instance = widget_res.instantiate()
	if widget_instance == null:
		return

	if "editor" in widget_instance:
		widget_instance.editor = _editor

	gp.widget_area.add_child(widget_instance)

	if item.has_method("connect_widget"):
		item.connect_widget(widget_instance)
