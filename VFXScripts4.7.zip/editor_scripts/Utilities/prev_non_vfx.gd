extends ScriptRunnerScript

#meta:name:Jump to previous non-VFX note (no select)
#meta:description:Jumps the playhead to the previous note that does NOT have VFX (via PH_VFX_MegaInjector) without changing the current selection.
#meta:usage:Run to move to the previous non-VFX note while keeping your current selection untouched.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpPrevNonVFXNoteNoSelect] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	# --- locate VFX Mega Injector (optional) --------------------------------------
	var mgr: Node = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr == null:
		mgr = _editor.find_child("PH_VFX_MegaInjector", true, false)
	
	var keys_with_vfx: Dictionary = {}
	var note_to_key_map: Dictionary = {}
	var has_injector_key_helper := false
	
	if mgr != null and mgr.has_method("get"):
		var raw = mgr.get("_keys_with_vfx")
		if typeof(raw) == TYPE_DICTIONARY:
			keys_with_vfx = raw
		
		var m = mgr.get("_note_data_to_key_preview")
		if typeof(m) == TYPE_DICTIONARY:
			note_to_key_map = m
		
		has_injector_key_helper = mgr.has_method("_key_for_note_data")
	
	# If mgr == null or keys_with_vfx is empty, we treat all notes as "non-VFX".
	
	# --- collect candidate notes (timeline notes that do NOT have VFX) ------------
	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpPrevNonVFXNoteNoSelect] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE
	
	var items: Array = _editor.get_timeline_items()
	var non_vfx_entries: Array = []   # each: { "time": int, "item": Object }
	
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue
		
		var note_obj = item.data
		if note_obj == null:
			continue
		
		var key := ""
		if mgr != null:
			key = _resolve_key_for_note(mgr, note_obj, note_to_key_map, has_injector_key_helper)
		
		var has_vfx_for_note := (key != "" and keys_with_vfx.has(key))
		if has_vfx_for_note:
			# Skip notes that DO have VFX – we want the opposite.
			continue
		
		var t := _get_time_from_item(item)
		if t < 0:
			continue
		
		non_vfx_entries.append({ "time": t, "item": item })
	
	if non_vfx_entries.is_empty():
		print("[JumpPrevNonVFXNoteNoSelect] No non-VFX notes found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No non-VFX notes on the timeline.")
		return OK
	
	# --- choose the previous non-VFX note before current playhead -----------------
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	
	for entry in non_vfx_entries:
		var t: int = entry["time"]
		if t >= cur_ms - 1:
			continue
		if best_time == -1 or t > best_time:
			best_time = t
	
	if best_time == -1:
		print("[JumpPrevNonVFXNoteNoSelect] No earlier non-VFX note found (before first non-VFX).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No earlier non-VFX note found.")
		return OK
	
	# --- move playhead ONLY -------------------------------------------------------
	_seek_editor_to_ms(best_time)
	
	print("[JumpPrevNonVFXNoteNoSelect] ✅ Jumped to previous non-VFX note at ", best_time, " ms (selection unchanged).")
	if _editor.message_shower:
		_editor.message_shower._show_notification("✅ Jumped to previous non-VFX note at %d ms (selection unchanged)." % best_time)
	
	return OK


# --- helpers: time / seek --------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	
	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1
	
	var data = null
	if item.has_method("get"):
		data = item.get("data")
	
	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))
	
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))
	
	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)
	
	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms
	
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()
	
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


# --- helpers: VFX key resolution (same as other VFX scripts) ---------------------

func _resolve_key_for_note(
		mgr: Node,
		note_obj: Object,
		note_to_key_map: Dictionary,
		has_injector_key_helper: bool
) -> String:
	# 1) Best: injector's live note_data -> key map
	if note_to_key_map.has(note_obj):
		var k0 = note_to_key_map.get(note_obj, "")
		if typeof(k0) == TYPE_STRING and k0 != "":
			return k0
	
	# 2) Next-best: injector's own helper
	if has_injector_key_helper:
		var k1 = mgr.call("_key_for_note_data", note_obj)
		if typeof(k1) == TYPE_STRING and k1 != "":
			return k1
	
	# 3) Fallback: local reconstruction
	return _build_vfx_key_for_note_data(note_obj)


func _build_vfx_key_for_note_data(nd: Object) -> String:
	if nd == null:
		return ""
	if not nd.has_method("get"):
		return ""
	
	var nt_v = nd.get("note_type")
	var time_v = nd.get("time")
	if nt_v == null or time_v == null:
		return ""
	
	var nti := int(nt_v)
	var head_t := int(time_v)
	
	var lname := "UNKNOWN"
	match nti:
		0: lname = "UP"
		1: lname = "LEFT"
		2: lname = "DOWN"
		3: lname = "RIGHT"
		4, 6: lname = "SLIDE_LEFT"
		5, 7: lname = "SLIDE_RIGHT"
		8: lname = "HEART"
	
	var is_l2 := _guess_is_layer2_from_note(nd)
	var layer_tag := "layer_%s%s" % [lname, ("2" if is_l2 else "")]
	return "%s@%d@%d" % [layer_tag, nti, head_t]


func _guess_is_layer2_from_note(obj: Object) -> bool:
	if obj == null:
		return false
	
	var lidx = null
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if String(p.name) == "layer_index":
				lidx = obj.get("layer_index")
				break
	if lidx == null and obj.has_method("get"):
		if "layer_index" in obj:
			lidx = obj.get("layer_index")
	if lidx != null and int(lidx) == 1:
		return true
	
	var has_flag = null
	if obj.has_method("get_property_list"):
		for p2 in obj.get_property_list():
			if String(p2.name) == "second_layer":
				has_flag = obj.get("second_layer")
				break
	if has_flag == null and obj.has_method("get"):
		if "second_layer" in obj:
			has_flag = obj.get("second_layer")
	if has_flag != null and bool(has_flag):
		return true
	
	var layer_meta = null
	if obj.has_method("get_property_list"):
		for p3 in obj.get_property_list():
			if String(p3.name) == "layer":
				layer_meta = obj.get("layer")
				break
	if layer_meta == null and obj.has_method("get"):
		if "layer" in obj:
			layer_meta = obj.get("layer")
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	
	return false
