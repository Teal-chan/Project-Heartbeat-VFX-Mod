extends ScriptRunnerScript

#meta:name:Open Edit Song Data for current song
#meta:description:Opens the Edit Song Data window for the song currently loaded in the editor.
#meta:usage:Run with any chart loaded; no selection required.

func run_script() -> int:
	var editor := _editor as HBEditor
	if editor == null:
		push_error("ScriptRunner: _editor is not an HBEditor.")
		return -1
	
	var song: HBSong = editor.current_song
	if song == null:
		push_error("ScriptRunner: No current song loaded in the editor.")
		return -1
	
	# Grab the same dialog the editor uses for Open Chart
	var open_chart_popup = editor.open_chart_popup_dialog
	if open_chart_popup == null:
		push_error("ScriptRunner: Could not access OpenChartPopupDialog from HBEditor.")
		return -1
	
	# Access its meta editor + dialog (same nodes used in _show_meta_editor)
	var meta_editor_dialog = open_chart_popup.song_meta_editor_dialog
	var meta_editor = open_chart_popup.song_meta_editor
	if meta_editor_dialog == null or meta_editor == null:
		push_error("ScriptRunner: Song meta editor dialog/editor nodes not found.")
		return -1
	
	# Recreate the 'hidden' logic from populate_tree(), but for the current song
	var hidden := song.get_fs_origin() == HBSong.SONG_FS_ORIGIN.BUILT_IN and not HBGame.enable_editor_dev_mode
	hidden = hidden or song.comes_from_ugc() or song is HBPPDSong \
		or song is SongLoaderDSC.HBSongMMPLUS or song is SongLoaderDSC.HBSongDSC
	
	# Configure the meta editor like _show_meta_editor() does, but using current_song
	meta_editor.show_hidden = hidden
	meta_editor.song_meta = song
	
	# Show the dialog
	meta_editor_dialog.size = Vector2.ZERO
	meta_editor_dialog.popup_centered_clamped(Vector2(500, 650))
	meta_editor_dialog.get_ok_button().disabled = hidden
	
	return OK
