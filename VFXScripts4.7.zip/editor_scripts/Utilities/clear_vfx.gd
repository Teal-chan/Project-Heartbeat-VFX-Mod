# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Clear VFX for Selected Notes
#meta:description:Removes all per-note VFX rows from the VFX JSON for the selected note heads (scale, color, etc.), keeping $PLAYFIELD / $MIRAI_LINK and other notes intact.
#meta:usage:Select note(s) and run. Compile shaders / reload preview afterwards if needed.

extends ScriptRunnerScript

const NOTE_TYPE_NAMES := {
	0:"UP",1:"LEFT",2:"DOWN",3:"RIGHT",
	4:"SLIDE_LEFT",5:"SLIDE_RIGHT",
	6:"SLIDE_CHAIN_PIECE_LEFT",7:"SLIDE_CHAIN_PIECE_RIGHT",
	8:"HEART"
}

const DEBUG_VFX := false

func _dbg(msg: String) -> void:
	if DEBUG_VFX:
		print("[ClearVFX] ", msg)


func run_script() -> int:
	if _editor == null:
		push_error("[ClearVFX] No editor context.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[ClearVFX] No notes selected.")
		return ERR_DOES_NOT_EXIST

	var specs := _collect_selected_note_specs()
	if specs.is_empty():
		push_error("[ClearVFX] No valid note specs from selection.")
		return ERR_DOES_NOT_EXIST

	var path := _get_vfx_path()
	if path == "":
		push_warning("[ClearVFX] No VFX path for this chart.")
		return ERR_DOES_NOT_EXIST
	if not FileAccess.file_exists(path):
		push_warning("[ClearVFX] VFX file does not exist: " + path)
		return ERR_DOES_NOT_EXIST

	# Build key set for selected heads: "%s@%d@%d" % [layer_tag, note_type, head_time]
	var sel_heads := {}
	for spec in specs:
		var layer := String(spec["layer"])
		var head  := int(spec["time"])
		var nt    := int(spec["note_type"])
		var key := "%s@%d@%d" % [layer, nt, head]
		sel_heads[key] = true
		_dbg("Will clear VFX for key: " + key)

	# Load existing JSON
	var existing: Array = []
	var f := FileAccess.open(path, FileAccess.READ)
	if f:
		var parsed := JSON.parse_string(f.get_as_text())
		if typeof(parsed) == TYPE_ARRAY:
			existing = parsed
		f.close()
	if existing.is_empty():
		push_warning("[ClearVFX] VFX file is empty or not an array, nothing to clear.")
		return OK

	# Preserve everything except per-note rows for selected heads
	var preserved: Array = []
	var removed_count := 0

	for e in existing:
		if typeof(e) != TYPE_DICTIONARY:
			preserved.append(e)
			continue

		var d: Dictionary = e

		var layer_e := String(d.get("layer", ""))
		var nt_e := int(d.get("note_type", -1))
		var head_e := int(d.get("anim_note_time", -1))

		# If it doesn't look like a per-note anim row, keep it.
		# This automatically preserves $PLAYFIELD, $MIRAI_LINK, etc.
		if layer_e == "" or nt_e < 0 or head_e < 0:
			preserved.append(d)
			continue

		var key_e := "%s@%d@%d" % [layer_e, nt_e, head_e]
		if sel_heads.has(key_e):
			removed_count += 1
			_dbg("Removing VFX row for " + key_e + " anim=" + String(d.get("anim","")))
			continue

		preserved.append(d)

	if removed_count == 0:
		print("[ClearVFX] No matching VFX rows found for selected notes.")
		return OK

	# Optional: sort (same ordering pattern as your other tools)
	preserved.sort_custom(func(a, b):
		if typeof(a) != TYPE_DICTIONARY or typeof(b) != TYPE_DICTIONARY:
			return false
		var la := String(a.get("layer",""))
		var lb := String(b.get("layer",""))
		if la == "$PLAYFIELD" and lb != "$PLAYFIELD":
			return true
		if lb == "$PLAYFIELD" and la != "$PLAYFIELD":
			return false
		var ta := int(a.get("time",0))
		var tb := int(b.get("time",0))
		if ta != tb:
			return ta < tb
		return la < lb
	)

	# Write back
	var lines := PackedStringArray()
	for e2 in preserved:
		lines.append(JSON.stringify(e2))
	var content := "[\n  " + "\n,  ".join(lines) + "\n]\n"

	var fout := FileAccess.open(path, FileAccess.WRITE)
	if not fout:
		push_error("[ClearVFX] Failed to open VFX JSON for write: " + path)
		return ERR_FILE_CANT_OPEN
	fout.store_string(content)
	fout.close()

	print("[ClearVFX] 💥 Removed %d VFX row(s) for selected note(s)." % removed_count)

	# Nudge VFX injector for live preview, same pattern as other scripts
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr:
		if mgr.has_method("reload_now"):
			mgr.call_deferred("reload_now")
		else:
			if mgr.has_method("disarm"):
				mgr.call("disarm")
			if mgr.has_method("configure"):
				mgr.call("configure", _editor, _get_vfx_path())
			if mgr.has_method("arm"):
				mgr.call_deferred("arm")
	else:
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ Run 'Step 2: Compile Shaders' once to enable preview.")

	if _editor.game_preview and not _editor.game_playback.is_playing():
		_editor.game_preview.set_visualizer_processing_enabled(true)
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	return OK


# ─────────────────────────────────────────────
# Selection → specs, same pattern as other tools
# ─────────────────────────────────────────────
func _collect_selected_note_specs() -> Array:
	var specs: Array = []
	for item in _editor.selected:
		var data_obj := _safe_get(item, "data", null)
		if data_obj == null:
			continue
		var props := _get_property_names(data_obj)
		if "note_type" in props and "time" in props:
			var sel_type := int(data_obj.get("note_type"))
			var time_val := int(data_obj.get("time"))
			var layer2 := _is_layer2_from_obj(data_obj) or _is_layer2_from_obj(item)
			var lname := NOTE_TYPE_NAMES.get(sel_type, "UNKNOWN")
			if lname == "SLIDE_CHAIN_PIECE_LEFT":
				lname = "SLIDE_LEFT"
			if lname == "SLIDE_CHAIN_PIECE_RIGHT":
				lname = "SLIDE_RIGHT"
			var layer_tag = "layer_" + lname + ( "2" if layer2 else "" )

			specs.append({
				"time": time_val,
				"note_type": sel_type,
				"layer": layer_tag,
				"note_obj": data_obj
			})
	return specs


# ─────────────────────────────────────────────
# Shared helpers (same as other VFX tools)
# ─────────────────────────────────────────────
func _safe_get(obj: Object, prop: String, fallback: Variant=null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	if obj.has_method("get") and obj.get(prop) != null:
		return obj.get(prop)
	return fallback

func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out

func _is_layer2_from_obj(obj: Object) -> bool:
	if obj == null:
		return false
	var lidx := _safe_get(obj, "layer_index", null)
	if lidx != null and int(lidx) == 1:
		return true
	var has_flag := _safe_get(obj, "second_layer", null)
	if has_flag != null and bool(has_flag):
		return true
	var layer_meta := _safe_get(obj, "layer", null)
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true
	return false

func _get_vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var sid := str(_editor.current_song.id)
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var dir_rel := "editor_songs/" + sid
		var d := DirAccess.open("user://")
		if d:
			d.make_dir_recursive(dir_rel)
		return "user://%s/%s_vfx.json" % [dir_rel, diff]
	return "user://note_vfx.json"
