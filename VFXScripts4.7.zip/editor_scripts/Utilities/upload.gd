extends ScriptRunnerScript

#meta:name:Upload Current Song to Workshop
#meta:description:Opens the Workshop upload dialog for the song currently loaded in the editor.
#meta:usage:Run with a chart loaded; no selection required.

func _notify(msg: String) -> void:
	if _editor and _editor.message_shower:
		_editor.message_shower._show_notification(msg)
	else:
		print(msg)


func run_script() -> int:
	var editor := _editor as HBEditor
	if editor == null:
		push_error("UploadToWorkshop: _editor is null or not HBEditor.")
		return ERR_DOES_NOT_EXIST

	var song: HBSong = editor.current_song
	if song == null:
		_notify("No song is currently loaded in the editor.")
		return ERR_DOES_NOT_EXIST

	var popup = editor.open_chart_popup_dialog
	if popup == null:
		push_error("UploadToWorkshop: open_chart_popup_dialog not found on HBEditor.")
		return ERR_DOES_NOT_EXIST

	# Mirror the 'hidden' rules from OpenChartPopupDialog.populate_tree()
	var hidden := song.get_fs_origin() == HBSong.SONG_FS_ORIGIN.BUILT_IN and not HBGame.enable_editor_dev_mode
	hidden = hidden or song.comes_from_ugc() or song is HBPPDSong \
		or song is SongLoaderDSC.HBSongMMPLUS or song is SongLoaderDSC.HBSongDSC

	if hidden:
		_notify("This song cannot be uploaded to the Workshop (official / external / UGC source).")
		return ERR_UNAVAILABLE

	# Same logic as _on_upload_to_workshop_pressed(), but using current_song
	var verification := HBSongVerification.new()
	var errors = verification.verify_song(song)

	# Reuse the helper on the popup to detect YouTube-based songs
	if popup.song_uses_yt_urls(song):
		var error = {
			"type": -1,
			"string": "Workshop songs must not use YouTube URLs anymore, please migrate your song!",
			"fatal": false,
			"warning": false,
			"fatal_ugc": true
		}
		errors["meta"].append(error)

	if verification.has_fatal_error(errors, true) and not HBGame.enable_editor_dev_mode:
		popup.verify_song_popup.show_song_verification(
			errors,
			true,
			"Before you can upload your song, there are some issues you have to resolve:"
		)
	else:
		popup.workshop_upload_dialog.set_song(song)
		popup.workshop_upload_dialog.popup_centered_ratio()
		_notify("Opened Workshop upload dialog for: %s" % song.get_visible_title())

	return OK
