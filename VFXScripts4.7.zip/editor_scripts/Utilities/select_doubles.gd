# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Select All Double Notes
#meta:description:Clears the current selection and selects every HBDoubleNote in the chart.
#meta:usage:Run to select all double notes in the current difficulty.

func run_script() -> int:
	if _editor == null:
		push_error("[SelectDoubles] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[SelectDoubles] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var double_items: Array = []

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")
		if data == null:
			continue

		# Strictly match HBDoubleNote
		if data is HBDoubleNote:
			double_items.append(item)

	if double_items.is_empty():
		print("[SelectDoubles] No double notes found.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No double notes found.")
		return OK

	# Clear existing selection
	if _editor.has_method("clear_selection"):
		_editor.clear_selection()
	else:
		_editor.selected = []

	# Mark all doubles as selected
	for d_item in double_items:
		_set_item_selected(d_item, true)

	# Keep editor's selected array in sync
	_editor.selected = double_items.duplicate()

	if _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()

	print("[SelectDoubles] ✅ Selected %d double note(s)." % double_items.size())
	if _editor.message_shower:
		_editor.message_shower._show_notification(
			"✅ Selected %d double note(s)." % double_items.size()
		)

	return OK


func _set_item_selected(item: Object, sel: bool) -> void:
	if item == null or not is_instance_valid(item):
		return

	var has_selected_prop := false
	if item.has_method("get_property_list"):
		for p in item.get_property_list():
			if String(p.name) == "selected":
				has_selected_prop = true
				break

	if has_selected_prop:
		item.set("selected", sel)
	elif item.has_method("set_selected"):
		item.call("set_selected", sel)
	elif sel and item.has_method("select"):
		item.call("select")
	elif (not sel) and item.has_method("deselect"):
		item.call("deselect")
