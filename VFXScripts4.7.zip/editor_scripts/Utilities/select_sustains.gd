# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Select All Sustain Notes
#meta:description:Clears the current selection and selects every sustain/hold note in the chart.
#meta:usage:Run to select all sustain notes in the current difficulty.

func run_script() -> int:
	if _editor == null:
		push_error("[SelectSustains] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[SelectSustains] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var sustain_items: Array = []

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		# Only look at note items on the timeline
		if not (item is EditorTimelineItemNote):
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")

		if data == null:
			continue

		var is_sustain := false

		# Preferred: real sustain class
		if data is HBSustainNote:
			is_sustain = true
		else:
			# Fallback: duration/end_time > 0
			var duration: int = 0
			if data.has_method("get"):
				var dur_val = data.get("duration")
				if dur_val != null:
					duration = int(dur_val)
				else:
					var time_val = data.get("time")
					var end_val  = data.get("end_time")
					if time_val != null and end_val != null:
						duration = int(end_val) - int(time_val)

			if duration > 0:
				is_sustain = true

		if is_sustain:
			sustain_items.append(item)

	if sustain_items.is_empty():
		print("[SelectSustains] No sustain notes found.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No sustain notes found.")
		return OK

	# Clear existing selection
	if _editor.has_method("clear_selection"):
		_editor.clear_selection()
	else:
		_editor.selected = []

	# Mark all sustain items as selected
	for s_item in sustain_items:
		_set_item_selected(s_item, true)

	# Keep editor's selected array in sync
	_editor.selected = sustain_items.duplicate()

	# Let the editor react normally (without us poking the Inspector directly)
	if _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()

	print("[SelectSustains] ✅ Selected %d sustain note(s)." % sustain_items.size())
	if _editor.message_shower:
		_editor.message_shower._show_notification(
			"✅ Selected %d sustain note(s)." % sustain_items.size()
		)

	return OK


func _set_item_selected(item: Object, sel: bool) -> void:
	if item == null or not is_instance_valid(item):
		return

	var has_selected_prop := false
	if item.has_method("get_property_list"):
		for p in item.get_property_list():
			if String(p.name) == "selected":
				has_selected_prop = true
				break

	if has_selected_prop:
		item.set("selected", sel)
	elif item.has_method("set_selected"):
		item.call("set_selected", sel)
	elif sel and item.has_method("select"):
		item.call("select")
	elif (not sel) and item.has_method("deselect"):
		item.call("deselect")
