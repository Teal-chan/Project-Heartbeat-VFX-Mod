extends ScriptRunnerScript

#meta:name:Verify Current Song
#meta:description:Runs the song verification on the currently loaded song and opens the verification popup.
#meta:usage:Run with any chart loaded; no selection required.

func _notify(msg: String) -> void:
	if _editor and _editor.message_shower:
		_editor.message_shower._show_notification(msg)
	else:
		print(msg)


func run_script() -> int:
	var editor := _editor as HBEditor
	if editor == null:
		push_error("VerifyCurrentSong: _editor is null or not HBEditor.")
		return ERR_DOES_NOT_EXIST

	var song: HBSong = editor.current_song
	if song == null:
		_notify("No song is currently loaded in the editor.")
		return ERR_DOES_NOT_EXIST

	var popup = editor.open_chart_popup_dialog
	if popup == null:
		push_error("VerifyCurrentSong: open_chart_popup_dialog not found on HBEditor.")
		return ERR_DOES_NOT_EXIST

	var verification := HBSongVerification.new()
	var result = verification.verify_song(song)

	# Same behavior as _on_verify_button_pressed(), but using current_song
	popup.verify_song_popup.show_song_verification(result, false)

	_notify("Opened verification results for: %s" % song.get_visible_title())
	return OK
