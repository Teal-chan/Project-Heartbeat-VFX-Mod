extends ScriptRunnerScript

#meta:name:Toggle Autosave
#meta:description:Toggle the 'Automatically save when "Play" is pressed' editor setting and refresh the General settings UI.
#meta:usage:Run with any chart loaded; no selection required.

func _notify(msg: String) -> void:
	if _editor and _editor.message_shower:
		_editor.message_shower._show_notification(msg)
	else:
		print(msg)


func run_script() -> int:
	var editor := _editor as HBEditor
	if editor == null:
		push_error("ToggleAutosave: _editor is null or not HBEditor.")
		return ERR_DOES_NOT_EXIST

	var us = UserSettings.user_settings
	if us == null:
		push_error("ToggleAutosave: UserSettings.user_settings is null.")
		return ERR_DOES_NOT_EXIST

	# 1) Flip the flag
	us.editor_autosave_enabled = not us.editor_autosave_enabled
	UserSettings.save_user_settings()

	# 2) Apply new settings to the running editor
	editor.update_user_settings()

	# 3) Refresh the General settings UI so the checkbox matches
	if editor.settings_editor and editor.settings_editor.general_settings_tab:
		editor.settings_editor.general_settings_tab.update()

	var state_text := "ENABLED" if us.editor_autosave_enabled else "DISABLED"
	_notify("Editor autosave is now: %s" % state_text)

	return OK
