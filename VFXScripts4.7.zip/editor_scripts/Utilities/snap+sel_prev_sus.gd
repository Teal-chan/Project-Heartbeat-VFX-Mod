# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

extends ScriptRunnerScript

#meta:name:Jump to previous Sustain (single, no inspector)
#meta:description:Jumps to the previous Sustain note (HBSustainNote), selects only that note, and shows its preview widget without switching to the Inspector tab.
#meta:usage:Run to move to the previous Sustain note and replace the current selection quietly.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpPrevSustainNote] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST

	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpPrevSustainNote] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var sustain_entries: Array = []   # each: { "time": int, "item": Object }

	# --- collect candidate notes: HBSustainNote only -------------------------------
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var data = null
		if item.has_method("get"):
			data = item.get("data")
		if data == null:
			continue

		# Sustain filter
		if not (data is HBSustainNote):
			continue

		var t := _get_time_from_item(item)
		if t < 0:
			continue

		sustain_entries.append({ "time": t, "item": item })

	if sustain_entries.is_empty():
		print("[JumpPrevSustainNote] No Sustain notes found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No Sustain notes on the timeline.")
		return OK

	# --- choose the previous Sustain before current playhead -----------------------
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	var best_item: Object = null

	for entry in sustain_entries:
		var t: int = entry["time"]
		# We want strictly earlier notes (with a tiny tolerance like your other scripts)
		if t >= cur_ms - 1:
			continue
		if best_item == null or t > best_time:
			best_time = t
			best_item = entry["item"]

	if best_item == null:
		print("[JumpPrevSustainNote] No earlier Sustain note found (before first Sustain).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No earlier Sustain note found.")
		return OK

	# --- move playhead + quiet-select with widget ---------------------------------
	_seek_editor_to_ms(best_time)
	_select_only_item_quiet(best_item)

	print("[JumpPrevSustainNote] ✅ Jumped to previous Sustain note at ", best_time, " ms.")
	if _editor.message_shower:
		_editor.message_shower._show_notification("✅ Jumped to previous Sustain note at %d ms." % best_time)

	return OK


# --- helpers: time / seek --------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0

	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0

	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1

	var data = null
	if item.has_method("get"):
		data = item.get("data")

	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))

	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)

	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms

	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


# --- helpers: quiet single selection + preview widget ----------------------------

func _select_only_item_quiet(item: Object) -> void:
	if item == null or not is_instance_valid(item):
		return

	# 1) Deselect current selection without using select_item()
	if "selected" in _editor and _editor.selected is Array:
		for it in _editor.selected:
			if it == null or not is_instance_valid(it):
				continue
			if it.has_method("deselect"):
				it.deselect()
			elif it.has_method("set_selected"):
				it.call("set_selected", false)

		_editor.selected.clear()

	# 2) Add this item and visually select it
	_editor.selected.append(item)

	if item.has_method("select"):
		item.select()
	elif item.has_method("set_selected"):
		item.call("set_selected", true)

	# 3) Spawn preview widget for this note
	_spawn_preview_widget_for_item(item)

	# 4) Notify editor that selection changed (no inspector/tab switch here)
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()


func _spawn_preview_widget_for_item(item: Object) -> void:
	if _editor == null:
		return
	if item == null or not is_instance_valid(item):
		return
	if not item.has_method("get_editor_widget"):
		return

	var widget_res = item.get_editor_widget()
	if widget_res == null:
		return

	if not ("game_preview" in _editor):
		return

	var gp = _editor.game_preview
	if gp == null:
		return
	if not ("widget_area" in gp):
		return

	var widget_instance = widget_res.instantiate()
	if widget_instance == null:
		return

	if "editor" in widget_instance:
		widget_instance.editor = _editor

	gp.widget_area.add_child(widget_instance)

	if item.has_method("connect_widget"):
		item.connect_widget(widget_instance)
