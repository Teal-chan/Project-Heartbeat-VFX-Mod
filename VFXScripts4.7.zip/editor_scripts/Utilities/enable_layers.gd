extends ScriptRunnerScript

#meta:name:Enable All Layers
#meta:description:Marks every layer as Visible in the Song settings UI and in the editor.
#meta:usage:Run with any chart loaded; no selection required.

func _notify(msg: String) -> void:
	if _editor and _editor.message_shower:
		_editor.message_shower._show_notification(msg)
	else:
		print(msg)


func run_script() -> int:
	var editor := _editor as HBEditor
	if editor == null:
		push_error("EnableAllLayers: _editor is null or not HBEditor.")
		return ERR_DOES_NOT_EXIST

	if editor.current_song == null:
		_notify("No song is currently loaded in the editor.")
		return ERR_DOES_NOT_EXIST

	var sse = editor.song_settings_editor
	if sse == null:
		push_error("EnableAllLayers: SongSettingsEditor not found on HBEditor.")
		return ERR_DOES_NOT_EXIST

	var layers_root: TreeItem = sse.layers_item
	if layers_root == null:
		_notify("Layer visibility tree is not initialized yet.")
		return ERR_DOES_NOT_EXIST

	# Iterate all layer rows under "Layer visibility"
	var children: Array = layers_root.get_children()
	for item in children:
		if item is TreeItem:
			# Only touch items that are currently hidden
			if not item.is_checked(1):
				item.set_checked(1, true)
				# Let the settings UI handle the rest (signals + icons + text)
				sse.custom_input_parser(item)

	_notify("All layers set to Visible in Song settings.")
	return OK
