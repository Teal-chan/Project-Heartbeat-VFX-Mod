# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:True Default (Position + Motion)
#meta:description:Resets selected notes to editor defaults: autoplace position/angle/frequency and hard-reset distance & oscillation amplitude.
#meta:usage:Select notes and run. Uses the same autoplace logic as the editor.

extends ScriptRunnerScript

const DEBUG_TRUE_DEFAULT := false

func _dbg(msg: String) -> void:
	if DEBUG_TRUE_DEFAULT:
		print("[TrueDefault] ", msg)


func run_script() -> int:
	if _editor == null:
		push_error("[TrueDefault] No editor context.")
		return ERR_DOES_NOT_EXIST
	if _editor.selected.is_empty():
		push_error("[TrueDefault] No notes selected.")
		return ERR_DOES_NOT_EXIST

	# ScriptRunner helper: gives us timing point clones for the selection
	var tps := get_selected_timing_points()
	if tps.is_empty():
		push_error("[TrueDefault] No timing points resolved from selection.")
		return ERR_DOES_NOT_EXIST

	var changed_any := false

	for tp in tps:
		if tp == null:
			continue

		# Only touch objects that look like notes (have position + motion fields)
		var props := _get_property_names(tp)
		var has_pos      := "position" in props
		var has_dist     := "distance" in props
		var has_amp      := "oscillation_amplitude" in props
		var has_freq     := "oscillation_frequency" in props
		var has_angle    := "entry_angle" in props
		var has_pos_mod  := "pos_modified" in props

		if not (has_pos or has_dist or has_amp or has_freq or has_angle):
			continue

		# Ask the editor to compute the "freshly placed" version of this note.
		# force = true → ignores old pos/row and uses current timing/autoplace rules.
		var new_data = _editor.autoplace(tp, true)
		if new_data == null:
			continue

		_dbg("Resetting note at t=%d" % int(new_data.time))

		# Position / angle / frequency: taken from autoplace result
		if has_pos:
			set_timing_point_property(tp, "position", new_data.position)
		if has_angle:
			set_timing_point_property(tp, "entry_angle", new_data.entry_angle)
		if has_freq:
			set_timing_point_property(tp, "oscillation_frequency", new_data.oscillation_frequency)

		# Hard defaults for single-note travel
		# These match the "clear multi" defaults rather than chord-specific overrides.
		if has_amp:
			set_timing_point_property(tp, "oscillation_amplitude", 500.0)
		if has_dist:
			set_timing_point_property(tp, "distance", 1200.0)

		# Important: mark as *not* manually positioned so future timing changes
		# can safely re-autoplace (same as editor's reset_note_position).
		if has_pos_mod:
			set_timing_point_property(tp, "pos_modified", false)

		changed_any = true

	if not changed_any:
		print("[TrueDefault] No eligible note properties to reset.")
		return OK

	print("[TrueDefault] ✅ Reset selected notes to true defaults (position + motion, pos_modified=false).")
	return OK


# ─────────────────────────────────────────────
# Minimal helpers
# ─────────────────────────────────────────────
func _get_property_names(obj: Object) -> Array[String]:
	var out: Array[String] = []
	if obj:
		for p in obj.get_property_list():
			out.append(str(p.name))
	return out
