extends ScriptRunnerScript

#meta:name:Jump to next Sustain note
#meta:description:Jumps the playhead to the next sustain note (HBSustainNote) after the current playhead position without changing the current selection.
#meta:usage:Run to move to the next sustain note while keeping your current selection untouched.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpNextSustainNote] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	# --- collect sustain notes from the timeline -------------------------------
	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpNextSustainNote] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE
	
	var items: Array = _editor.get_timeline_items()
	var sustain_entries: Array = []   # each: { "time": int, "item": Object }
	
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		# Only timeline note items
		if not (item is EditorTimelineItemNote):
			continue
		
		var data = null
		if item.has_method("get"):
			data = item.get("data")
		
		# Only HBSustainNote
		if data == null or not (data is HBSustainNote):
			continue
		
		var t := _get_time_from_item(item)
		if t < 0:
			continue
		
		sustain_entries.append({ "time": t, "item": item })
	
	if sustain_entries.is_empty():
		print("[JumpNextSustainNote] No sustain notes found on the timeline.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No sustain notes on the timeline.")
		return OK
	
	# --- choose the next sustain after current playhead ------------------------
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	
	for entry in sustain_entries:
		var t: int = entry["time"]
		# strictly after current playhead (allow tiny tolerance)
		if t <= cur_ms + 1:
			continue
		if best_time == -1 or t < best_time:
			best_time = t
	
	if best_time == -1:
		print("[JumpNextSustainNote] No later sustain note found (past last sustain).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No later sustain note found.")
		return OK
	
	# --- move playhead ONLY ----------------------------------------------------
	_seek_editor_to_ms(best_time)
	
	print("[JumpNextSustainNote] 🎵 Jumped to next sustain note at ", best_time, " ms (selection unchanged).")
	if _editor.message_shower:
		_editor.message_shower._show_notification("🎵 Jumped to next sustain at %d ms (selection unchanged)." % best_time)
	
	return OK


# --- helpers: time / seek -----------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	
	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	if item == null or not is_instance_valid(item):
		return -1
	
	var data = null
	if item.has_method("get"):
		data = item.get("data")
	
	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))
	
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))
	
	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)
	
	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms
	
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()
	
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()
