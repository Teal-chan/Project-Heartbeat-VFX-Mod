extends ScriptRunnerScript

#meta:name:Compile Shaders
#meta:description:Attach / configure PH_VFX_MegaInjector to the editor and arm it.
#meta:usage:Run once per session after writing animation rows.

const INJECTOR_SCRIPT_PATH := "user://editor_scripts/Utilities/injector.gd"

func _vfx_path() -> String:
	if _editor and _editor.current_song and _editor.current_difficulty:
		var song = _editor.current_song
		var diff := str(_editor.current_difficulty).replace(" ", "_")
		var diff_lower := diff.to_lower()

		# 1) Look next to the song file/folder (works for workshop AND editor songs)
		var song_res_path: String = song.path
		print("[PH_VFX_Compile] song.path = %s" % song_res_path)

		if song_res_path != "":
			var song_fs_path := ProjectSettings.globalize_path(song_res_path)
			var dir_path := song_fs_path
			print("[PH_VFX_Compile] Globalized path = %s" % song_fs_path)

			# If song.path points to a file, use its parent directory
			if not DirAccess.dir_exists_absolute(dir_path):
				dir_path = song_fs_path.get_base_dir()
				print("[PH_VFX_Compile] Not a directory, using parent: %s" % dir_path)

			if DirAccess.dir_exists_absolute(dir_path):
				var dir := DirAccess.open(dir_path)
				if dir != null:
					var preferred := ""   # "<difficulty>_vfx.json"
					var fallback := ""    # any "*_vfx.json"
					var loose := ""       # any JSON with "vfx" in the name

					dir.list_dir_begin()
					while true:
						var fn := dir.get_next()
						if fn == "":
							break
						if dir.current_is_dir():
							continue

						var lower := fn.to_lower()
						if not lower.ends_with(".json"):
							continue

						if lower == "%s_vfx.json" % diff_lower:
							preferred = dir_path.path_join(fn)
							break
						if fallback == "" and lower.ends_with("_vfx.json"):
							fallback = dir_path.path_join(fn)
							continue
						if loose == "" and lower.find("vfx") != -1:
							loose = dir_path.path_join(fn)
					dir.list_dir_end()

					var os_path := preferred
					if os_path == "" and fallback != "":
						os_path = fallback
					if os_path == "" and loose != "":
						os_path = loose

					if os_path != "":
						var vfs_path := ProjectSettings.localize_path(os_path)
						print("[PH_VFX_Compile] Using song-local VFX JSON: %s" % vfs_path)
						return vfs_path
					else:
						print("[PH_VFX_Compile] No VFX JSON found in song directory: %s" % dir_path)
				else:
					print("[PH_VFX_Compile] Could not open directory: %s" % dir_path)
			else:
				print("[PH_VFX_Compile] Directory does not exist: %s" % dir_path)
		else:
			print("[PH_VFX_Compile] song.path is empty")

		# 2) Legacy editor path (user://editor_songs/<id>/<diff>_vfx.json)
		var sid := str(song.id)
		var candidate := "user://editor_songs/%s/%s_vfx.json" % [sid, diff]
		print("[PH_VFX_Compile] Trying legacy editor path: %s" % candidate)
		if FileAccess.file_exists(candidate):
			print("[PH_VFX_Compile] Using editor_songs VFX JSON: %s" % candidate)
			return candidate
		else:
			print("[PH_VFX_Compile] Legacy path not found: %s" % candidate)
	else:
		print("[PH_VFX_Compile] Missing editor/song/difficulty context")

	# 3) Global fallback
	print("[PH_VFX_Compile] Falling back to global: user://note_vfx.json")
	return "user://note_vfx.json"


func run_script() -> int:
	if _editor == null:
		push_error("[PH_VFX_Compile] ❌ No HBEditor reference.")
		return ERR_DOES_NOT_EXIST

	# 1) Find existing injector node, if any
	var mgr = _editor.get_node_or_null("PH_VFX_MegaInjector")
	# 2) If missing, load the external script and create it
	if mgr == null:
		var res := load(INJECTOR_SCRIPT_PATH)
		if res == null:
			push_error("[PH_VFX_Compile] ❌ Could not load injector script at: %s" % INJECTOR_SCRIPT_PATH)
			return ERR_CANT_ACQUIRE_RESOURCE

		mgr = res.new()
		if not (mgr is Node):
			push_error("[PH_VFX_Compile] ❌ Injector script did not produce a Node.")
			return ERR_CANT_ACQUIRE_RESOURCE

		mgr.name = "PH_VFX_MegaInjector"
		_editor.add_child(mgr)

	# 3) Sanity-check the API
	if not mgr.has_method("configure") or not mgr.has_method("arm"):
		push_error("[PH_VFX_Compile] ❌ Injector is missing configure() or arm().")
		return ERR_CANT_ACQUIRE_RESOURCE

	# 4) Configure + arm using the same JSON path logic as before
	var vfx_path := _vfx_path()
	mgr.call("configure", _editor, vfx_path)
	mgr.call("arm")

	print("💥 VFX Mega Injector armed (external injector scripts).")

	return OK
