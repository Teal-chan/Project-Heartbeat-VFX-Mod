extends ScriptRunnerScript

#meta:name:Go To Playhead
#meta:description:Scrolls the timeline so the current playhead is in view (centered).
#meta:usage:Run to re-center the editor timeline around the current playhead.

func run_script() -> int:
	if _editor == null:
		push_error("Go To Playhead: no editor reference.")
		return ERR_DOES_NOT_EXIST

	var tl = _editor.timeline
	if tl == null:
		push_error("Go To Playhead: editor.timeline is null.")
		return ERR_DOES_NOT_EXIST

	# First, make sure the playhead is on-screen at all.
	tl.ensure_playhead_is_visible()

	# Now center the playhead in the visible region.
	# Same idea as HBEditor._on_game_playback_time_changed()
	var half_width = tl.size.x / 2.0
	var playhead_pos_x = tl.calculate_playhead_position().x
	var current_playhead_offset = half_width - playhead_pos_x
	var target_offset = tl._offset - current_playhead_offset

	tl.set_layers_offset(target_offset)

	return OK
