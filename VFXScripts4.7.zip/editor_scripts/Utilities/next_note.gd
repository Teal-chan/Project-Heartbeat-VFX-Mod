extends ScriptRunnerScript

#meta:name:Jump to and select next chord (no inspector)
#meta:description:Moves the editor playhead to the next note time and ADDS all notes at that time to the current selection, without switching to the Inspector tab.
#meta:usage:Run to jump to the next chord/multi on the timeline and extend selection.

func run_script() -> int:
	if _editor == null:
		push_error("[JumpNextChord] No editor context (_editor is null).")
		return ERR_DOES_NOT_EXIST
	
	if not _editor.has_method("get_timeline_items"):
		push_error("[JumpNextChord] Editor has no get_timeline_items() method.")
		return ERR_UNAVAILABLE
	
	var items: Array = _editor.get_timeline_items()
	var times: Array[int] = []
	
	# Collect all unique note times
	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue
		
		var t := _get_time_from_item(item)
		if t < 0:
			continue
		
		if not times.has(t):
			times.append(t)
	
	if times.is_empty():
		print("[JumpNextChord] No notes found on the timeline.")
		return OK
	
	times.sort()
	
	var cur_ms := _get_current_playhead_ms()
	var best_time := -1
	
	# Find the smallest note time strictly greater than current playhead
	for t in times:
		if t > cur_ms + 1:
			best_time = t
			break
	
	if best_time == -1:
		print("[JumpNextChord] No later chord found (already at or past the last note).")
		if _editor.message_shower:
			_editor.message_shower._show_notification("ℹ️ No later note found.")
		return OK
	
	# Move playhead
	_seek_editor_to_ms(best_time)
	
	# ADD all notes at best_time to selection WITHOUT poking the Inspector
	_add_items_at_time_to_selection_quiet(best_time)
	
	print("[JumpNextChord] ▶ Jumped to chord at ", best_time, " ms and extended selection (quiet).")
	if _editor.message_shower:
		_editor.message_shower._show_notification("▶ Jumped to chord at %d ms (selection extended)" % best_time)
	
	return OK


# --- helpers -------------------------------------------------------------

func _get_current_playhead_ms() -> int:
	if _editor == null:
		return 0
	var v = null
	if _editor.has_method("get"):
		v = _editor.get("playhead_position")
	if v == null:
		return 0
	return int(round(float(v)))


func _get_time_from_item(item: Object) -> int:
	var data = null
	if item.has_method("get"):
		data = item.get("data")
	
	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))
	
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))
	
	return -1


func _seek_editor_to_ms(ms: int) -> void:
	# Clamp to song length just in case
	if _editor.current_song and _editor.has_method("get_song_length"):
		var max_ms := int(_editor.get_song_length() * 1000.0)
		ms = clamp(ms, 0, max_ms)
	
	if _editor.has_method("seek"):
		_editor.seek(ms)
	else:
		_editor.playhead_position = ms
	
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()
	
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()


func _add_items_at_time_to_selection_quiet(target_time_ms: int) -> void:
	# Use editor helper to get items at that exact time
	if not _editor.has_method("get_items_at_time"):
		return
	
	var items_at_time: Array = _editor.get_items_at_time(target_time_ms)
	if items_at_time.is_empty():
		return
	
	# Work directly on _editor.selected so we don't trigger inspector/select_item logic
	for item in items_at_time:
		if item == null or not is_instance_valid(item):
			continue
		
		# Avoid duplicates
		if item in _editor.selected:
			continue
		
		# Extend the selection array
		_editor.selected.append(item)
		
		# Visually mark this item as selected
		if item.has_method("select"):
			item.select()
		elif item.has_method("set_selected"):
			item.call("set_selected", true)
	
	# Tell the editor that selection changed (updates timeline + modules),
	# but does NOT switch to Inspector (that only happens in select_item()).
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()
