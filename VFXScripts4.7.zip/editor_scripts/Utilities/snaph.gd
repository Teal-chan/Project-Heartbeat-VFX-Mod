# Any script that interacts with the Project Heartbeat API is licensed under the
# AGPLv3 for the general public and also gives an exclusive, royalty-free license
# for EIRTeam to incorporate it in the game

#meta:name:Select Note At Playhead
#meta:description:Adds all notes at the (snapped) playhead time to the current selection.
#meta:usage:Move the playhead to a note, then run. Existing selection is preserved; notes at playhead are added.

extends ScriptRunnerScript

func run_script() -> int:
	if _editor == null:
		printerr("[SelectNoteAtPlayhead] ❌ Editor not found.")
		return ERR_DOES_NOT_EXIST

	# 1) Get playhead time (ms)
	var playhead_pos: int = int(_editor.playhead_position)

	# 2) Snap to timeline grid, same behavior as keyboard note input
	var t: int = playhead_pos
	if _editor.has_method("snap_time_to_timeline"):
		t = int(_editor.snap_time_to_timeline(playhead_pos))

	# 3) Get items at that time
	if not _editor.has_method("get_items_at_time"):
		printerr("[SelectNoteAtPlayhead] ❌ Editor does not expose get_items_at_time().")
		return ERR_DOES_NOT_EXIST

	var items: Array = _editor.get_items_at_time(t)

	# 4) Filter to actual notes (HBBaseNote and derived)
	var note_items: Array = []
	for item in items:
		var data := _safe_get(item, "data", null)
		if data != null and data is HBBaseNote:
			note_items.append(item)

	if note_items.is_empty():
		var msg := "No notes at playhead (t=%d ms)" % t
		printerr("[SelectNoteAtPlayhead] " + msg)
		if _editor.message_shower:
			_editor.message_shower._show_notification("⚠️ " + msg)
		return ERR_DOES_NOT_EXIST

	# 5) Add them to selection WITHOUT calling select_item (no inspector jump)
	var cur_selection: Array = []
	if "selected" in _editor and _editor.selected is Array:
		cur_selection = _editor.selected.duplicate()

	for item in note_items:
		if not cur_selection.has(item):
			cur_selection.append(item)

			# visually mark as selected
			if item.has_method("select"):
				item.select()
			elif item.has_method("set_selected"):
				item.call("set_selected", true)
			else:
				# last-resort: try a 'selected' property if it exists
				if item.has_method("get_property_list"):
					for p in item.get_property_list():
						if String(p.name) == "selected":
							item.set("selected", true)
							break

	_editor.selected = cur_selection

	# Let the editor know the selection changed, but this should NOT switch inspector tabs
	if _editor.has_method("notify_selected_changed"):
		_editor.notify_selected_changed()
	elif _editor.has_method("_on_selection_changed"):
		_editor._on_selection_changed()

	if _editor.message_shower:
		_editor.message_shower._show_notification(
			"Selected %d note(s) at t=%d ms" % [note_items.size(), t]
		)

	print("[SelectNoteAtPlayhead] ✅ Selected %d note(s) at t=%d ms" % [note_items.size(), t])
	return OK


# ───────────────────────────────────────────────────────────────────────────────
# Helper (same pattern as your other scripts)
# ───────────────────────────────────────────────────────────────────────────────

func _safe_get(obj: Object, prop: String, fallback: Variant = null) -> Variant:
	if obj == null:
		return fallback
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if str(p.name) == prop:
				return obj.get(prop)
	if obj.has_method("has_meta") and obj.has_meta(prop):
		return obj.get_meta(prop)
	return fallback
