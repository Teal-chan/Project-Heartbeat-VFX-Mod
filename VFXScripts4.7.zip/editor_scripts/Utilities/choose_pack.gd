#meta:name:Select icon pack (dropdown)
#meta:description:Shows a dropdown of all available resource packs, applies the selected one, rebuilds atlases, and refreshes timeline, lane headers, minimap and GamePreview.
#meta:usage:Run, choose a pack from the popup, then press OK.

extends ScriptRunnerScript

const PREFERRED_PACK_ORDER = [
	"default_skin",
	"nintendo",
	"playstation",
	"xbox",
	"vfxfriendly_icons_for_nintendo",
	"vfxfriendly_icons_for_xboxsteam_deck",
	"whitegrayscale_icons_for_vfx"
]

# Packs that should also drive the UI skin
const SKIN_PACK_KEYS := {
	"default_skin": true,
	"nintendo": true,
	"playstation": true,
	"xbox": true,
}


# -------------------------------------------------------------------
# Helper node that owns the dialog + application logic
# -------------------------------------------------------------------
class IconPackDialogHandler:
	extends Node

	var editor            # HBEditor instance
	var pack_keys = []    # Array of String

	func show_dialog():
		if editor == null:
			print("SelectIconPackHandler: editor is null")
			queue_free()
			return
		
		var tree = editor.get_tree()
		if tree == null:
			print("SelectIconPackHandler: get_tree() returned null")
			queue_free()
			return
		
		var root = tree.get_root()
		if root == null:
			print("SelectIconPackHandler: root is null")
			queue_free()
			return
		
		var dialog = AcceptDialog.new()
		dialog.title = "Select icon pack"
		dialog.min_size = Vector2(420, 140)
		dialog.unresizable = true
		
		var vbox = VBoxContainer.new()
		vbox.custom_minimum_size = Vector2(380, 80)
		dialog.add_child(vbox)
		
		var label = Label.new()
		label.text = "Select a resource pack:"
		vbox.add_child(label)
		
		var option = OptionButton.new()
		vbox.add_child(option)
		
		var current_key = String(UserSettings.user_settings.resource_pack)
		var selected_idx = 0
		var idx = 0
		for key in pack_keys:
			var str_key = String(key)
			option.add_item(str_key)
			if str_key == current_key:
				selected_idx = idx
			idx += 1
		option.select(selected_idx)
		
		root.add_child(dialog)
		
		dialog.connect(
			"confirmed",
			Callable(self, "_on_dialog_confirmed").bind(dialog, option)
		)
		
		dialog.popup_centered()
		print("SelectIconPackHandler: dialog shown with packs: ", pack_keys)

	func _on_dialog_confirmed(dialog: AcceptDialog, option: OptionButton):
		var idx = option.get_selected()
		dialog.queue_free()
		
		if idx < 0 or idx >= pack_keys.size():
			print("SelectIconPackHandler: invalid index, doing nothing")
			queue_free()
			return
		
		var chosen_key = String(pack_keys[idx])
		var current_key = String(UserSettings.user_settings.resource_pack)
		print("SelectIconPackHandler: user chose pack: ", chosen_key)
		
		if chosen_key == current_key:
			print("SelectIconPackHandler: same pack selected, nothing to change")
			queue_free()
			return
		
		_apply_pack(chosen_key)
		queue_free()

	func _apply_pack(chosen_key: String):
		if editor == null:
			print("SelectIconPackHandler: editor null in _apply_pack")
			return
		
		var tree = editor.get_tree()
		if tree == null:
			print("SelectIconPackHandler: get_tree() null in _apply_pack")
			return
		
		var root = tree.get_root()
		if root == null:
			print("SelectIconPackHandler: root null in _apply_pack")
			return
		
		var loader = root.get_node("ResourcePackLoader")
		if loader == null:
			print("SelectIconPackHandler: ResourcePackLoader not found")
			return
		
		var packs = loader.resource_packs
		if packs == null or typeof(packs) != TYPE_DICTIONARY:
			print("SelectIconPackHandler: resource_packs invalid in _apply_pack")
			return
		
		# 1) Update user settings
		UserSettings.user_settings.resource_pack = chosen_key
		
		# 2) Rebuild atlases
		if loader.has_method("rebuild_final_atlases"):
			loader.rebuild_final_atlases()
			print("SelectIconPackHandler: called rebuild_final_atlases()")
		else:
			print("SelectIconPackHandler: WARNING - loader has no rebuild_final_atlases()")
		
		# 3) If this pack is (or should act as) a UI skin, hook it in.
		var pack = packs.get(chosen_key, null)
		var should_apply_skin := false

		# A) Pack explicitly reports "I am a skin"
		if pack != null and pack.has_method("is_skin") and pack.is_skin():
			should_apply_skin = true
		# B) Or we’ve whitelisted it as a skin-driving pack (e.g. console glyph sets)
		elif SKIN_PACK_KEYS.has(chosen_key):
			should_apply_skin = true

		if should_apply_skin:
			UserSettings.user_settings.ui_skin = chosen_key
			if loader.has_method("reload_skin"):
				loader.reload_skin()
				print("SelectIconPackHandler: applied UI skin = %s and called reload_skin()" % chosen_key)
		else:
			print("SelectIconPackHandler: pack %s is not a UI skin; leaving ui_skin as %s"
				% [chosen_key, String(UserSettings.user_settings.ui_skin)])

		
		# 4) Refresh timeline items (note icons on the grid)
		_refresh_timeline_items()
		
		# 4.5) Refresh lane header icons using the same logic as CycleIconRebuild
		_refresh_lane_header_icons()
		
		# 5) Redraw timeline & minimap
		_refresh_timeline_and_minimap()
		
		# 6) Persist settings
		if UserSettings.has_method("save_user_settings"):
			UserSettings.save_user_settings()
			print("SelectIconPackHandler: UserSettings.save_user_settings() called")
		
		# 7) Rebuild runtime preview notes (preview + playtest)
		_rebuild_preview_runtime_notes()

		# 8) If a playtest is running, refresh the HoldIndicator icons there too
		_refresh_hold_indicator_icons()

		# 9) Try to clear any custom judgement overrides so defaults take over
		_refresh_judgement_labels()

		print("SelectIconPackHandler: apply_pack complete for ", chosen_key)


	func _refresh_timeline_items():
		if editor == null or not editor.has_method("get_timeline_items"):
			print("SelectIconPackHandler: WARNING - editor.get_timeline_items() not found")
			return
		
		var items = editor.get_timeline_items()
		print("SelectIconPackHandler: refreshing textures on ", items.size(), " timeline items")
		for item in items:
			if item == null:
				continue
			if item.has_method("set_texture"):
				item.set_texture()
			if item.has_method("update_widget_data"):
				item.update_widget_data()
			if item.has_method("queue_redraw"):
				item.queue_redraw()

	func _refresh_hold_indicator_icons() -> void:
		# Only matters if a playtest RhythmGame UI (HoldIndicator) exists.
		if editor == null:
			return

		var tree = editor.get_tree()
		if tree == null:
			return
		var root = tree.get_root()
		if root == null:
			return

		# Find all nodes named "HoldIndicator" in the current scene tree.
		var hold_nodes: Array = []
		var stack: Array = [root]
		while stack.size() > 0:
			var n = stack.pop_back()
			if n == null:
				continue
			if String(n.name) == "HoldIndicator":
				hold_nodes.append(n)
			for c in n.get_children():
				stack.append(c)

		if hold_nodes.is_empty():
			# No playtest / no hold-bonus UI visible.
			return

		# Use the current pack's UP note glyph as the generic hold icon.
		var up_type = null
		if HBBaseNote.NOTE_TYPE.has("UP"):
			up_type = HBBaseNote.NOTE_TYPE["UP"]
		elif HBNoteData.NOTE_TYPE.has("UP"):
			up_type = HBNoteData.NOTE_TYPE["UP"]

		if up_type == null:
			return

		var tex := HBNoteData.get_note_graphic(up_type, "note") as Texture2D
		if tex == null:
			return

		for hold in hold_nodes:
			_apply_tex_to_hold_indicator(hold, tex)

	func _apply_tex_to_hold_indicator(node: Node, tex: Texture2D) -> void:
		# Only touch TextureRects under HoldIndicator; other children (labels, panels)
		# are left alone.
		if node is TextureRect:
			var tr := node as TextureRect
			tr.texture = tex
			tr.queue_redraw()

		for child in node.get_children():
			_apply_tex_to_hold_indicator(child, tex)

	func _apply_texture_to_children(node: Node, tex: Texture2D) -> void:
		if node is TextureRect:
			var tr := node as TextureRect
			tr.texture = tex
			tr.queue_redraw()
		elif node is TextureButton:
			var tb := node as TextureButton
			tb.texture_normal = tex
			tb.queue_redraw()
		elif node is TextureProgressBar:
			var tp := node as TextureProgressBar
			tp.texture_progress = tex
			tp.queue_redraw()
		
		for child in node.get_children():
			_apply_texture_to_children(child, tex)

	func _refresh_lane_header_icons() -> void:
		if editor == null:
			print("SelectIconPackHandler: no editor for lane header refresh")
			return
		
		if not ("timeline" in editor):
			print("SelectIconPackHandler: editor has no 'timeline'; skipping lane headers")
			return
		
		var timeline = editor.timeline
		if timeline == null:
			print("SelectIconPackHandler: editor.timeline is null; skipping lane headers")
			return
		
		if not ("layer_names" in timeline):
			print("SelectIconPackHandler: timeline has no 'layer_names'; skipping lane headers")
			return
		
		var name_container = timeline.layer_names
		if name_container == null:
			print("SelectIconPackHandler: timeline.layer_names is null; skipping lane headers")
			return
		
		var updated := 0
		
		for name_node in name_container.get_children():
			if name_node == null:
				continue
			
			if not ("layer_name" in name_node):
				continue
			
			var ln := String(name_node.layer_name)
			
			var base_name := ln
			if base_name.ends_with("2"):
				base_name = base_name.substr(0, base_name.length() - 1)
			
			var note_type = null
			if HBNoteData.NOTE_TYPE.has(base_name):
				note_type = HBNoteData.NOTE_TYPE[base_name]
			elif HBBaseNote.NOTE_TYPE.has(base_name):
				note_type = HBBaseNote.NOTE_TYPE[base_name]
			
			if note_type == null:
				continue
			
			var tex := HBNoteData.get_note_graphic(note_type, "note") as Texture2D
			if tex == null:
				continue
			
			_apply_texture_to_children(name_node, tex)
			updated += 1
		
		print("SelectIconPackHandler: lane header icons refreshed (via layer_names): ", updated)

	func _refresh_timeline_and_minimap():
		if editor == null:
			return
		
		if not ("timeline" in editor):
			return
		
		var timeline = editor.timeline
		if timeline == null:
			return
		
		if timeline.has_method("queue_redraw"):
			timeline.queue_redraw()
			print("SelectIconPackHandler: timeline.queue_redraw() called")
		
		if timeline.has_method("send_time_cull_changed_signal"):
			timeline.send_time_cull_changed_signal()
			print("SelectIconPackHandler: timeline.send_time_cull_changed_signal() called")
		
		if "minimap" in timeline:
			var minimap = timeline.minimap
			if minimap != null and minimap.has_method("queue_redraw"):
				minimap.queue_redraw()
				print("SelectIconPackHandler: minimap.queue_redraw() called")

	func _rebuild_preview_runtime_notes():
		if editor == null:
			print("SelectIconPackHandler: no editor in preview rebuild")
			return

		var games := _get_runtime_rhythm_games()
		if games.is_empty():
			print("SelectIconPackHandler: no rhythm_game instances found")
			return

		var items: Array = []
		if editor.has_method("get_timeline_items"):
			items = editor.get_timeline_items()

		for rg in games:
			if rg == null:
				continue

			if rg.has_method("editor_clear_notes"):
				rg.editor_clear_notes()
				print("SelectIconPackHandler: editor_clear_notes() on ", rg)

			if items.size() > 0 and rg.has_method("editor_add_timing_point"):
				var count := 0
				for item in items:
					if item == null:
						continue
					if item.data is HBTimingPoint:
						rg.editor_add_timing_point(item.data, false)
						count += 1
				print("SelectIconPackHandler: re-added ", count, " timing points to ", rg)

		# These are editor-level helpers; we only need to call them once.
		if editor.has_method("sort_groups"):
			editor.sort_groups()
			print("SelectIconPackHandler: editor.sort_groups() called")

		if editor.has_method("force_game_process"):
			editor.force_game_process()

	# Helper: find all active rhythm_game instances (preview + playtest)
	func _get_runtime_rhythm_games() -> Array:
		var games: Array = []
		if editor == null:
			return games

		# Editor / preview instance
		if "rhythm_game" in editor:
			var rg1 = editor.rhythm_game
			if rg1 != null and not games.has(rg1):
				games.append(rg1)

		# Playtest popup instance, if present
		if editor.has_method("get"):
			var popup = editor.get("rhythm_game_playtest_popup")
			if popup is Node:
				var rg2 = (popup as Node).get("rhythm_game")
				if rg2 != null and not games.has(rg2):
					games.append(rg2)

		return games

	func _refresh_judgement_labels() -> void:
		# Try to retarget JudgementLabel’s textures to the current resource pack.
		if editor == null:
			return

		var tree = editor.get_tree()
		if tree == null:
			return
		var root = tree.get_root()
		if root == null:
			return

		var loader = root.get_node_or_null("ResourcePackLoader")
		if loader == null:
			print("SelectIconPackHandler: no ResourcePackLoader when refreshing judgements")
			return

		# 1) Collect all atlas keys that look like judgement graphics.
		var judgement_keys: Array[String] = []
		var ft = loader.final_textures
		if typeof(ft) == TYPE_DICTIONARY:
			for key in ft.keys():
				var s := String(key).to_lower()
				if s.find("judge") != -1 or s.find("judgement") != -1:
					judgement_keys.append(String(key))

		if judgement_keys.is_empty():
			print("SelectIconPackHandler: no judgement-like keys in final_textures")
			return

		judgement_keys.sort()

		# 2) Find all JudgementLabel nodes in the running scene tree.
		var jl_nodes: Array = []
		var stack: Array = [root]
		while stack.size() > 0:
			var n = stack.pop_back()
			if n == null:
				continue
			if String(n.name) == "JudgementLabel":
				jl_nodes.append(n)
			for c in n.get_children():
				stack.append(c)

		if jl_nodes.is_empty():
			print("SelectIconPackHandler: no JudgementLabel nodes found")
			return

		# 3) For each JudgementLabel, collect all TextureRect/Sprite2D children
		#    and assign judgement textures in order.
		var total_changed := 0

		for jl in jl_nodes:
			var tex_nodes: Array = []
			_collect_judgement_texture_nodes(jl, tex_nodes)

			if tex_nodes.is_empty():
				continue

			var idx := 0
			for tex_node in tex_nodes:
				if idx >= judgement_keys.size():
					break

				var key := judgement_keys[idx]
				var tex = loader.get_graphic(key)
				if tex == null:
					idx += 1
					continue

				if tex_node is TextureRect:
					var tr := tex_node as TextureRect
					tr.texture = tex
					tr.queue_redraw()
					total_changed += 1
				elif tex_node is Sprite2D:
					var sp := tex_node as Sprite2D
					sp.texture = tex
					sp.queue_redraw()
					total_changed += 1

				idx += 1

		print("SelectIconPackHandler: judgement refresh changed %d texture slots" % total_changed)

	func _collect_judgement_texture_nodes(node: Node, out: Array) -> void:
		# Collect TextureRect/Sprite2D children under JudgementLabel.
		if node is TextureRect or node is Sprite2D:
			out.append(node)

		for child in node.get_children():
			_collect_judgement_texture_nodes(child, out)

	func _retarget_judgement_node(node: Node, loader: Node, tex_to_key: Dictionary) -> int:
		var changed := 0

		if node is TextureRect:
			var tr = node as TextureRect
			if tr.texture != null and tex_to_key.has(tr.texture):
				var key = tex_to_key[tr.texture]
				var new_tex = loader.get_graphic(key)
				if new_tex != null:
					tr.texture = new_tex
					tr.queue_redraw()
					changed += 1

		elif node is Sprite2D:
			var sp = node as Sprite2D
			if sp.texture != null and tex_to_key.has(sp.texture):
				var key2 = tex_to_key[sp.texture]
				var new_tex2 = loader.get_graphic(key2)
				if new_tex2 != null:
					sp.texture = new_tex2
					sp.queue_redraw()
					changed += 1

		for child in node.get_children():
			changed += _retarget_judgement_node(child, loader, tex_to_key)

		return changed



# -------------------------------------------------------------------
# Script entry point
# -------------------------------------------------------------------
func run_script() -> int:
	if _editor == null:
		print("SelectIconPack: _editor is null")
		return OK
	
	var tree = _editor.get_tree()
	if tree == null:
		print("SelectIconPack: _editor.get_tree() returned null")
		return OK
	
	var root = tree.get_root()
	if root == null:
		print("SelectIconPack: tree.get_root() returned null")
		return OK
	
	var loader = root.get_node("ResourcePackLoader")
	if loader == null:
		print("SelectIconPack: /root/ResourcePackLoader not found")
		return OK
	
	print("SelectIconPack: ResourcePackLoader found at ", loader.get_path())
	
	var packs = loader.resource_packs
	if packs == null:
		print("SelectIconPack: loader.resource_packs is null")
		return OK
	if typeof(packs) != TYPE_DICTIONARY:
		print("SelectIconPack: resource_packs is not a Dictionary, type id: ", typeof(packs))
		return OK
	
	# Build ordered list of pack keys:
	# 1) preferred/builtin keys in our known order
	# 2) any remaining keys (UGC etc.), sorted alphabetically
	var ordered_keys: Array = []
	for key in PREFERRED_PACK_ORDER:
		if packs.has(key) and not ordered_keys.has(String(key)):
			ordered_keys.append(String(key))
	
	var remaining: Array = []
	for key in packs.keys():
		var k = String(key)
		if not ordered_keys.has(k):
			remaining.append(k)
	remaining.sort()
	for key in remaining:
		ordered_keys.append(key)
	
	if ordered_keys.size() == 0:
		print("SelectIconPack: No resource_packs available.")
		return OK
	
	print("SelectIconPack: Available packs: ", ordered_keys)
	print("SelectIconPack: current resource_pack = ", UserSettings.user_settings.resource_pack)
	
	var handler = IconPackDialogHandler.new()
	handler.editor = _editor
	handler.pack_keys = ordered_keys
	root.add_child(handler)
	handler.show_dialog()
	
	print("SelectIconPack: dialog handler added.")
	return OK
