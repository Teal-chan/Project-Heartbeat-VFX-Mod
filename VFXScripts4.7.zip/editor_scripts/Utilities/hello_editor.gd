extends ScriptRunnerScript

#meta:name: Hello Editor
#meta:description: Verifies we have an HBEditor instance and shows its current playhead.
#meta:usage: Run any time with a chart open.

func run_script() -> int:
	if _editor == null:
		printerr("[HelloEditor] ❌ No HBEditor reference.")
		return ERR_DOES_NOT_EXIST

	var pos_ms := int(_editor.playhead_position)
	print("[HelloEditor] ✅ Playhead at %d ms" % pos_ms)

	if _editor.message_shower:
		_editor.message_shower._show_notification(
			"Playhead at %d ms" % pos_ms
		)

	return OK
