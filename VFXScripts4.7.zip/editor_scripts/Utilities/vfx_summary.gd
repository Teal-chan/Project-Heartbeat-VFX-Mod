extends ScriptRunnerScript

#meta:name:VFX Summary
#meta:description:Shows a summary of VFX usage and bookmarks for the current chart.
#meta:usage:Run while PH_VFX_MegaInjector is active.

func run_script() -> int:
	if _editor == null:
		push_error("[VFXSummary] ❌ No editor context.")
		return ERR_DOES_NOT_EXIST

	# --- Find injector -------------------------------------------------
	var mgr: Node = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if mgr == null:
		mgr = _editor.find_child("PH_VFX_MegaInjector", true, false)

	if mgr == null:
		push_error("[VFXSummary] ❌ PH_VFX_MegaInjector not found. Inject VFX first.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("❌ VFX Injector not found. Inject VFX first.")
		return ERR_DOES_NOT_EXIST

	# anim_bank + key helper
	var anim_bank = null
	if mgr.has_method("get"):
		anim_bank = mgr.get("anim_bank")

	var has_injector_key_helper := mgr.has_method("_key_for_note_data")

	# keys_with_vfx dictionary
	var keys_with_vfx: Dictionary = {}
	if mgr.has_method("get"):
		var raw = mgr.get("_keys_with_vfx")
		if typeof(raw) == TYPE_DICTIONARY:
			keys_with_vfx = raw

	# --- Gather timeline notes -----------------------------------------
	if not _editor.has_method("get_timeline_items"):
		push_error("[VFXSummary] Editor has no get_timeline_items().")
		return ERR_UNAVAILABLE

	var items: Array = _editor.get_timeline_items()
	var total_notes := 0
	var notes_with_any_vfx := 0

	# Per-lane stats: lane_name -> { total:int, with_vfx:int }
	var lane_stats: Dictionary = {}

	for item in items:
		if item == null or not is_instance_valid(item):
			continue
		if not (item is EditorTimelineItemNote):
			continue

		var note_obj = item.data
		if note_obj == null:
			continue

		total_notes += 1

		# Lane name (UP / DOWN / SLIDE_LEFT / etc.)
		var lane := _lane_name_from_note_data(note_obj)
		if lane == "":
			lane = "UNKNOWN"

		if not lane_stats.has(lane):
			lane_stats[lane] = {"total": 0, "with_vfx": 0}
		var L: Dictionary = lane_stats[lane]
		L["total"] = int(L.get("total", 0)) + 1
		lane_stats[lane] = L

		# VFX key lookup
		var key := ""
		if has_injector_key_helper:
			var k_val = mgr.call("_key_for_note_data", note_obj)
			if typeof(k_val) == TYPE_STRING:
				key = k_val
		else:
			key = _build_vfx_key_for_note_data(note_obj)

		if key != "" and keys_with_vfx.has(key):
			notes_with_any_vfx += 1
			L = lane_stats[lane]
			L["with_vfx"] = int(L.get("with_vfx", 0)) + 1
			lane_stats[lane] = L

	# --- Top-level counts ----------------------------------------------
	var notes_without_vfx := max(0, total_notes - notes_with_any_vfx)
	var pct_with: float = 0.0
	var pct_without: float = 0.0
	if total_notes > 0:
		pct_with = (notes_with_any_vfx * 100.0) / total_notes
		pct_without = (notes_without_vfx * 100.0) / total_notes

	# --- VFX type counts from anim_bank -------------------------------
	var type_counts: Dictionary = {}
	if anim_bank != null:
		type_counts["scale"]  = _count_bucket_keys(anim_bank, "buckets_scale")
		type_counts["color"]  = _count_bucket_keys(anim_bank, "buckets_color")
		type_counts["rot"]    = _count_bucket_keys(anim_bank, "buckets_rot")
		type_counts["offset"] = _count_bucket_keys(anim_bank, "buckets_offset")
		type_counts["glow"]   = _count_bucket_keys(anim_bank, "buckets_glow")
		type_counts["spot"]   = _count_bucket_keys(anim_bank, "buckets_spot")

	# --- Playfield animation rows from PlayfieldSlidesManager --------
	var pf_slide_rows: Array = []
	var pf_rot_rows: Array = []
	var pf_scale_rows: Array = []
	
	var pf_mgr: Node = _editor.get_node_or_null("PH_PlayfieldSlides_UNIFIED")
	if pf_mgr == null:
		pf_mgr = _editor.find_child("PH_PlayfieldSlides_UNIFIED", true, false)
	
	if pf_mgr != null:
		if "rows" in pf_mgr:
			var raw_rows = pf_mgr.get("rows")
			if typeof(raw_rows) == TYPE_ARRAY:
				pf_slide_rows = raw_rows
		if "rot_rows" in pf_mgr:
			var raw_rot = pf_mgr.get("rot_rows")
			if typeof(raw_rot) == TYPE_ARRAY:
				pf_rot_rows = raw_rot
		if "scale_rows" in pf_mgr:
			var raw_scale = pf_mgr.get("scale_rows")
			if typeof(raw_scale) == TYPE_ARRAY:
				pf_scale_rows = raw_scale

	# --- Bookmarks (optional) -----------------------------------------
	var bm_path := _get_bookmarks_path()
	var bookmarks: Array = []
	if bm_path != "" and FileAccess.file_exists(bm_path):
		var f := FileAccess.open(bm_path, FileAccess.READ)
		if f != null:
			var txt := f.get_as_text()
			f.close()
			var parsed = JSON.parse_string(txt)
			if typeof(parsed) == TYPE_ARRAY:
				bookmarks = parsed

	# --- Build report text ---------------------------------------------
	var lines: Array = []

	var song_name := ""
	if "current_song" in _editor and _editor.current_song != null:
		var cs = _editor.current_song
		if "title" in cs:
			song_name = str(cs.title)
		elif "song_id" in cs:
			song_name = str(cs.song_id)

	if song_name == "":
		song_name = "(unknown song)"

	var vfx_path := ""
	if mgr.has_method("get"):
		var jp = mgr.get("json_path")
		if typeof(jp) == TYPE_STRING:
			vfx_path = jp

	lines.append("[VFXSummary] =====================================================")
	lines.append("[VFXSummary]  Chart: %s" % song_name)
	if vfx_path != "":
		lines.append("[VFXSummary]  VFX file: %s" % vfx_path)
	lines.append("[VFXSummary] -----------------------------------------------------")
	lines.append("[VFXSummary]  Total notes on timeline: %5d" % total_notes)
	lines.append("[VFXSummary]  Notes with VFX:        %5d (%.1f%%)" % [notes_with_any_vfx, pct_with])
	lines.append("[VFXSummary]  Notes without VFX:     %5d (%.1f%%)" % [notes_without_vfx, pct_without])

	# VFX type section
	if not type_counts.is_empty():
		lines.append("[VFXSummary] -----------------------------------------------------")
		lines.append("[VFXSummary]  By VFX type (from anim_bank.buckets_*):")
		for t in ["color", "scale", "rot", "offset", "glow", "spot"]:
			if type_counts.get(t, 0) > 0:
				lines.append("[VFXSummary]   - %-6s  %3d key(s)" % [t, int(type_counts[t])])


	# Lane section
	if not lane_stats.is_empty():
		lines.append("[VFXSummary] -----------------------------------------------------")
		lines.append("[VFXSummary]  By lane (includes layer 2 variants):")
		for lane_name in _sorted_lane_names(lane_stats.keys()):
			var S: Dictionary = lane_stats[lane_name]
			var t := int(S.get("total", 0))
			var w := int(S.get("with_vfx", 0))
			var pct_lane: float = 0.0
			if t > 0:
				pct_lane = (w * 100.0) / t
			lines.append("[VFXSummary]  %-11s total=%4d  with_vfx=%4d  (%.1f%% of lane)" %
				[lane_name, t, w, pct_lane])

	# Playfield animations section
	if not pf_slide_rows.is_empty() or not pf_rot_rows.is_empty() or not pf_scale_rows.is_empty():
		lines.append("[VFXSummary] -----------------------------------------------------")
		lines.append("[VFXSummary]  Playfield Animations:")
		
		if not pf_slide_rows.is_empty():
			lines.append("[VFXSummary]   $PLAYFIELD (slides): %d segment(s)" % pf_slide_rows.size())
			for i in range(pf_slide_rows.size()):
				var row = pf_slide_rows[i]
				var t0 := _get_row_time(row, "start_time", "t0")
				var t1 := _get_row_time(row, "end_time", "t1")
				var endpoint := _get_row_vec2(row, "endpoint")
				var ease_str := _get_row_string(row, "ease", "linear")
				lines.append("[VFXSummary]     #%d: %s → %s  endpoint=(%.0f,%.0f)  ease=%s" %
					[i + 1, _fmt_time(int(t0)), _fmt_time(int(t1)), endpoint.x, endpoint.y, ease_str])
		
		if not pf_rot_rows.is_empty():
			lines.append("[VFXSummary]   $PF_ROTATE_SEL (rotations): %d segment(s)" % pf_rot_rows.size())
			for i in range(pf_rot_rows.size()):
				var row = pf_rot_rows[i]
				var t0 := _get_row_time(row, "start_time", "t0")
				var t1 := _get_row_time(row, "end_time", "t1")
				var a0 := _get_row_float(row, "a0_deg", "a0", 0.0)
				var a1 := _get_row_float(row, "a1_deg", "a1", 0.0)
				var pivot := _get_row_vec2(row, "pivot_gl_local")
				var ease_str := _get_row_string(row, "ease", "linear")
				lines.append("[VFXSummary]     #%d: %s → %s  angle=%.1f°→%.1f°  pivot=(%.0f,%.0f)  ease=%s" %
					[i + 1, _fmt_time(int(t0)), _fmt_time(int(t1)), a0, a1, pivot.x, pivot.y, ease_str])
		
		if not pf_scale_rows.is_empty():
			lines.append("[VFXSummary]   $PF_SCALE_SEL (scales): %d segment(s)" % pf_scale_rows.size())
			for i in range(pf_scale_rows.size()):
				var row = pf_scale_rows[i]
				var t0 := _get_row_time(row, "start_time", "t0")
				var t1 := _get_row_time(row, "end_time", "t1")
				var s0 := _get_row_float(row, "s0", "s0", 1.0)
				var s1 := _get_row_float(row, "s1", "s1", 1.0)
				var pivot := _get_row_vec2(row, "pivot_gl_local")
				var ease_str := _get_row_string(row, "ease", "linear")
				lines.append("[VFXSummary]     #%d: %s → %s  scale=%.2f→%.2f  pivot=(%.0f,%.0f)  ease=%s" %
					[i + 1, _fmt_time(int(t0)), _fmt_time(int(t1)), s0, s1, pivot.x, pivot.y, ease_str])
	else:
		lines.append("[VFXSummary] -----------------------------------------------------")
		lines.append("[VFXSummary]  Playfield Animations: (none)")

	# Bookmarks section
	lines.append("[VFXSummary] -----------------------------------------------------")
	lines.append("[VFXSummary]  Bookmarks:")

	if bm_path == "" and bookmarks.is_empty():
		lines.append("[VFXSummary]   (no bookmark path resolved)")
	elif not FileAccess.file_exists(bm_path):
		lines.append("[VFXSummary]   file: %s" % bm_path)
		lines.append("[VFXSummary]   (no bookmarks file yet)")
	else:
		lines.append("[VFXSummary]   file: %s" % bm_path)
		lines.append("[VFXSummary]   total:%d" % bookmarks.size())
		for i in range(bookmarks.size()):
			var bm = bookmarks[i]
			if typeof(bm) != TYPE_DICTIONARY:
				continue
			var t_ms := int(bm.get("time_ms", 0))
			var label := String(bm.get("label", ""))
			lines.append("[VFXSummary]   #%d @ %s (%d ms) - %s" %
				[i + 1, _fmt_time(t_ms), t_ms, label])

	lines.append("[VFXSummary] =====================================================")

	# Print to console (still handy)
	for l in lines:
		print(l)

	# Show popup window in the editor
	_show_summary_popup("\n".join(lines))

	return OK


# ========================================================================
# Helper functions
# ========================================================================

func _lane_name_from_note_data(nd: Object) -> String:
	if nd == null or not nd.has_method("get"):
		return ""

	var nt_v = nd.get("note_type")
	if nt_v == null:
		return ""

	var nti := int(nt_v)
	match nti:
		0: return "UP"
		1: return "LEFT"
		2: return "DOWN"
		3: return "RIGHT"
		4, 6: return "SLIDE_LEFT"
		5, 7: return "SLIDE_RIGHT"
		8: return "HEART"
		_: return "UNKNOWN"


func _build_vfx_key_for_note_data(nd: Object) -> String:
	if nd == null or not nd.has_method("get"):
		return ""

	var nt_v = nd.get("note_type")
	var time_v = nd.get("time")
	if nt_v == null or time_v == null:
		return ""

	var nti := int(nt_v)
	var head_t := int(time_v)

	var lname := _lane_name_from_note_data(nd)
	var is_l2 := _guess_is_layer2_from_note(nd)
	var layer_tag := "layer_%s%s" % [lname, ("2" if is_l2 else "")]
	return "%s@%d@%d" % [layer_tag, nti, head_t]


func _guess_is_layer2_from_note(obj: Object) -> bool:
	if obj == null:
		return false

	var lidx = null
	if obj.has_method("get_property_list"):
		for p in obj.get_property_list():
			if String(p.name) == "layer_index":
				lidx = obj.get("layer_index")
				break
	if lidx == null and obj.has_method("get"):
		if "layer_index" in obj:
			lidx = obj.get("layer_index")
	if lidx != null and int(lidx) == 1:
		return true

	var has_flag = null
	if obj.has_method("get_property_list"):
		for p2 in obj.get_property_list():
			if String(p2.name) == "second_layer":
				has_flag = obj.get("second_layer")
				break
	if has_flag == null and obj.has_method("get"):
		if "second_layer" in obj:
			has_flag = obj.get("second_layer")
	if has_flag != null and bool(has_flag):
		return true

	var layer_meta = null
	if obj.has_method("get_property_list"):
		for p3 in obj.get_property_list():
			if String(p3.name) == "layer":
				layer_meta = obj.get("layer")
				break
	if layer_meta == null and obj.has_method("get"):
		if "layer" in obj:
			layer_meta = obj.get("layer")
	if layer_meta != null and String(layer_meta).ends_with("2"):
		return true

	return false


func _count_bucket_keys(bank: Object, bucket_name: String) -> int:
	if bank == null:
		return 0
	if not bank.has_method("get"):
		return 0
	if not (bucket_name in bank):
		return 0

	var dict = bank.get(bucket_name)
	if typeof(dict) != TYPE_DICTIONARY:
		return 0
	return dict.size()


func _sorted_lane_names(keys: Array) -> Array:
	# Preserve a nice human order where possible
	var order := [
		"UP", "DOWN", "LEFT", "RIGHT",
		"SLIDE_LEFT", "SLIDE_RIGHT",
		"HEART", "UNKNOWN"
	]
	var out: Array = []
	for name in order:
		if keys.has(name):
			out.append(name)
	for k in keys:
		if not out.has(k):
			out.append(k)
	return out


func _fmt_time(ms: int) -> String:
	var total_sec := ms / 1000
	var minutes := total_sec / 60
	var seconds := total_sec % 60
	var millis := ms % 1000
	return "%02d:%02d.%03d" % [minutes, seconds, millis]


func _get_bookmarks_path() -> String:
	if _editor == null:
		return "user://editor_scripts/bookmarks_default.json"

	var inj = _editor.get_node_or_null("PH_VFX_MegaInjector")
	if inj == null:
		inj = _editor.find_child("PH_VFX_MegaInjector", true, false)

	if inj != null and inj.has_method("get"):
		var raw = inj.get("json_path")
		if typeof(raw) == TYPE_STRING and raw != "":
			var p: String = raw
			if p.ends_with(".json"):
				p = p.substr(0, p.length() - 5)
			if p.ends_with("_vfx"):
				p = p.substr(0, p.length() - 4)
			return p + "_bookmarks.json"

	# Fallback: global default
	return "user://editor_scripts/bookmarks_default.json"


func _show_summary_popup(text: String) -> void:
	if _editor == null:
		return

	var tree = _editor.get_tree()
	var ui_root: Node = tree.root if tree != null else _editor

	# Reuse / replace an existing dialog if present
	var existing := ui_root.get_node_or_null("PH_VFXSummaryDialog")
	if existing != null and is_instance_valid(existing):
		existing.queue_free()

	var dlg := AcceptDialog.new()
	dlg.name = "PH_VFXSummaryDialog"
	dlg.title = "VFX Summary"
	dlg.min_size = Vector2(720, 480)

	var text_edit := TextEdit.new()
	text_edit.readonly = true
	text_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	text_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_edit.size_flags_vertical = Control.SIZE_EXPAND_FILL
	text_edit.text = text
	text_edit.set_anchors_preset(Control.PRESET_FULL_RECT)

	dlg.add_child(text_edit)
	ui_root.add_child(dlg)

	dlg.confirmed.connect(dlg.queue_free)
	dlg.canceled.connect(dlg.queue_free)

	dlg.popup_centered_ratio(0.7)


# --- Playfield row data extraction helpers ---

func _get_row_time(row, key1: String, key2: String) -> float:
	"""Extract time value from a row object or dictionary."""
	if row == null:
		return 0.0
	
	# Try as object property first
	if typeof(row) == TYPE_OBJECT:
		if key1 in row:
			return float(row.get(key1))
		if key2 in row:
			return float(row.get(key2))
	
	# Try as dictionary
	if typeof(row) == TYPE_DICTIONARY:
		if row.has(key1):
			return float(row[key1])
		if row.has(key2):
			return float(row[key2])
	
	return 0.0


func _get_row_float(row, key1: String, key2: String, default: float) -> float:
	"""Extract float value from a row object or dictionary."""
	if row == null:
		return default
	
	if typeof(row) == TYPE_OBJECT:
		if key1 in row:
			return float(row.get(key1))
		if key2 in row:
			return float(row.get(key2))
	
	if typeof(row) == TYPE_DICTIONARY:
		if row.has(key1):
			return float(row[key1])
		if row.has(key2):
			return float(row[key2])
	
	return default


func _get_row_string(row, key: String, default: String) -> String:
	"""Extract string value from a row object or dictionary."""
	if row == null:
		return default
	
	if typeof(row) == TYPE_OBJECT:
		if key in row:
			return String(row.get(key))
	
	if typeof(row) == TYPE_DICTIONARY:
		if row.has(key):
			return String(row[key])
	
	return default


func _get_row_vec2(row, key: String) -> Vector2:
	"""Extract Vector2 value from a row object or dictionary."""
	if row == null:
		return Vector2.ZERO
	
	if typeof(row) == TYPE_OBJECT:
		if key in row:
			var val = row.get(key)
			if val is Vector2:
				return val
			# Handle array format [x, y]
			if typeof(val) == TYPE_ARRAY and val.size() >= 2:
				return Vector2(float(val[0]), float(val[1]))
	
	if typeof(row) == TYPE_DICTIONARY:
		if row.has(key):
			var val = row[key]
			if val is Vector2:
				return val
			if typeof(val) == TYPE_ARRAY and val.size() >= 2:
				return Vector2(float(val[0]), float(val[1]))
	
	return Vector2.ZERO
