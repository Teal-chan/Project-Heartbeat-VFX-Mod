#meta:name: Manual Playhead Stepper (Backward 5ms)
#meta:description: Decrements the playhead by a fixed number of milliseconds without snapping to the timeline grid.
#meta:usage: Run repeatedly. Never calls _editor.seek(), so it won't snap.

extends ScriptRunnerScript

const STEP_MS := -5                  # exact step size in milliseconds
const END_TARGET_MS := -1            # >= 0 to stop at a specific time; -1 disables

func run_script() -> int:
	if _editor == null:
		printerr("[Stepper±10ms] ❌ No editor found.")
		return ERR_DOES_NOT_EXIST

	var current := int(_editor.playhead_position)
	var song_end_ms := int(_editor.get_song_length() * 1000.0) - 1

	# Always move forward by STEP_MS, ignoring grid
	var next := min(current + STEP_MS, song_end_ms)
	if END_TARGET_MS >= 0:
		next = min(next, END_TARGET_MS)

	# Apply WITHOUT using _editor.seek() to avoid snap
	_editor.playhead_position = next
	_editor.game_playback.seek(next)          # keep EditorPlayback in sync
	_editor.game_preview.set_time(next / 1000.0)  # update visual preview
	_editor.timeline.ensure_playhead_is_visible()
	_editor.emit_signal("playhead_position_changed")

	if END_TARGET_MS >= 0 and next >= END_TARGET_MS:
		_editor._playhead_traveling = false
		print("[Stepper±10ms] 🛑 Reached target at %d ms." % END_TARGET_MS)
	elif next >= song_end_ms:
		_editor._playhead_traveling = false
		print("[Stepper±10ms] 🛑 Reached song end at %d ms." % song_end_ms)

	return OK
