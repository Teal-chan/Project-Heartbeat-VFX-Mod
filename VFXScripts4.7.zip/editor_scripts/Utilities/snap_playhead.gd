#meta:name:Snap playhead to selected note
#meta:description:Moves the editor playhead (seek) to the earliest selected note/time and ensures it is visible on the timeline.
#meta:usage:Select one or more notes, then run.

extends ScriptRunnerScript

func run_script() -> int:
	if _editor == null:
		printerr("[SnapPlayheadToSelection] No editor context.")
		return ERR_DOES_NOT_EXIST
	
	if _editor.selected.is_empty():
		printerr("[SnapPlayheadToSelection] No items selected.")
		return ERR_DOES_NOT_EXIST
	
	var best_time_ms := _get_earliest_selected_time()
	if best_time_ms < 0:
		printerr("[SnapPlayheadToSelection] Could not find a valid time on selected items.")
		return ERR_DOES_NOT_EXIST
	
	# Clamp to song length just in case
	if _editor.current_song:
		var max_ms := int(_editor.get_song_length() * 1000.0)
		best_time_ms = clamp(best_time_ms, 0, max_ms)
	
	# ✅ Use the real seek API if available so everything (audio, preview, etc.) moves.
	if _editor.has_method("seek"):
		_editor.seek(best_time_ms)
	else:
		# Fallback: directly set playhead_position if seek() doesn't exist
		_editor.playhead_position = best_time_ms
	
	# Ask the timeline to bring it into view, if possible
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()
	
	# Nudge the preview game loop if present
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()
	
	print("[SnapPlayheadToSelection] ▶ Seeked to ", best_time_ms, " ms.")
	return OK


func _get_earliest_selected_time() -> int:
	var best := -1
	
	for item in _editor.selected:
		if item == null:
			continue
		
		var t := _get_time_from_item(item)
		if t < 0:
			continue
		
		if best < 0 or t < best:
			best = t
	
	return best


func _get_time_from_item(item: Object) -> int:
	# Most editor items have a "data" object with a "time" property (HBBaseNote, HBTimingPoint, etc.)
	var data = null
	if item.has_method("get"):
		data = item.get("data")
	
	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))
	
	# Fallback: try the item itself
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))
	
	return -1
