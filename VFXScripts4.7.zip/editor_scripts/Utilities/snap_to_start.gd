extends ScriptRunnerScript

#meta:name:Snap Playhead to Selection Start
#meta:description:Moves the playhead to the earliest time in the current selection (requires at least 2 selected items).
#meta:usage:Select 2+ notes/items, then run.

func run_script() -> int:
	if _editor == null:
		printerr("[SnapSelectionStart] No editor context.")
		return ERR_DOES_NOT_EXIST
	
	if _editor.selected.is_empty() or _editor.selected.size() < 2:
		printerr("[SnapSelectionStart] Need at least 2 selected items.")
		if _editor.message_shower:
			_editor.message_shower._show_notification("❌ Need at least 2 selected items.")
		return ERR_DOES_NOT_EXIST
	
	var min_time_ms := _get_selected_time_extremes().x
	if min_time_ms < 0:
		printerr("[SnapSelectionStart] Could not find valid times on selected items.")
		return ERR_DOES_NOT_EXIST

	# Clamp to song length just in case
	if _editor.current_song:
		var max_ms := int(_editor.get_song_length() * 1000.0)
		min_time_ms = clamp(min_time_ms, 0, max_ms)

	# Preferred: editor.seek()
	if _editor.has_method("seek"):
		_editor.seek(min_time_ms)
	else:
		_editor.playhead_position = min_time_ms

	# Keep timeline view in sync if possible
	if "timeline" in _editor and _editor.timeline:
		var tl = _editor.timeline
		if tl.has_method("ensure_playhead_is_visible"):
			tl.ensure_playhead_is_visible()
		elif tl.has_method("queue_redraw"):
			tl.queue_redraw()

	# Nudge preview/game if editor exposes a hook
	if _editor.has_method("force_game_process"):
		_editor.force_game_process()

	print("[SnapSelectionStart] ▶ Seeked to selection start at ", min_time_ms, " ms.")
	if _editor.message_shower:
		_editor.message_shower._show_notification("▶ Playhead → selection start (%d ms)" % min_time_ms)
	return OK


# Returns a Vector2i(min_time_ms, max_time_ms) across selection, or (-1, -1) if none.
func _get_selected_time_extremes() -> Vector2i:
	var min_t := -1
	var max_t := -1

	for item in _editor.selected:
		if item == null:
			continue

		var t := _get_time_from_item(item)
		if t < 0:
			continue

		if min_t < 0 or t < min_t:
			min_t = t
		if max_t < 0 or t > max_t:
			max_t = t

	return Vector2i(min_t, max_t)


func _get_time_from_item(item: Object) -> int:
	# Most editor items have a "data" object with a "time" property (HBBaseNote, HBTimingPoint, etc.)
	var data = null
	if item.has_method("get"):
		data = item.get("data")

	if data != null and data.has_method("get"):
		var t = data.get("time")
		if t != null:
			return int(round(float(t)))

	# Fallback: try the item itself directly
	if item.has_method("get"):
		var t2 = item.get("time")
		if t2 != null:
			return int(round(float(t2)))

	return -1
